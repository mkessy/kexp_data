# Adapted from: https://github.com/telekom/lazy-imports/blob/main/lazy_imports/lazy_imports.py
import importlib
from pathlib import Path
from types import ModuleType
from typing import Any, Dict, Iterable, List, Set


class LazyImporter(ModuleType):
    name: str
    imports: Dict[str, List[str]]
    modules: Set[str]
    names: Dict[str, str]

    def __init__(self, name: str, module_file: str, imports: Dict[str, List[str]]):
        super().__init__(name)
        self.name = name
        self.imports = imports
        self.modules = set(imports.keys())
        self.names = {}
        for key, values in imports.items():
            for value in values:
                self.names[value] = key
        self.__all__ = list(self.modules) + list(self.names.keys())
        self.__file__ = module_file
        self.__path__ = [str(Path(module_file).parent)]

    def __dir__(self) -> Iterable[str]:
        return list(super().__dir__()) + list(self.__all__)

    def __getattr__(self, name: str) -> Any:
        if name in self.names:  # we have a function
            module = self.get_module(self.names[name])
            value = getattr(module, name)
        elif name in self.modules:  # we have a module
            value = self.get_module(name)
        else:
            raise AttributeError(f"module {self.__name__} has no attribute {name}")
        setattr(self, name, value)
        return value

    def __reduce__(self):
        return (self.__class__, (self.name, self.__file__, self.imports))

    def get_module(self, module_name: str) -> ModuleType:
        return importlib.import_module(f".{module_name}", self.__name__)

    def import_all(self) -> None:
        for name in self.names:
            self.__getattr__(name)
