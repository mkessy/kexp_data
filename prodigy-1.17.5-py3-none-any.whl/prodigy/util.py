import base64
import copy
import datetime
import inspect
import mimetypes
import os
import warnings
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Iterable,
    List,
    Optional,
    Tuple,
    Union,
    cast,
)

import catalogue
import murmurhash
import srsly
from cloudpathlib import AnyPath, CloudPath
from confection import registry as confection_registry
from toolz.itertoolz import interleave, partition_all

from ._util import (
    WarnOnlyOnce,
    color,
    deep_merge_dicts,
    get_log_level,
    log,
    msg,
    obfuscate_secret_config,
)
from .env_vars import ENV_VARS
from .errors import ConfigError, ProdigyError, RecipeError
from .protocols import ModelProtocol, PredictProtocol, UpdateProtocol
from .types import (
    PathInputType,
    PathType,
    ScoredStreamType,
    StreamType,
    TaskType,
)

if TYPE_CHECKING:
    from spacy.language import Language


class registry(confection_registry):
    recipes = catalogue.create("prodigy", "recipes", entry_points=False)
    databases = catalogue.create("prodigy", "db", entry_points=True)
    loaders = catalogue.create("prodigy", "loaders", entry_points=True)
    source_loaders = catalogue.create("prodigy", "source_loaders", entry_points=True)
    apis = catalogue.create("prodigy", "apis", entry_points=True)
    example_types = catalogue.create("prodigy", "example_types", entry_points=True)
    metrics = catalogue.create("prodigy", "metrics", entry_points=True)


# Check if Prodigy home exists and if not, create dir and empty config file
_prodigy_home = Path(os.environ.get(ENV_VARS.HOME, Path.home() / ".prodigy"))
if not _prodigy_home.exists():
    _prodigy_home.mkdir()
    _config_file = _prodigy_home / "prodigy.json"
    _config_file.open("w", encoding="utf8").write("{\n\n}")


# fmt: off
PRODIGY_HOME = str(_prodigy_home)
INPUT_HASH_ATTR = "_input_hash"
TASK_HASH_ATTR = "_task_hash"
ANNOTATOR_ID_ATTR = "_annotator_id"
SESSION_ID_ATTR = "_session_id"
VIEW_ID_ATTR = "_view_id"
BINARY_ATTR = "_is_binary"
TIMESTAMP_ATTR = "_timestamp"
PAGE_TITLE_ATTR = "_page_title"
PAGE_NUM_ATTR = "_page"
IGNORE_HASH_KEYS = ("score", "rank", "model", "source", "pattern", "priority", "path", VIEW_ID_ATTR, SESSION_ID_ATTR, ANNOTATOR_ID_ATTR, "answer")
INPUT_HASH_KEYS = ("text", "image", "html", "input")
TASK_HASH_KEYS = ("spans", "label", "options", "arcs")
PAGES_KEYS = ("pages", "page_titles", "config", "meta", "answer")
UNSET = object()
EVAL_PREFIX = "eval:"
# fmt: on

# component-specific defaults
MISSING_VALUE = ""
NEG_PREFIX = "!"
NER_DEFAULT_INCORRECT_KEY = "incorrect_spans"
NER_DEFAULT_BEAM_DENSITY = 0.1
SENT_START_LABEL = "S"
SENT_INSIDE_LABEL = "I"
SPANCAT_DEFAULT_KEY = "sc"
COREF_DEFAULT_PREFIX = "coref_cluster_"
DEFAULT_NLP_BATCH_SIZE = 10
DEFAULT_LLM_BATCH_SIZE = 3


# OpenAI defaults
class OPENAI_DEFAULTS:
    # endpoints #
    COMPLETIONS_ENDPOINT = "https://api.openai.com/v1/completions"

    # prompt paths #
    # fmt: off
    TEMPLATES_DIR = "openai_templates"
    TEXTCAT_PROMPT_PATH = Path(__file__).parent / TEMPLATES_DIR / "textcat_prompt.jinja2"
    NER_PROMPT_PATH = Path(__file__).parent / TEMPLATES_DIR / "ner_prompt.jinja2"
    TERMS_PROMPT_PATH = Path(__file__).parent / TEMPLATES_DIR / "terms_prompt.jinja2"
    # fmt: on

    # html templates #
    TEXTCAT_HTML_TEMPLATE = """
    <div class="cleaned">
    {{ #label }}
        <centering>
        <h2>OpenAI GPT-3 says: {{ meta.answer }}</h2>
        </centering>
    {{ /label }}
    <details>
        <summary>Show the prompt for OpenAI</summary>
        <pre>{{openai.prompt}}</pre>
    </details>
    <details>
        <summary>Show the response from OpenAI</summary>
        <pre>{{openai.response}}</pre>
    </details>
    </div>
    """
    NER_HTML_TEMPLATE = """
    <div class="cleaned">
    <details>
        <summary>Show the prompt for OpenAI</summary>
        <pre>{{openai.prompt}}</pre>
    </details>
    <details>
        <summary>Show the response from OpenAI</summary>
        <pre>{{openai.response}}</pre>
    </details>
    </div>
    """


class LLM_DEFAULTS:
    # html templates #
    TEXTCAT_HTML_TEMPLATE = """
    <div class="cleaned">
    {{ #label }}
        <centering>
        <h2>LLM Answer: {{ llm.response }}</h2>
        </centering>
    {{ /label }}
    <details>
        <summary>Show the prompt sent to LLM</summary>
        <pre>{{llm.prompt}}</pre>
    </details>
    <details>
        <summary>Show the response from the LLM</summary>
        <pre>{{llm.response}}</pre>
    </details>
    </div>
    """
    NER_HTML_TEMPLATE = """
    <div class="cleaned">
    <details>
        <summary>Show the prompt sent to LLM</summary>
        <pre>{{llm.prompt}}</pre>
    </details>
    <details>
        <summary>Show the response from the LLM</summary>
        <pre>{{llm.response}}</pre>
    </details>
    </div>
    """


def hashes_missing(example: Dict):
    """True if either input/task hash is missing"""
    return (INPUT_HASH_ATTR not in example) or (TASK_HASH_ATTR not in example)


# This object can check if a warning is the first warning
MISSING_HASHES_WARNING_KEY = "hashes_missing"
first_warning = WarnOnlyOnce()


def get_timestamp_session_id() -> str:
    """Get a new timestamp-based session ID.

    RETURNS (str): The current timestamp, up to seconds.
    """
    return f"{datetime.datetime.now():%Y-%m-%d_%H-%M-%S}"


def set_hashes(
    task: TaskType,
    input_keys: Iterable[str] = INPUT_HASH_KEYS,
    task_keys: Iterable[str] = TASK_HASH_KEYS,
    ignore: Iterable[str] = IGNORE_HASH_KEYS,
    overwrite: bool = False,
) -> TaskType:
    """Set hash IDs on a task based on the task properties. If the task is paginated,
    hashes are set on each page, and the hashes for the whole task are computed
    based on the input and task hashes of the pages.

    task (dict): The task to set hashes on.
    input_keys (tuple): The task keys to consider for the input hash.
    task_keys (tuple): The task keys to consider for the task hash.
    overwrite (bool): Overwrite existing hashes.
    RETURNS (dict): The task with hashes set.
    """
    task = dict(task)
    if "pages" in task:
        task["pages"] = [
            set_hashes(
                p,
                input_keys=input_keys,
                task_keys=task_keys,
                ignore=ignore,
                overwrite=overwrite,
            )
            for p in task["pages"]
        ]
        hashes = {
            "input_hashes": [p[INPUT_HASH_ATTR] for p in task["pages"]],
            "task_hashes": [p[TASK_HASH_ATTR] for p in task["pages"]],
        }
        task[INPUT_HASH_ATTR] = get_hash(hashes, ["input_hashes"])
        task[TASK_HASH_ATTR] = get_hash(hashes, ["task_hashes"])
        return task
    else:
        if overwrite or INPUT_HASH_ATTR not in task:
            task[INPUT_HASH_ATTR] = get_hash(task, input_keys, ignore=ignore)
        if overwrite or TASK_HASH_ATTR not in task:
            task[TASK_HASH_ATTR] = get_hash(
                task, task_keys, task[INPUT_HASH_ATTR], ignore=ignore
            )
        return task


def get_hash(
    task: TaskType,
    keys: Iterable[str],
    prefix: str = "",
    *,
    ignore: Iterable[str] = IGNORE_HASH_KEYS,
) -> int:
    """Get hash for a task based on task keys.

    task (dict): The task to hash.
    keys (tuple): The keys to include.
    prefix (str): Optional prefix to add. For task hashes, they input hash
        is used as the prefix.
    ignore (list): Optional list of keys to ignore. The hash will be insensitive
        to the presence and values of the ignored keys, anywhere in the object.
        Defaults to ('score', 'rank', 'model').
    RETURNS (str): The hash.
    """
    # renamed because implicit conversion to TaskType would fail
    filtered_task = _filter_keys(task, set(ignore))
    assert isinstance(filtered_task, dict)
    values = [
        f"{key}={srsly.json_dumps(filtered_task[key], sort_keys=True)}"
        for key in keys
        if key in filtered_task
    ]
    values = "".join(values)
    if not values:
        values = srsly.json_dumps(filtered_task, sort_keys=True)
    values = str(prefix) + values
    hash_ = murmurhash.hash(values)
    return hash_


def _filter_keys(
    task: Union[TaskType, List[TaskType]], ignored: Iterable[str]
) -> Union[TaskType, List[TaskType]]:
    """Remove certain keys from a dictionary, recursively."""
    if isinstance(task, list):
        filtered_examples: List[TaskType] = [
            cast(TaskType, _filter_keys(value, ignored)) for value in task
        ]
        return filtered_examples
    elif isinstance(task, dict):
        return {
            key: _filter_keys(value, ignored)
            for key, value in task.items()
            if key not in ignored
        }
    else:
        return task


def get_task_hashes(tasks: Iterable[TaskType]) -> List[int]:
    """Get a list of all task hashes for a list of task.

    tasks (iterable): The tasks to get hashes for.
    RETURNS (list): The task hashes.
    """
    hashes = [eg[TASK_HASH_ATTR] for eg in tasks if TASK_HASH_ATTR in eg]
    return hashes


def ensure_path(file_path: PathInputType) -> PathType:
    if isinstance(file_path, str):
        path = AnyPath(file_path)
        assert isinstance(path, (Path, CloudPath))
        return path
    return file_path


def resolve_labels(
    user_labels: List[str], nlp_labels: List[str], spacy_llm: bool = False
) -> List[str]:
    """Resolves the user_labels vs. nlp labels

    user_labels (list): The labels provided by the user
    nlp_labels (list): The labels provided by the pipeline
    RETURNS (list): The relevant labels, assuming no error had to be raised
    """
    if user_labels:
        missing_labels = set(user_labels).difference(set(nlp_labels))
        if missing_labels:
            err_msg = f"Requested labels: {','.join(missing_labels)} not found in the pipeline labels: {','.join(nlp_labels)}. "
            if spacy_llm:
                err_msg += "Please cross-check the labels used in spacy-llm config file and the labels provided via --labels argument."
            msg.fail(
                err_msg,
                exits=True,
            )
        return user_labels
    return nlp_labels


def get_labels(
    labels_data: Optional[str], *args  # *args for backwards compatibility
) -> List[str]:
    """Create a list of labels from string or path. Used as a helper to
    resolve the command line input of the `--label` argument in manual
    annotation recipes that require passing in a label set. If `labels_data` is
    a path, it's expected to be a text file with one label per line and read in
    accordingly. Otherwise, it's expected to be a string of comma-separated
    labels and will be split.

    labels_data (str): The labels, either string path, string or None.
    RETURNS (set): The label set.
    """
    # TODO: After v2, this function should get replaced by the `get_pipe_labels` function.
    if not labels_data:
        return []
    if len(labels_data) < 256:  # checking for path will fail otherwise
        labels_path = Path(labels_data)
        if labels_path.is_file():
            labels = [t for t in read_txt(labels_path) if t != ""]
            msg.text(f"Using {len(labels)} label(s) from {labels_path}")
            return labels
    labels = [t.strip() for t in labels_data.split(",") if t != ""]
    msg.text(f"Using {len(labels)} label(s): {', '.join(labels)}")
    return labels


def get_pipe_labels(
    labels: Optional[List[str]], pipe_labels: List[str], allow_new: bool = True
) -> List[str]:
    if not labels and not pipe_labels:
        raise RecipeError("No --label argument set and no labels found in model")
    if not labels:
        msg.text(
            f"Using {len(pipe_labels)} labels from model: {', '.join(pipe_labels)}"
        )
        return pipe_labels
    new_labels = [label for label in labels if label not in pipe_labels]
    if new_labels and not allow_new:
        err = "Can't annotate labels that are not already in model"
        raise RecipeError(err, ", ".join(new_labels))
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    return labels


def convert_labels(labels_data: Optional[PathInputType]) -> List[str]:
    """Create a list of labels from string or path. Used as a helper to
    resolve the command line input of the `--label` argument in manual
    annotation recipes that require passing in a label set. If `labels_data` is
    a path, it's expected to be a text file with one label per line and read in
    accordingly. Otherwise, it's expected to be a string of comma-separated
    labels and will be split.

    labels_data (str): The labels, either string path, string or None.
    RETURNS (set): The label set.
    """
    labels = []
    if not labels_data:
        return []
    labels_data = str(labels_data)
    if len(labels_data) < 256:  # checking for path will fail otherwise
        labels_path = ensure_path(labels_data)
        if labels_path.is_file():
            labels = [t for t in read_txt(labels_path) if t != ""]
            msg.text(f"Using {len(labels)} label(s) from {labels_path}")
            return labels
    labels = [t.strip() for t in labels_data.split(",") if t != ""]
    msg.text(f"Using {len(labels)} label(s): {', '.join(labels)}")
    return labels


def split_string(text: str) -> List[str]:
    """Split a string on commas. Mostly as a converter function in CLI argument
    annotation to convert comma-separated lists of labels.

    text (str): The text to split.
    RETURNS (list): The split text or empty list if text is falsy.
    """
    if not text:
        return []
    return [t.strip() for t in text.split(",")]


def handle_cli_error(err: ProdigyError) -> int:
    msg.fail(err.title, err.text)
    return 1


def convert_blob(blob: Union[bytes, memoryview]) -> bytes:
    """Helper to convert blob fields in DB (bytea in PostgreSQL). blob (bytes / bytea): The blob to convert. RETURNS (bytes): The blob as bytes."""
    if hasattr(blob, "tobytes"):
        blob = cast(memoryview, blob).tobytes()
    return blob


def read_txt(file_path: PathInputType) -> List[str]:
    """Read a .txt file line by line.

    file_path (str / Path): The file path.
    RETURNS (list): A list of strings containing the stripped lines.
    """
    path = ensure_path(file_path)
    with path.open("r", encoding="utf8") as txt_file:
        return [line.strip() for line in txt_file]


def get_mimetype(file_path: PathInputType) -> str:
    """Guess mimetype of a file using the mimetypes.guess_type function. Mostly
    used for converting image files to base64-encoded data URIs.

    file_path (str / Path): The file path.
    RETURNS (str): The guessed mimetype.
    """
    file_path = str(file_path)
    mime, _ = mimetypes.guess_type(file_path)
    if not mime:
        mime = "Unknown"
    return mime


def file_to_b64(file_path: PathInputType, mimetype: Optional[str] = None) -> str:
    """Read in a file and return converted base64 data URI.

    file_path (str / Path): The file path.
    mimetype (str): Optional mimetype. If not set, it's guessed using the
        get_mimetype helper.
    RETURNS (str): The base64-encoded data URI.
    """
    if not mimetype:
        mimetype = get_mimetype(file_path)
    file_path = ensure_path(file_path)
    with file_path.open("rb") as f:
        data = f.read()
        return bytes_to_b64(data, mimetype)


def bytes_to_b64(data: bytes, mimetype: str) -> str:
    """Convert bytes data to a base64-encoded data URI.

    data (bytes): The data.
    mimetype (str): The mimetype.
    RETURNS (str): The base64-encoded data URI.
    """
    encoded = base64.encodebytes(data).splitlines()
    data64 = "".join([b.decode("utf8") for b in encoded])
    return f"data:{mimetype};base64,{data64}"


def b64_to_bytes(data_uri: str) -> bytes:
    """Convert a base64-encoded data URI to bytes. Mostly used for images.

    data_uri (str): The data URI to convert.
    RETURNS (bytes): The image data.
    """
    data = data_uri.split("base64,", 1)[1]
    return base64.decodebytes(bytes(data, "ascii"))


def get_display_name(func: Callable) -> str:
    """Get a human-readable display name for functions, classes etc. Currently
    mostly used to provide display names for custom database components. Checks
    the function's __name__ and __class__ and defaults to `repr(func)`.

    func (callable): The function.
    RETURNS (str): A human-readable display name.
    """
    if hasattr(func, "__name__"):
        return func.__name__
    if hasattr(func, "__class__") and hasattr(func.__class__, "__name__"):
        return func.__class__.__name__
    return repr(func)


def deprecated(message: str, filter: str = "always", depth: int = 2) -> None:
    """Show a deprecation warning.

    message (str): The message to display.
    filter (str): Filter value.
    depth (int): Stack depth.
    """
    stack = inspect.stack()[depth]
    with warnings.catch_warnings():
        warnings.simplefilter(filter, DeprecationWarning)  # type: ignore (it requires warnings internal _ActionType type, triggers default filter if there's no match)
        warnings.warn_explicit(message, DeprecationWarning, stack[1], stack[2])


def get_valid_sessions() -> Optional[List[str]]:
    """Return the valid list of session ids that prodigy session should recognize, or None
    if there are no restrictions."""
    sessions = os.environ.get(ENV_VARS.ALLOWED_SESSIONS, None)
    if sessions is None:
        return None
    sessions = sessions.replace('"', "")
    sessions = sessions.replace("'", "")
    sessions = [s.strip() for s in sessions.split(",") if s != ""]
    return sessions


def ensure_component(nlp: "Language", name: str) -> "Language":
    if name not in nlp.pipe_names:
        raise RecipeError(
            f"No component '{name}' found in pipeline (missing or disabled)",
            f"Available enabled names: {nlp.pipe_names}",
        )
    return nlp


def load_spacy_model(spacy_model: str) -> "Language":
    import spacy

    nlp = spacy.load(spacy_model)
    log(f"RECIPE: Loaded model {spacy_model}")
    return nlp


def copy_nlp(nlp: "Language") -> "Language":
    from spacy.vectors import Vectors

    vectors = nlp.vocab.vectors
    nlp.vocab.vectors = Vectors()
    orig_nlp = copy.deepcopy(nlp)
    nlp.vocab.vectors = vectors
    orig_nlp.vocab.vectors = vectors
    return orig_nlp


def is_neg_label(label: str) -> bool:
    """Whether a label is a negated label."""
    return label.startswith(NEG_PREFIX)


def neg_to_pos_label(label: str) -> str:
    """Convert a negated label to a regular label."""
    return label[len(NEG_PREFIX) :]


def pos_to_neg_label(label: str) -> str:
    """Convert a label to a negated label."""
    return f"{NEG_PREFIX}{label}"


def combine_models(
    one: Union[ModelProtocol, Tuple[PredictProtocol, UpdateProtocol]],
    two: Union[ModelProtocol, Tuple[PredictProtocol, UpdateProtocol]],
    batch_size: int = 32,
) -> Tuple[PredictProtocol, UpdateProtocol]:
    """Combine two models and return a predict and update function. Predictions
    of both models are combined using the toolz.interleave function. Mostly
    used to combine an EntityRecognizer with a PatternMatcher.

    one Union(callable, Tuple(callable, callable)): The first model object (requires a `__call__` and `update` method) or a tuple of the `predict` and `update` methods of the first model.
    two Union(callable, Tuple(callable, callable)): The second model object (requires a `__call__` and `update` method) or a tuple of the `predict` and `update` methods of the second model.
    batch_size (int): The batch size to use for predicting the stream.
    RETURNS (tuple): A `(predict, update)` tuple of the respective functions.
    """
    if isinstance(one, tuple):
        one_predict, one_update = one
    else:
        one_predict, one_update = one, one.update

    if isinstance(two, tuple):
        two_predict, two_update = two
    else:
        two_predict, two_update = two, two.update

    def predict(stream: StreamType) -> ScoredStreamType:
        for batch in partition_all(batch_size, stream):
            batch = list(batch)
            stream1 = one_predict(iter(batch))
            stream2 = two_predict(iter(batch))
            yield from interleave((stream1, stream2))

    def update(examples: List[TaskType]) -> float:
        upd1 = one_update(examples)
        upd2 = two_update(examples)
        loss = (upd1 or 0.0) + (upd2 or 0.0)
        return loss

    return predict, update


def load_config_json(path: Union[str, Path]) -> Dict[str, Any]:
    """Load a config file from a path and handle errors.

    path (str / Path): The path to the config file.
    RETURNS (dict): The loaded config.
    """
    config = {}
    try:
        config = srsly.read_json(path)
    except ValueError:
        raise ConfigError(
            f"Couldn't load config from {path}"
            "Make sure the file has the correct format and doesn't contain invalid JSON",
        )
    return cast(Dict[str, Any], config)


def get_config() -> Dict[str, Any]:
    """Get config from Prodigy home and current working directory and merge it.

    RETURNS (dict): The configuration settings.
    """
    home_config_path = Path(PRODIGY_HOME) / "prodigy.json"
    env_config = os.environ.get(ENV_VARS.CONFIG)
    global_config = {}
    local_config = {}
    if env_config:
        env_config_path = Path(env_config)
        if not env_config_path.exists():
            err = f"Can't find config file provided via {ENV_VARS.CONFIG} env var"
            raise ConfigError(err, env_config)
        log(
            f"CONFIG: Using config from {ENV_VARS.CONFIG} env var",
            env_config_path,
            only_once=True,
        )
        global_config = load_config_json(env_config_path)
    elif home_config_path.exists():
        log(
            "CONFIG: Using config from global prodigy.json",
            home_config_path,
            only_once=True,
        )
        global_config = load_config_json(home_config_path)
    for filename in [".prodigy.json", "prodigy.json"]:
        cwd_path = Path.cwd() / filename
        if cwd_path.exists():
            log("CONFIG: Using config from working dir", cwd_path, only_once=True)
            local_config = load_config_json(cwd_path)
            break
    overrides = parse_env_overrides()
    return merge_configs(global_config, local_config, overrides)


def parse_env_overrides() -> Dict[str, Any]:
    """Parse config overrides provided by environment variable.

    RETURNS (dict): The parsed config overrides.
    """
    env_string = os.environ.get(ENV_VARS.CONFIG_OVERRIDES, "{}")
    err = f"Can't load overrides from env variable {ENV_VARS.CONFIG_OVERRIDES}"
    overrides = {}
    try:
        overrides = srsly.json_loads(env_string)
    except ValueError:
        err = f"{err}: invalid JSON. Make sure to use double quotes in your overrides."
        raise ConfigError(err, env_string)
    if not isinstance(overrides, dict):
        raise ConfigError(f"{err}: not a dictionary", str(overrides))
    return cast(Dict[str, Any], overrides)


def merge_configs(
    config: Dict[str, Any], local_config: Dict[str, Any], overrides: Dict[str, Any]
) -> Dict[str, Any]:
    """Merge the global and local config and add optional overrides. Exists as a
    helper function to make it easier to test functionality independently.

    config (dict): The global config (e.g. from prodigy.json).
    local_config (dict): The local config in the current working directory that
        overrides global config settings.
    overrides (dict): Config overrides provided via the CLI.
    RETURNS (dict): The final merged config.
    """
    if local_config:
        config = deep_merge_dicts(config, local_config)
    if overrides:
        obfs_overrides = obfuscate_secret_config(overrides)
        log("CONFIG: Merging config from CLI overrides", obfs_overrides)
        config = deep_merge_dicts(config, overrides)
    return config


def add_global_config(
    global_config: Dict[str, Any], config: Dict[str, Any]
) -> Dict[str, Any]:
    """Merge an existing config (recipe config) with the global/local config
    and warn for problems. Modifies config in place and returns it.
    Warnings are used to address potential problems like this one:
    https://support.prodi.gy/t/2788/4

    global_config (dict): The global configuration in the prodigy.json.
    config (dict): The "config" returned by a recipe.
    RETURNS (dict): The modified config with the added global config.s
    """
    # fmt: off
    warn_keys = ["feed_overlap", "diff_style", "html_template", "javascript",
                 "global_css", "card_css", "javascript_files", "global_css_files",
                 "card_css_files", "writing_dir", "choice_style", "labels",
                 "blocks", "exclude_by", "keymap", "keymap_by_label"]
    # fmt: on
    for key in warn_keys:
        if key in config and key in global_config and config[key] != global_config[key]:
            msg.warn(
                f"Config setting '{key}' defined in recipe is overwritten by "
                f"a different value set in the global or local prodigy.json. "
                f"This may lead to unexpected results and potentially changes "
                f"to the core behavior of the recipe. If that's surprising, you "
                f"should probably remove the setting '{key}' from your prodigy.json."
            )
    return deep_merge_dicts(config, global_config)


__all__ = [
    "color",
    "get_config",
    "merge_configs",
    "add_global_config",
    "log",
    "get_log_level",
    "msg",
]
