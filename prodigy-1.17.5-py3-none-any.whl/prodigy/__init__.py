import logging
import sys
from typing import TYPE_CHECKING

from .about import __version__
from .env_vars import get_log_level
from .lazy_imports import LazyImporter
from .protocols import ControllerComponentsDict


class ServerErrorFilter(logging.Filter):
    # uvicorn logs all errors using its logger and includes the tracebacks. This
    # means that if Prodigy raises a custom error, it's almost hidden because
    # it's followed by a giant traceback. Disabling error logs isn't viable
    # either, because that'd mean the user would never see server errors. This
    # filter works around that by raising the underlying exception (unless it's
    # a system exit caused by our own custom messages).
    def filter(self, rec):
        if rec.levelno == logging.ERROR and rec.exc_info:
            if rec.exc_info[0] != SystemExit:
                raise rec.exc_info[1]
            return False
        return True


# Apply our own logging level to relevant third-party loggers
# TODO: find better solution for this
THIRD_PARTY_LOGGERS = ["fastapi", "uvicorn.error", "uvicorn.access", "uvicorn.asgi"]
log_level = get_log_level()
for logger_name in THIRD_PARTY_LOGGERS:
    logging.getLogger(logger_name).setLevel(log_level)
# Workaround for errors caught by uvicorn
uvicorn_error_logger = logging.getLogger("uvicorn.error")
uvicorn_error_logger.addFilter(ServerErrorFilter())

# Lazy imports
imports = {
    "core": ["get_recipe", "recipe", "set_recipe"],
    "protocols": ["ControllerComponentsDict"],
    "util": ["get_config", "log", "msg", "set_hashes"],
    "cli": ["serve"],
    "components.loaders": ["get_loader", "get_stream"],
    "components.validate": ["get_schema"],
}
lazy_imports = LazyImporter(__name__, globals()["__file__"], imports)

if TYPE_CHECKING:
    lazy_imports.import_all()
else:
    sys.modules[__name__] = lazy_imports

__all__ = ["__version__", "ControllerComponentsDict", *lazy_imports.__all__]  # type: ignore
