import copy
from collections.abc import Mapping
from dataclasses import MISSING, Field, asdict, dataclass, fields, is_dataclass
from enum import Enum
from inspect import isclass
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    ClassVar,
    Dict,
    Iterable,
    Iterator,
    List,
    Optional,
    Set,
    Tuple,
    Type,
    Union,
    cast,
)
from typing_extensions import (
    Literal,
    Self,
    TypeVar,
    dataclass_transform,
    get_args,
    get_origin,
)

import pydantic

try:
    from pydantic import model_validator

    pre_validator = model_validator(mode="before")
except ImportError:
    from pydantic import root_validator

    pre_validator = root_validator(pre=True)

import typeguard
from typeguard import TypeCheckError

from .components.validate import ValidationErrorMsg, get_validation_error_msg
from .errors import ProdigyError
from .types import (
    AudioSpan,
    ChoiceOption,
    ImageSpan,
    Relation,
    TaskType,
    TextManualSpan,
    TextSpan,
    Token,
)
from .util import (
    IGNORE_HASH_KEYS,
    INPUT_HASH_ATTR,
    TASK_HASH_ATTR,
    get_hash,
    registry,
)

if TYPE_CHECKING:
    from .components.db import Database


_ExampleT = TypeVar("_ExampleT", bound="Example", default="Example")


@dataclass_transform()
def prodigy_example_type(name: str) -> Callable[[Type[_ExampleT]], Type[_ExampleT]]:
    """Decorator for a new Custom Prodigy Type.
    Registers the type in the example_types registry, sets its registered
    name to the __catalogue_name__ ClassVar, and ensures the top
    level type is a dataclass.
    NOTE: we can always wrap in a dataclass without errors even if the
    user manually decorates their type with a dataclass as well as this
    decorator.
    """

    def wrapper(cls: Type[_ExampleT]) -> Type[_ExampleT]:
        cls = cast(Type[_ExampleT], dataclass(cls))
        cls.__catalogue_name__ = name
        registry.example_types.register(name, func=cls)
        return cls

    return wrapper


class StructuredExampleError(ProdigyError):
    ...


class ValidationError(StructuredExampleError):
    def __init__(
        self,
        errors: List[ValidationErrorMsg],
        data: Optional[Dict[str, Any]] = None,
        base_msg: str = "Prodigy Structured Type ValidationError",
    ):
        self.errors = errors
        self.data = data
        self.msg = get_validation_error_msg(errors, base_msg)

    def __str__(self) -> str:
        return f"\n{self.msg}"

    @classmethod
    def check_key(
        cls,
        key: str,
        type_: Type,
        default: Any,
        data: Dict[str, Any],
    ) -> Optional[Self]:
        if key not in data:
            if default == MISSING:
                return cls.from_missing(key)
            else:
                value = copy.deepcopy(default)
        else:
            value = data[key]
        return cls.check_type(value, type_, key=key)

    @classmethod
    def check_type(cls, value: Any, type_: Type, *, key: str) -> Optional[Self]:
        try:
            typeguard.check_type(value=value, expected_type=type_)
        except TypeCheckError as e:
            return cls.from_TypeGuardError(e, key)
        else:
            return None

    @classmethod
    def from_TypeGuardError(cls, e: TypeCheckError, key: str) -> Self:
        return cls([ValidationErrorMsg(loc=(key,), msg=str(e))])

    @classmethod
    def from_msg(cls, msg: str, key: Optional[str] = None) -> Self:
        loc = (key,) if key is not None else tuple()
        return cls([ValidationErrorMsg(loc=loc, msg=msg)])

    @classmethod
    def from_missing(cls, key: str) -> Self:
        return cls.from_msg("missing, field required", key)

    @classmethod
    def from_list(cls, errors: List[Self], data: Dict[str, Any]) -> Self:
        flattened_errors = []
        for error in errors:
            flattened_errors += error.errors
        return cls(flattened_errors, data=data)


class MissingAnswerError(StructuredExampleError):
    def __init__(self, data: Dict[str, Any], example_type: Type[_ExampleT]):
        self.data = data
        self.example_type = example_type
        self.msg = (
            "Failed to parse unstructured example into Structured Example. Structured Examples with 'user_anns' "
            "set require 'answer' to be set in the example data.\n"
            "Either ensure an 'answer' is set or use: "
            f"{example_type.__name__}.from_unst_server(data) instead."
        )


class MissingInputError(StructuredExampleError):
    def __init__(
        self, data: Dict[str, Any], example_type: Type[_ExampleT], input_keys: Set[str]
    ):
        self.data = data
        self.example_type = example_type
        self.msg = (
            "Failed to parse unstructured example into Structured Example.\n"
            "Structured Examples require at least 1 key as 'input' "
            "when converting from unstructured data but found 0.\n"
            "This can happen when trying to convert invalid data or when the keys passed as "
            "`input_keys` do not exist in the unstructured example data.\n"
            f"input_keys: {input_keys}\n"
        )


class ConflictingKeysError(StructuredExampleError):
    def __init__(
        self,
        example_type: Type[_ExampleT],
        input_keys: Set[str],
        overlap_keys: Set[str],
    ):
        self.example_type = example_type
        self.input_keys = input_keys
        self.overlap_keys = overlap_keys

        self.msg = (
            "Failed to parse unstructured example into Structured Example. "
            "Conflicting keys between `input_keys` and annotation keys. "
            "Ensure there is no overlap between the `input_keys` and "
            "`server_ann_keys`/`user_ann_keys` arguments.\n"
            f"\tConflicting Keys: {overlap_keys}"
        )


class TypeGuardPydanticError(TypeCheckError):
    @classmethod
    def from_error(cls, e: pydantic.ValidationError):
        err_msg = "is invalid because of a Pydantic Validation Error.\n" + str(e)
        return cls(err_msg)


@prodigy_example_type("prodigy.example_types.BaseExample.v1")
class Example:
    """The base class for Prodigy Structured Examples.
    All Structured Examples should inherit from Example.
    """

    input_hash: int
    task_hash: int
    input: Dict[str, Any]
    meta: Dict[str, Any]
    extras: Dict[str, Any]
    answer: Optional[Literal["accept", "reject", "ignore"]]
    server_anns: Optional[Dict[str, Any]]
    user_anns: Optional[Dict[str, Any]]

    __catalogue_name__: ClassVar[str]
    input_keys: ClassVar[Optional[List[str]]] = None
    server_ann_keys: ClassVar[Optional[List[str]]] = None
    user_ann_keys: ClassVar[Optional[List[str]]] = None

    @classmethod
    def get_fields(
        cls, include: Optional[Set[str]] = None, exclude: Optional[Set[str]] = None
    ) -> Tuple[Field]:
        """Get the underlying Dataclass Fields. Use the include and exclude arguments
        to get only a subset of the fields.
        include (Optional[Set[str]]): Field names to include, defaults to all
        exclude (Optional[Set[str]]): Field names to exclude, defaults to None
        RETURNS (Tuple[Field]): Tuple of dataclass fields
        """
        flds = fields(cls)
        if include is not None and exclude is not None:
            ints = include.intersection(exclude)
            if ints is not None:
                raise ValueError(
                    "include and exclude parameters have overlapping field names", ints
                )
        if include:
            flds = [f for f in flds if f.name in include]
        if exclude:
            flds = [f for f in flds if f.name not in exclude]
        return tuple(flds)

    @classmethod
    def get_field(cls, field_name: str) -> Field:
        """Get one of the dataclass fields by its name.
        If the Field name does not exist, raises a ValueError
        field_name (str): Field name
        RAISES (ValueError): if the field name does not exist for this class
        RETURNS: (Field): Returns the dataclass Field for the provided field_name
        """
        fields_map = {f.name: f for f in cls.get_fields()}
        if field_name not in fields_map:
            raise ValueError(f"Field {field_name} not found in class {cls.__name__}")
        return fields_map[field_name]

    @classmethod
    def get_field_type(cls, field_name: str) -> Type:
        """Gets the type of one of the Example's dataclass fields
        by its name.
        field_name (str): Field name
        RETURNS (Type): The type associated with this Field
        """
        return cls.get_field(field_name).type

    @classmethod
    def get_validation_errors(
        cls,
        data: Dict[str, Any],
        include: Optional[Set[str]] = None,
        exclude: Optional[Set[str]] = None,
    ) -> Iterator[ValidationError]:
        """Get all ValidationErrors for the provided data.
        Called internally by default in `cls.from_dict`.

        data (Dict[str, Any]): Dict of input data to validate
        include (Optional[Set[str]]): Field names to include in validation, defaults to all
        exclude (Optional[Set[str]]): Field names to exclude from validation, defaults to None
        YIELDS: (Iterator[ValidationError]): Yields ValidationError objects
            so users can raise errors early if there are multiple
        """
        for field in cls.get_fields(include=include, exclude=exclude):
            maybe_error = ValidationError.check_key(
                field.name, field.type, field.default, data
            )
            if maybe_error is not None:
                yield maybe_error

    @classmethod
    def raise_validation_errors(
        cls,
        data: Dict[str, Any],
        include: Optional[Set[str]] = None,
        exclude: Optional[Set[str]] = None,
    ) -> None:
        """Raises a ValidationError from a list of errors
        returned by consuming the `cls.get_validation_errors` generator

        data (Dict[str, Any]): Dict of input data to validate
        to get only a subset of the fields.
        include (Optional[Set[str]]): Field names to include in validation, defaults to all
        exclude (Optional[Set[str]]): Field names to exclude from validation, defaults to None
        RAISES (ValidationError): Outer validation error from list of errors
        """
        errors = list(cls.get_validation_errors(data, include=include, exclude=exclude))
        if errors:
            raise ValidationError.from_list(errors, data)

    @classmethod
    def resolve_missing_input(
        cls, data: Dict[str, Any], db: Optional["Database"]
    ) -> Dict[str, Any]:
        """If the 'input' key is missing from the dict, retrieve it from the database, using the task
        hash. Otherwise, return the value present in the dict.
        """
        if db is None:
            # TODO: Make this a more specific error class I guess. Improve message.
            raise ValueError("'input' is missing from data, and no db provided")
        elif "input_hash" not in data:
            # TODO: Make this a more specific error class I guess. Improve message.
            raise ValueError("'input_hash' is missing from data")
        return _resolve_input(db, data["input_hash"])

    @classmethod
    def from_dict(
        cls: Type[Self], data: Dict[str, Any], db: Optional["Database"] = None
    ) -> Self:
        """Main entrypoint for deserialization and creating a Structured Example.
        Responsible for
        1. Validate incoming data for required attrs and correct types
        2. Resolve missing input from the Database if only `input_hash` is provided
        3. Validate the resolved input by itself to identify any type errors
        4. Resolves any custom Pydantic model subtypes for each of the `input`,
            `user_anns`, `server_anns`, and `meta` fields.

        data (Dict[str, Any]): Dict of input data
        include (Optional[Set[str]]): Field names to include in validation, defaults to all
        exclude (Optional[Set[str]]): Field names to exclude from validation, defaults to None
        db (Optional[Database]): Optional Prodigy Database instance
            to resolve missing input with. Not required if `input` provided directly

        RETURNS (_ExampleT): Instance of class with validated, resolved data.
        """
        cls.raise_validation_errors(data, exclude={"input", "input_hash", "task_hash"})
        data = dict(data)
        if "input" not in data:
            data["input"] = cls.resolve_missing_input(data, db)
        if "input_hash" not in data:
            input_dict = _attr_to_dict(data["input"])
            input_hash = get_hash(input_dict, keys=input_dict.keys())
            data["input_hash"] = input_hash
        if "task_hash" not in data:
            task_dict = _attr_to_dict(data["server_anns"])
            task_hash = get_hash(
                task_dict, keys=task_dict.keys(), prefix=str(data["input_hash"])
            )
            data["task_hash"] = task_hash
        cls.raise_validation_errors(data, include={"input", "input_hash", "task_hash"})
        for field in ("input", "user_anns", "server_anns", "meta"):
            data[field] = cls._resolve_subtype_value(data[field], field)
        return cls(**data)

    @classmethod
    def _resolve_subtype_value(cls, value: Any, field_name: str) -> Any:
        """Resolves a value in the provided data to `from_dict`
        to a custom class if possible. By default, Pydantic models
        are supported and this will try to resolve a dict of data
        into an instance of the model provided on the Example subclass.

        value (Any): The value for the current field
        field_name (str): field name

        RETURNS (Any): The resolved value
        """
        field_type = cls.get_field_type(field_name)
        if value is None:
            return None
        if isclass(field_type) and _is_mapping(value):
            # Handles resolving Custom Pydantic Models and Dataclasses
            value = field_type(**value)
        else:
            # Handles resolving Optionals of
            # Custom Pydantic Models and Dataclasses
            NoneType = type(None)
            origin_type = get_origin(field_type)
            if origin_type == Union:
                args = get_args(field_type)
                for arg in args:
                    if arg is not NoneType and isclass(arg) and _is_mapping(value):
                        try:
                            value = arg(**value)
                        except pydantic.ValidationError:
                            continue
                        else:
                            break
        return value

    @classmethod
    def _get_unst_keys(
        cls,
        attr: str,
        keys: Optional[List[str]] = None,
        validate: bool = True,
    ) -> Set[str]:
        """Used when parsing unstructured examples.
        Get unstructured keys from the provided `keys` param or from this cls's
        keys under the `attr` variable.

        e.g.

        for a custom Structured Example subclass, `MyCustomExample` with the ClassVar `input_keys`
        set to ["text"]. These 2 method calls are equivalent.

        1. Example._get_unst_keys("input_keys", ["text"])
        2. MyCustomExample._get_unst_keys("input_keys", None)

        attr (str): Attr to look for on the cls to resolve keys to
        keys (Optional[List[str]]): Optional list of keys to use, if None, looks at this cls
        validate (bool): If True, validate keys are not None and raise a ValueError if they are

        RAISES (ValueError): If validate is True and the keys are None
        RETURNS (Set[str]): Set of keys to use for parsing unstructured examples to Structured examples
        """
        keys = keys if keys is not None else getattr(cls, attr)
        if keys is None and validate:
            raise ValueError(f"{attr} cannot be None")
        return set(keys) if keys is not None else set()

    @classmethod
    def _check_key_conflicts(cls, input_keys: Set[str], ann_keys: Set[str]) -> None:
        overlap_keys = input_keys.intersection(ann_keys)
        if overlap_keys:
            raise ConflictingKeysError(
                cls, input_keys=input_keys, overlap_keys=overlap_keys
            )

    @classmethod
    def _extract_extras(
        cls,
        data: Dict[str, Any],
        input_keys: Set[str],
        server_ann_keys: Set[str],
        user_ann_keys: Set[str],
    ) -> Dict[str, Any]:
        """Used when parsing unstructured examples.
        This extracts the extra keys in the unstructured
        data that are not explicitly specified to be included
        in the `input`, `server_anns` or `user_anns`
        data for the Example.

        data (Dict[str, Any]): Unstructured example data
        input_keys (Set[str]): Set of keys to go in `input` to skip over
        server_ann_keys (Set[str]): Set keys to go in `server_anns` to skip over
        user_ann_keys (Set[str]): Set keys to go in `user_anns` to skip over

        RETURNS (Dict[str, Any]): Dictionary to put in `extras` for the Structured Example
        """
        known_keys = (
            {"meta", "answer", INPUT_HASH_ATTR, TASK_HASH_ATTR}
            .union(input_keys)
            .union(server_ann_keys)
            .union(user_ann_keys)
        )
        extra_keys = [k for k in data.keys() if k not in known_keys]
        return _get_subdict(data, extra_keys)

    @classmethod
    def from_unst_server(
        cls: Type[Self],
        data: Dict[str, Any],
        *,
        input_keys: Optional[List[str]] = None,
        server_ann_keys: Optional[List[str]] = None,
        db: Optional["Database"] = None,
    ) -> Self:
        """Parse an unstructured example into a Structured Example object
        from the server, without user annotations and before the example has an answer.

        cls (Type[Self]): Example type to parse as (can be the base Example or any registered subtype)
        data (Dict[str, Any]): Unstructured example data to parse
        input_keys (Optional[List[str]]): Optional list of keys to parse into `input`.
            Defaults to the cls's configured `input_keys`
        server_ann_keys (Optional[List[str]]): Optional list of keys to parse into `server_anns`.
            Defaults to the cls's configured `server_ann_keys`
        db (Optional[Database]): Optional Prodigy Database instance to resolve `input`
            from `_input_hash` with

        RETURNS (_ExampleT): Initialized Structured Example
        """
        input_keys_ = cls._get_unst_keys("input_keys", input_keys)
        server_ann_keys_ = cls._get_unst_keys("server_ann_keys", server_ann_keys)
        cls._check_key_conflicts(input_keys_, server_ann_keys_)

        meta = dict(data.get("meta", {}))
        extras = cls._extract_extras(
            data,
            input_keys=input_keys_,
            server_ann_keys=server_ann_keys_,
            user_ann_keys=set(),
        )

        input = _maybe_get_subdict(data, input_keys_)
        if not input:
            raise MissingInputError(data, cls, input_keys_)

        from_dict_data = {
            "input": input,
            "server_anns": _maybe_get_subdict(data, server_ann_keys_),
            "user_anns": None,
            "answer": data.get("answer", None),
            "meta": meta,
            "extras": extras,
        }
        if INPUT_HASH_ATTR in data:
            from_dict_data["input_hash"] = data[INPUT_HASH_ATTR]
        if TASK_HASH_ATTR in data:
            from_dict_data["task_hash"] = data[TASK_HASH_ATTR]

        return cls.from_dict(from_dict_data, db=db)

    @classmethod
    def from_unst_user(
        cls,
        data: Dict[str, Any],
        *,
        input_keys: Optional[List[str]] = None,
        server_ann_keys: Optional[List[str]] = None,
        user_ann_keys: Optional[List[str]] = None,
        db: Optional["Database"] = None,
    ) -> Self:
        """Parse an unstructured example into a Structured Example object
        with a valid answer and annotations from a user. Used after annotations are received through
        the the Prodigy server `/receive_answers` endpoint. (i.e. after examples are annotated and saved by an annotator).

        cls (Type[Self]): Example type to parse as (can be the base Example or any registered subtype)
        data (Dict[str, Any]): Unstructured example data to parse
        input_keys (Optional[List[str]]): Optional list of keys to parse into `input`.
            Defaults to the cls's configured `input_keys`
        server_ann_keys (Optional[List[str]]): Optional list of keys to parse into `server_anns`.
            Defaults to the cls's configured `server_ann_keys`
        user_ann_keys (Optional[List[str]]): Optional list of keys to parse into `user_anns`.
            Defaults to the cls's configured `user_ann_keys`
        db (Optional[Database]): Optional Prodigy Database instance to resolve `input`
            from `_input_hash` with

        RAISES (MissingAnswerError): If the example data doesn't have both
            an `answer` attribute set

        RETURNS (_ExampleT): Initialized Structured Example
        """
        if "answer" not in data:
            raise MissingAnswerError(data, cls)

        input_keys_ = cls._get_unst_keys("input_keys", input_keys)
        user_ann_keys_ = cls._get_unst_keys("user_ann_keys", user_ann_keys)
        server_ann_keys_ = cls._get_unst_keys(
            "server_ann_keys", server_ann_keys, validate=False
        )
        cls._check_key_conflicts(input_keys_, server_ann_keys_)
        cls._check_key_conflicts(input_keys_, user_ann_keys_)

        meta = dict(data.get("meta", {}))
        extras = cls._extract_extras(
            data,
            input_keys=input_keys_,
            server_ann_keys=server_ann_keys_,
            user_ann_keys=user_ann_keys_,
        )

        input = _maybe_get_subdict(data, input_keys_)
        if not input:
            raise MissingInputError(data, cls, input_keys_)

        from_dict_data = {
            "answer": data["answer"],
            "input": input,
            "server_anns": _maybe_get_subdict(data, server_ann_keys_),
            "user_anns": _maybe_get_subdict(data, user_ann_keys_),
            "meta": meta,
            "extras": extras,
        }
        if INPUT_HASH_ATTR in data:
            from_dict_data["input_hash"] = data[INPUT_HASH_ATTR]
        if TASK_HASH_ATTR in data:
            from_dict_data["task_hash"] = data[TASK_HASH_ATTR]

        return cls.from_dict(from_dict_data, db=db)

    def to_dict(
        self, include: Optional[Set[str]] = None, exclude: Optional[Set[str]] = None
    ) -> Dict[str, Any]:
        """Serialize a Example instance to a dict.
        Handles serializing any Pydantic model instances to dict
        for any of the fields.
        Adds a '__class__' attr to the dict with the registered
        name of this Example type.
        include (Optional[Set[str]]): Field names to include, defaults to all
        exclude (Optional[Set[str]]): Field names to exclude, defaults to None
        RETURNS (Dict[str, Any]): Dict representation of Example
        """
        values = {}
        for key, value in asdict(self).items():
            if include is not None and key not in include:
                continue
            if exclude is not None and key in exclude:
                continue
            if isinstance(value, pydantic.BaseModel):
                values[key] = value.dict()
            else:
                values[key] = value
        values["__class__"] = f"@{self.__catalogue_name__}"
        return values

    def to_unst(self) -> Dict[str, Any]:
        """Serialize a Example to the unstructured flat dict format.
        Handles serializing custom types with Pydantic models to dict.
        `user_anns` take precedence over `server_anns`. So if
        `user_anns` and `server_anns` both have the `spans` key,
        the `user_anns['spans']` will be set for the final dict
        RETURNS (Dict[str, Any]): Example dict in the unstructured format
        """
        values = {
            INPUT_HASH_ATTR: self.input_hash,
            TASK_HASH_ATTR: self.task_hash,
            "meta": _attr_to_dict(self.meta),
        }
        if self.answer is not None:
            values["answer"] = self.answer
        inp_val = _attr_to_dict(self.input)
        values.update(inp_val)
        server_anns_val = _attr_to_dict(self.server_anns)
        user_anns_val = _attr_to_dict(self.user_anns)
        # Overwrite server anns keys that exist in the user_anns with the values in user_anns
        server_anns_val.update(user_anns_val)
        values.update(server_anns_val)
        values.update(_attr_to_dict(self.extras))
        return values

    def rehash(self, ignore: Iterable[str] = IGNORE_HASH_KEYS) -> None:
        """Recompute the input and task hashes for this Example
        based on changes to the input or server_anns. This data can
        change based on any Stream wrappers that get called when building the stream
        for a custom recipe.
        """
        input_dict = _attr_to_dict(self.input)
        input_hash = get_hash(input_dict, keys=input_dict.keys(), ignore=ignore)
        self.input_hash = input_hash

        task_dict = _attr_to_dict(self.server_anns)
        task_hash = get_hash(
            task_dict, keys=task_dict.keys(), prefix=str(input_hash), ignore=ignore
        )
        self.task_hash = task_hash


## Compat


def get_task_hash(example: Union[Example, TaskType]) -> int:
    task_hash = (
        example.task_hash if isinstance(example, Example) else example[TASK_HASH_ATTR]
    )
    assert isinstance(task_hash, int), task_hash
    return task_hash


def get_input_hash(example: Union[Example, TaskType]) -> int:
    task_hash = (
        example.task_hash if isinstance(example, Example) else example[INPUT_HASH_ATTR]
    )
    assert isinstance(task_hash, int), task_hash
    return task_hash


def ensure_structured_stream(
    stream: Union[Iterable[Dict[str, Any]], Iterable[_ExampleT]],
    *,
    parse_as: Type[_ExampleT] = Example,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
    db: Optional["Database"] = None,
) -> Iterator[_ExampleT]:
    """Ensure a stream of dict or Example objects are converted to Example instances."""

    for eg in stream:
        if isinstance(eg, dict):
            yield cast(
                _ExampleT,
                parse_as.from_unst_server(
                    eg, db=db, input_keys=input_keys, server_ann_keys=server_ann_keys
                ),
            )
        else:
            yield eg


# Extension to typeguard. You register a lookup function that
# then returns the checker. So we first have a function over
# the type we're passed in, and then that returns a function
# which we use to do the actual check.
def typeguard_pydantic_check(
    origin_type: Type,
    args: Tuple[Any, ...],
    extras: Tuple[Any, ...],
) -> Optional[
    Callable[
        [Any, Type[pydantic.BaseModel], Tuple[Any, ...], typeguard.TypeCheckMemo], None
    ]
]:
    def _typecheck_inner(
        value: Any,
        origin: Type[pydantic.BaseModel],
        args: Tuple[Any, ...],
        memo: typeguard.TypeCheckMemo,
    ) -> None:
        if value is None:
            raise TypeGuardPydanticError(
                "is invalid for this field. Field is required."
            )
        try:
            origin.validate(value)
        except pydantic.ValidationError as e:
            raise TypeGuardPydanticError.from_error(e) from None

    if issubclass(origin_type, pydantic.BaseModel):
        return _typecheck_inner
    else:
        return None


# Enum type checker for typeguard primarily to handle the Answer enum
def typeguard_enum_check(
    origin_type: Type,
    args: Tuple[Any, ...],
    extras: Tuple[Any, ...],
) -> Optional[
    Callable[[Any, Type[Enum], Tuple[Any, ...], typeguard.TypeCheckMemo], None]
]:
    def _typecheck_inner(
        value: Any,
        origin: Type[Enum],
        args: Tuple[Any, ...],
        memo: typeguard.TypeCheckMemo,
    ) -> None:
        if isinstance(value, origin):
            return None
        try:
            value = origin(value)
        except ValueError as e:
            raise TypeCheckError(str(e))

    if issubclass(origin_type, Enum):
        return _typecheck_inner
    else:
        return None


def register_type_check_lookup(
    lookup: Callable[
        [Type, Tuple[Any, ...], Tuple[Any, ...]],
        Optional[Callable[[Any, Type, Tuple[Any, ...], typeguard.TypeCheckMemo], None]],
    ]
) -> bool:
    if lookup in typeguard.checker_lookup_functions:
        return False
    else:
        typeguard.checker_lookup_functions.append(lookup)
        return True


register_type_check_lookup(typeguard_pydantic_check)
register_type_check_lookup(typeguard_enum_check)


def _is_mapping(value: Any) -> bool:
    return isinstance(value, Mapping)


def _resolve_input(database: "Database", input_hash: int) -> Dict:
    """Resolve the Dict Input from the Structured Example Input table.
    database (Database): Prodigy Database instance
    input_hash (int): Input hash to resolve

    RETURNS (Dict): Full input dict
    """
    return database.get_st_input_by_hash(input_hash)


def _get_subdict(data: Dict[str, Any], keys: Iterable[str]) -> Dict[str, Any]:
    return {key: data[key] for key in keys if key in data}


def _maybe_get_subdict(
    data: Dict[str, Any], keys: Iterable[str]
) -> Optional[Dict[str, Any]]:
    subdict = {key: data[key] for key in keys if key in data}
    if not subdict:
        return None
    return subdict


def _attr_to_dict(
    data: Union[Dict[str, Any], pydantic.BaseModel, None]
) -> Dict[str, Any]:
    if data is None:
        return {}
    elif isinstance(data, pydantic.BaseModel):
        return data.dict()
    elif isinstance(data, dict):
        return dict(data)
    elif is_dataclass(data):
        return asdict(data)
    return data


#########################################
### Internal Structured Example Subtypes ###
#########################################

## Spans Example


class TextInput(pydantic.BaseModel):
    text: str


class SpansAnns(pydantic.BaseModel):
    spans: List[TextSpan] = []


@prodigy_example_type("prodigy.example_types.SpansExample.v1")
class SpansExample(Example):
    """Used for NER and SpanCat recipes

    NER: https://prodi.gy/docs/api-interfaces#ner
    Spancat: https://prodi.gy/docs/api-interfaces#spans
    """

    input_keys = ["text"]
    server_ann_keys = ["spans"]
    user_ann_keys = ["spans"]

    input: TextInput
    server_anns: Optional[SpansAnns] = None
    user_anns: Optional[SpansAnns] = None


## Spans Manual Example


class SpansManualAnns(pydantic.BaseModel):
    spans: List[TextManualSpan] = []
    tokens: List[Token] = []


@prodigy_example_type("prodigy.example_types.SpansManualExample.v1")
class SpansManualExample(Example):
    """Used for token based manual NER and SpanCat recipes

    NER: https://prodi.gy/docs/api-interfaces#ner_manual
    Spancat: https://prodi.gy/docs/api-interfaces#spans_manual
    """

    input_keys = ["text"]
    server_ann_keys = ["spans", "tokens"]
    user_ann_keys = ["spans", "tokens"]

    input: TextInput
    user_anns: Optional[SpansManualAnns]
    server_anns: Optional[SpansManualAnns]


## Relations Example


class RelationsAnns(pydantic.BaseModel):
    spans: Optional[List[TextManualSpan]] = None
    relations: Optional[List[Relation]] = None
    tokens: List[Token] = []


@prodigy_example_type("prodigy.example_types.RelationsExample.v1")
class RelationsExample(Example):
    """Used for Relation Extraction

    https://prodi.gy/docs/api-interfaces#relations
    """

    input_keys = ["text"]
    server_ann_keys = ["spans", "relations", "tokens"]
    user_ann_keys = ["spans", "relations", "tokens"]

    input: TextInput
    server_anns: Optional[RelationsAnns]
    user_anns: Optional[RelationsAnns]


## Dependency Parsing Example


class DepAnns(pydantic.BaseModel):
    relations: List[Relation]
    tokens: List[Token]

    @pre_validator
    @classmethod
    def validate_arc_and_relations_as_relations(
        cls, values: Dict[str, Any]
    ) -> Dict[str, Any]:
        values = dict(values)
        values["relations"] = values.get("relations", values.get("arcs", []))
        return values


@prodigy_example_type("prodigy.example_types.DepExample.v1")
class DepExample(Example):
    """Used for Dependency Parser Annotations

    https://prodi.gy/docs/api-interfaces#dep
    """

    input_keys = ["text"]
    server_ann_keys = ["arcs", "relations", "tokens"]
    user_ann_keys = ["arcs", "relations", "tokens"]

    input: TextInput
    server_anns: Optional[DepAnns]
    user_anns: Optional[DepAnns]


## Image Example


class ImageInput(pydantic.BaseModel):
    # image is a url to an image or a base64 encoded str for the actual image
    image: str
    width: Optional[int] = None
    height: Optional[int] = None


class BoundingBoxAnns(pydantic.BaseModel):
    spans: Optional[List[ImageSpan]] = None


@prodigy_example_type("prodigy.example_types.ImageExample.v1")
class ImageExample(Example):
    """Used for annotating Images with bounding boxes

    https://prodi.gy/docs/api-interfaces#image
    https://prodi.gy/docs/api-interfaces#image_manual
    """

    input_keys = ["image", "width", "height"]
    server_ann_keys = ["spans"]
    user_ann_keys = ["spans"]

    input: ImageInput
    server_anns: Optional[BoundingBoxAnns]
    user_anns: Optional[BoundingBoxAnns]


## Audio and Video Span Annotation Examples


class AudioInput(pydantic.BaseModel):
    audio: str


class AudioSpansAnns(pydantic.BaseModel):
    audio_spans: List[AudioSpan] = []


@prodigy_example_type("prodigy.example_types.AudioSpansExample.v1")
class AudioSpansExample(Example):
    """Used for Audio Manual Span Annotations

    https://prodi.gy/docs/api-interfaces#audio
    https://prodi.gy/docs/api-interfaces#audio_manual
    """

    input_keys = ["audio"]
    server_ann_keys = ["audio_spans"]
    user_ann_keys = ["audio_spans"]

    input: AudioInput
    server_anns: Optional[AudioSpansAnns]
    user_anns: Optional[AudioSpansAnns]


class VideoInput(pydantic.BaseModel):
    video: str


@prodigy_example_type("prodigy.example_types.VideoSpansExample.v1")
class VideoSpansExample(Example):
    """Used for Audio Manual Span Annotations from a video

    https://prodi.gy/docs/api-interfaces#audio
    https://prodi.gy/docs/api-interfaces#audio_manual
    """

    input_keys = ["video"]
    server_ann_keys = ["audio_spans"]
    user_ann_keys = ["audio_spans"]

    input: VideoInput
    server_anns: Optional[AudioSpansAnns]
    user_anns: Optional[AudioSpansAnns]


## Transcription and Text Input Examples


class TextInputConfig(pydantic.BaseModel):
    field_id: Optional[str] = None
    field_label: Optional[str] = None
    field_placeholder: Optional[str] = None
    field_rows: Optional[int] = None
    field_autofocus: Optional[bool] = False
    field_suggestions: Optional[List[str]] = None


class AudioTranscribeServerAnns(TextInputConfig):
    user_input: Optional[str] = None


class AudioTranscribeUserAnns(pydantic.BaseModel):
    user_input: str


@prodigy_example_type("prodigy.example_types.AudioTranscribeExample.v1")
class AudioTranscribeExample(Example):
    """Used for Audio Transcription Annotations

    https://prodi.gy/docs/api-interfaces#audio
    """

    input_keys = ["audio"]
    server_ann_keys = [
        "audio_spans",
        "field_id",
        "field_label",
        "field_placeholder",
        "field_rows",
        "field_autofocus",
        "field_suggestions",
    ]
    user_ann_keys = ["field_id", "user_input"]

    input: AudioInput
    server_anns: Optional[AudioTranscribeServerAnns]
    user_anns: Optional[AudioTranscribeUserAnns]


@prodigy_example_type("prodigy.example_types.VideoTranscribeExample.v1")
class VideoTranscribeExample(Example):
    """Used for Video Transcription Annotations

    https://prodi.gy/docs/api-interfaces#video
    """

    input_keys = ["video"]
    server_ann_keys = [
        "audio_spans",
        "field_id",
        "field_label",
        "field_placeholder",
        "field_rows",
        "field_autofocus",
    ]
    user_ann_keys = ["field_id", "user_input"]

    input: VideoInput
    server_anns: Optional[AudioTranscribeServerAnns]
    user_anns: Optional[AudioTranscribeUserAnns]


## Classification Examples


class TextcatServerAnns(pydantic.BaseModel):
    label: Optional[str] = None
    spans: Optional[List[TextSpan]] = None


class ClassificationAnns(pydantic.BaseModel):
    label: str


class ChoiceAnns(pydantic.BaseModel):
    options: List[ChoiceOption]


@prodigy_example_type("prodigy.example_types.TextcatExample.v1")
class TextcatExample(Example):

    input_keys = ["text"]
    server_ann_keys = ["label", "spans"]
    user_ann_keys = ["label"]

    input: TextInput
    server_anns: Optional[TextcatServerAnns]
    user_anns: Optional[ClassificationAnns]


@prodigy_example_type("prodigy.example_types.ImagecatExample.v1")
class ImagecatExample(Example):

    input_keys = ["image"]
    server_ann_keys = ["label"]
    user_ann_keys = ["label"]

    input: ImageInput
    server_anns: Optional[ClassificationAnns]
    user_anns: Optional[ClassificationAnns]


@prodigy_example_type("prodigy.example_types.AudiocatExample.v1")
class AudiocatExample(Example):

    input_keys = ["audio"]
    server_ann_keys = ["label"]
    user_ann_keys = ["label"]

    input: AudioInput
    server_anns: Optional[ClassificationAnns]
    user_anns: Optional[ClassificationAnns]


class HTMLInput(pydantic.BaseModel):
    html: str


@prodigy_example_type("prodigy.example_types.HTMLcatExample.v1")
class HTMLcatExample(Example):

    input_keys = ["html"]
    server_ann_keys = ["label"]
    user_ann_keys = ["label"]

    input: HTMLInput
    server_anns: Optional[ClassificationAnns]
    user_anns: Optional[ClassificationAnns]


# Choice Examples
# https://prodi.gy/docs/api-interfaces#choice


class ChoiceServerAnns(pydantic.BaseModel):
    options: List[ChoiceOption]


class ChoiceUserAnns(pydantic.BaseModel):
    accept: Union[List[str], List[int]]


class TextcatChoiceServerAnns(pydantic.BaseModel):
    options: List[ChoiceOption]
    spans: Optional[List[TextSpan]] = None


@prodigy_example_type("prodigy.example_types.TextcatChoiceExample.v1")
class TextcatChoiceExample(Example):
    input_keys = ["text"]
    server_ann_keys = ["options", "spans"]
    user_ann_keys = ["accept"]

    input: TextInput
    server_anns: Optional[TextcatChoiceServerAnns]
    user_anns: Optional[ChoiceUserAnns]


@prodigy_example_type("prodigy.example_types.ImagecatChoiceExample.v1")
class ImagecatChoiceExample(Example):
    input_keys = ["image"]
    server_ann_keys = ["options"]
    user_ann_keys = ["accept"]

    input: ImageInput
    server_anns: Optional[ChoiceServerAnns]
    user_anns: Optional[ChoiceUserAnns]


@prodigy_example_type("prodigy.example_types.AudiocatChoiceExample.v1")
class AudiocatChoiceExample(Example):
    input_keys = ["audio"]
    server_ann_keys = ["options"]
    user_ann_keys = ["accept"]

    input: AudioInput
    server_anns: Optional[ChoiceServerAnns]
    user_anns: Optional[ChoiceUserAnns]


@prodigy_example_type("prodigy.example_types.HTMLcatChoiceExample.v1")
class HTMLcatChoiceExample(Example):
    input_keys = ["html"]
    server_ann_keys = ["options"]
    user_ann_keys = ["accept"]

    input: HTMLInput
    server_anns: Optional[ChoiceServerAnns]
    user_anns: Optional[ChoiceUserAnns]
