import datetime
import os
import uuid
from typing import Optional, Tuple

import jwt
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBasic, HTTPBearer
from pydantic import BaseModel, ValidationError
from starlette.status import HTTP_401_UNAUTHORIZED, HTTP_403_FORBIDDEN

from ._util import ENV_VARS
from .errors import UnauthorizedSessionIdRequestError
from .types import JWTPayload
from .util import log

# The name used for prodigy JWT cookies
JWT_COOKIE_NAME = "_prodigy_"
# Generate a uuid secret if the user hasn't specified one.
JWT_FALLBACK_SECRET = uuid.uuid4().hex
# Default JWT expiration time in seconds
JWT_FALLBACK_EXPIRE = 60 * 60 * 24  # 24 hours

BEARER_SCHEME = HTTPBearer(auto_error=False)


def company_auth_configured() -> bool:
    try:
        from prodigy_company_plugins.auth import auth_configured

        if os.getenv("PRODIGY_OIDC_AUTH_ENABLED") == "1":
            # to allow running w/o OIDC while still having the Plugin installed
            return auth_configured()
        else:
            log("API: PRODIGY_OIDC_AUTH_ENABLED is not set to 1, skipping OIDC auth")
            return False
    except ImportError:
        return False


def add_company_auth(app: FastAPI) -> None:
    if company_auth_configured():
        from prodigy_company_plugins.auth import (
            add_company_auth as plugin_add_company_auth,
        )

        plugin_add_company_auth(app)


def _clean_session_id(session_id: Optional[str]) -> Optional[str]:
    """Clean a session_id from a request by removing trailing slashes"""
    # Ensure that trailing backslashes are ignored, otherwise it polutes the session info.
    # This seems to be an open FastAPI Issue: https://github.com/tiangolo/fastapi/discussions/7663
    # Details of original bug: https://support.prodi.gy/t/session-name-include-the-backslash/6149/4
    if session_id and session_id.endswith("/"):
        return session_id.rstrip("/")
    return session_id


def get_requesting_session_id(
    request_session_id: Optional[str],
    current_user_session_id: Optional[str],
) -> Optional[str]:
    """Get the true session_id to use when making calls to the Controller.
    If the request_session_id is None, use the currently logged in user's ID
    """
    request_session_id = _clean_session_id(request_session_id)
    if current_user_session_id is None:
        # If there is no current user, then just return whatever the request
        # session_id is. This will always be the case for personal license without
        # company auth enabled. (i.e. there is no current user)
        return request_session_id

    elif request_session_id is None and current_user_session_id is not None:
        # If there is no request session_id, but there is a current user, then
        # all the Controller requests (e.g. get_questions, receive_answers) should
        # just use the current user's session_id
        return current_user_session_id

    elif request_session_id != current_user_session_id:
        # If we have a current user AND the requests contains a session_id, these must be equal
        # User's can't request questions (or send back answers) for somebody else's session.
        # For this case we raise an explicit Auth error.
        raise UnauthorizedSessionIdRequestError(
            current_user_session_id, request_session_id
        )
    else:
        # By default use the request session_id
        return request_session_id


def encode_token(secret: str, audience: str, issuer: str, expire_seconds: int) -> str:
    """Encode a JWT for accessing the prodigy API routes"""
    payload = {
        "exp": datetime.datetime.utcnow() + datetime.timedelta(seconds=expire_seconds),
        "aud": audience,
        "iss": issuer,
    }
    return jwt.encode(payload, secret)


def get_jwt_config(default_config: bool = False) -> Tuple[str, str]:
    """Get the JSONWebToken auth configuration from the environment.

    PRODIGY_JWT_SECRET is a shared secret that is used for signing tokens
    and verifying them. Use this secret when generating tokens that will be
    used to authenticate calls to prodigy.

    PRODIGY_JWT_AUDIENCE is set to the web address that prodigy will be running
    at, for example http://localhost:8080. The same value must be used when signing
    the tokens and when verifying them.
    """
    default_secret = None
    default_audience = None
    if default_config is True:
        default_secret = JWT_FALLBACK_SECRET
        default_audience = os.environ.get(ENV_VARS.HOST, "localhost")
    token_secret = os.environ.get(ENV_VARS.JWT_SECRET, default_secret)
    token_audience = os.environ.get(ENV_VARS.JWT_AUDIENCE, default_audience)
    return token_secret, token_audience  # type: ignore


def get_basic_auth_config() -> Tuple[str, str]:
    """Get the HTTP Basic Auth configuration for protecting access to the running prodigy
    static files.

    This is not a full security system, and only offers weak-protection against unwanted
    access. This protection should not be used in production without strong passwords and
    the app served over https to encrypt the user/pass that is entered.

    PRODIGY_BASIC_AUTH_PASS is a string variable containing the password to accept.
    PRODIGY_BASIC_AUTH_USER is a string variable containung the user to accept.

    raises: ValueError if only one of the two environment variables is set
    returns: a tuple of (user, password) which will be (None, None) if basic auth is disabled
    """
    basic_password = os.environ.get(ENV_VARS.BASIC_AUTH_PASS, None)
    basic_username = os.environ.get(ENV_VARS.BASIC_AUTH_USER, None)
    if basic_password is None and basic_username is None:
        return None, None  # type: ignore
    if basic_password is None or basic_username is None:
        raise ValueError(
            "Invalid configuration."
            "You cannot specify one HTTP basic auth environment variable without the other"
        )
    return basic_username, basic_password


async def get_basic_auth(request: Request):
    # Check for disabled auth configuration before using the auth controller.
    # NOTE: this is so that when auth is disabled the client doesn't get sent
    #       an authorization prompt, which happens when the auth controller is
    #       called by the DepInjector. I tried auto_error=False but then I needed
    #       to call it again later to get the auth challenge headers needed in
    #       a failure response. This ends up being the cleanest way I've found.
    basic_username, basic_password = get_basic_auth_config()
    if basic_password is None and basic_username is None:
        return None

    # Invoke HTTP Basic auth challenge/handler
    basic_auth = HTTPBasic()
    credentials = await basic_auth(request)
    if (
        credentials is None
        or credentials.username != basic_username
        or credentials.password != basic_password
    ):
        raise HTTPException(
            status_code=HTTP_401_UNAUTHORIZED, detail="Incorrect email or password"
        )
    else:
        return credentials


async def maybe_get_current_user(request: Request) -> Optional[BaseModel]:
    user = None
    if company_auth_configured():
        from prodigy_company_plugins.auth import maybe_get_current_user

        user = await maybe_get_current_user(request)
    return user


def get_frontend_auth_dependency(app: FastAPI):
    if company_auth_configured():
        # If Pro and Auth Settings are properly configured
        return app.state.auth.auth_user_index
    else:
        return get_basic_auth


def get_jwt_auth_dependency(app: FastAPI):
    if company_auth_configured():
        return app.state.auth.auth_user_api
    else:

        return validate_simple_prodigy_token


async def validate_simple_prodigy_token(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(BEARER_SCHEME),
) -> Optional[JWTPayload]:
    if not os.getenv(ENV_VARS.JWT):
        return None
    token = None
    if JWT_COOKIE_NAME in request.cookies:
        token = request.cookies[JWT_COOKIE_NAME]
    elif credentials is not None:
        token = credentials.credentials

    if token is None:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN,
            detail="No token provided. Not authenticated.",
        )
    secret, audience = get_jwt_config(default_config=True)
    payload = _decode_simple_prodigy_token(token, secret, "HS256", audience)
    return JWTPayload(**payload)


def _decode_simple_prodigy_token(
    token: str, secret_key: str, algorithm: str, audience: str
) -> dict:
    try:
        payload = jwt.decode(
            token,
            secret_key,
            algorithms=[algorithm],
            audience=audience,
        )
    except (jwt.PyJWTError, ValidationError) as e:
        raise HTTPException(status_code=HTTP_403_FORBIDDEN, detail=f"Token Error: {e}")
    return payload
