import sys
from collections import defaultdict
from typing import TYPE_CHECKING, List, Optional, Sequence, Tuple

from radicli import ConvertersType, Radicli

from .about import __version__

PROG = "prodigy"
HELP_ARGS = ["--help", "-h"]

if TYPE_CHECKING:
    from .core import Controller


def get_converters() -> ConvertersType:
    from radicli import get_list_converter
    from radicli.util import DEFAULT_CONVERTERS
    from spacy.language import Language

    from .types import LabelsType
    from .util import convert_labels, load_spacy_model

    # We need to include everything here because this is also used to construct
    # Command objects directly and not via the Radicli class
    return {
        **DEFAULT_CONVERTERS,
        List[str]: get_list_converter(str),
        Sequence[str]: get_list_converter(str),
        LabelsType: convert_labels,
        Language: load_spacy_model,
    }


def get_cli() -> Radicli:
    from . import recipes  # noqa: F401
    from .errors import ProdigyError
    from .util import handle_cli_error, msg, registry

    # Just load the entry points here so the decorator runs and sets them
    # properly. Don't add them to the registry, because the functions will
    # be wrong (original recipe, not the recipe proxy). Also beware of circular
    # imports – we can't just call this in util etc., because that may be
    # imported by third-party packages.
    registry.recipes.get_entry_points()
    commands = registry.recipes.get_all()

    def info_overwrite(self):
        """Override the normal Radicli table because there are just too many recipes."""
        groups = defaultdict(list)
        for name, cmd in self.commands.items():
            groupname = "other"
            split = name.split(".")
            if len(split) > 1:
                groupname = name.split(".")[0]
            groups[groupname].append(name)
        msg.divider("Available commands")
        for group, names in groups.items():
            print("")  # noqa: T201
            msg.row(names, widths=6, aligns="l")
        return ""

    Radicli.format_info = info_overwrite
    cli = Radicli(
        prog=PROG,
        version=__version__,
        converters=get_converters(),
        errors={ProdigyError: handle_cli_error},
    )
    cli.commands = {k: v for k, v in sorted(commands.items())}

    return cli


def generate_cli_components(command: str) -> Tuple[Optional["Controller"], List[str]]:
    """Added a helper function to make it easier to test."""
    import shlex

    # Adding `prodigy` here because the `run_recipe` function later assumes it is the 1st arg
    cli_args = shlex.split(f"prodigy {command}", posix="win" not in sys.platform)
    return run_recipe(cli_args), cli_args


def serve(command: str, **config) -> None:
    """Start the Prodigy server from Python.

    command (str): Full string command.
    **config: Config settings to overwrite Prodigy config.
    """
    from .app import server
    from .util import msg

    controller, cli_args = generate_cli_components(command)
    if not controller:
        msg.fail(
            f"Can't serve '{cli_args[0]}'. It doesn't seem to be a recipe "
            f"that requires the Prodigy server to be started.",
            exits=1,
        )
    assert controller
    merged_config = {**controller.config, **config}
    server(controller, merged_config)


def run_recipe(run_args: List[str], paths: List[str] = []) -> Optional["Controller"]:
    import signal

    from .core import Controller, get_recipe, is_server_recipe
    from .util import log, msg

    cli = get_cli()
    if len(run_args) <= 1 or run_args[1] in HELP_ARGS:
        cli.run([PROG])
    command = run_args[1]
    args = run_args[2:]
    recipe_command = get_recipe(command)
    if recipe_command:
        if has_help(args):
            cli.run([PROG, command, HELP_ARGS[0]])
        parsed_args = cli.parse(args, recipe_command)
        log(f"RECIPE: Calling recipe '{command}'")
        try:
            with cli.handle_errors():
                components = recipe_command.func(**parsed_args)
        except BrokenPipeError:
            # We catch the BrokenPipeError here to handle Unix pipes that break
            # The signal handler is still needed
            # See: https://stackoverflow.com/a/16865106/6400719
            # And: https://docs.python.org/3/library/signal.html#note-on-sigpipe
            # E.g. in Bash (doesn't happen in Zsh)
            # python -m prodigy db-out ner_fashion | bash -c "exit 1"
            signal.signal(signal.SIGPIPE, signal.SIG_DFL)
            sys.exit()
        if is_server_recipe(components):
            if isinstance(components, Controller):
                return components
            else:
                return Controller.from_components(command, components)
    else:
        opts = ", ".join(cli.commands.keys())
        info = f"Run {PROG} --help for more details."
        err = f"Can't find recipe or command '{command}'."
        if paths:
            err += " It's not a built-in recipe and not available in the provided file paths."
        else:
            info += " If you're using a custom recipe, provide the path to the Python file using the -F argument."
        msg.fail(err, info)
        msg.text(f"Available recipes: {opts}")
        sys.exit(1)


def has_help(args: List[str], help_args: List[str] = HELP_ARGS) -> bool:
    for arg in help_args:
        if arg in args:
            return True
    return False
