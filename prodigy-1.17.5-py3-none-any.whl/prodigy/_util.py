"""Internal utilities. Must not import anything else in the library."""

import copy
import logging
import os
import sys
import traceback
import warnings
from pprint import pprint
from typing import Any, Callable, Dict, List, Optional

import wasabi
from pydantic import SecretStr
from wasabi.printer import Printer
from wasabi.util import NO_UTF8, locale_escape, supports_ansi
from wasabi.util import color as wasabi_color

from .env_vars import ENV_VARS


# Helper class to only give a warning once
class WarnOnlyOnce:
    def __init__(self) -> None:
        self.seen_warnings = {}

    def __call__(self, name: str, indicator: Callable[[], bool]) -> bool:
        """This helper method can help detect if this might be the first
        when a warning should be raised. Useful to check for behavior inside
        a for-loop that should raise an issue only once.

        name (str): name of a warning, preferably via a constant
        indicator (callable): indicates if a warning should be raised now
        """
        seen_before = self.seen_warnings.get(name, False)
        if not seen_before and indicator():
            self.seen_warnings[name] = True
            return True
        return False


def deep_merge_dicts(
    a: Dict[str, Any], b: Dict[str, Any], path: Optional[List[str]] = None
) -> Dict[str, Any]:
    """Deep-merge two dictionaries (e.g. Prodigy config settings).

    a (dict): The base dictionary to merge into.
    b (dict): The dictionary to merge into other dict.
    RETURNS (dict): The merged dictionaries.
    """
    if path is None:
        path = []
    for key in b:
        if key in a:
            if isinstance(a[key], dict) and isinstance(b[key], dict):
                deep_merge_dicts(a[key], b[key], path + [str(key)])
            elif a[key] == b[key]:
                pass  # same leaf value
            else:
                # This happens if we have a conflict, e.g. if one value is a
                # dict and the other isn't. Instead of raising here, we take
                # whatever we got in the second dict, to support settings that
                # take different types of values (e.g. dict or None).
                a[key] = b[key]
        else:
            a[key] = b[key]
    return a


def color(
    text: str, fg: Optional[str] = None, bg: Optional[str] = None, bold: bool = False
) -> str:
    """Wrap text in color ANSI escape sequences.

    text (str): The text to print.
    color (str): The pre-defined color name to use as the foreground color.
    bg (str): The pre-defined color name to use as the background color.
    RETURNS (str): The colored string.
    """
    if not supports_ansi():
        return text
    text = locale_escape(text)
    return wasabi_color(
        text,
        fg=ANSI_COLORS.get(fg) if fg is not None else None,
        bg=ANSI_COLORS.get(bg) if bg is not None else None,
        bold=bold,
    )


def _obfuscate_secret_key(
    config: Dict[str, Any],
    secret_key: str,
) -> None:
    """Obfuscate keys in a config dict using Pydantic SecretField subclass
    Updates config dict inplace

    config (Dict[str, Any]): Config to check
    secret_key (str): Key to update with SecretField impl. e.g. `db_settings`
    secret_type (Union[Type[SecretStr], Type[SecretField]]): Pydantic SecretField subclass to use
    """
    for k, v in config[secret_key].items():
        if isinstance(v, str):
            config[secret_key].update({k: SecretStr(v)})
        elif isinstance(v, dict):
            _obfuscate_secret_key(config[secret_key], k)


def obfuscate_secret_config(
    config: Dict[str, Any],
    keys: List[str] = ["db_settings", "api_keys"],
) -> Dict[str, Any]:
    """Returns a new config dict with obfuscated keys"""
    config = copy.deepcopy(config)
    for key in keys:
        if key in config:
            _obfuscate_secret_key(config, key)
    return config


# Logging with custom logger to allow users to modify output
class LoggingFormatter(logging.Formatter):
    def format(self, record):
        time = self.formatTime(record, datefmt="%H:%M:%S")
        prefix = color(time, fg="theme", bold=True) if supports_ansi() else time
        record.__dict__["message"] = f"{prefix}: {record.getMessage()}"
        return super().formatMessage(record)


# Third-party loggers that we want to apply our own logging levels to
# NB: uvicorn doesn't seem to respect it, so we're also passing in the
# log level separately when we run the app
THIRD_PARTY_LOGGERS = ["fastapi", "uvicorn.error", "uvicorn.access", "uvicorn.asgi"]


LOGGER = logging.getLogger("prodigy")
LOGGER.setLevel(logging.INFO)
logging_formatter = LoggingFormatter()
logging_handler = logging.StreamHandler()
logging_handler.setFormatter(logging_formatter)
LOGGER.addHandler(logging_handler)


class ServerErrorFilter(logging.Filter):
    # uvicorn logs all errors using its logger and includes the tracebacks. This
    # means that if Prodigy raises a custom error, it's almost hidden because
    # it's followed by a giant traceback. Disabling error logs isn't viable
    # either, because that'd mean the user would never see server errors. This
    # filter works around that by raising the underlying exception (unless it's
    # a system exit caused by our own custom messages).
    def filter(self, rec):
        if rec.levelno == logging.ERROR and rec.exc_info:
            if rec.exc_info[0] != SystemExit:
                raise rec.exc_info[1]
            return False
        return True


ONLY_ONCE_LOG_SET = set()


def log(
    message: Optional[str] = None,
    details: Optional[Any] = None,
    only_once: bool = False,
) -> None:
    """Add an entry to Prodigy's log (used via the PRODIGY_LOGGING environment
    variable). Entries are displayed with a timestamp and log entry details
    are only shown if PRODIGY_LOGGING=verbose.

    message (str): Logging message to add to the log.
    details: Optional details to add in verbose mode.
    only_once: Boolean to indicate if the line should only be logged once.
    """
    level = os.environ.get(ENV_VARS.LOGGING)
    if level:
        if message:
            if only_once:
                ONLY_ONCE_LOG_SET.add(message)
                if message not in ONLY_ONCE_LOG_SET:
                    LOGGER.info(message)
            else:
                LOGGER.info(message)
        if (level == "verbose") and details:
            LOGGER.info(details)


# fmt: off
ANSI_COLORS = dict(wasabi.util.COLORS)
ANSI_COLORS.update({"accept": ANSI_COLORS["green"], "reject": ANSI_COLORS["red"],
                    "grey": 250, "ignore": 250, "black": 16, "theme": 135,
                    "highlight": 222, "white": 15})
# fmt: on


# Create and customize wasabi printer
def _trace_decorator(method) -> Callable:
    """If we exit, we should provide a traceback to help the user debug."""

    def wrapper(*args, **kwargs) -> None:
        if ("exits" in kwargs) and kwargs["exits"]:
            level = os.environ.get(ENV_VARS.LOGGING)
            allowed = ("true", "1", "t")
            render_locals = os.getenv(ENV_VARS.LOG_LOCALS, "f").lower() in allowed
            if level:
                msg.divider("Traceback")
                # Add newlines to be consistent with warning message.
                print()  # noqa: T201
                # Don't show the final trace, that's this decorator
                for line in traceback.format_stack()[:-1]:
                    print(line.strip())  # noqa: T201
                if render_locals:
                    msg.divider("Locals")
                    print()  # noqa: T201
                    info = sys.exc_info()[2]
                    if info is not None:
                        frame = info.tb_frame  # type: ignore
                        stack_locals = frame.f_locals
                        pprint(stack_locals, indent=2)
                    else:
                        pprint({})
                msg.divider("Warning message")
        method(*args, **kwargs)

    return wrapper


def get_msg(**kwargs) -> Printer:
    msg = Printer(**kwargs)
    msg.icons["emoji"] = "\u2728 " if not NO_UTF8 else "[*]"
    msg.fail = _trace_decorator(msg.fail)
    return msg


msg = get_msg()


def init_package() -> None:
    """This helper function is called first thing in the __init__.py and takes
    care of ignoring specific warnings, setting logger levels etc. This has
    to be done before the respective modules and loggers are imported.
    """
    # TODO: check if we still need this for numpy
    warnings.filterwarnings("ignore", message="numpy.dtype size changed")
    warnings.filterwarnings("ignore", message="numpy.ufunc size changed")
    warnings.filterwarnings("ignore", message="DeprecationWarning")
    # Apply our own logging level to relevant third-party loggers
    log_level = get_log_level()
    for logger_name in THIRD_PARTY_LOGGERS:
        logging.getLogger(logger_name).setLevel(log_level)
    # Workaround for errors caught by uvicorn
    uvicorn_error_logger = logging.getLogger("uvicorn.error")
    uvicorn_error_logger.addFilter(ServerErrorFilter())
    log(f"INIT: Setting all logging levels to {log_level}")


def get_log_level() -> int:
    """Get the log level for third-party loggers baased on the PRODIGY_LOGGING
    env variable: none: CRITICAL, basic: INFO, verbose: DEBUG
    """
    mapping = {None: logging.ERROR, "basic": logging.INFO, "verbose": logging.DEBUG}
    return mapping.get(os.environ.get(ENV_VARS.LOGGING), logging.ERROR)
