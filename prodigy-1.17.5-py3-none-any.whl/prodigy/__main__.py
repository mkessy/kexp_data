import os
from pathlib import Path

from .env_vars import ENV_VARS

FILE = Path(__file__).parent / "cli.json"
IS_DEBUG = ENV_VARS.CLI_DEBUG in os.environ
IS_DISABLED = ENV_VARS.CLI_NO_STATIC in os.environ


def main():
    from radicli import StaticRadicli

    # TODO: ideally we want to set disable=True for local development, but
    # not sure yet how to best determine that?
    # TODO: Disabled the static CLI for now until we have a better solution
    # that works with commands registered from entry points
    if FILE.exists():
        static = StaticRadicli.load(FILE, debug=IS_DEBUG, disable=True)
        static.run()

    import sys

    from prodigy.app import server
    from prodigy.cli import run_recipe
    from prodigy.core import Controller, import_code
    from prodigy.util import get_valid_sessions, log

    valid_sessions = get_valid_sessions()
    if valid_sessions is not None:
        log(f"CLI: limiting user sessions to list: {', '.join(valid_sessions)}")

    run_args = [*sys.argv]
    paths = []
    if "-F" in run_args:
        paths = run_args.pop(run_args.index("-F") + 1)
        run_args.pop(run_args.index("-F"))
        paths = [path.strip() for path in paths.split(",")]
    # Import all code provided as paths (recipes, registered functions)
    for path in paths:
        log(f"CLI: Importing file {path}")
        import_code(path)

    controller = run_recipe(run_args)
    if isinstance(controller, Controller):
        server(controller, controller.config)


if __name__ == "__main__":
    main()
