import random
from typing import Union

import numpy
from toolz.itertoolz import concat, take

from ..types import ScoredStreamType, StreamType, TaskType
from ..util import UNSET, log


def prefer_uncertain(
    stream: ScoredStreamType, bias: float = 0.0, algorithm: Union[str, object] = UNSET
) -> StreamType:
    sorted_stream = ((get_uncertainty(score, bias), eg) for score, eg in stream)
    log(f"SORTER: Resort stream to prefer uncertain scores (bias {bias})")
    if algorithm == "probability":
        return Probability(sorted_stream)
    else:
        return ExpMovingAverage(sorted_stream)


def get_uncertainty(score: float, bias: float = 0.0) -> float:
    uncertainty = 1.0 - (abs(score - 0.5) * 2)
    return ((1 - bias) * uncertainty) + (bias * score)


def prefer_high_scores(stream: ScoredStreamType, bias: float = 0.0) -> StreamType:
    log(f"SORTER: Resort stream to prefer high scores (bias {bias})")
    return ExpMovingAverage(stream)


def prefer_low_scores(stream: ScoredStreamType, bias: float = 0.0) -> StreamType:
    sorted_stream = ((-score, eg) for score, eg in stream)
    log(f"SORTER: Resort stream to prefer low scores (bias {bias})")
    return ExpMovingAverage(sorted_stream)


class Linear:
    """Given a stream of (p, item) pairs ask questions in the descending order of p."""

    def __init__(self, stream: ScoredStreamType) -> None:
        self.stream = sorted(stream, key=lambda x: x[0], reverse=True)

    def __next__(self) -> TaskType:
        if len(self.stream) > 0:
            _, task = self.stream.pop(0)
            return task
        raise StopIteration

    def __iter__(self) -> StreamType:
        return self


class Threshold:
    """Given a stream of (p, item) pairs and priority range,
    ask questions with p within the priority range.
    """

    def __init__(
        self, stream: ScoredStreamType, minimum: float = 0.0, maximum: float = 1.0
    ) -> None:
        self.stream = stream
        self.minimum = minimum
        self.maximum = maximum

    def __next__(self) -> TaskType:
        found_task = None
        while not found_task:
            priority, next_task = next(self.stream)
            if self.minimum < priority < self.maximum:
                found_task = next_task
                return found_task
        raise StopIteration

    def __iter__(self) -> StreamType:
        return self


class Probability:
    """Given a stream of (p, item) pairs, ask questions with probability 1-p."""

    def __init__(self, stream: ScoredStreamType) -> None:
        log(
            "SORTER: Randomly select questions using their score as the "
            "selection probability"
        )
        self.stream = stream
        self._iterator = None

    def __next__(self) -> TaskType:
        if self._iterator is None:
            self._iterator = iter(self)
        return next(self._iterator)

    def __iter__(self) -> StreamType:
        for i, (prob, task) in enumerate(self.stream):
            if not isinstance(prob, int) and not isinstance(prob, float):
                err = f"Sorting priority needs to be numeric, not {type(prob)}"
                raise ValueError(err)
            if i == 0:
                yield task
                continue
            prob = max(0.0001, prob)
            if random.random() < prob:
                yield task


class ExpMovingAverage:
    """
    Given a stream of (priority, item) pairs, track the mean and variance
    of the priority, and emit items where:

    >>> priority >= mean + (variance * patience)

    Where patience is a dynamic factor that increases as items are emited,
    and decreases as items are skipped.
    """

    def __init__(self, stream: ScoredStreamType, first_n: int = 64) -> None:
        self.stream = stream
        self.v = 0
        self.m = 0
        self.first_n = first_n
        self._iterator = None

    def __next__(self) -> TaskType:
        if self._iterator is None:
            self._iterator = iter(self)
        return next(self._iterator)

    def __iter__(self) -> StreamType:
        prebatch = list(take(self.first_n, self.stream))
        prebatch.sort(reverse=True, key=lambda x: x[0])
        for priority, task in prebatch[: self.first_n // 10]:
            yield task
        self.stream = concat((prebatch[self.first_n // 10 :], self.stream))
        patience = 0.0
        priorities = numpy.asarray([p for p, task in prebatch])
        self.m = priorities.mean()
        self.v = priorities.var()
        for i, (priority, task) in enumerate(self.stream):
            if not isinstance(priority, int) and not isinstance(priority, float):
                err = f"Sorting priority needs to be numeric, not: {type(priority)}"
                raise ValueError(err)
            decay = min((1.0 + i) / (10.0 + i), 0.9999)
            # http://people.ds.cam.ac.uk/fanf2/hermes/doc/antiforgery/stats.pdf
            diff = priority - self.m
            incr = decay * diff
            self.m += incr
            self.v = (1 - decay) * (self.v + diff * incr)
            if priority >= self.m + (self.v * patience):
                yield task
                patience += 1.0 / max(i + 10, 100)
            else:
                patience -= 1.0 / max(i + 10, 100)
