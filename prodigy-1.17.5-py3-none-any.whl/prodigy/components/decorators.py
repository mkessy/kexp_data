import inspect
from functools import partial, wraps
from typing import (
    Any,
    Callable,
    Iterable,
    Iterator,
    List,
    Optional,
    Tuple,
    Type,
    Union,
    cast,
)
from typing_extensions import ParamSpec, TypeVar

import toolz

from ..structured_types import Example, ensure_structured_stream
from ..types import TaskType
from .stream import Stream

_ExampleT = TypeVar("_ExampleT", Example, TaskType)
_StructuredExampleT = TypeVar("_StructuredExampleT", bound=Example, default=Example)
_StreamApplyParams = ParamSpec("_StreamApplyParams")


def _validate_stream_arg_sig(func: Callable, stream_arg_name: str) -> inspect.Signature:
    signature = inspect.signature(func)
    if stream_arg_name not in signature.parameters:
        raise ValueError(
            f"{stream_arg_name} not found in function signature for {func.__name__}"
        )
    return signature


def _is_structured_stream(
    stream: Iterable[_ExampleT],
) -> Tuple[bool, bool, Iterable[_ExampleT]]:
    """Check if a stream is structured or not and whether it's empty. Combines these 2 operations
    so we don't have to peek twice.
    Deterimind by peeking at the first example in the stream so the original
    stream is also returned.
    RETURNS (Tuple[bool, bool, Iterable[_ExampleT]]): Tuple of (is_empty, is_structured, original stream)
    """
    is_empty = False
    is_structured = False
    is_list = isinstance(stream, list)
    try:
        item, orig = toolz.peek(stream)
    except StopIteration:
        is_empty = True
        is_structured = False
    else:
        stream = orig
        if isinstance(item, Example):
            is_structured = True
    if is_list:
        stream = list(stream)
    return is_empty, is_structured, stream


def support_both_streams(stream_arg: str):
    """This is a decorator that you can apply to a function such that it supports
    both the generator style and the new Stream object.
    """

    def decorator(
        func: Callable[_StreamApplyParams, Iterator[_ExampleT]]
    ) -> Callable[
        _StreamApplyParams, Union[Iterator[_ExampleT], Stream[Any, _ExampleT]]
    ]:
        signature = _validate_stream_arg_sig(func, stream_arg)

        @wraps(func)
        def inner(
            *args: _StreamApplyParams.args, **kwargs: _StreamApplyParams.kwargs
        ) -> Union[Iterator[_ExampleT], Stream[Any, _ExampleT]]:
            bound_arguments = signature.bind(*args, **kwargs)
            bound_arguments.apply_defaults()
            stream_in = bound_arguments.arguments[stream_arg]

            if not isinstance(stream_in, Stream):
                return func(*bound_arguments.args, **bound_arguments.kwargs)  # type: ignore (paramspec stuff)

            stream_in.apply(func, *args, **kwargs)
            return stream_in

        return inner

    return decorator


def support_structured(
    stream_arg: str,
    *,
    parse_as: Optional[Type[_StructuredExampleT]] = None,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
):
    """Wrap a v1 function that operates on Unstructured Example dicts
    so it can work with both Structured and Unstructured Examples as inputs.
    Requires one of the arguments to be the stream of tasks to operate on.

    Since the function signature for the structured variant will change,
    the signature of the original function is not preserved.
    """

    def decorator(
        func: Callable[..., Iterator[_ExampleT]]
    ) -> Callable[..., Union[Iterator[_ExampleT], Iterator[_StructuredExampleT]]]:
        signature = _validate_stream_arg_sig(func, stream_arg)

        @wraps(func)
        def inner(
            *args: Any, **kwargs: Any
        ) -> Union[Iterator[_ExampleT], Iterator[_StructuredExampleT]]:
            bound_arguments = signature.bind(*args, **kwargs)
            bound_arguments.apply_defaults()
            stream = bound_arguments.arguments[stream_arg]
            is_empty, is_structured, stream = _is_structured_stream(stream)
            if is_empty:
                return stream

            return_list = False
            first_item, stream = toolz.peek(stream)

            # if stream is structured, convert it to unstructured.
            # If already unstructured just pass it through
            unst_stream = stream
            if is_structured:
                stream = cast(Iterable[_StructuredExampleT], stream)
                unst_stream = (eg.to_unst() for eg in stream)
                if isinstance(stream, list):
                    unst_stream = list(unst_stream)
                    return_list = True

            # replace the stream argument with the unstructured stream
            # and call the original function
            bound_arguments.arguments[stream_arg] = unst_stream
            unst_stream = func(*bound_arguments.args, **bound_arguments.kwargs)
            (
                _local_parse_as,
                _local_input_keys,
                _local_server_ann_keys,
            ) = _resolve_structured_params(
                first_stream_item=first_item,
                parse_as=parse_as,
                input_keys=input_keys,
                server_ann_keys=server_ann_keys,
            )
            # If we started with a structured stream, return a structured stream
            # If we started with an unstuctured stream, return an unstructured stream
            final_stream = unst_stream
            if is_structured:
                final_stream = ensure_structured_stream(
                    unst_stream,  # type: ignore
                    parse_as=_local_parse_as,
                    input_keys=_local_input_keys,
                    server_ann_keys=_local_server_ann_keys,
                )
            if return_list:
                return list(final_stream)
            else:
                yield from final_stream  # type: ignore

        return inner

    return decorator


def support_unstructured(
    stream_arg: str,
    *,
    parse_as: Optional[Type[_StructuredExampleT]] = None,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
):
    """Wrap a v2 Stream wrapper that operates on Structured Example objects
    so it can work with both Structured and Unstructured Examples as inputs.
    Requires one of the arguments to be the stream of tasks to operate on.

    Since the function signature for the unstructured variant will change,
    the signature of the original function is not preserved.
    """

    def decorator(
        func: Callable[..., Iterator[_ExampleT]]
    ) -> Callable[..., Union[Iterator[_ExampleT], Iterator[_StructuredExampleT]]]:
        signature = _validate_stream_arg_sig(func, stream_arg)

        @wraps(func)
        def inner(
            *args: Any, **kwargs: Any
        ) -> Union[Iterator[_ExampleT], Iterator[_StructuredExampleT]]:
            bound_arguments = signature.bind(*args, **kwargs)
            bound_arguments.apply_defaults()
            stream = bound_arguments.arguments[stream_arg]
            is_empty, is_structured, stream = _is_structured_stream(stream)
            if is_empty:
                return stream

            return_list = False
            first_item, stream = toolz.peek(stream)
            (
                _local_parse_as,
                _local_input_keys,
                _local_server_ann_keys,
            ) = _resolve_structured_params(
                first_stream_item=first_item,
                parse_as=parse_as,
                input_keys=input_keys,
                server_ann_keys=server_ann_keys,
            )

            # if stream is structured, convert it to unstructured.
            # If already unstructured just pass it through
            st_stream = stream
            if not is_structured:
                stream = cast(Iterable[TaskType], stream)
                _make_st_eg = partial(
                    _local_parse_as.from_unst_server,
                    input_keys=_local_input_keys,
                    server_ann_keys=_local_server_ann_keys,
                )
                st_stream = (_make_st_eg(eg) for eg in stream)
                if isinstance(stream, list):
                    st_stream = list(st_stream)
                    return_list = True

            # replace the stream argument with the unstructured stream
            # and call the original function
            bound_arguments.arguments[stream_arg] = st_stream
            st_stream = func(*bound_arguments.args, **bound_arguments.kwargs)  # type: ignore

            # If we started with a structured stream, return a structured stream
            # If we started with an unstuctured stream, return an unstructured stream
            final_stream = st_stream
            if not is_structured:
                final_stream = cast(Iterator[_StructuredExampleT], st_stream)
                final_stream = (eg.to_unst() for eg in final_stream)
            if return_list:
                return list(final_stream)
            else:
                yield from final_stream  # type: ignore

        return inner

    return decorator


def _resolve_structured_params(
    *,
    first_stream_item: _ExampleT,
    parse_as: Optional[Type[_StructuredExampleT]] = None,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
) -> Tuple[
    Union[Type[_StructuredExampleT], Type[Example]],
    Optional[List[str]],
    Optional[List[str]],
]:
    _local_parse_as = parse_as
    if parse_as is None and isinstance(first_stream_item, Example):
        _local_parse_as = first_stream_item.__class__
        if issubclass(first_stream_item.__class__, Example):
            input_keys = first_stream_item.input_keys or input_keys
            server_ann_keys = first_stream_item.server_ann_keys or server_ann_keys
    _local_parse_as = _local_parse_as or Example
    return _local_parse_as, input_keys, server_ann_keys
