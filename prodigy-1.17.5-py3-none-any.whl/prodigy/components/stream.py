import copy
import functools
import sys
import uuid
from dataclasses import dataclass
from io import TextIOWrapper
from pathlib import Path
from queue import SimpleQueue
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    Iterable,
    Iterator,
    List,
    Optional,
    Tuple,
    Type,
    Union,
    cast,
    overload,
)
from typing_extensions import ParamSpec, Self, TypeVar

import toolz
from typeguard import TypeCheckError, check_type

from .._util import (
    log,
    msg,
)
from ..structured_types import (
    Example,
    StructuredExampleError,
    get_task_hash,
)
from ..types import TaskType, ViewId
from ..util import (
    IGNORE_HASH_KEYS,
    MISSING_HASHES_WARNING_KEY,
    UNSET,
    first_warning,
    hashes_missing,
    registry,
    set_hashes,
)
from .db import DatasetNotFound, DatasetNotStructured, connect
from .source import (
    AUDIO_FILE_EXT,
    IMAGE_FILE_EXT,
    VIDEO_FILE_EXT,
    BinaryFileSource,
    DatasetSource,
    GeneratorSource,
    JSONLFileCountError,
    JSONLFileSource,
    ListSource,
    ParquetFileSource,
    Source,
    TextFileSource,
    load_audio_files,
    load_csv_file,
    load_image_files,
    load_json_file,
    load_jsonl_file,
    load_noop,
    load_text_file,
    load_video_files,
)
from .validate import format_obj

_StructExampleT = TypeVar("_StructExampleT", bound=Example, default=Example)
_ExampleT = TypeVar("_ExampleT", bound=Union[Example, TaskType])
_NewExampleT = TypeVar("_NewExampleT", bound=Union[Example, TaskType])
_InputT = TypeVar("_InputT")
_LoaderParams = ParamSpec("_LoaderParams")
_EXECUTION_ID = uuid.uuid4()

STREAM_PLACEHOLDER = "== STREAM PLACEHOLDER =="


def ensure_structured(
    stream: Union[Iterator[TaskType], Iterator[_StructExampleT]],
    parse_as: Type[_StructExampleT] = Example,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
) -> Iterator[_StructExampleT]:
    for eg in stream:
        if isinstance(eg, dict):
            eg = parse_as.from_unst_server(
                eg, input_keys=input_keys, server_ann_keys=server_ann_keys
            )
            # It seems to need this cast because of the default value
            yield cast(_StructExampleT, eg)
        else:
            yield eg


@dataclass
class QueueItem(Generic[_ExampleT]):
    """A tuple of an item, and the position of the source
    when the item was emitted. Note that sequences can be arbitrarily
    reordered, so the position might not be where it was in the underlying
    data.
    """

    key: int
    position: int
    data: _ExampleT


class Stream(Generic[_InputT, _ExampleT]):
    """Load and transform items from a raw data source,
    and then enqueue them to one or more queues.

    Queues can be added during iteration, populated by
    any number of items from the history.
    """

    _source: Source[_InputT]
    _loader: Callable[[Source[_InputT]], Iterator[_ExampleT]]
    _max_history_size: int
    _wrappers: List[
        Tuple[
            Callable[[Iterator[_ExampleT]], Iterator[Union[Example, TaskType]]],
            List,
            Dict[str, Any],
        ]
    ]
    _history: List[QueueItem[_ExampleT]]
    _iterator: Optional[Iterator[_ExampleT]]
    _buffer: List[QueueItem[_ExampleT]]
    _queues: Dict[str, SimpleQueue]

    @classmethod
    def from_iterable(cls: Type[Self], data: Iterable[_ExampleT]) -> Self:
        if hasattr(data, "__len__") and hasattr(data, "__getitem__"):
            source = ListSource(cast(List[_ExampleT], data))
        else:
            source = GeneratorSource(cast(Iterator[_ExampleT], data))
        # TODO type
        return cls(source, loader=load_noop, wrappers=[])  # type: ignore

    def __init__(
        self,
        source: Source[_InputT],
        loader: Callable[[Source[_InputT]], Iterator[_ExampleT]],
        wrappers: List[
            Callable[[Iterator[_ExampleT]], Iterator[Union[Example, TaskType]]]
        ],
        *,
        history: Optional[List[QueueItem[_ExampleT]]] = None,
        max_history_size: int = -1,
    ):
        self._source = source
        self._loader = loader
        self._queues = {}
        self._history = list(history) if history is not None else []
        self._iterator = None
        self._buffer = []
        self._max_history_size = max_history_size
        self._wrappers = []
        for func in wrappers:
            self.apply(func)

    def __next__(self) -> _ExampleT:
        if self.is_empty:
            raise StopIteration
        else:
            item = self._get_from_iterator()
            return item.data

    def __iter__(self) -> Iterator[_ExampleT]:
        return self

    @property
    def source(self) -> Source[_InputT]:
        return self._source

    @property
    def source_size(self) -> Optional[int]:
        return self._source.size

    @property
    def source_position(self) -> int:
        return self._source.position

    @property
    def is_empty(self) -> bool:
        return self.peek() is None

    @property
    def max_history_size(self) -> int:
        return self._max_history_size

    @property
    def wrappers(
        self,
    ) -> List[
        Tuple[
            Callable[[Iterator[_ExampleT]], Iterator[Union[Example, TaskType]]],
            List,
            Dict[str, Any],
        ]
    ]:
        return self._wrappers

    def set_wrappers(
        self,
        wrappers: List[
            Tuple[
                Callable[[Iterator[_ExampleT]], Iterator[Union[Example, TaskType]]],
                List,
                Dict[str, Any],
            ]
        ],
    ) -> None:
        self._wrappers = wrappers

    def set_max_history_size(self, size: int) -> None:
        self._max_history_size = size

    def has_queue(self, queue_id: str) -> bool:
        return queue_id in self._queues

    def peek(self) -> Optional[QueueItem[_ExampleT]]:
        if not self._buffer:
            try:
                item = self._get_from_iterator()
            except StopIteration:
                return None

            self._buffer.append(item)
        return self._buffer[0]

    # This declares us as always returning a Stream instance, which won't be correct
    # for subclasses. I don't think there's a way to express the generic relationship with
    # a type var though? We can't use the Self because we need the generic
    def apply(
        self,
        wrapper: Callable[..., Iterator[_NewExampleT]],
        *args,
        **kwargs,
    ) -> "Stream[_InputT, _NewExampleT]":
        """Apply a function to the stream. You can supply extra arguments to the function,
        putting the stream instance in where it would go in the function call. For isntance,

            def my_wrapper(nlp, stream):
                ...

            stream.apply(my_wrapper, nlp, stream)

        You can also import and use the special value STREAM_PLACEHOLDER to indicate this. The
        same works for keyword arguments:

            def my_wrapper(arg1, arg2, *, arbitrary_name):
                ...

            stream.apply(my_wrapper, arg1, arg2, arbitrary_name=stream)

        If the stream instance is not in the args or kwargs, it is assumed to be the first argument
        to the wrapper.
        """
        # We allow callables to take the stream as an arbitrary argument, not just the first
        # argument or an arbitrary keyword. So we need to know how to assemble the args/kwargs to pass in,
        # inserting the 'self' where it needs to go.
        # What we do is insert a marker symbol, which we later use to insert self. We use this marker
        # instead of the 'self' object to avoid a circular reference.
        args, kwargs = _set_stream_placeholder(self, list(args), kwargs)
        self._wrappers.append((wrapper, args, kwargs))
        # If we're already iterating, we need to apply the wrapper to the current iterator.
        # MH, later: Feels weird that we support this. If you're already iterating, should you
        # really get to apply? I guess it was legal before, so we have to.
        if self._iterator is not None:
            # Need to also respect buffered items (from peek)
            buffer_data = [item.data for item in self._buffer]
            iterator = toolz.concat((buffer_data, self._iterator))
            iterator = _apply_paginated(wrapper, iterator, args, kwargs)
            # Update the self state
            self._iterator = cast(Iterator[_ExampleT], iterator)
            self._buffer = []
        return cast(Stream[_InputT, _NewExampleT], self)

    def ensure_queue(self, queue_id: str, n_history: int = -1) -> None:
        if not self.has_queue(queue_id):
            self.create_queue(queue_id, n_history)

    def create_queue(self, queue_id: str, n_history: int = -1) -> None:
        if self.has_queue(queue_id):
            raise RuntimeError(
                f"Running `stream.create_queue(queue_id={queue_id})` while {queue_id} already exists."
            )
        queue = SimpleQueue()
        if n_history < 0:
            n_history = len(self._history)
        # If the history is zero, we don't want to put items in the queue.
        if n_history > 0:
            for item_position in self._history[-n_history:]:
                queue.put(item_position)
        log(f"STREAM: Created queue for {queue_id}.")
        self._queues[queue_id] = queue

    def get_next(
        self, router: Callable[[_ExampleT], List[str]], queue_id: str
    ) -> QueueItem[_ExampleT]:
        queue = self._queues[queue_id]
        while queue.empty():
            item = self._get_from_iterator()
            queue_ids = router(item.data)
            try:
                check_type(queue_ids, List[str])
            except TypeCheckError:
                msg.fail(
                    "The task router is not returning a list of sessions. "
                    f"Received: `{queue_ids}`. If you are using a custom "
                    "task router make sure that you output a list "
                    "of strings resembling session ids instead. ",
                    exits=True,
                )
            self._put(queue_ids, item)
        return queue.get()

    def iter_queue(
        self, router: Callable[[_ExampleT], List[str]], queue_id: str
    ) -> Iterator[QueueItem[_ExampleT]]:
        while True:
            try:
                item = self.get_next(router, queue_id)
                yield item
            except StopIteration:
                break

    def has_next(self, queue_id: str) -> bool:
        if not self.is_empty:
            return True
        elif not self._queues[queue_id].empty():
            return True
        else:
            return False

    def _get_from_iterator(self) -> QueueItem[_ExampleT]:
        if self._buffer:
            return self._buffer.pop(0)
        if self._iterator is None:
            self.start_iterator()
        assert self._iterator is not None
        data = next(self._iterator)
        if isinstance(data, dict):
            data = _fix_hashes(data)
        task_hash = get_task_hash(data)
        return cast(
            QueueItem[_ExampleT],
            QueueItem(key=task_hash, position=self.source_position, data=data),
        )

    def _put(self, queue_ids: Iterable[str], item: QueueItem[_ExampleT]) -> None:
        for queue_id in queue_ids:
            if queue_id not in self._queues.keys():
                msg.fail(
                    f"Session {queue_id} is not known. Did you ensure it's existence via Controller.ensure_session()?",
                    exits=True,
                )
            queue = self._queues[queue_id]
            queue.put(item)
        self._history.append(item)
        self._history = self._history[-self._max_history_size :]

    def start_iterator(self) -> None:
        iterator = self._loader(self._source)
        for wrapper, args, kwargs in self._wrappers:
            iterator = _apply_paginated(wrapper, iterator, args, kwargs)
        # We need the cast here because the type variable on the stream says "This is the eventual type".
        # We only know this last type, not the intermediate types in the loop.
        self._iterator = cast(Iterator[_ExampleT], iterator)

    def copy(self) -> Self:
        copied = self.__class__(
            source=self._source.copy(),
            loader=copy.deepcopy(self._loader),
            history=copy.deepcopy(self._history),
            max_history_size=copy.deepcopy(self._max_history_size),
            wrappers=[],
        )
        for func, args, kwargs in self._wrappers:
            copied.apply(func, *args, **kwargs)
        return copied

    def copy_restarted(self) -> Self:
        copied = self.__class__(
            source=self._source.copy(),
            loader=copy.deepcopy(self._loader),
            history=[],
            max_history_size=copy.deepcopy(self._max_history_size),
            wrappers=[],
        )
        for func, args, kwargs in self._wrappers:
            copied.apply(func, *args, **kwargs)
        return copied


def _fix_hashes(data: TaskType) -> TaskType:
    """Add input/task hashes if they don't exist, but give warning."""
    # Add input/task hashes if they don't exist, but give warning
    # attach the hex(id(self)) to ensure the warnings are unique per
    # stream object. Otherwise, the tests go haywire.
    if "pages" in data:
        data["pages"] = [_fix_hashes(p) for p in data["pages"]]
        return data

    if first_warning(
        f"{MISSING_HASHES_WARNING_KEY}{_EXECUTION_ID}",
        lambda: hashes_missing(data),
    ):
        msg.warn(
            "Prodigy automatically assigned an input/task hash because it was missing. "
            "This automatic hashing will be deprecated as of Prodigy v2 because it can lead to "
            "unwanted duplicates in custom recipes if the examples deviate from the default "
            "assumptions. More information can found on the docs: "
            "https://prodi.gy/docs/api-components#set_hashes"
        )
    return set_hashes(data)


def make_st_loader(
    loader_func: Callable[_LoaderParams, Iterator[_ExampleT]],
    structured_class: Type[_StructExampleT] = Example,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
    skip_invalid: bool = True,
) -> Callable[_LoaderParams, Iterator[_StructExampleT]]:
    """Wrap a loader function to return structured examples.

    loader_func (Callable): The loader function to wrap.
    structured_class (Type): The structured class to use.
    input_keys (List[str]): The input keys to use.
    server_ann_keys (List[str]): The server annotation keys to use.
    RETURNS (Callable): The wrapped loader function.
    """

    def st_loader_func(
        *args: _LoaderParams.args, **kwargs: _LoaderParams.kwargs
    ) -> Iterator[_StructExampleT]:
        for eg in loader_func(*args, **kwargs):
            st_eg = eg
            if isinstance(eg, dict):
                eg = _fix_hashes(eg)
                try:
                    st_eg = structured_class.from_unst_server(
                        eg, input_keys=input_keys, server_ann_keys=server_ann_keys
                    )
                except StructuredExampleError as e:
                    if skip_invalid:
                        continue
                    msg.fail(e.msg, f"Invalid Data: {format_obj(eg)}", exits=True)

            yield cast(_StructExampleT, st_eg)

    return st_loader_func


def _rehash_stream_st(
    stream: Iterator[_StructExampleT],
    ignore_hash_keys: Iterable[str] = IGNORE_HASH_KEYS,
) -> Iterator[_StructExampleT]:
    for eg in stream:
        eg.rehash(ignore=ignore_hash_keys)
        yield eg


@overload
def get_stream(
    source: Any,
    api: Optional[str] = None,
    loader: Optional[str] = None,
    rehash: bool = False,
    dedup: bool = False,
    input_key: Union[str, object] = UNSET,
    skip_invalid: bool = True,
    is_binary: Optional[bool] = None,
    view_id: Optional[ViewId] = None,
    structured: bool = False,
) -> Stream[Any, TaskType]:
    ...


@overload
def get_stream(
    source: Any,
    api: Optional[str] = None,
    loader: Optional[str] = None,
    rehash: bool = False,
    dedup: bool = False,
    input_key: Union[str, object] = UNSET,
    skip_invalid: bool = True,
    is_binary: Optional[bool] = None,
    view_id: Optional[ViewId] = None,
    structured: bool = True,
    structured_class: Type[_StructExampleT] = Example,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
) -> Stream[Any, _StructExampleT]:
    ...


def get_stream(
    source: Any,
    api: Optional[str] = None,
    loader: Optional[str] = None,
    rehash: bool = False,
    dedup: bool = False,
    input_key: Union[str, object] = UNSET,
    skip_invalid: bool = True,
    is_binary: Optional[bool] = None,
    view_id: Optional[ViewId] = None,
    structured: bool = False,
    structured_class: Type[_StructExampleT] = Example,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
) -> Union[Stream[Any, TaskType], Stream[Any, _StructExampleT]]:
    """Get a stream of annotation examples. Mostly used to process arguments
    passed in via the command line.

    source (str): The source (file path or "-" to read from standard input).
    api (str): DEPRECATED: Name of API loader, or None.
    rehash (bool): Asssign new hashes to the stream.
    dedup (bool): Remove duplicates from the stream.
    input_key (str): Task key containing the input data. If set, empty
        values will be filtered out.
    skip_invalid (bool): If input_key is set, skip invalid or empty examples
        instead of raising an error. Defaults to True.
    is_binary (bool): Whether the examples in the stream are binary or manual
        annotations. Added as an attribute to the tasks. If not set, no
        attribute will be added.
    view_id (str): Interface ID used for pages if the pages loader is set.
    RETURNS (stream): The stream of annotation examples.
    """
    try:
        stream = _get_stream_internal(
            source=source,
            api=api,
            loader=loader,
            rehash=rehash,
            dedup=dedup,
            input_key=input_key,
            skip_invalid=skip_invalid,
            is_binary=is_binary,
            view_id=view_id,
            structured=structured,
            structured_class=structured_class,
            input_keys=input_keys,
            server_ann_keys=server_ann_keys,
        )
    except (DatasetNotFound, DatasetNotStructured, StructuredExampleError) as e:
        msg.fail(e.msg, exits=1)
    except ValueError as e:
        msg.fail(str(e), exits=1)
    else:
        return stream


def _get_stream_internal(
    source: Any,
    api: Optional[str] = None,
    loader: Optional[str] = None,
    rehash: bool = False,
    dedup: bool = False,
    input_key: Union[str, object] = UNSET,
    skip_invalid: bool = True,
    is_binary: Optional[bool] = None,
    view_id: Optional[ViewId] = None,
    structured: bool = False,
    structured_class: Type[_StructExampleT] = Example,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
) -> Union[Stream[Any, TaskType], Stream[Any, _StructExampleT]]:
    """Internal function to get a stream of annotation examples. Mostly used to process arguments
    passed in via the command line. This internal function raises exceptions instead of formatting
    msg failures to the console. Should not be used directly, use `get_stream` instead.

    source (str): The source (file path or "-" to read from standard input).
    api (str): DEPRECATED: Name of API loader, or None.
    rehash (bool): Asssign new hashes to the stream.
    dedup (bool): Remove duplicates from the stream.
    input_key (str): Task key containing the input data. If set, empty
        values will be filtered out.
    skip_invalid (bool): If input_key is set, skip invalid or empty examples
        instead of raising an error. Defaults to True.
    is_binary (bool): Whether the examples in the stream are binary or manual
        annotations. Added as an attribute to the tasks. If not set, no
        attribute will be added.
    view_id (str): Interface ID used for pages if the pages loader is set.
    RETURNS (stream): The stream of annotation examples.
    """
    from .filters import filter_duplicates, filter_duplicates_st, filter_empty
    from .loaders import _add_attrs, _rehash_stream

    _make_st_loader = functools.partial(
        make_st_loader,
        structured_class=structured_class,
        input_keys=input_keys,
        server_ann_keys=server_ann_keys,
        skip_invalid=skip_invalid,
    )

    _load_noop_st = _make_st_loader(load_noop, structured_class=structured_class)
    _load_jsonl_file_st = _make_st_loader(
        load_jsonl_file, structured_class=structured_class
    )
    _load_json_file_st = _make_st_loader(
        load_json_file, structured_class=structured_class
    )
    _load_text_file_st = _make_st_loader(
        load_text_file, structured_class=structured_class
    )
    _load_csv_file_st = _make_st_loader(
        load_csv_file, structured_class=structured_class
    )
    _load_image_files_st = _make_st_loader(
        load_image_files, structured_class=structured_class
    )
    _load_audio_files_st = _make_st_loader(
        load_audio_files, structured_class=structured_class
    )
    _load_video_files_st = _make_st_loader(
        load_video_files, structured_class=structured_class
    )
    if _source_is_api(source, loader) or api is not None:
        raise ValueError(
            "Using the 'api' loader is not supported with the new `get_stream` implementation. "
            "To use the 'api' loader you will need to use the legacy "
            "`prodigy.components.loaders.get_stream` function instead and provide the "
            "the stream as a plain python generator of task dicts. "
        )
    elif loader and loader.startswith("pages"):
        from .loaders import Pages

        log("get_stream: Loading paginated stream")
        if not view_id:
            raise ValueError(
                "Can't load paginated content: no view_id specified in get_stream"
            )
        sub_loader = loader.replace("pages:", "") if ":" in loader else None
        resolved_source = GeneratorSource(
            Pages(source, view_id=view_id, loader=sub_loader)
        )
        stream = Stream(resolved_source, loader=load_noop, wrappers=[])
    elif _source_is_stdin(source, loader or ""):
        log("get_stream: Loading dataset from stdin")
        if loader is None:
            raise ValueError("Loader should be specified when reading from stdin")
        resolved_loader = registry.source_loaders.get(loader)
        resolved_source = GeneratorSource(resolved_loader(sys.stdin, stdin=True))
        stream = Stream(resolved_source, loader=load_noop, wrappers=[])
    elif _source_is_dataset(source, loader or ""):
        log(f"get_stream: Loading dataset {source}")
        db = connect()

        dataset_name = str(source).replace("dataset:", "", 1)
        answer = "all"
        if ":" in dataset_name:
            dataset_name, split_answer = dataset_name.split(":", 1)
            if split_answer is not None:
                if split_answer not in ("accept", "reject", "ignore"):
                    raise ValueError(
                        f"Invalid source '{str(source)}' for 'dataset' loader. "
                        f"Provided answer suffix '{split_answer}' is invalid. "
                        "Dataset sources must use one of 'accept', 'reject', or 'ignore' "
                        "as the answer suffix. e.g. 'dataset:my_dataset:accept'"
                    )
                answer = split_answer
        resolved_source = DatasetSource(
            db, dataset_name, answer=answer, structured=structured
        )
        resolved_loader = _load_noop_st if structured else load_noop
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif _source_is_sequence_dict(source):
        log("get_stream: Loading List")
        resolved_source = ListSource[TaskType](list(source))
        resolved_loader = _load_noop_st if structured else load_noop
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif _source_is_iterable_dict(source):
        log("get_stream: Loading Iterator")
        resolved_source = GeneratorSource(source)
        resolved_loader = _load_noop_st if structured else load_noop
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif _source_is_path("jsonl", source, loader):
        source = _ensure_path(source)
        log("get_stream: Loading .jsonl file")
        try:
            resolved_source = JSONLFileSource.from_path(source)
            resolved_loader = _load_noop_st if structured else load_noop
            stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
        except JSONLFileCountError:
            resolved_source = TextFileSource.from_path(source)
            resolved_loader = _load_jsonl_file_st if structured else load_jsonl_file
            stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif _source_is_path("json", source, loader):
        source = _ensure_path(source)
        log("get_stream: Loading .json file")
        resolved_source = TextFileSource.from_path(source)
        resolved_loader = _load_json_file_st if structured else load_json_file
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif _source_is_path("txt", source, loader):
        source = _ensure_path(source)
        log("get_stream: Loading .txt file")
        resolved_source = TextFileSource.from_path(source)
        resolved_loader = _load_text_file_st if structured else load_text_file
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif _source_is_path("csv", source, loader):
        source = _ensure_path(source)
        log("get_stream: Loading .csv file")
        resolved_source = TextFileSource.from_path(source)
        resolved_loader = _load_csv_file_st if structured else load_csv_file
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif _source_is_path("parquet", source, loader):
        source = _ensure_path(source)
        log("get_stream: Loading .parquet file")
        resolved_source = ParquetFileSource.from_path(source)
        resolved_loader = _load_noop_st if structured else load_noop
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif loader == "images" or _source_is_path(IMAGE_FILE_EXT, source, loader):
        source = _ensure_path(source)
        log("get_stream: Loading image files")
        resolved_source = BinaryFileSource.from_path(source)
        resolved_loader = _load_image_files_st if structured else load_image_files
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif loader == "audio" or _source_is_path(AUDIO_FILE_EXT, source, loader):
        source = _ensure_path(source)
        log("get_stream: Loading audio files")
        resolved_source = BinaryFileSource.from_path(source)
        resolved_loader = _load_audio_files_st if structured else load_audio_files
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif loader == "video" or _source_is_path(VIDEO_FILE_EXT, source, loader):
        source = _ensure_path(source)
        log("get_stream: Loading video files")
        resolved_source = BinaryFileSource.from_path(source)
        resolved_loader = _load_video_files_st if structured else load_video_files
        stream = Stream(resolved_source, loader=resolved_loader, wrappers=[])
    elif _source_is_legacy_custom_loader(source, loader or ""):
        from .loaders import get_loader as legacy_get_loader

        log(f"get_stream: Falling back to a legacy Prodigy loader: {loader}")
        msg.warn(
            f"Using a legacy loader '{loader}' from the `prodigy.registry.loaders` "
            "registry is deprecated and will be removed in a future Prodigy version. "
            "The progress bar will not work correctly with this loader. "
        )
        loader_func = legacy_get_loader(loader or "jsonl")
        source = GeneratorSource(loader_func(source))
        stream = Stream(source, loader=load_noop, wrappers=[])
    else:
        # If none of our source/loader checks work, fail
        # gracefully with a good message for the user
        if loader is not None:
            err_msg = f"Loader: '{loader}' could not be resolved."
        else:
            source_path = _ensure_path(source)
            if isinstance(source_path, Path) and not source_path.exists():
                err_msg = (
                    f"Provided source: '{source}' was resolved as a Path but does not exist. "
                    "If this is not a Path, try specifying an explicit loader. "
                    "Otherwise, ensure the Path exists. "
                    "If this is a dataset, remember to prefix the dataset name with `dataset:`."
                )
            elif isinstance(source_path, Path) and source_path.exists():
                err_msg = (
                    f"No loader specified and provided source: '{source}' "
                    "could not be automatically resolved to a built-in Prodigy loader. "
                )
            else:
                err_msg = (
                    f"Combination of source: '{source}' and loader: '{loader}' cannot be loaded "
                    "by Prodigy. "
                )
        raise ValueError(err_msg)

    stream = cast(Union[Stream[Any, TaskType], Stream[Any, _StructExampleT]], stream)
    if rehash:
        log("get_stream: Rehashing stream")
        if structured:
            stream.apply(_rehash_stream_st)
        else:
            stream.apply(_rehash_stream)
    if input_key is not UNSET and not structured:
        assert isinstance(input_key, str)
        stream.apply(functools.partial(filter_empty, key=input_key, skip=skip_invalid))
    if dedup:
        log("get_stream: Removing duplicates")
        if structured:
            stream.apply(functools.partial(filter_duplicates_st, by_input=True))
        else:
            stream.apply(functools.partial(filter_duplicates, by_input=True))
    if not structured:
        stream.apply(functools.partial(_add_attrs, is_binary=is_binary))
    return stream


def _set_stream_placeholder(
    stream: Stream, args: List, kwargs: Dict[str, Any]
) -> Tuple[List, Dict[str, Any]]:
    args = list(args)
    kwargs = dict(kwargs)
    seen_stream = False
    for i, arg in enumerate(list(args)):
        # If the stream placeholder is present it's considered seen
        if arg == STREAM_PLACEHOLDER:
            seen_stream = True
        if arg is stream:
            args[i] = STREAM_PLACEHOLDER
            seen_stream = True
    for key, arg in list(kwargs.items()):
        # If the stream placeholder is present it's considered seen
        if arg == STREAM_PLACEHOLDER:
            seen_stream = True
        if arg is stream:
            kwargs[key] = STREAM_PLACEHOLDER
            seen_stream = True
    if not seen_stream:
        args.insert(0, STREAM_PLACEHOLDER)
    return args, kwargs


def _replace_stream_placeholder(
    stream: Any, args: List, kwargs: Dict[str, Any]
) -> Tuple[List, Dict[str, Any]]:
    seen_stream = False
    args = list(args)
    kwargs = dict(kwargs)
    for i, arg in enumerate(list(args)):
        if arg == STREAM_PLACEHOLDER:
            args[i] = stream
            seen_stream = True
    for key, arg in list(kwargs.items()):
        if arg == STREAM_PLACEHOLDER:
            kwargs[key] = stream
            seen_stream = True
    if not seen_stream:
        # Users should never reach this, but if it happens, we want to know
        # about it
        raise ValueError("Did not find stream in args. Internal error")
    return args, kwargs


def _ensure_path(path: Union[str, Path]) -> Path:
    if isinstance(path, str):
        return Path(path)
    else:
        return path


def _source_is_sequence_dict(source: Any) -> bool:
    return (
        hasattr(source, "__iter__")
        and hasattr(source, "__len__")
        and not isinstance(source, (str, TextIOWrapper))
    )


def _source_is_iterable_dict(source: Any) -> bool:
    return hasattr(source, "__iter__") and not isinstance(source, (str, TextIOWrapper))


def _source_is_legacy_custom_loader(source: Any, loader: str) -> bool:
    from .loaders import get_loader as legacy_get_loader

    try:
        legacy_get_loader(loader, str(source))
    except ValueError:
        return False
    else:
        return True


def _source_is_path(
    path_type: Union[str, Tuple[str, ...]], source: Any, loader: Optional[str]
) -> bool:
    if isinstance(source, str):
        source = Path(source)
    if not isinstance(source, Path):
        return False
    elif loader is not None and isinstance(path_type, str) and loader == path_type:
        # If loader is specified, trust that rather than the extension.
        return True
    elif loader is None:
        if not source.exists():
            raise ValueError(
                f"Provided source: '{source}' was resolved as a Path but does not exist. "
                "If this is not a Path, try specifying an explicit loader. "
                "Otherwise, ensure the Path exists. "
                "If this is a dataset, remember to prefix the dataset name with `dataset:`."
            )
        file_exts = path_type if isinstance(path_type, tuple) else (path_type,)
        file_exts = [f".{ext}" if not ext.startswith(".") else ext for ext in file_exts]
        if any(source.suffix == path_type for path_type in file_exts):
            # If loader is None fallback to file path suffix
            return True
        elif any(any(source.glob(f"*{path_type}")) for path_type in file_exts):
            # If loader is None and source is a directory,
            # check if any of the files match the path_type suffix
            return True
        else:
            return False
    else:
        return False


def _source_is_api(source: Any, loader: Optional[str]) -> bool:
    if not isinstance(source, str):
        return False
    if isinstance(loader, str) and loader in registry.apis:
        return True
    return False


def _source_is_dataset(source: Any, loader: Optional[str]) -> bool:
    if not isinstance(source, str):
        source = str(source)
    if source.startswith("dataset:"):
        return True
    return False


def _source_is_stdin(source: Any, loader: Optional[str]) -> bool:
    if isinstance(source, str) and (source == "-"):
        return True
    return False


def _apply_paginated(func: Callable, iter_unsplit_in, args, kwargs) -> Iterator:
    from .preprocess import merge_pages, split_pages

    # First we split the stream, getting back an iterator over the pages
    # and a callback that allows us to reverse the operation.
    iter_split_in = split_pages(iter_unsplit_in)
    # Next, we need to assemble the *args and **kwargs to pass into the
    # func. This involves inserting the input iterator into them, wherever
    # we determined it should go (by default first, but could be elsewhere)
    args, kwargs = _replace_stream_placeholder(iter_split_in, args, kwargs)
    # Now we call our function. At this point we have a stream of split
    # pages where the necessary manipulation from our input func has
    # taken place.
    iter_split_out = func(*args, **kwargs)
    # Now we use our callback from the _split_pages function to reverse
    # the process.
    iter_unsplit_out = merge_pages(iter_split_out)
    return iter_unsplit_out
