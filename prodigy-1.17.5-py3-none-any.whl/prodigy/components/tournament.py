import random
from abc import ABC, abstractmethod
from collections import Counter
from typing import List, Tuple, Union

import numpy as np
import numpy.typing as npt

from ..util import log


class Tournament(ABC):
    def __init__(self, options: List[str]):
        assert len(options) == len(set(options))
        self._options = options
        self._matches = []

    @abstractmethod
    def top_k(self, k: int) -> List[str]:
        pass

    @abstractmethod
    def update(
        self, name_i: str, name_j: str, outcome: Union[int, float, bool]
    ) -> None:
        pass

    @property
    def player_counts(self):
        c = Counter()
        for i, j in self._matches:
            c[i] += 1
            c[j] += 1
        return c

    @property
    def match_log(self):
        return self._matches

    def _name2idx(self, name: str) -> int:
        return self._options.index(name)

    def _idx2name(self, idx: int) -> str:
        return self._options[idx]

    def _incr_match_logs(self, name_i: str, name_j: str):
        self._matches.append((name_i, name_j))


class RandomTournament(Tournament):
    def __init__(self, options: List[str]) -> None:
        super().__init__(options=options)
        self._wins = Counter(self._options)
        random.seed(42)

    def top_k(self, k: int = 2) -> List[str]:
        return [v for v, count in self._wins.most_common(k)]

    def update(self, name_i: str, name_j: str, outcome: Union[int, bool]) -> None:
        if outcome:
            self._wins[name_i] += 1
        if not outcome:
            self._wins[name_j] += 1
        self._incr_match_logs(name_i, name_j)


class GlickoTournament(Tournament):
    """
    Tournament based on: http://www.glicko.net/glicko/glicko.pdf
    """

    def __init__(self, options: List[str]) -> None:
        super().__init__(options=options)
        # Initial values per paper http://www.glicko.net/glicko/glicko.pdf
        self._ratings = np.array([[1500, 350] for _ in self._options])
        self._q = np.log(10.0) / 400.0

    def top_k(self, k=2) -> List[str]:
        """Return indices of top `k` values."""
        p_best = self._rank1_probs(self._ratings)
        return [self._idx2name(i) for i in np.argsort(p_best)[::-1][:k]]

    def update(self, name_i: str, name_j: str, outcome: float) -> None:
        """Update ratings array after matchup

        i (str): name of first player
        j (str): name of second player
        s (float): match outcome, player :i: wins = 1, player :i: loses = 0, draw = 0.5
        """
        i_idx, j_idx = self._name2idx(name_i), self._name2idx(name_j)
        r_1, RD_1 = self._ratings[i_idx]
        r_2, RD_2 = self._ratings[j_idx]
        r_delta_1, RD_prime_1 = self._glicko_update(r_1, RD_1, outcome, r_2, RD_2)
        r_delta_2, RD_prime_2 = self._glicko_update(r_2, RD_2, 1.0 - outcome, r_1, RD_1)
        self._ratings[i_idx, 0] += r_delta_1
        self._ratings[i_idx, 1] = RD_prime_1
        self._ratings[j_idx, 0] += r_delta_2
        self._ratings[j_idx, 1] = RD_prime_2
        updated_ratings = {
            name_i: {
                "rating": self._ratings[i_idx][0],
                "noise": self._ratings[i_idx][1],
            },
            name_j: {
                "rating": self._ratings[j_idx][0],
                "noise": self._ratings[j_idx][1],
            },
        }
        rating_keys = list(updated_ratings.keys())
        rating_keys.sort()
        self._incr_match_logs(name_i, name_j)
        log(
            details={k: updated_ratings[k] for k in rating_keys},
        )

    def _g(self, RD: npt.NDArray) -> npt.NDArray:
        return 1.0 / np.sqrt(1.0 + 3.0 * (self._q**2) * (RD**2) / np.pi**2)

    def _E(self, r: npt.NDArray, r_j: npt.NDArray, RD_j: npt.NDArray) -> npt.NDArray:
        return 1.0 / (1.0 + np.power(10, -self._g(RD_j) * (r - r_j) / 400.0))

    def _glicko_update(
        self,
        r: npt.NDArray,
        RD: npt.NDArray,
        s_j: Union[float, int],
        r_j: npt.NDArray,
        RD_j: npt.NDArray,
    ) -> Tuple[npt.NDArray, npt.NDArray]:
        """
        Glicko 1 rating update.

        r (numpy float): current player rating
        RD (numpy float): current player rating deviation
        s_j (float): outcome vector for player being updated; 0 for loss, 1 for win, 0.5 for draw
        r_j (numpy float): (N) opponent ratings vector
        RD_j (numpy float): (N) opponent rating deviations vector
        """
        ps = self._E(r, r_j, RD_j)
        d2 = 1.0 / ((self._q**2) * np.sum((self._g(RD_j) ** 2) * ps * (1.0 - ps)))
        r_delta = (self._q / (1.0 / RD**2 + 1.0 / d2)) * np.sum(
            self._g(RD_j) * (s_j - ps)
        )
        RD_prime = np.sqrt(1.0 / (1.0 / RD**2 + 1.0 / d2))
        return r_delta, RD_prime

    def _rank1_probs(self, ratings: npt.NDArray, num_samples=4000) -> npt.NDArray:
        """
        Estimate the probability of having the highest rating.

        ratings (numpy array): ratings with RD, first column is ratings, second column is ratings deviation.
        num_samples (int): number of samples to draw
        """
        assert ratings.ndim == 2
        assert ratings.shape[1] == 2
        assert num_samples > 0
        num_players = ratings.shape[0]
        loc = ratings[:, 0, np.newaxis]
        scale = ratings[:, 1, np.newaxis]
        samples = np.random.normal(
            loc=loc, scale=scale, size=(num_players, num_samples)
        )
        counts = np.bincount(np.argmax(samples, axis=0), minlength=num_players)
        p = counts / num_samples
        return p

    def _win_prob_bradley_terry(
        self, theta_1: npt.NDArray, theta_2: npt.NDArray, base=10, scale=400
    ) -> npt.NDArray:
        """
        Compute the bradley terry win probability p(s = 1 | theta_1, theta_2).
        This resembles the probability player with rating theta_1 beats player with rating theta_2.

        theta_1 (numpy float): known rating 1
        theta_2 (numpy float): known rating 2
        """
        odds = base ** ((theta_1 - theta_2) / scale)
        p = odds / (1 + odds)
        return p
