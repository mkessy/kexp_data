import csv
import sys
from pathlib import Path
from typing import Callable, Iterable, Optional, Union, cast

import srsly
from cloudpathlib import AnyPath, CloudPath

from ..errors import RecipeError
from ..types import PathInputType, PathType, SourceType, StreamType, TaskType, ViewId
from ..util import (
    BINARY_ATTR,
    PAGE_NUM_ATTR,
    UNSET,
    ensure_path,
    file_to_b64,
    log,
    registry,
    set_hashes,
)
from .db import connect
from .filters import filter_duplicates, filter_empty

IMAGE_FILE_EXT = (".jpg", ".jpeg", ".png", ".gif", ".svg")
AUDIO_FILE_EXT = (".mp3", ".m4a", ".wav")
VIDEO_FILE_EXT = (".mpeg", ".mpg", ".mp4")


def _rehash_stream(stream: StreamType) -> StreamType:
    for eg in stream:
        yield set_hashes(eg, overwrite=True)


def _add_attrs(stream: StreamType, is_binary: Optional[bool] = None) -> StreamType:
    # Using a more generic helper here in case we ever need more attributes
    for eg in stream:
        if is_binary is not None:
            eg[BINARY_ATTR] = is_binary
        yield eg


def get_stream(
    source: SourceType,
    *,
    loader: Optional[str] = None,
    rehash: bool = False,
    dedup: bool = False,
    input_key: Union[str, object] = UNSET,
    skip_invalid: bool = True,
    is_binary: Optional[bool] = None,
) -> StreamType:
    """Get a stream of annotation examples. Mostly used to process arguments
    passed in via the command line.
    source (str): The source (file path or "-" to read from standard input).
    loader (str): ID of a loader, e.g. "json" or "csv".
    rehash (bool): Asssign new hashes to the stream.
    dedup (bool): Remove duplicates from the stream.
    input_key (str): Task key containing the input data. If set, empty
        values will be filtered out.
    skip_invalid (bool): If input_key is set, skip invalid or empty examples
        instead of raising an error. Defaults to True.
    is_binary (bool): Whether the examples in the stream are binary or manual
        annotations. Added as an attribute to the tasks. If not set, no
        attribute will be added.
    RETURNS (stream): The stream of annotation examples.
    """
    stream: Optional[StreamType] = None
    loader_id = None
    if hasattr(source, "__iter__") and not isinstance(source, (str, Path, CloudPath)):
        log("LOADER: Using supplied iterable source as stream", repr(source))
        stream = iter(source)  # pyright: ignore
    elif isinstance(source, str) and source.startswith("dataset:"):
        dataset_name = source.replace("dataset:", "")
        answer = "all"
        if ":" in dataset_name:
            dataset_name, answer = dataset_name.rsplit(":", 1)
        log(f"LOADER: Loading stream from dataset {dataset_name} (answer: {answer})")
        db = connect()
        if dataset_name not in db:
            raise RecipeError(f"Can't find dataset {dataset_name} in database")
        stream = iter(db.get_dataset_examples(dataset_name))
        if answer != "all":
            stream = iter([eg for eg in stream if eg.get("answer") == answer])
    else:
        if source is None or source == "-":
            loader_id = loader or "jsonl"
            source = sys.stdin
            log("LOADER: Reading stream from sys.stdin")
        elif isinstance(source, (str, Path, CloudPath)):
            if (
                isinstance(loader, str) and loader not in registry.loaders
            ) or loader is None:
                path = AnyPath(source)
                assert isinstance(path, (Path, CloudPath))
                loader_id = path.suffix[1:]
                log(
                    f"LOADER: Using file extension '{loader_id}' to find loader", source
                )
            else:
                loader_id = loader
        try:
            assert loader_id is not None
            loader_func = get_loader(loader_id)
        except Exception as e:
            raise RecipeError(f"Couldn't get loader for {loader_id}", e) from e
        stream = loader_func(source)
    assert stream is not None
    # stream can be a Iterator[TaskType] or Iterator[Unknown]
    # because I called `iter` when source is an iterable or a list
    # Perhaps the db methods should return StreamType directly?
    # At this point I think it's safe to cast to StreamType but I'm not 100% sure
    stream = cast(StreamType, stream)
    if rehash:
        log("LOADER: Rehashing stream")
        stream = _rehash_stream(stream)
    if input_key is not UNSET:
        stream = filter_empty(stream, key=input_key, skip=skip_invalid)
    if dedup:
        stream = filter_duplicates(stream, by_input=True)  # type: ignore
    stream = _add_attrs(cast(StreamType, stream), is_binary=is_binary)
    return stream


def get_loader(
    loader_id: Optional[str], file_path: Optional[PathInputType] = None
) -> Callable[[SourceType], StreamType]:
    """Get the respective loader based on a loader or API ID and/or file path.
    If no loader is set, it will be guessed based on the file extension.
    loader_id (str): Name of loader or API to use, or None.
    file_path (str / Path): Path to source file to guess loader.
    Raises:
        ValueError: When loader cannot be found.
    RETURNS (callable): The loader.
    """
    if (not loader_id or loader_id not in registry.loaders) and file_path:
        path = AnyPath(file_path)
        assert isinstance(path, (Path, CloudPath))
        loader_id = path.suffix[1:]
        log(f"LOADER: Using file extension '{loader_id}' to find loader", file_path)
    if loader_id and loader_id in registry.loaders:
        log(f"LOADER: Loading stream from {loader_id}")
        return registry.loaders.get(loader_id)
    raise ValueError(f"No loader found for '{loader_id}'")


def is_matching_file(file_path: PathType, suffix: str) -> bool:
    return (
        file_path.is_file()
        and not file_path.name.startswith(".")
        and (
            file_path.suffix.lower() == f".{suffix.lower()}"
            or (file_path.suffix == "" and suffix == "")
        )
    )


def read_jsonl(file_path: PathType) -> StreamType:
    """Stream JSONL.

    f (Path): The JSONL file to read in.
    YIELDS (dict): The annotation tasks.
    """
    f = file_path.open("r", encoding="utf8")
    n_lines = 0
    for line in f:
        n_lines += 1
        try:  # hack to handle broken jsonl
            task = cast(TaskType, srsly.json_loads(line.strip()))
            if not isinstance(task, dict):
                err = f"Invalid task: expected dict, got {type(task)}"
                raise RecipeError(err, repr(task))
            yield task
        except ValueError as e:
            err_title = f"Failed to load task (invalid JSON in file {file_path.resolve()} on line {n_lines})"
            err = (
                "This error pretty much always means that there's something "
                "wrong with this line of JSON and Python can't load it. Even "
                "if you think it's correct, something must confuse it. Try "
                "calling json.loads(line) on each line or use a JSON linter."
            )
            raise RecipeError(err_title, err) from e


@registry.loaders.register("jsonl")
def JSONL(f: PathInputType, suffix: str = "jsonl") -> StreamType:
    """Check if f is a file or directory and call read_jsonl accordingly,
    on the JSONL file directly or on every JSONL file in the given directory.

    file_path (str / Path / file): The JSONL file or the directory of JSONL files to read in.
    suffix (str): File extension used when iterating through folders. Default: ".jsonl"
    YIELDS (dict): The annotation tasks.
    """
    file_path = ensure_path(f)
    if not file_path.exists():
        raise RecipeError(f"Can't find path {f}", file_path.resolve())
    if file_path.is_file():
        for task in read_jsonl(file_path):
            yield task
    elif file_path.is_dir():
        for sub_file_path in sorted(file_path.iterdir()):
            if is_matching_file(sub_file_path, suffix):
                for task in read_jsonl(sub_file_path):
                    yield task


def read_json(file_path: PathType) -> StreamType:
    """Stream JSON.

    file_path (Path): The JSON file to read in.
    YIELDS (dict): The annotation tasks.
    """
    with file_path.open("r", encoding="utf8") as f:
        stream = srsly.json_loads(f.read())
    if not isinstance(stream, list):
        raise RecipeError(f"Invalid JSON file: expected list, got {type(stream)}")
    assert isinstance(stream, list)
    for task in stream:
        if not isinstance(task, dict):
            err = f"Invalid task: expected dict, got type {type(task)}"
            raise RecipeError(err, repr(task))
        yield task


@registry.loaders.register("json")
def JSON(f: PathInputType, suffix: str = "json") -> StreamType:
    """Check if f is a file or directory and call read_json accordingly,
    on the JSON file directly or on every JSON file in the given directory.

    f (str / Path / file): The JSON file or the directory containing JSON files to read in.
    suffix (str): File extension used when iterating through folders. Default: ".json"
    YIELDS (dict): The annotation tasks.
    """
    file_path = ensure_path(f)
    if not file_path.exists():
        raise RecipeError(f"Can't find file {f}", file_path.resolve())
    if file_path.is_file():
        for task in read_json(file_path):
            yield task
    elif file_path.is_dir():
        for sub_file_path in sorted(file_path.iterdir()):
            if is_matching_file(sub_file_path, suffix):
                for task in read_json(sub_file_path):
                    yield task


def read_csv(file_path: PathType, delimiter: str) -> StreamType:
    """Read CSV and parse contents as dict, keyed by title row.

    file_path (Path): The CSV file or directory of CSV files to read in.
    YIELDS (dict): The annotation tasks.
    """
    f = file_path.open("r", encoding="utf8")
    reader = csv.DictReader(f, delimiter=delimiter)
    for row in reader:
        row = {key.lower(): value for key, value in row.items() if isinstance(key, str)}
        text = row.get("text", "")
        if text == "":
            continue
        task = {"text": text}
        if "label" in row:
            task["label"] = row["label"]
        if "meta" in row:
            task["meta"] = {"meta": row["meta"]}
        if PAGE_NUM_ATTR in row:
            task[PAGE_NUM_ATTR] = row[PAGE_NUM_ATTR]
        yield task


@registry.loaders.register("csv")
def CSV(f: PathInputType, suffix: str = "csv", delimiter: str = ",") -> StreamType:
    """Check if f is a file or directory and call read_csv accordingly,
    on the csv file directly or on every csv file in the given directory.

    f (str / Path / file): The CSV file to read in.
    suffix (str): File extension used when iterating through folders. Default: ".csv"
    YIELDS (dict): The annotation tasks.
    """
    file_path = ensure_path(f)
    if not file_path.exists():
        raise RecipeError(f"Can't find file {f}", file_path.resolve())
    if file_path.is_file():
        for task in read_csv(file_path, delimiter=delimiter):
            yield task
    elif file_path.is_dir():
        for sub_file_path in sorted(file_path.iterdir()):
            if is_matching_file(sub_file_path, suffix):
                for task in read_csv(sub_file_path, delimiter=delimiter):
                    yield task


def read_txt(file_path: PathType) -> StreamType:
    """Read TXT line by line and yield text task.

    file_path (Path): The text file to read in.
    YIELDS (dict): The annotation tasks.
    """
    for line in file_path.open("r", encoding="utf8"):
        if line != "":
            yield {"text": line.strip()}


def read_paginated_txt(file_path: PathType, view_id: ViewId) -> StreamType:
    """Create paginated examples for records separated by 2 line breaks.

    file_path (Path): The text file to read in.
    YIELDS (dict): The annotation tasks.
    """
    pages = []
    for line in file_path.open("r", encoding="utf8"):
        line = line.strip()
        if line != "":
            pages.append({"text": line, "view_id": view_id})
        elif pages:
            yield {"pages": pages}
            pages = []
    if pages:
        yield {"pages": pages}


@registry.loaders.register("txt")
def TXT(f: PathInputType, suffix: str = "txt") -> StreamType:
    """Check if f is a file or directory and call read_txt accordingly,
    on the TXT file directly or on every TXT file in the given directory.

    f (str / Path): The text file or folder containing text files to read in.
    suffix (str): File extension used when iterating through folders. Default: ".txt"
    YIELDS (dict): The annotation tasks.
    """
    file_path = ensure_path(f)
    if not file_path.exists():
        raise RecipeError(f"Can't find file {f}", file_path.resolve())
    if file_path.is_file():
        for task in read_txt(file_path):
            yield task
    elif file_path.is_dir():
        for sub_file_path in sorted(file_path.iterdir()):
            if is_matching_file(sub_file_path, suffix):
                for task in read_txt(sub_file_path):
                    yield task


@registry.loaders.register("images")
def Images(
    f: PathInputType, file_ext: Optional[Iterable[str]] = IMAGE_FILE_EXT
) -> StreamType:
    """Stream in images from a directory."""
    yield from Base64(f, "image", file_ext=file_ext)


@registry.loaders.register("audio")
def Audio(
    f: PathInputType, file_ext: Optional[Iterable[str]] = AUDIO_FILE_EXT
) -> StreamType:
    """Stream in audio from a directory."""
    yield from Base64(f, "audio", file_ext=file_ext)


@registry.loaders.register("video")
def Video(
    f: PathInputType, file_ext: Optional[Iterable[str]] = VIDEO_FILE_EXT
) -> StreamType:
    """Stream in videos from a directory."""
    yield from Base64(f, "video", file_ext=file_ext)


def Base64(
    f: PathInputType,
    input_key: str,
    file_ext: Optional[Iterable[str]] = None,
) -> StreamType:
    """Stream in files from a directory and convert them to base64.

    f (str / Path): The directory containing the files.
    input_key (str): The key to assign the URL to, e.g. "image".
    file_ext (list / tuple): Allowed file extensions. None for all files.
        (Caution: This may include hidden files!)
    YIELDS (dict): The annotation tasks.
    """
    dir_path = ensure_path(f)
    if not dir_path.exists() or not dir_path.is_dir():
        raise RecipeError(f"Can't load from directory: {f}", dir_path.resolve())
    for file_path in sorted(dir_path.iterdir()):
        if (
            file_path.is_file()
            and not file_path.name.startswith(".")
            and (file_ext is None or file_path.suffix.lower() in file_ext)
        ):
            data = file_to_b64(file_path)
            yield cast(
                TaskType,
                {
                    input_key: data,
                    "text": file_path.stem,
                    "meta": {"file": file_path.parts[-1]},
                    "path": str(file_path),
                },
            )


def Server(
    f: PathInputType,
    input_key: str,
    file_ext: Optional[Iterable[str]] = None,
) -> StreamType:
    """Load files from a local directory and expose them as static files
    using the Prodigy server. This allows loading large images, audio files etc.
    without having to send them back and forth. (Using local paths won't work,
    as modern browsers block embeds from local paths.)

    f (str / Path): The directory containing the files.
    input_key (str): The key to assign the URL to, e.g. "image".
    file_ext (list / tuple): Allowed file extensions. None for all files.
        (Caution: This may include hidden files!)
    YIELDS (dict): The annotation tasks.
    """
    # Import this in the function body, to avoid nasty circular imports
    from ..app import mount_user_files

    dir_path = ensure_path(f)
    if not dir_path.exists() or not dir_path.is_dir():
        raise RecipeError(f"Can't load from directory: {f}", dir_path.resolve())
    if not isinstance(dir_path, Path):
        raise RecipeError(f"Can only use server loader with local paths {f}")
    base_url = mount_user_files(dir_path)
    for file_path in sorted(dir_path.iterdir()):
        if (
            file_path.is_file()
            and not file_path.name.startswith(".")
            and (file_ext is None or file_path.suffix.lower() in file_ext)
        ):
            yield cast(
                TaskType,
                {
                    input_key: f"{base_url}/{file_path.parts[-1]}",
                    "text": file_path.stem,
                    "meta": {"file": str(file_path.parts[-1])},
                    "path": str(file_path),
                },
            )


@registry.loaders.register("image-server")
def ImageServer(
    f: PathInputType, file_ext: Optional[Iterable[str]] = IMAGE_FILE_EXT
) -> StreamType:
    """Serve image files from a local directory."""
    yield from Server(f, "image", file_ext=file_ext)


@registry.loaders.register("audio-server")
def AudioServer(
    f: PathInputType, file_ext: Optional[Iterable[str]] = AUDIO_FILE_EXT
) -> StreamType:
    """Serve audio files from a local directory."""
    yield from Server(f, "audio", file_ext=file_ext)


@registry.loaders.register("video-server")
def VideoServer(
    f: PathInputType, file_ext: Optional[Iterable[str]] = VIDEO_FILE_EXT
) -> StreamType:
    """Serve video files from a local directory."""
    yield from Server(f, "video", file_ext=file_ext)


def _add_page_view_id(stream: StreamType, view_id: ViewId) -> StreamType:
    for eg in stream:
        for page in eg.get("pages", []):
            page["view_id"] = view_id
        yield eg


@registry.loaders.register("pages")
def Pages(
    f: PathInputType,
    view_id: ViewId,
    loader: Optional[str] = None,
) -> StreamType:
    """Load multi-page tasks from a directory. For images, it expects one
    subdirectory per task containing the images, i.e. pages. For text, it
    expects a directory of single files per task containing the pages (although
    sub-folders should work as well).
    """
    from .preprocess import merge_pages

    log("LOADER: Load multi-page tasks")
    path = ensure_path(f)
    if not path.exists():
        raise RecipeError(f"Can't load from file or directory: {f}", path.resolve())
    if not loader:
        if not path.suffix:
            raise RecipeError(
                "No content type specified for pages loader and can't resolve it "
                "based on the file extension. Set --loader pages:jsonl etc. to specify "
                "the expected content."
            )
        loader = path.suffix[1:]
    resolved_loader = registry.loaders.get(loader)
    if loader in ("json", "jsonl"):
        stream = resolved_loader(path)
        merged_stream = merge_pages(stream)
        yield from _add_page_view_id(merged_stream, view_id)  # type: ignore
    elif loader == "txt":
        yield from read_paginated_txt(path, view_id=view_id)
    else:
        for sub_path in sorted(path.iterdir()):
            if sub_path.name.startswith("."):
                continue
            eg = {"pages": [], "meta": {"title": sub_path.stem}}
            for page in resolved_loader(sub_path):
                page["view_id"] = view_id
                eg["pages"].append(page)
            eg = set_hashes(eg)
            yield eg
