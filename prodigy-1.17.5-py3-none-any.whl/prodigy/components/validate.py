import copy
import sys
from dataclasses import dataclass
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    List,
    Optional,
    Tuple,
    Type,
    Union,
)

from pydantic import BaseModel, ValidationError
from wasabi.printer import Printer

from ..errors import RecipeValidationError
from ..types import (
    AudioTask,
    BlocksTask,
    ChoiceTask,
    ClassificationTask,
    CompareTask,
    Config,
    DepTask,
    DiffTask,
    HtmlTask,
    ImageTask,
    PagesTask,
    RecipeComponents,
    RelationsTask,
    ReviewTask,
    SpansManualTask,
    SpansTask,
    TextInputTask,
    TextTask,
)
from ..util import log

if TYPE_CHECKING:
    from pydantic.error_wrappers import ErrorDict

SCHEMAS = {
    "text": TextTask,
    "classification": ClassificationTask,
    "spans": SpansTask,
    "spans_manual": SpansManualTask,
    "ner": SpansTask,
    "ner_manual": SpansManualTask,
    "pos": SpansTask,
    "pos_manual": SpansManualTask,
    "dep": DepTask,
    "image": ImageTask,
    "image_manual": ImageTask,
    "html": HtmlTask,
    "compare": CompareTask,
    "diff": DiffTask,
    "choice": ChoiceTask,
    "review": ReviewTask,
    "text_input": TextInputTask,
    "blocks": BlocksTask,
    "audio": AudioTask,
    "audio_manual": AudioTask,
    "relations": RelationsTask,
    "pages": PagesTask,
}


def get_schema(
    view_id: str, json: bool = True
) -> Union[Dict[str, Any], Type[BaseModel]]:
    """Get the schema for a given view ID (called by Validator or the user).

    view_id (unicode): The view ID to get the schema for.
    json (bool): Return schema as JSON schema instead of pydantic model.
    RETURNS (dict / BaseModel): The schema.
    """
    if view_id not in SCHEMAS:
        raise RecipeValidationError(
            f"Not a valid view ID: '{view_id}'",
            f"Available: {', '.join(SCHEMAS.keys())}",
        )
    schema = SCHEMAS[view_id]
    if json:
        return schema.schema_json()
    return schema


def validate_config(config: Dict[str, Any]) -> None:
    log("VALIDATE: Validating Prodigy and recipe config")
    error_msg = "Invalid settings found in prodigy.json and/or recipe config"
    validate(Config, config, error_msg=error_msg, print_obj=False)


def validate_recipe(name: str, components: Dict[str, Any]) -> None:
    log("VALIDATE: Validating components returned by recipe")
    error_msg = f"Invalid components returned by recipe '{name}'"
    validate(RecipeComponents, components, error_msg=error_msg)


@dataclass
class ValidationErrorMsg:
    loc: Tuple[Union[int, str], ...]
    msg: str

    @classmethod
    def from_error_dict(cls, data: "ErrorDict") -> "ValidationErrorMsg":
        return cls(loc=data.get("loc", tuple()), msg=data["msg"])


def get_validation_error_msg(
    errors: List[ValidationErrorMsg], base_msg: Optional[str] = None
) -> str:
    """Generate a custom Prodigy style error message from a list of
        ErrorDicts. ErrorDicts can be retrieved from a Pydantic
        ValidationError with `validation_error.errors()`
    errors (List[ErrorDict]): List of ErrorDicts to display
    base_msg (str): Top level Error Message
    RETURNS (str): Prodigy style formatted Error Message
    """
    error_printer = Printer(no_print=True)
    error_msg = ""
    if base_msg is not None:
        error_msg = error_printer.fail(f"{base_msg}\n")
        assert error_msg is not None
    data = []
    for error in errors:
        err_loc = " -> ".join([str(p) for p in error.loc])
        data.append((err_loc, error.msg))
    table = error_printer.table(data)
    if table is not None:
        error_msg += table
    return error_msg


def validate(
    Schema: Type[BaseModel],
    obj: Dict[str, Any],
    error_msg: str = "Validation error",
    print_obj: bool = True,
) -> None:
    """Validate a JSON object with a given schema.

    Schema (pydantic.BaseModel): The pydantic model to check against.
    obj (dict): The object to validate.
    error_msg (str): Optional custom error message to show.
    print_obj (bool): Whether to also print the object on error.
    """
    try:
        Schema(**obj)
    except ValidationError as e:
        errors = e.errors()
        if errors:
            val_errors = [
                ValidationErrorMsg.from_error_dict(err_dict) for err_dict in errors
            ]
            validation_err_msg = get_validation_error_msg(val_errors, error_msg)
            print(validation_err_msg)  # noqa: T201
            if print_obj:
                print(format_obj(obj))  # noqa: T201
        sys.exit(1)


def format_obj(
    obj: Dict[str, Any],
    keys: Iterable[str] = ("text", "image", "audio", "video"),
    max_length: int = 200,
) -> Dict[str, Any]:
    """Reformat task dict with base64 keys to not clog up the terminal."""
    try:
        obj = copy.deepcopy(obj)
    except TypeError:
        return obj
    for key in keys:
        if key in obj and isinstance(obj[key], str) and len(obj[key]) > max_length:
            obj[key] = f"{obj[key][:max_length]}..."
    return obj


class Validator:
    """Validate incoming tasks against JSON schemas."""

    def __init__(self, view_id: str) -> None:
        log(f"VALIDATE: Creating validator for view ID '{view_id}'")
        self.view_id = view_id
        self.Schema = get_schema(view_id, json=False)
        self.error_msg = f"Invalid task format for view ID '{self.view_id}'"

    def check(self, obj: Dict[str, Any]) -> None:
        """Check a task and raise an error if it's not valid.

        obj (dict): The task to validate.
        """
        if not isinstance(obj, dict):
            log(f"FEED: Invalid task: expected dict, got {type(obj)}", obj)
            err = (
                "This error usually happens when you pass in a stream of "
                "`(score, example)` tuples returned by the model without "
                "using a sorter. If you don't want to use a sorter, make "
                "sure to filter out the scores: "
                "stream = (eg for score, eg in stream)"
            )
            raise RecipeValidationError(
                f"Invalid task: expected dict, got {type(obj)}", err
            )
        pages = obj.get("pages")
        if not pages:
            # this can be ignored is self.Schema is guaranteed to be a BaseModel
            validate(self.Schema, obj, error_msg=self.error_msg)  # type: ignore
        else:
            validate(PagesTask, obj, error_msg=self.error_msg)
            for page in pages:
                page_schema = (
                    self.Schema
                    if self.view_id != "pages"
                    else get_schema(page["view_id"], json=False)
                )
                validate(page_schema, page, error_msg=self.error_msg)  # type: ignore

    def is_valid(self, obj: Dict[str, Any]) -> bool:
        """
        obj (dict): The task to check.
        RETURNS (bool): Whether the task is valid.
        """
        try:
            # this can be ignored is self.Schema is guaranteed to be a BaseModel
            self.Schema(**obj)  # type: ignore
            return True
        except ValidationError:
            return False
