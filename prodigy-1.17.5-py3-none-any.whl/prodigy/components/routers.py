from typing import TYPE_CHECKING, Dict, List

from ..protocols import TaskRouterProtocol
from ..structured_types import get_input_hash, get_task_hash
from ..util import INPUT_HASH_ATTR, SESSION_ID_ATTR, TASK_HASH_ATTR, log

if TYPE_CHECKING:
    from ..core import Controller


def log_router(hash_attr: str, hash_val: int, annot: List[str]) -> None:
    out = f"ROUTER: Routing item with {hash_attr}={hash_val} -> {annot}"
    log(details=out)


def route_average_per_task(average: float) -> TaskRouterProtocol:
    """Uses the task/input hash to ensure consistency across annotators."""
    if average < 1:
        raise ValueError(f"Number of annotators must be at least 1. Got {average}")

    def _task_router(ctrl: "Controller", session_id: str, item: Dict) -> List[str]:
        # If task_hash appears enough times already, don't add annotators
        nonlocal average
        hash_attr = TASK_HASH_ATTR if ctrl.exclude_by == "task" else INPUT_HASH_ATTR
        item_hash = (
            get_task_hash(item) if ctrl.exclude_by == "task" else get_input_hash(item)
        )
        assert ctrl.dataset
        hash_count = ctrl.db.get_hash_count(ctrl.dataset, hash=item_hash, kind=ctrl.exclude_by)  # type: ignore
        if hash_count >= average:
            return []

        # If there is already an annotation in the db, we should keep that in mind
        annots_needed = average - hash_count
        pool = ctrl.session_ids
        h = item_hash
        annot = []

        # Ensure that annotators that have already annotated don't get to re-appear in the annot list!
        # Since this is a DB query, for speed, only run when we have to.
        if hash_count > 0:
            annot_examples = ctrl.db.get_dataset_examples_by_hash(
                ctrl.dataset, hash=item_hash, kind=ctrl.exclude_by
            )
            allready_annotated = [ex[SESSION_ID_ATTR] for ex in annot_examples]
            pool = [u for u in pool if u not in allready_annotated]

        # Keep adding whole annotators
        while len(annot) < int(annots_needed // 1):
            if len(pool) == 0:
                log_router(hash_attr, item_hash, annot)
                return annot
            idx = h % len(pool)
            annot.append(pool.pop(idx))

        # In case of average=1.5 we need to do something probalistic.
        if len(annot) < annots_needed:
            if len(pool) == 0:
                log_router(hash_attr, item_hash, annot)
                return annot
            prob_from_hash = h / 1000 % 1
            prob_required = annots_needed % 1
            if prob_from_hash < prob_required:
                idx = h % len(pool)
                annot.append(pool.pop(idx))
        log_router(hash_attr, item_hash, annot)
        return annot

    return _task_router


def no_overlap(ctrl: "Controller", session_id: str, item: Dict) -> List[str]:
    """Just let the current session_id take it."""
    hash_attr = TASK_HASH_ATTR if ctrl.exclude_by == "task" else INPUT_HASH_ATTR
    item_hash = (
        get_task_hash(item) if ctrl.exclude_by == "task" else get_input_hash(item)
    )
    annot = [session_id]
    log_router(hash_attr, item_hash, annot)
    return annot


def full_overlap(ctrl: "Controller", session_id: str, item: Dict) -> List[str]:
    """Enforce each example to be seen by everyone."""
    hash_attr = TASK_HASH_ATTR if ctrl.exclude_by == "task" else INPUT_HASH_ATTR
    item_hash = (
        get_task_hash(item) if ctrl.exclude_by == "task" else get_input_hash(item)
    )
    annot = ctrl.session_ids
    log_router(hash_attr, item_hash, annot)
    return annot
