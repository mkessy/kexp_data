import copy
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, cast, get_args

import requests
from spacy.language import Language
from spacy.tokens import Doc, Token
from spacy_llm.pipeline import LLMWrapper
from spacy_llm.ty import LLMTask
from tqdm import tqdm

from ..structured_types import Example
from ..types import StreamType, TaskType, ViewId
from ..util import (
    ANNOTATOR_ID_ATTR,
    DEFAULT_NLP_BATCH_SIZE,
    PAGE_NUM_ATTR,
    PAGE_TITLE_ATTR,
    PAGES_KEYS,
    SESSION_ID_ATTR,
    VIEW_ID_ATTR,
    bytes_to_b64,
    file_to_b64,
    get_config,
    log,
    msg,
    set_hashes,
)
from .decorators import support_both_streams, support_structured


@support_structured(
    stream_arg="stream",
    input_keys=["text"],
    server_ann_keys=["spans", "tokens", "entities"],
)
@support_both_streams(stream_arg="stream")
def split_sentences(
    nlp: "Language",
    stream: StreamType,
    text_key: str = "text",
    batch_size: int = 32,
    min_length: Optional[int] = None,
) -> StreamType:
    """Split examples in a stream into sentences using spaCy. Setting a
    min_length will only split texts longer than a certain number of
    characters. This lets you use your own logic, while still preventing very
    long examples from throwing off the beam search and affecting performance.
    If no min_length is set, Prodigy will check the config for a
    'split_sents_threshold' setting.

    nlp (spacy.language.Language): spaCy pipeline with sentence boundary detector.
    stream (iterable): The stream of examples.
    text_key (str): The task key containing the text, defaults to 'text'.
    batch_size (int): Batch size to use when piping examples through spaCy.
    min_length (int): Minimum character length of text to be split. If None,
        Prodigy will check the config for a 'split_sents_threshold' setting. If
        False, all texts are split, if possible.
    YIELDS (dict): The annotation examples.
    """
    log("PREPROCESS: Splitting sentences", locals())
    if not min_length:
        config = get_config()
        min_length = config.get("split_sents_threshold", False)
    tuples = ((eg[text_key], eg) for eg in stream)
    no_sents_warned = False
    for doc, orig_eg in nlp.pipe(tuples, as_tuples=True, batch_size=batch_size):
        orig_eg = copy.deepcopy(orig_eg)
        _add_tokens(orig_eg, doc, True)
        if min_length and len(doc.text) < min_length:
            yield orig_eg
        else:
            if not doc.has_annotation("SENT_START"):
                if not no_sents_warned:
                    msg.warn(
                        "The model you're using isn't setting sentence "
                        "boundaries (e.g. via the parser or sentencizer). This "
                        "means that incoming examples won't be split into sentences."
                    )
                    no_sents_warned = True
                yield orig_eg
            else:
                for sent in doc.sents:
                    eg = copy.deepcopy(orig_eg)
                    eg[text_key] = sent.text
                    # Get the spans for the sentence.
                    spans = []
                    for span in eg.get("spans", []):
                        start = span["start"]
                        end = span["end"]
                        if start >= sent.start_char and end <= sent.end_char:
                            span = dict(span)
                            span["start"] = start - sent.start_char
                            span["end"] = end - sent.start_char  # Not an error
                            span["token_start"] -= sent[0].i
                            span["token_end"] -= sent[0].i
                            spans.append(span)
                    # Get the tokens for the sentence
                    eg["tokens"] = [get_token(token, i) for i, token in enumerate(sent)]
                    # Make offsets not relative to larger doc
                    for token in eg["tokens"]:
                        token["start"] = token["start"] - sent.start_char
                        token["end"] = token["end"] - sent.start_char  # Not an error
                    eg["spans"] = spans
                    if "entities" in eg:
                        eg["entities"] = spans
                    eg = set_hashes(eg, overwrite=True)
                    yield eg


@support_structured(
    stream_arg="stream",
    input_keys=["text"],
    server_ann_keys=["spans", "tokens", "entities"],
)
@support_both_streams(stream_arg="stream")
def split_spans(
    stream: StreamType, labels: Optional[Iterable[str]] = None
) -> StreamType:
    """Split a stream with multiple spans per example so that there's one
    span per task.

    stream (iterable): The stream of annotation tasks.
    labels (list): Only split spans for labels included in this list.
    YIELDS (dict): The annotation examples.
    """
    log("PREPROCESS: Splitting stream into examples with one span per task")
    for eg in stream:
        spans = eg.get("spans", [])
        if labels:
            spans = [span for span in spans if span["label"] in labels]
        if len(spans) == 1:
            score = spans[0].get("score", 1.0)
            eg.setdefault("meta", {}).setdefault("score", score)
            eg["spans"] = spans
            eg = set_hashes(eg)
            yield eg
        else:
            meta = eg.get("meta", {})
            for span in spans:
                task = {"text": eg["text"], "spans": [span], "meta": dict(meta)}
                task = set_hashes(task)
                meta["score"] = span.get("score", 1.0)
                yield task


def split_pages(stream: StreamType) -> StreamType:
    """Split a stream with multiple pages into individual tasks (one per page).

    stream (iterable): The stream of paginated annotation tasks.
    YIELDS (dict): The annotation examples.
    """
    for task in stream:
        if isinstance(task, Example):
            # TODO: Support pagination for structured tasks
            yield task
            continue
        elif not isinstance(task, dict):
            # Handles stream entries that are arbitrary stuff. Technically the loader
            # shouldn't allow this but people can have their stream be disorganised
            yield task
            continue
        extra_keys = [
            k for k in task.keys() if k not in PAGES_KEYS and not k.startswith("_")
        ]
        if not task.get("pages"):
            yield task
        elif any(extra_keys):
            raise ValueError(
                f"Paginated examples must only have the keys {', '.join(PAGES_KEYS)}. "
                f"Found extra keys: {extra_keys}"
            )
        else:
            page_titles = task.get("page_titles")
            pages = task["pages"]
            if page_titles and len(page_titles) != len(pages):
                raise ValueError(
                    "Paginated examples must have equal length 'page_titles' and 'pages' if 'page_titles' is provided"
                )
            for i, page in enumerate(pages):
                eg = copy.deepcopy(page)
                if page_titles and PAGE_TITLE_ATTR not in eg:
                    eg[PAGE_TITLE_ATTR] = page_titles[i]
                eg[PAGE_NUM_ATTR] = i
                eg.setdefault("meta", {})
                eg["meta"]["_parent"] = task.get("meta", {})
                if "answer" in task:
                    eg["answer"] = task["answer"]
                eg[VIEW_ID_ATTR] = page["view_id"]
                yield eg


def merge_pages(stream: StreamType) -> StreamType:
    """Merge a split paginated stream into tasks with pages. Pages belonging
    to the same task must be consecutive and in order, with ascending {PAGE_NUM_ATTR}
    values. For instance, if the page numbers are [0, 1, 2, 0, 1] the examples
    will be merged into [(0, 1, 2), (0, 1)].

    stream (iterable): The stream of split annotation tasks.
    YIELDS (dict): The annotation examples with pages.
    """

    def assemble_doc(current_pages):
        titles = [page[1] for page in current_pages]
        pages = [page[2] for page in current_pages]
        metas = [page[3] for page in current_pages]
        eg = set_hashes(
            {"pages": pages, "config": {"view_id": "pages"}, "meta": metas[0]}
        )
        if any(title is not None for title in titles):
            eg["page_titles"] = titles
        return eg

    current_pages = []
    for task in stream:
        if isinstance(task, Example):
            # TODO: Support pagination for structured tasks
            yield task
            continue
        elif not isinstance(task, dict):
            # Handles stream entries that are arbitrary stuff. Technically the loader
            # shouldn't allow this but people can have their stream be disorganised
            yield task
            continue
        if PAGE_NUM_ATTR not in task:
            if current_pages:
                yield assemble_doc(current_pages)
                current_pages = []
            yield task
        else:
            page = copy.deepcopy(task)
            parent_meta = task.get("meta", {}).get("_parent", {})
            page_num = page.pop(PAGE_NUM_ATTR)
            page_title = page.pop(PAGE_TITLE_ATTR, None)
            if current_pages and current_pages[-1][0] >= page_num:
                # If our page number is less than the previous one, we're at a
                # document boundary, so we should reassemble.
                yield assemble_doc(current_pages)
                current_pages = [(page_num, page_title, page, parent_meta)]
            else:
                current_pages.append((page_num, page_title, page, parent_meta))
    if current_pages:
        yield assemble_doc(current_pages)


def make_raw_doc(nlp: "Language", eg: TaskType) -> Doc:
    tokens = eg.get("tokens", [])
    if tokens:
        words = [token["text"] for token in tokens]
        spaces = [token.get("ws", True) for token in tokens]
        return Doc(nlp.vocab, words=words, spaces=spaces)
    return nlp.make_doc(eg["text"])


def check_retokenizes(nlp: "Language") -> bool:
    """Check whether a pipeline contains components that retokenize. This
    information can be used to decide whether the whole pipeline needs to be
    run to create a tokenized Doc (slower) or whether we can fall back to
    nlp.make_doc / nlp.pipe with all components disabled (faster).

    RETURNS (bool): Whether the pipeline retokenizes.
    """
    analysis = nlp.analyze_pipes()
    assert analysis is not None
    # it doesn't seem like analyze_pipes ever returns None but its return type is Optional
    return any(v["retokenizes"] for v in analysis["summary"].values())


@support_structured(
    stream_arg="stream",
    input_keys=["text"],
    server_ann_keys=["spans", "tokens", "entities"],
)
@support_both_streams(stream_arg="stream")
def add_tokens(
    nlp: "Language",
    stream: StreamType,
    skip: bool = False,
    overwrite: bool = False,
    batch_size: int = 10,
) -> StreamType:
    """Add a 'tokens' key to each example in the stream. If the example
    has spans, each span is updated with a token_start and token_end key.

    nlp (spacy.language.Language): spaCy pipeline with a tokenizer.
    stream (iterable): The stream of examples.
    skip (bool): Skip mismatched tokenization instead of raising an error.
    YIELDS (dict): The annotation examples with added tokens.
    """
    retokenizes = check_retokenizes(nlp)
    log(
        f"PREPROCESS: Tokenizing examples "
        f"({'running whole pipeline because components retokenize' if retokenizes else 'running tokenizer only'})"
    )
    data = ((eg["text"], eg) for eg in stream)
    # If a component in the pipeline retokenizes, we just run the whole pipeline
    # because it may depend on other annotations and we don't want to resolve
    # the whole tree of dependencies and make assumptions about which components
    # need to run. If no components retokenize, we assume it's safe to just run
    # the tokenizer only.
    disable = [] if retokenizes else nlp.pipe_names
    for doc, eg in nlp.pipe(
        data, as_tuples=True, batch_size=batch_size, disable=disable
    ):
        _add_tokens(eg, doc, skip, overwrite)
        yield eg


def get_token(token: "Token", i: int) -> Dict[str, Any]:
    """Create a token dict for a Token object. Helper function used inside
    add_tokens preprocessor or standalone if recipes need more flexibility.

    token (spacy.tokens.Token): The token.
    i (int): The index of the token. Important: we're not using token.i here,
        because that might not actually reflect the correct token index in the
        example (e.g. when sentence segmentation is enabled).
    RETURNS (dict): The token representation.
    """
    return {
        "text": token.text,
        "start": token.idx,
        "end": token.idx + len(token.text),
        "id": i,
        "ws": bool(token.whitespace_),
    }


def sync_spans_to_tokens(
    spans: List[Dict[str, Any]], tokens: List[Dict[str, Any]], skip: bool = False
) -> List[Dict[str, Any]]:
    """Given a list of spans and a list of tokens in Prodigy's format, adjust
    the spans to match the token boundaries, if needed.

    spans (list): The spans.
    tokens (list): The tokens to sync the spans with.
    skip (bool): Skip tokenization mismatches and don't raise.
    RETURNS (list): The updated spans.
    """
    starts = {token["start"]: token["id"] for token in tokens}
    ends = {token["end"]: token["id"] for token in tokens}
    err = (
        "Mismatched tokenization. Can't resolve span to token index {}. This "
        "can happen if your data contains pre-set spans. Make sure that the spans "
        "match spaCy's tokenization or add a 'tokens' property to your task.\n\n{}"
    )
    new_spans = []
    for span in spans:
        if "token_start" not in span:
            start_idx = span["start"]
            if start_idx not in starts:
                if not skip:
                    raise ValueError(err.format(start_idx, repr(span)))
                log("PREPROCESS: Skipping mismatched tokens", span)
                continue
            span["token_start"] = starts[start_idx]
        if "token_end" not in span:
            end_idx = span["end"]
            if end_idx not in ends:
                if not skip:
                    raise ValueError(err.format(end_idx, repr(span)))
                log("PREPROCESS: Skipping mismatched tokens", span)
                continue
            span["token_end"] = ends[end_idx]
        new_spans.append(span)
    return new_spans


def _add_tokens(
    eg: TaskType,
    doc: Doc,
    skip: bool,
    overwrite: bool = False,
) -> TaskType:
    if "tokens" not in eg or overwrite:
        eg["tokens"] = [get_token(token, i) for i, token in enumerate(doc)]
    if "spans" in eg:
        eg["spans"] = sync_spans_to_tokens(eg["spans"], eg["tokens"], skip)
    return eg


def fetch_task_media(eg: TaskType, input_key: str, skip: bool = False) -> TaskType:
    """Replace all paths and URLs in a stream with base64 data URIs. The
    `skip` keyword argument lets you specify whether to skip invalid files
    that can't be converted (e.g. because the path doesn't exist, or the URL
    can't be fetched). If set to `False`, Prodigy will raise a `ValueError` if
    it encounters invalid files.

    eg (dict): The annotation task.
    input_key (str): Task key containing the media, e.g. to 'image'.
    skip (bool): Skip examples with files that can't be fetched.
    RETURNS (dict): The example with fetched data URIs.
    """
    eg = copy.deepcopy(eg)
    media = eg[input_key]
    if media.startswith("data:"):  # valid base64-encoded data URI
        return eg
    elif media.startswith("http://") or media.startswith("https://"):
        r = requests.get(media, stream=True)
        if r.status_code != 200:
            if not skip:
                raise ValueError(f"Can't download media: {input_key}")
            log(f"PREPROCESS: Skipping media (status {r.status_code}): {media}", eg)
            return eg
        mimetype = r.headers["content-type"]
        data = BytesIO(r.content).getvalue()
        eg[input_key] = bytes_to_b64(data, mimetype)
        eg["path"] = media
        return eg
    elif Path(media).exists():  # file is local path
        eg[input_key] = file_to_b64(Path(media))
        eg["path"] = media
        return eg
    elif not skip:
        err = f"Invalid '{input_key}' - doesn't seem to be a data URI, URL or local path: {media}"
        raise ValueError(err)
    log(f"PREPROCESS: Skipping '{input_key}' (no data URI, URL or path)", media)
    return eg


@support_structured(stream_arg="stream", input_keys=["image", "audio", "video"])
@support_both_streams(stream_arg="stream")
def fetch_media(
    stream: StreamType,
    input_keys: Iterable[str] = ("image", "audio", "video"),
    skip: bool = False,
) -> StreamType:
    """Replace all paths and URLs in a stream with base64 data URIs. The
    `skip` keyword argument lets you specify whether to skip invalid files
    that can't be converted (e.g. because the path doesn't exist, or the URL
    can't be fetched). If set to `False`, Prodigy will raise a `ValueError` if
    it encounters invalid files.

    stream (iterable): The stream of annotation tasks.
    input_keys (list): Task keys containing the media, e.g. ['image', 'audio'].
    skip (bool): Skip examples with files that can't be fetched.
    YIELDS (dict): The examples with fetched data URIs.
    """
    log(f"PREPROCESS: Fetching media if necessary: {input_keys}", locals())
    for eg in stream:
        for key in input_keys:
            if key in eg:
                eg = fetch_task_media(eg, key, skip=skip)
        yield eg


@support_structured(stream_arg="stream", input_keys=["image"])
@support_both_streams(stream_arg="stream")
def fetch_images(
    stream: StreamType, image_key: str = "image", skip: bool = False
) -> StreamType:
    # Keep method for backwards-compatibility
    return fetch_media(stream, [image_key], skip=skip)  # type: ignore


@support_structured(
    stream_arg="stream",
    input_keys=["text", "image", "audio", "video"],
    server_ann_keys=["options"],
)
@support_both_streams(stream_arg="stream")
def add_label_options(stream: StreamType, labels: List[str]) -> StreamType:
    """Add options to a streak of tasks, based on labels.

    stream (iterable): The stream of annotation tasks.
    labels (list): The label set.
    YIELDS (dict): The annotation examples with added options.
    """
    log(f"PREPROCESS: Add multiple choice options for {len(labels)} labels")
    options = [{"id": label, "text": label} for label in labels]
    for eg in stream:
        eg["options"] = options
        yield eg


@support_structured(
    stream_arg="stream",
    input_keys=["text", "image", "audio", "video"],
    server_ann_keys=["label"],
)
@support_both_streams(stream_arg="stream")
def add_labels_to_stream(stream: StreamType, labels: List[str] = []) -> StreamType:
    log(f"PREPROCESS: Adding {len(labels)} labels to examples in stream")
    for task in stream:
        for label_name in labels:
            if len(labels) > 1:
                eg = copy.deepcopy(task)
            else:
                eg = task
            eg["label"] = label_name
            eg = set_hashes(eg, overwrite=True)
            yield eg


def convert_options_to_cats(
    answers: Iterable[TaskType], exclusive: bool = True
) -> List[TaskType]:
    """Convert tasks with accepted answers to individual tasks with a single
    "cats" property, if available. Can be used to convert text classification
    annotations created in the choice interface to annotations for training
    a text classifier.

    answers (iterable): Example dicts with added "answer".
    exclusive (bool): Whether the options were mutually exclusive.
    RETURNS (list): The converted examples.
    """
    converted = []
    n_converted = 0
    for eg in answers:
        cats = {}
        if eg.get("answer", "ignore") == "ignore":
            continue
        if "options" in eg:
            selected = eg.get("accept", [])
            if eg["answer"] == "accept":
                for option in eg["options"]:
                    label = option["id"]
                    if label in selected:
                        cats[str(label)] = 1.0
                    elif exclusive:
                        cats[str(label)] = 0.0
            elif eg["answer"] == "reject":
                # If we reject the response, then the selected label is
                # False. We don't know about the other labels.
                for option in eg["options"]:
                    label = option["id"]
                    if label in selected:
                        cats[str(label)] = 0.0
            n_converted += 1
        else:
            if "label" not in eg:
                log('Skipping example: no "label" or "options" found', eg)
                continue
            if eg["answer"] == "accept":
                cats[eg["label"]] = 1.0
            elif eg["answer"] == "reject":
                cats[eg["label"]] = 0.0
        converted.append(copy.deepcopy(eg))
        converted[-1]["cats"] = cats
    if n_converted:
        log(
            f"PREPROCESS: Converted {n_converted} examples with multiple-choice "
            f"options to Doc.cats dictionaries."
        )
    return converted


def validate_component(nlp: Language, component: str):
    """Validate that the component on the nlp object exists and is configured correctly"""
    log(f"PREPROCESSING: Validating {component} component")
    if component not in nlp.pipe_names:
        message = f"Failed to find component: {component} in spaCy pipeline, double-check the --component flag to specify a different component name. If you're using spacy-llm, make sure you double-check the configuration file for the right name."
        msg.fail(message, exits=1)
    if is_llm_component(nlp, component):
        if not nlp.get_pipe(component)._save_io:
            msg.fail(
                f"Can't generate proper suggestions from LLM pipeline. Manually ensure that `components.{component}.save_io` setting is set to `True` such that `Doc._.llm_io` information is attached.",
                exits=1,
            )


def is_llm_component(nlp: Language, component: str) -> bool:
    """Checks if the component is a spacy-llm component"""
    return isinstance(nlp.get_pipe(component), LLMWrapper)


def get_llm_task(nlp: Language, component: str) -> LLMTask:
    """Gets the LLMTask from a spacy-llm component"""
    llm_pipe = cast(LLMWrapper, nlp.get_pipe(component))
    return llm_pipe.task


def resolve_labels(
    nlp: Language, component: str, recipe_labels: Optional[List[str]] = None
) -> List[str]:
    """Resolves a list of labels by comparing it to those from a pipeline component."""
    validate_component(nlp=nlp, component=component)
    msg.text(f"Getting labels from the '{component}' component")
    nlp_labels = nlp.pipe_labels[component]
    if recipe_labels:
        missing_labels = set(recipe_labels).difference(set(nlp_labels))
        if missing_labels:
            message = f"Requested labels: {','.join(missing_labels)} are not found in the pipeline: {','.join(nlp_labels)}. "
            if is_llm_component(nlp, component):
                message += "Please cross-check the labels used in spacy-llm config file and the labels provided via --labels argument."
            msg.fail(message, exits=True)
        labels = recipe_labels
    else:
        labels = nlp_labels
    msg.text(f"Using {len(labels)} labels: {labels}")
    return labels


@support_both_streams(stream_arg="stream")
def make_textcat_suggestions(
    stream: StreamType,
    nlp: Language,
    component: str,
    labels: List[str],
    threshold: float,
    batch_size: int = DEFAULT_NLP_BATCH_SIZE,
    show_progress_bar: bool = False,
    progress_bar_total: Optional[int] = None,
) -> StreamType:
    """Add an 'options' key to each example, with potential classes for textcat."""
    validate_component(nlp=nlp, component=component)
    texts = ((eg["text"], eg) for eg in stream)
    log(f"PREPROCESSING: Getting labels from {component}", locals())
    for doc, eg in tqdm(
        nlp.pipe(texts, as_tuples=True, batch_size=batch_size),
        total=progress_bar_total,
        disable=not show_progress_bar,
    ):
        task = copy.deepcopy(eg)
        options = []
        selected = []
        if len(labels) > 1:
            for cat, score in doc.cats.items():
                if cat in labels:
                    options.append({"id": cat, "text": cat, "meta": f"{score:.2f}"})
                    if score >= threshold:
                        selected.append(cat)
            task["options"] = options
        else:
            task["label"] = labels[0]
        task["accept"] = selected
        if is_llm_component(nlp, component):
            task["llm"] = doc.user_data["llm_io"][component]
        yield task


@support_both_streams(stream_arg="stream")
def make_ner_suggestions(
    stream: StreamType,
    nlp: Language,
    component: str,
    labels: Iterable[str],
    batch_size: int = DEFAULT_NLP_BATCH_SIZE,
    show_progress_bar: bool = False,
    progress_bar_total: Optional[int] = None,
) -> StreamType:
    """Add a 'spans' key to each example, with predicted entities."""
    validate_component(nlp=nlp, component=component)
    texts = ((eg["text"], eg) for eg in stream)
    log(f"PREPROCESSING: Getting entities from {component}", locals())
    for doc, eg in tqdm(
        nlp.pipe(texts, as_tuples=True, batch_size=batch_size),
        total=progress_bar_total,
        disable=not show_progress_bar,
    ):
        task = copy.deepcopy(eg)
        spans = []
        for ent in doc.ents:
            if labels and ent.label_ not in labels:
                continue
            spans.append(
                {
                    "token_start": ent.start,
                    "token_end": ent.end - 1,
                    "start": ent.start_char,
                    "end": ent.end_char,
                    "text": ent.text,
                    "label": ent.label_,
                }
            )
        task["spans"] = spans
        if is_llm_component(nlp, component):
            task["llm"] = doc.user_data["llm_io"][component]
        yield task


@support_both_streams(stream_arg="stream")
def make_spancat_suggestions(
    stream: StreamType,
    nlp: Language,
    component: str,
    labels: Iterable[str],
    batch_size: int = DEFAULT_NLP_BATCH_SIZE,
    show_progress_bar: bool = False,
    progress_bar_total: Optional[int] = None,
) -> StreamType:
    """Add a 'spans' key to each example, with predicted spans."""
    validate_component(nlp=nlp, component=component)
    texts = ((eg["text"], eg) for eg in stream)
    log(f"PREPROCESSING: Getting spans from {component}", locals())
    for doc, eg in tqdm(
        nlp.pipe(texts, as_tuples=True, batch_size=batch_size),
        total=progress_bar_total,
        disable=not show_progress_bar,
    ):
        task = copy.deepcopy(eg)
        spans = []
        for spansvals in doc.spans.values():
            for span in spansvals:
                if labels and span.label_ not in labels:
                    continue
                spans.append(
                    {
                        "token_start": span.start,
                        "token_end": span.end - 1,
                        "start": span.start_char,
                        "end": span.end_char,
                        "text": span.text,
                        "label": span.label_,
                    }
                )
        task["spans"] = spans
        if is_llm_component(nlp, component):
            task["llm"] = doc.user_data["llm_io"][component]
        yield task


def add_annot_name(stream: StreamType, name: str):
    for ex in stream:
        ex[ANNOTATOR_ID_ATTR] = name
        ex[SESSION_ID_ATTR] = name
        ex["answer"] = "accept"
        yield ex


def add_view_id(stream: StreamType, view_id: ViewId):
    try:
        assert view_id in get_args(ViewId)
    except AssertionError:
        raise ValueError(
            f"Invalid view_id: {view_id}. Supported view_ids: {get_args(ViewId)}"
        )
    for ex in stream:
        ex[VIEW_ID_ATTR] = view_id
        yield ex


def add_answer(stream: StreamType, answer: str = "accept"):
    for ex in stream:
        ex["answer"] = answer
        yield ex
