from pathlib import Path
from typing import Iterable

from jinja2 import Template
from spacy.tokens import Doc
from spacy_llm.registry import registry
from spacy_llm.util import load_config

from ..util import msg


class TextPrompter:
    """
    Each text from the doc is the prompt!

    This is what a config file for this task might look like:

    ```
    [nlp]
    lang = "en"
    pipeline = ["llm"]

    [components]

    [components.llm]
    factory = "llm"

    [components.llm.task]
    @llm_tasks = "prodigy.TextPrompter.v1"

    [components.llm.model]
    @llm_models = "spacy.GPT-3-5.v1"
    ```
    """

    def __init__(self):
        self._field = "response"
        self._check_doc_extension()

    def _check_doc_extension(self):
        """Add extension if need be."""
        if not Doc.has_extension(self._field):
            Doc.set_extension(self._field, default=None)

    def generate_prompts(self, docs: Iterable[Doc]) -> Iterable[str]:
        return [doc.text for doc in docs]

    def parse_responses(
        self, docs: Iterable[Doc], responses: Iterable[str]
    ) -> Iterable[Doc]:
        self._check_doc_extension()
        for doc, resp in zip(docs, responses):
            try:
                setattr(doc._, self._field, resp)
            except ValueError:
                setattr(doc, self._field, None)
            yield doc


@registry.llm_tasks("prodigy.TextPrompter.v1")
def textprompter_task() -> "TextPrompter":
    return TextPrompter()


class TermsGeneration:
    """
    Describes a term generation task.

    The assumption is that each doc the pipeline receives is a term that we'd like
    to generate examples for. We don't re-use the previously generated terms for a
    new topic because spacy-llm prefers a static prompt. To mitigate this, you could
    re-run the same query a bunch of times and save all the results.

    This is what a config file for this task might look like:

    ```
    [nlp]
    lang = "en"
    pipeline = ["llm"]

    [components]

    [components.llm]
    factory = "llm"

    [components.llm.task]
    @llm_tasks = "prodigy.Terms.v1"
    batch_size = 100

    [components.llm.model]
    @llm_models = "spacy.GPT-3-5.v1"
    ```

    Be mindful that it's a bad idea to configure a cache for this task! You'll end up
    getting the same responses over and over again.
    """

    def __init__(self, batch_size: int = 50):
        self._template = """Make me a long list of '{{topic}}' with {{batch_size}} items. Make sure each item is on a new line. Only give the items on each line. Do not display a numbered list."""
        self.template = Template(self._template)
        self.batch_size = batch_size
        self._field = "terms"
        self._check_doc_extension()

    @property
    def prompt_template(self) -> str:
        return self._template

    def _check_doc_extension(self):
        """Add extension if need be."""
        if not Doc.has_extension(self._field):
            Doc.set_extension(self._field, default=None)

    def generate_prompts(self, docs: Iterable[Doc]) -> Iterable[str]:
        return [
            self.template.render(topic=doc.text, batch_size=self.batch_size)
            for doc in docs
        ]

    def parse_line(self, line: str):
        return " ".join(line.split(" ")[1:])

    def parse_responses(
        self, docs: Iterable[Doc], responses: Iterable[str]
    ) -> Iterable[Doc]:
        self._check_doc_extension()
        for doc, resp in zip(docs, responses):
            terms = [self.parse_line(t) for t_list in resp for t in t_list.split("\n")]
            try:
                setattr(doc._, "terms", terms)
            except ValueError:
                setattr(doc, "terms", None)
            yield doc


@registry.llm_tasks("prodigy.Terms.v1")
def terms_generator_task(batch_size: int = 100) -> "TermsGeneration":
    return TermsGeneration(batch_size=batch_size)


def llm_component_configs(config_path: Path):
    config = load_config(config_path)
    for name, comp_config in config["components"].items():
        if comp_config["factory"] == "llm":
            yield comp_config


def confirm_correct_task(config_path: Path, expected_task: str) -> None:
    """Raises a sysexit if task does not appear in config."""
    comp_configs = llm_component_configs(config_path=config_path)
    task_names = [c["task"]["@llm_tasks"] for c in comp_configs]
    if expected_task not in task_names:
        msg.fail(
            f"Did not find `{expected_task}` task in {config_path}. This recipe needs it.",
            exits=True,
        )
