# pyright: reportMissingImports=false, reportMissingModuleSource=false

import os
import tempfile
from contextvars import ContextVar
from datetime import datetime
from pathlib import Path
from shutil import copyfile
from typing import (
    Any,
    Callable,
    ClassVar,
    Dict,
    Generic,
    Iterable,
    Iterator,
    List,
    Literal,
    Optional,
    Set,
    Tuple,
    Type,
    Union,
    cast,
    overload,
)
from typing_extensions import Concatenate, ParamSpec, TypeVar

import peewee as orm
import srsly
from pydantic import BaseModel
from toolz import partition_all

from ..errors import ProdigyError
from ..structured_types import Example as _StructExample
from ..types import Answer, TaskType
from ..util import (
    ENV_VARS,
    INPUT_HASH_ATTR,
    PRODIGY_HOME,
    TASK_HASH_ATTR,
    convert_blob,
    deprecated,
    get_config,
    get_display_name,
    log,
    registry,
)

_ExampleT = TypeVar("_ExampleT", bound=_StructExample, default=_StructExample)

db_state_default = {"closed": None, "conn": None, "ctx": None, "transactions": None}
db_state = ContextVar("db_state", default=db_state_default.copy())
DB_PROXY = orm.Proxy()
DEFAULT_MYSQL_MAX_LEN = 65535
USE_OLD_DROP = int(os.getenv("PRODIGY_USE_OLD_DROP", "0"))
_DB = None


def get_db() -> Optional["Database"]:
    """Get access to the shared database instance that was previously connected"""
    global _DB
    return _DB


def set_db(instance: Optional["Database"]) -> None:
    """Set the shared database instance. Mostly useful for testing."""
    global _DB
    if _DB is not None:
        disconnect()
    _DB = instance


def disconnect() -> None:
    """Disconnect the shared database instance and revert it back to None type"""
    global _DB
    if _DB is None:
        raise AssertionError("Database is already destroyed")
    _DB.close()
    _DB = None


MYSQL_MAX_LEN = int(os.getenv(ENV_VARS.MYSQL_MAX_LEN, DEFAULT_MYSQL_MAX_LEN))


_ModelT = TypeVar("_ModelT", bound="BaseORMModel")
_MappedT = TypeVar("_MappedT")
_FieldParams = ParamSpec("_FieldParams")


class Mapped(Generic[_MappedT], orm.Field):
    @overload
    def __get__(self, instance: None, owner: Any) -> "Mapped[_MappedT]":
        ...

    @overload
    def __get__(self, instance: object, owner: Any) -> _MappedT:
        ...

    def __get__(
        self, instance: Optional[object], owner: Any
    ) -> Union["Mapped[_MappedT]", _MappedT]:
        ...


def as_mapped(
    x: Callable[_FieldParams, Any], t: Type[_MappedT]
) -> Callable[_FieldParams, Mapped[_MappedT]]:
    return x


def as_mapped_fk(
    x: Callable[Concatenate[Type[_ModelT], _FieldParams], Any], t: None = None
) -> Callable[Concatenate[Type[_ModelT], _FieldParams], Mapped[Type[_ModelT]]]:
    return x


AutoField = as_mapped(orm.AutoField, int)
BigIntegerField = as_mapped(orm.BigIntegerField, int)
BlobField = as_mapped(orm.BlobField, bytes)
BooleanField = as_mapped(orm.BooleanField, bool)
CharField = as_mapped(orm.CharField, str)
DateTimeField = as_mapped(orm.DateTimeField, datetime)
TimestampField = as_mapped(orm.TimestampField, int)
ForeignKeyField = as_mapped_fk(orm.ForeignKeyField)


def _check_db_driver_installed(db_name: str):
    if db_name == "PostgreSQL":
        try:
            import psycopg2  # noqa
        except ImportError:
            raise ImportError(
                "The PostgreSQL database requires the psycopg2 library. "
                "You can install it with pip: `python -m pip install psycopg2`"
            )
    if db_name == "MySQL":
        try:
            import pymysql  # noqa
        except ImportError:
            raise ImportError(
                "The MySQL database requires the PyMySQL library. "
                "You can install it with pip: `python -m pip install PyMySQL`"
            )


def connect(
    db_id: Optional[str] = None, db_settings: Optional[Dict[str, Any]] = None
) -> "Database":
    """Connect to the database.

    db_id (str): 'sqlite' (default), 'postgresql' or 'mysql'.
    db_settings (dict): Optional database connection parameters.
    RETURNS (prodigy.components.db.Database): The initialized database.
    """
    # Check whether we have a global shared DB defined, and use that
    # if it's there. Mostly useful for testing.
    global_db = get_db()
    if global_db is not None:
        return global_db
    connectors = {
        "sqlite": connect_sqlite,
        "postgresql": connect_postgresql,
        "mysql": connect_mysql,
    }
    config = get_config()
    if db_id in (True, False, None):
        db_id = config.get("db", "sqlite")
    if db_settings in (True, False, None):
        config_db_settings = config.setdefault("db_settings", {})
        db_settings = config_db_settings.get(db_id, {})
    if db_id in registry.databases:
        return registry.databases.get(db_id)
    if db_id not in connectors:
        raise ValueError(f"Invalid database id: {db_id}")
    db_name, db = connectors[db_id](**db_settings)
    _check_db_driver_installed(db_name=db_name)
    database = Database(db, db_id, db_name)
    log(f"DB: Connecting to database {db_name}", only_once=True)
    return database


class BaseORMModel(orm.Model):
    id: Mapped[int] = AutoField()
    DoesNotExist: ClassVar[Type[orm.DoesNotExist]]
    _meta: orm.Metadata

    class Meta:
        database = DB_PROXY


class Dataset(BaseORMModel):
    name: Mapped[str] = CharField(unique=True)
    created: Mapped[int] = TimestampField()
    meta: Mapped[bytes] = BlobField()
    session: Mapped[bool] = BooleanField()

    class Meta:
        table_name = "dataset"

    @property
    def structured(self) -> bool:
        meta = self.load_meta()
        return meta["structured"] if "structured" in meta else False

    def load_meta(self) -> Dict[str, Any]:
        meta = convert_blob(self.meta)
        return cast(Dict[str, Any], srsly.json_loads(meta)) if meta is not None else {}


class Example(BaseORMModel):
    link: Mapped["Link"]
    input_hash: Mapped[int] = BigIntegerField()
    content: Mapped[bytes] = BlobField()
    task_hash: Mapped[int] = BigIntegerField()

    class Meta:
        table_name = "example"

    def load(self) -> Dict[str, Any]:
        content = convert_blob(self.content)
        return cast(Dict[str, Any], srsly.json_loads(content))

    def serialize(self) -> Dict[str, Any]:
        content = convert_blob(self.content)
        return {
            "content": srsly.json_loads(content),
            "input_hash": self.input_hash,
            "task_hash": self.task_hash,
        }


class Link(BaseORMModel):
    example_id: Mapped[int]
    dataset_id: Mapped[int]
    example: Mapped[Example] = ForeignKeyField(Example)
    dataset: Mapped[Dataset] = ForeignKeyField(Dataset)

    class Meta:
        table_name = "link"


class StructuredInputModel(BaseORMModel):
    hash: Mapped[int] = BigIntegerField(unique=True, index=True)
    content: Mapped[bytes] = BlobField()
    created: Mapped[datetime] = DateTimeField(default=datetime.utcnow)

    class Meta:
        table_name = "structured_input"

    def load(self) -> Dict[str, Any]:
        content = convert_blob(self.content)
        return cast(Dict[str, Any], srsly.json_loads(content))


class StructuredExampleModel(BaseORMModel):
    task_hash: Mapped[int] = BigIntegerField(index=True)
    answer: Mapped[str] = CharField(
        max_length=6, index=True, choices=["accept", "reject", "ignore"]
    )
    content: Mapped[bytes] = BlobField()
    input: Mapped[StructuredInputModel] = ForeignKeyField(StructuredInputModel)
    created: Mapped[datetime] = DateTimeField(default=datetime.utcnow)

    class Meta:
        table_name = "structured_example"

    def load(self) -> Dict[str, Any]:
        content = convert_blob(self.content)
        return cast(Dict[str, Any], srsly.json_loads(content))


class StructuredLinkModel(BaseORMModel):
    example_id: Mapped[int]
    dataset_id: Mapped[int]
    example: Mapped[StructuredExampleModel] = ForeignKeyField(StructuredExampleModel)
    dataset: Mapped[Dataset] = ForeignKeyField(Dataset)
    session_id: Mapped[str] = CharField(max_length=255)
    created: Mapped[datetime] = DateTimeField(default=datetime.utcnow)

    class Meta:
        table_name = "structured_link"


# Monkeypatch Peewee
# ref: https://fastapi.tiangolo.com/advanced/sql-databases-peewee/
class PeeweeConnectionState(orm._ConnectionState):
    def __init__(self, **kwargs):
        super().__setattr__("_state", db_state)
        super().__init__(**kwargs)

    def __setattr__(self, name, value):
        self._state.get()[name] = value

    def __getattr__(self, name):
        return self._state.get()[name]


def connect_sqlite(**settings) -> Tuple[str, orm.SqliteDatabase]:
    database = settings.pop("name", "prodigy.db")
    path = settings.pop("path", PRODIGY_HOME)
    if database != ":memory:":
        database = str(Path(path) / database)
    settings["check_same_thread"] = settings.get("check_same_thread", False)
    # Enable SQLite foreign key constraints
    settings["pragmas"] = settings.get("pragmas", [("foreign_keys", 1)])
    db = orm.SqliteDatabase(database, **settings)
    return "SQLite", db


def connect_postgresql(**settings) -> Tuple[str, orm.PostgresqlDatabase]:
    database = "prodigy"
    for setting in ("db", "name", "dbname", "database"):
        if setting in settings:
            database = settings.pop(setting)
    db = orm.PostgresqlDatabase(database, **settings)
    return "PostgreSQL", db


def connect_mysql(**settings) -> Tuple[str, orm.MySQLDatabase]:
    database = "prodigy"
    for setting in ("db", "name", "dbname", "database"):
        if setting in settings:
            database = settings.pop(setting)
    db = orm.MySQLDatabase(database, **settings)
    return "MySQL", db


DB_TABLES = [
    Dataset,
    Example,
    Link,
    StructuredInputModel,
    StructuredExampleModel,
    StructuredLinkModel,
]


class ProdigyDatabaseError(ProdigyError):
    ...


class DatasetNotFound(ProdigyDatabaseError):
    def __init__(self, name: str, db_id: str):
        self.name = name
        self.db = db_id
        self.msg = (
            f"Dataset: '{name}' not found in the currently "
            f"configured Prodigy Database: {db_id}"
        )


class DatasetIsStructured(ProdigyDatabaseError):
    def __init__(self, name: str, db_id: str):
        self.name = name
        self.db = db_id
        self.msg = (
            f"Dataset: '{name}' exists but is configured as a structured dataset. "
            "Only Structured Examples can be inserted but you are trying "
            "to insert unstructured Examples."
        )


class DatasetNotStructured(ProdigyDatabaseError):
    def __init__(self, name: str, db_id: str):
        self.name = name
        self.db = db_id
        self.msg = (
            f"Dataset: '{name}' exists but is not configured as a structured dataset. "
            "Unable to insert Structured Examples."
        )


class BulkCreateNotInTransaction(ProdigyDatabaseError):
    def __init__(self, db: "Database"):
        self.db = db
        self.msg = "Cannot run a bulk create operation outside of a Peewee Database transaction."


class Database:
    def __init__(
        self,
        db: orm.Database,
        display_id: str = "custom",
        display_name: Optional[str] = None,
    ) -> None:
        """Initialize a database.

        db: A database object that can be initialized by peewee.
        display_id (str): Database ID used for logging, e.g. 'sqlite'.
        display_name (str): Database name used for logging, e.g. 'SQLite'.
        RETURNS (Database): The initialized database.
        """
        # Monkeypatch Peewee
        # ref: https://fastapi.tiangolo.com/advanced/sql-databases-peewee/
        db._state = PeeweeConnectionState()
        DB_PROXY.initialize(db)
        self.db_id = display_id
        self.db_name = display_name or get_display_name(db)
        log(f"DB: Initializing database {self.db_name}", only_once=True)
        DB_PROXY.create_tables(DB_TABLES, safe=True)
        self.db = DB_PROXY

    def __bool__(self) -> bool:
        return True

    def __len__(self) -> int:
        """
        RETURNS (int): The number of datasets in the database.
        """
        return len(self.datasets)

    def __contains__(self, name: str) -> bool:
        """
        name (str): Name of the dataset.
        RETURNS (bool): Whether the dataset exists in the database.
        """
        try:
            has_ds = bool(self.get_dataset_by_name(name))
        except DatasetNotFound:
            has_ds = False
        return has_ds

    @property
    def datasets(self) -> List[str]:
        """
        RETURNS (list): A list of dataset IDs.
        """
        datasets = (
            Dataset.select(Dataset.name, Dataset.meta)
            .where(Dataset.session == False)  # noqa: E712
            .order_by(Dataset.created)
        )
        return [ds.name for ds in datasets if not ds.structured]

    @property
    def sessions(self) -> List[str]:
        """
        RETURNS (list): A list of session dataset IDs.
        """
        datasets = (
            Dataset.select(Dataset.name)
            .where(Dataset.session == True)  # noqa: E712
            .order_by(Dataset.created)
        )
        return [ds.name for ds in datasets]

    @property
    def st_datasets(self) -> List[str]:
        """
        RETURNS (list): A list of structured dataset IDs.
        """
        datasets = Dataset.select(Dataset.name, Dataset.meta).order_by(Dataset.created)
        return [ds.name for ds in datasets if ds.structured]

    @property
    def st_sessions(self) -> List[str]:
        """
        RETURNS (list): A list of session_ids for structured datasets.
        """
        links = (
            StructuredLinkModel.select(StructuredLinkModel.session_id)
            .distinct()
            .join(Dataset)
        )
        return [sl.session_id for sl in links]

    def close(self) -> None:
        """
        Close the database connection (if not already closed). Called after
        API requests to avoid timeout issues, especially with MySQL.
        """
        if not self.db.is_closed():
            self.db.close()

    def reconnect(self) -> None:
        """
        Reconnect to the database. Called on API requests to avoid timeout
        issues, especiallly with MySQL. If the database connection is still
        open, it will be closed before reconnecting.
        """
        if not self.db.is_closed():
            self.db.close()
        self.db.connect()

    def get_examples(
        self, ids: Union[Iterable[int], int], by: str = "task_hash"
    ) -> List[TaskType]:
        """
        ids (list): List of example hashes.
        by (str): ID to get examples by. Defaults to 'task_hash'.
        RETURNS (list): The examples.
        """
        if hasattr(ids, "__iter__"):
            ids_ = list(cast(Iterable[int], ids))
        else:
            assert isinstance(ids, int)
            ids_ = [ids]
        field = getattr(Example, by)
        return [eg.load() for eg in Example.select().where(field << ids_).iterator()]

    def get_orphan_example_ids(self) -> List[int]:
        # There are other ways to structure this, e.g. by a left outer join.
        # The choice of this approach has no particular motivation, so change
        # it later if there's reason to prefer another.
        query = Example.select(Example.id).where(
            ~(Example.id.in_(Link.select(Link.example)))
        )
        orphans = [eg.id for eg in query.execute()]
        query = StructuredExampleModel.select(StructuredExampleModel.id).where(
            ~(
                StructuredExampleModel.id.in_(
                    StructuredLinkModel.select(StructuredLinkModel.example)
                )
            )
        )
        orphans.extend(eg.id for eg in query.execute())
        return orphans

    def delete_orphan_examples(self) -> None:
        """Delete examples that are not part of any dataset (session or otherwise)"""
        # There are other ways to structure this, e.g. by a left outer join.
        # The choice of this approach has no particular motivation, so change
        # it later if there's reason to prefer another.
        query = Example.delete().where(~(Example.id.in_(Link.select(Link.example))))
        query.execute()
        query = StructuredExampleModel.delete().where(
            ~(
                StructuredExampleModel.id.in_(
                    StructuredLinkModel.select(StructuredLinkModel.example)
                )
            )
        )
        query.execute()

    def get_meta(self, name: str) -> Optional[Dict[str, Any]]:
        """
        name (str): The dataset name.
        RETURNS (dict): The dataset meta.
        """
        if name not in self:
            return None
        dataset = self.get_dataset_by_name(name=name)
        meta = dataset.load_meta()
        meta["created"] = dataset.created
        return meta

    def get_dataset_sessions(self, dataset_name: str) -> List[str]:
        """Get all session datasets associated with a parent dataset.
        Finds all the session datasets that have examples also associated with
        the parent dataset. Can be an expensive query for large datasets.
        dataset_name (str): The parent dataset name
        RETURNS (List[str]): The list of session dataset names
        """
        try:
            dataset = self.get_dataset_by_name(dataset_name)
        except DatasetNotFound:
            return []

        link_subquery = Link.select(Link.example).where(Link.dataset == dataset.id)

        query = (
            Dataset.select(Dataset)
            .join(Link)
            .where(Link.example.in_(link_subquery) & (Link.dataset != dataset.id))
        ).distinct()
        sessions = [ds.name for ds in query.execute() if ds.session]
        return sessions

    def get_sessions_examples(
        self, session_ids: Optional[List[str]] = None
    ) -> List[TaskType]:
        """
        session_ids (list): A list of session IDs to gather examples from
        RETURNS (list): The examples linked to the given sessions.
        """
        if session_ids is None or len(session_ids) == 0:
            raise ValueError("One or more sessions are required")

        db_sessions = self.sessions
        session_ids = [sid for sid in session_ids if sid in db_sessions]
        query = (
            Example.select(Example, Link, Dataset)
            .join(Link)
            .where(Dataset.name << session_ids)
            .join(Dataset)
        )
        # Tag each example with `session_id` so it can be mapped
        # back to the original session later if needed.
        examples = []
        for eg in query.iterator():
            example = eg.load()
            session_id = eg.link.dataset.name
            example["session_id"] = session_id
            examples.append(example)
        log(f"DB: Retrieved {len(examples)} examples from {len(session_ids)} sessions")
        return examples

    def count_dataset(self, name: str, session: bool = False) -> int:
        """
        name (str): The dataset name.
        session: Return only session datasets when True.
        RETURNS (int): The number of examples in the dataset.
        """
        if name not in self:
            raise ValueError(f"Can't find dataset '{name}' in database {self.db_name}")
        dataset = self.get_unst_dataset(name)
        query = (
            Example.select().join(Link).join(Dataset).where(Dataset.id == dataset.id)
        )
        if session is True:
            query = query.where(Dataset.session == True)  # noqa: E712
        count = query.count()
        return count

    def get_dataset(
        self, name: str, default: Optional[Any] = None, session: bool = False
    ) -> Union[List[TaskType], Any]:
        """Get examples for a dataset"""
        deprecated(
            "`Database.get_dataset` is deprecated and will be removed in "
            "Prodigy v2. Use `Database.get_dataset_examples` "
            "or `Database.iter_dataset_examples` instead. "
        )
        return self.get_dataset_examples(name, default=default, session=session)

    def get_dataset_examples(
        self, name: str, default: Optional[Any] = None, session: bool = False
    ) -> Union[List[TaskType], Any]:
        # we are actually not documenting defult arg in the docs, should
        # we remove it and make the return type more specific?
        """Get examples for a dataset
        name (str): Name of the dataset to get examples for.
        default: Return value if dataset not in database.
        session: Return only session datasets when True.
        RETURNS (List[TaskType]): The examples in the dataset or default value.
        """
        if default is not None:
            deprecated(
                "The `default` argument to `Database.get_dataset_examples` "
                "is deprecated and will be removed in Prodigy v2. "
            )
        if name not in self:
            return default
        examples = list(self.iter_dataset_examples(name, session=session))
        log(f"DB: Finished Loading dataset '{name}' ({len(examples)} examples)")
        return examples

    def iter_dataset_examples(
        self, name: str, session: bool = False
    ) -> Iterator[TaskType]:
        # we are actually not documenting defult arg in the docs, should
        # we remove it and make the return type more specific?
        """Get examples for a dataset
        name (str): Name of the dataset to get examples for.
        default: Return value if dataset not in database.
        session: Return only session datasets when True.
        RETURNS (Iterator[TaskType]): The examples in the dataset or default value.
        """
        dataset = self.get_unst_dataset(name)
        query = (
            Example.select().join(Link).join(Dataset).where(Dataset.id == dataset.id)
        )
        if session is True:
            query = query.where(Dataset.session is True)
        log(f"DB: Loading dataset '{name}'")
        for eg in query.iterator():
            yield eg.load()

    def get_dataset_page(
        self, name: str, page_number: int, page_size: int
    ) -> Tuple[List[TaskType], int]:
        """
        Get a page of dataset examples. This is useful for paginating API endpoints.
        name (str): The dataset name.
        page_number (int): The page number to retrieve
        page_size (int): The number of items to return in a page
        RETURNS (list, int): A tuple of the requested page of examples as a list
        and the total count in the dataset.
        """
        if name not in self:
            return [], -1
        dataset = self.get_unst_dataset(name)
        query = (
            Example.select().join(Link).join(Dataset).where(Dataset.id == dataset.id)
        )
        count = query.count()
        examples = query.paginate(page_number, page_size).execute()
        log(
            f"DB: Loading dataset '{name}' page {page_number} ({len(examples)} examples)"
        )
        return ([eg.serialize() for eg in examples], count)

    def get_input_hashes(self, *names: str) -> Set[int]:
        """
        *names (str): Dataset names to get hashes for.
        RETURNS (set): The input hashes.
        """
        in_db = self.datasets + self.sessions
        datasets = [name for name in names if name in in_db]
        query = (
            Example.select(Example.input_hash)
            .join(Link)
            .join(Dataset)
            .where(Dataset.name << datasets)
        )
        return {eg.input_hash for eg in query.iterator()}

    def get_task_hashes(self, *names: str) -> Set[int]:
        """
        *names (str): The dataset names.
        RETURNS (set): The task hashes.
        """
        in_db = self.datasets + self.sessions
        datasets = [name for name in names if name in in_db]
        query = (
            Example.select(Example.task_hash)
            .join(Link)
            .join(Dataset)
            .where(Dataset.name << datasets)
        )
        return {eg.task_hash for eg in query.iterator()}

    def get_hashes(
        self, *names: str, kind: Literal["task", "input"] = "task"
    ) -> Set[int]:
        """
        *names (str): The dataset names.
        kind (str): The kind of hash. Can be "input" or "task"
        RETURNS (set): Set of the hashes in the provided dataset names.
        """
        if kind not in ["input", "task"]:
            raise ValueError("Can only use `task` or `input` kinds of hashes.")
        if kind == "task":
            hashes = self.get_task_hashes(*names)
        elif kind == "input":
            hashes = self.get_input_hashes(*names)
        return hashes

    def get_hash_count(
        self, *names: str, hash: int, kind: Literal["task", "input"] = "task"
    ) -> int:
        """
        names (str): The dataset names
        hash (int): Hash value to check
        kind (str): The kind of hash. Can be "input" or "task"
        RETURNS (int): The number of times a task hash appears in the dataset
        """

        if kind not in ["input", "task"]:
            raise ValueError("Can only use `task` or `input` kinds of hashes.")

        in_db = self.datasets + self.sessions
        datasets = [name for name in names if name in in_db]
        identifier = Example.task_hash if kind == "task" else Example.input_hash

        query = (
            Example.select(identifier)
            .where(identifier == hash)
            .join(Link)
            .join(Dataset)
            .where(Dataset.name << datasets)
        )
        return query.count()

    def get_dataset_examples_by_hash(
        self, name: str, hash: int, kind: Literal["task", "input"] = "task"
    ) -> List[Dict]:
        """
        names (str): The dataset name
        hash (int): Hash value to check
        kind (str): The kind of hash. Can be "input" or "task"
        RETURNS (list): List of examples that belong to hash
        """

        if kind not in ["input", "task"]:
            raise ValueError("Can only use `task` or `input` kinds of hashes.")

        identifier = Example.task_hash if kind == "task" else Example.input_hash
        query = (
            Example.select()
            .where(identifier == hash)
            .join(Link)
            .join(Dataset)
            .where(Dataset.name == name)
        )

        return [eg.load() for eg in query.iterator()]

    def get_hashes_min_cardinality(
        self, *names: str, n: int = 2, kind: str = "task"
    ) -> Set[int]:
        """
        names (str): The dataset names
        n (int): The minimum number of times that the task hash needs to appear in the datasets
        kind (str): The kind of hash. Can be "input" or "task"
        RETURNS (set): Set of hashes that appear at least `n` times in the datasets
        """
        if kind not in ["input", "task"]:
            raise ValueError("Can only use `task` or `input` kinds of hashes.")

        in_db = self.datasets + self.sessions
        datasets = [name for name in names if name in in_db]
        identifier = Example.task_hash if kind == "task" else Example.input_hash

        query = (
            Example.select(identifier)
            .join(Link)
            .join(Dataset)
            .where(Dataset.name << datasets)
            .group_by(identifier)
            .having(orm.fn.Count(orm.SQL("*")) >= n)
        )
        return {
            eg.task_hash if kind == "task" else eg.input_hash for eg in query.iterator()
        }

    def add_dataset(
        self,
        name: str,
        meta: Dict[str, Any] = {},
        session: bool = False,
        structured: bool = False,
    ) -> Dataset:
        """
        name (str): The name of the dataset to add.
        meta (dict): Optional dataset meta.
        session (bool): Whether the dataset is a session dataset.
        RETURNS (Dataset): The created dataset.
        """
        if any([char in name for char in (",", " ")]):
            raise ValueError("Dataset name can't include commas or whitespace")
        db_type = "structured" if structured else "unstructured"
        try:
            dataset = (
                self.get_st_dataset(name) if structured else self.get_unst_dataset(name)
            )
        except DatasetNotFound:
            log(f"DB: Creating {db_type} dataset '{name}'", meta)
            if structured:
                meta = dict(meta)
                meta["structured"] = True
            dataset = Dataset.create(
                name=name,
                meta=srsly.json_dumps(meta),
                session=session,
            )
        return dataset

    def add_examples(
        self,
        examples: Iterable[TaskType],
        datasets: Iterable[str] = tuple(),
        batch_size: int = 64,
    ) -> None:
        """
        examples (iterable): The examples to add.
        datasets (list): The names of the dataset(s) to add the examples to.
        """
        if not isinstance(datasets, (tuple, list)):
            raise ValueError(f"Datasets must be a tuple or list, not: {type(datasets)}")

        db_examples: List[Example] = []
        for eg in examples:
            content = srsly.json_dumps(eg)
            self._validate_mysql_maxlen(content, "example")
            eg = Example(
                input_hash=eg[INPUT_HASH_ATTR],
                task_hash=eg[TASK_HASH_ATTR],
                content=content,
            )
            db_examples.append(eg)

        with self.db.atomic():
            created_examples = _do_bulk_create(
                self, Example, instances=db_examples, batch_size=batch_size
            )
            ids = [eg.id for eg in created_examples]
            for dataset in datasets:
                self.link(dataset, ids)
        log(f"DB: Added {len(created_examples)} examples to {len(datasets)} datasets")

    def link(
        self, dataset_name: str, example_ids: Iterable[int], batch_size: int = 64
    ) -> None:
        """
        dataset_name (str): The name of the dataset.
        example_ids (iterable): The IDs of the examples to link to the dataset.
        """
        links = []
        db_dataset = self.add_dataset(dataset_name)
        for eg in example_ids:
            links.append(Link(dataset=db_dataset.id, example=eg))

        with self.db.atomic():
            Link.bulk_create(links, batch_size=batch_size)

    def unlink(self, dataset: str) -> None:
        """
        dataset (str): The name of the dataset to unlink.
        """
        with self.db.atomic():
            db_dataset = self.get_unst_dataset(dataset)
            query = Link.delete().where(Dataset.id == db_dataset.id)
            query.execute()

    def drop_dataset(self, name: str, batch_size: int = 64) -> bool:
        """
        name (str): The name of the dataset to drop.
        batch_size (int): If specified examples will be deleted in batches of the given size.
        RETURNS (bool): True if dataset was dropped.
        """
        if USE_OLD_DROP:
            return self._drop_dataset_old(name, batch_size)
        else:
            return self._drop_dataset_new(name)

    def count_examples(self) -> int:
        return Example.select().count()

    def count_links(self) -> int:
        return Link.select().count()

    def _drop_dataset_new(self, name: str) -> bool:
        orphan_examples = self.get_orphan_example_ids()
        if orphan_examples:
            # Usually the DB shouldn't contain orphans, so we raise an error
            # for this and suggest resolutions, rather than accept a parameter
            # for it.
            raise ValueError(
                "Database contains orphaned examples (examples not "
                "linked to any dataset). When we delete a dataset, we "
                "delete all newly orphaned examples, but this would delete "
                "extra data in your case. Either delete the orphaned examples "
                "explicitly with Databse.delete_orphan_examples(), or link "
                "them to a new dataset (perhaps just called 'orphaned')."
            )
        log(f"DB: Dropping dataset '{name}'")
        db_dataset = self.get_dataset_by_name(name)
        to_delete_ids = [db_dataset.id]
        if not db_dataset.session:
            session_names = self.get_dataset_sessions(name)
            to_delete_ids.extend(self.get_dataset_by_name(s).id for s in session_names)

        if db_dataset.structured:
            with self.db.atomic():
                query = StructuredLinkModel.delete().where(
                    StructuredLinkModel.dataset_id << to_delete_ids
                )
                query.execute()
                Dataset.delete().where(Dataset.id << to_delete_ids).execute()
        else:
            with self.db.atomic():
                query = Link.delete().where(Link.dataset_id << to_delete_ids)
                query.execute()
                Dataset.delete().where(Dataset.id << to_delete_ids).execute()
        # After we unlink, delete all examples that now have no links
        # associated.
        self.delete_orphan_examples()
        return True

    def _drop_dataset_old(self, name: str, batch_size: Optional[int] = None) -> bool:
        """
        name (str): The name of the dataset to drop.
        batch_size (int): If specified examples will be deleted in batches of the given size.
        RETURNS (bool): True if dataset was dropped.
        """
        with self.db.atomic():
            log(f"DB: Dropping dataset '{name}'")
            #  Use strong reference counting to free Examples by looking
            #  at how many times an example is referenced by Links and only
            #  deleting it when the final referencing Link goes away.
            dataset = self.get_dataset_by_name(name)

            # Grab all the example ids before we delete the links
            if dataset.structured:
                links_query = StructuredLinkModel.select().where(
                    StructuredLinkModel.dataset == dataset.id
                )
                original_example_ids = [
                    link.example_id for link in links_query.iterator()
                ]
                StructuredLinkModel.delete().where(
                    StructuredLinkModel.dataset == dataset.id
                ).execute()
                to_delete_datasets = [dataset.id]
            else:
                dataset_session_ids = self.get_dataset_sessions(name)
                dataset_sessions_query = Dataset.select().where(
                    Dataset.name << dataset_session_ids
                )
                dataset_sessions = [ds.id for ds in dataset_sessions_query.iterator()]
                to_delete_datasets = dataset_sessions + [dataset.id]
                links_query = Link.select().where(Link.dataset << to_delete_datasets)
                original_example_ids = [
                    link.example_id for link in links_query.iterator()
                ]
                Link.delete().where(Link.dataset << to_delete_datasets).execute()

            Dataset.delete().where(Dataset.id << to_delete_datasets).execute()

            def delete_refs(
                original_example_ids: List[int],
                LinkType: Union[Type[Link], Type[StructuredLinkModel]],
                ExampleType: Union[Type[Example], Type[StructuredExampleModel]],
            ):
                log(f"DB: Found {len(original_example_ids)} examples to unlink")

                batches = [original_example_ids]
                if batch_size is not None:
                    batches = partition_all(
                        batch_size, (eg_id for eg_id in original_example_ids)
                    )
                for batch in batches:
                    # Count references for each example
                    link_examples = (
                        LinkType.select().where(LinkType.example_id << batch).execute()
                    )
                    if len(link_examples) == 0:
                        # All the original links were deleted, so the delete list is
                        # batch
                        to_delete_example_ids = batch
                        log("DB: All batch example links were removed")
                    else:
                        # Group the links into a dict of counts {example_id: count}
                        link_counts = {}
                        link_by_id = {}
                        for link in link_examples:
                            key = link.example_id
                            link_by_id[key] = link
                            if key not in link_counts:
                                link_counts[key] = 0
                            if link.dataset.session is not True:
                                # Skip counting non-session datasets. They only contain
                                # examples because of the sessions that insert them. If
                                # all sessions are gone, the example linked to the dataset
                                # is unlinked.
                                continue
                            link_counts[key] += 1
                        # reference count (v) == 0 for items that can be deleted
                        to_delete_example_ids = [
                            k for k, v in link_counts.items() if v == 0
                        ]
                        to_delete_links = [
                            link_by_id[k].id for k in to_delete_example_ids
                        ]
                        # We need to remove any links identified for removal. This will only include
                        # links being removed from non-session datasets as a result of their session
                        # reference counts hitting 0.
                        LinkType.delete().where(
                            LinkType.id << to_delete_links
                        ).execute()
                        log(
                            f"DB: {len(to_delete_example_ids)} out of {len(link_examples)} examples with 0 ref-count"
                        )
                    # Delete the examples that are no longer referenced.
                    if len(to_delete_example_ids) > 0:
                        ExampleType.delete().where(
                            ExampleType.id << to_delete_example_ids
                        ).execute()
                        log(f"DB: Deleted {len(to_delete_example_ids)} examples")

            if dataset.structured:
                delete_refs(
                    original_example_ids, StructuredLinkModel, StructuredExampleModel
                )
            else:
                delete_refs(original_example_ids, Link, Example)
            self.db.commit()
        log(f"DB: Removed dataset '{name}'")
        return True

    def drop_examples(self, ids: Iterable[int], by: str = "task_hash") -> None:
        """
        ids (iterable): The IDs of the examples to drop.
        by (str): ID to get examples by. Defaults to 'task_hash'.
        """
        if hasattr(ids, "__iter__"):
            ids_ = list(cast(Iterable[int], ids))
        else:
            assert isinstance(ids, int)
            ids_ = [ids]
        field = getattr(Example, by)
        with self.db.atomic():
            example_ids = [
                e.id for e in Example.select(Example.id).where(field << ids_)
            ]
            Link.delete().where(Link.example << example_ids).execute()
            Example.delete().where(field << ids).execute()
            self.db.commit()

    def save(self) -> None:
        log("DB: Saving database")
        self.reconnect()
        self.db.commit()

    def export_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        log(f"DB: Exporting session '{session_id}'")
        if session_id is None:
            raise ValueError("session_id is required to export a session")
        if session_id not in self:
            raise ValueError("session does not exist in db")
        examples = self.get_dataset_examples(session_id)
        if len(examples) == 0:
            return None
        result = self.add_to_exports(examples, session_id)
        log(f"DB: Exported {len(examples)} examples to {result}")
        return {"total": len(examples), "file": result}

    def trash_session(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Delete a session and add its examples into the trash folder.

        RETURNS (tuple): number_deleted, trash_file"""
        log(f"DB: Trashing session {session_id}")
        results = []
        trash_file = None
        if session_id is None:
            raise ValueError("session_id is required")
        if session_id in self:
            results = self.get_dataset_examples(session_id)
            trash_file = self.add_to_trash(results, session_id)
            self.drop_dataset(session_id)
        log(f"DB: Moved {len(results)} examples to the trash.")
        return {"total": len(results), "file": str(trash_file)}

    def add_to_trash(
        self, examples: List[TaskType], base_path: Union[str, Path]
    ) -> str:
        """Move a set of examples out of the database into the PRODIGY_TRASH folder

        RETURNS (str): the exported file path
        """
        log(f"DB: Moving {len(examples)} examples to trash: {base_path}")
        out_path = get_trash_path()
        return self.write_examples(examples, out_path, base_path)

    def add_to_exports(
        self, examples: List[TaskType], base_path: Union[str, Path]
    ) -> str:
        """Write a set of examples from the database into the exports folder

        RETURNS (str): the exported file path
        """
        log(f"DB: Exporting {len(examples)} examples from session: {base_path}")
        out_path = get_exports_path()
        return self.write_examples(examples, out_path, base_path)

    def write_examples(
        self,
        examples: List[TaskType],
        folder_name: str,
        file_base: Union[str, Path],
    ) -> str:
        """Write a set of examples into a folder/file while dealing with conflicts
        by using incrementing suffixes on the given file_base.

        RETURNS (str): the exported file path
        """
        # We write the examples to a file, then move it into the destination.
        # This avoids thrashing virtual file-systems like GCSFuse with a bunch
        # of writes, by making it a single (maybe large) copy operation.
        fd, tmp_file = tempfile.mkstemp()
        out_file = get_unique_file_name(folder_name, file_base)
        srsly.write_jsonl(tmp_file, examples)
        # Copy the file instead of renaming because we might cross device boundaries
        # into a VFS and that operation may not be supported.
        copyfile(tmp_file, str(out_file))
        os.close(fd)
        os.remove(tmp_file)
        return str(out_file)

    def export_sessions(
        self, session_ids: List[str], export_name: str
    ) -> Dict[str, Any]:
        """Export examples from a list of given sessions"""
        examples = self.get_sessions_examples(session_ids)
        result = self.add_to_exports(examples, export_name)
        return {"total": len(examples), "file": result}

    def trash_sessions(
        self, session_ids: List[str], export_name: str
    ) -> Dict[str, Any]:
        """Delete all examples from a list of given sessions"""
        examples = self.get_sessions_examples(session_ids)
        result = self.add_to_trash(examples, export_name)
        for session_id in session_ids:
            if session_id in self:
                self.drop_dataset(session_id)
        return {"total": len(examples), "file": result}

    def export_collection(
        self, sessions_ids_dict: Dict[str, List[str]], collection_name: str
    ) -> Dict[str, Any]:
        """Export a key/value collection of session_ids groups"""
        folder = Path(get_unique_folder_name(get_exports_path(), collection_name))
        folder.mkdir(parents=True)
        meta_file = folder / "index.json"
        index: Dict[str, Any] = {"root": str(folder)}
        count = 0
        for group_key, session_ids in sessions_ids_dict.items():
            session_ids.sort()
            examples = self.get_sessions_examples(session_ids)
            examples_len = len(examples)
            count = count + examples_len
            result = self.add_to_exports(examples, folder / group_key)
            index[group_key] = {
                "file": result,
                "count": examples_len,
                "sessions": session_ids,
            }
        srsly.write_json(meta_file, index)
        return {"total": count, "file": str(meta_file)}

    def trash_collection(
        self, sessions_ids_dict: Dict[str, List[str]], collection_name: str
    ) -> Dict[str, Any]:
        """Remove a collection of sessions and the associated examples from the database"""
        folder = Path(get_unique_folder_name(get_trash_path(), collection_name))
        folder.mkdir(parents=True)
        meta_file = folder / "index.json"
        index: Dict[str, Any] = {"root": str(folder)}
        count = 0
        # Iterate the collection and export backups
        for group_key, session_ids in sessions_ids_dict.items():
            session_ids.sort()
            examples = self.get_sessions_examples(session_ids)
            examples_len = len(examples)
            count = count + examples_len
            result = self.add_to_trash(examples, folder / group_key)
            index[group_key] = {
                "file": result,
                "count": examples_len,
                "sessions": session_ids,
            }
        # Iterate the collection again to remove the referenced examples. If we
        # did this above, only the first interested group would get a chance to
        # reference any given example.
        for group_key, session_ids in sessions_ids_dict.items():
            for session_id in session_ids:
                if session_id in self:
                    self.drop_dataset(session_id)
        srsly.write_json(meta_file, index)
        return {"total": count, "file": str(meta_file)}

    def get_dataset_by_name(self, name: str) -> Dataset:
        """Get a Dataset by its name.
        name (str): Dataset name to query for
        RAISES (DatasetNotFound): if the dataset with this name does not exist
        RETURNS (Dataset): Dataset object with the provided name
        """
        try:
            ds = Dataset.get(Dataset.name == name)
        except Dataset.DoesNotExist:
            raise DatasetNotFound(name, self.db_id)
        else:
            return ds

    def get_st_dataset(self, name: str) -> Dataset:
        """Get a Dataset by its name and ensure it has `structured` set to True
        name (str): Dataset name to query for
        RAISES (DatasetNotFound): if the dataset with this name does not exist
        RAISES (DatasetNotStructured): if the dataset is found but structured is False
            (Dataset.structured defaults to False)
        RETURNS (Dataset): Dataset object with the provided name
        """
        ds = self.get_dataset_by_name(name)
        if ds.structured is False:
            raise DatasetNotStructured(name, self.db_id)
        return ds

    def get_unst_dataset(self, name: str) -> Dataset:
        """Get a Dataset by its name and ensure it has `structured` set to False
        name (str): Dataset name to query for
        RAISES (DatasetNotFound): if the dataset with this name does not exist
        RAISES (DatasetIsStructured): if the dataset is found but structured is True
            (Dataset.structured defaults to False)
        RETURNS (Dataset): Dataset object with the provided name
        """
        ds = self.get_dataset_by_name(name)
        if ds.structured is True:
            raise DatasetIsStructured(name, self.db_id)
        return ds

    def get_st_input_hashes(self, *names: str) -> Set[int]:
        """
        *names (str): Dataset names to get hashes for.
        RETURNS (set): The StructuredInputModel hashes.
        """
        datasets = [self.get_st_dataset(name) for name in names]
        query = (
            StructuredInputModel.select(StructuredInputModel.hash)
            .join(StructuredExampleModel)
            .join(StructuredLinkModel)
            .join(Dataset)
            .where(Dataset.id << datasets)
        )
        return {eg.hash for eg in query.iterator()}

    def get_st_task_hashes(self, *names: str) -> Set[int]:
        """
        *names (str): The dataset names.
        RETURNS (set): The StructuredExampleModel task hashes.
        """
        datasets = [self.get_st_dataset(name) for name in names]
        query = (
            StructuredExampleModel.select(StructuredExampleModel.task_hash)
            .join(StructuredLinkModel)
            .join(Dataset)
            .where(Dataset.id << datasets)
        )
        return {eg.task_hash for eg in query.iterator()}

    def get_st_input_by_hash(self, input_hash: int) -> Dict[str, Any]:
        """Resolve a StructuredInputModel record from an input_hash
        input_hash (int): Hash of the input for a task
        RETURNS (Dict[str, Any]): The internal JSON content as a dict of the input record
        """
        st_input = StructuredInputModel.get(StructuredInputModel.hash == input_hash)
        return st_input.load()

    def _validate_mysql_maxlen(self, content: str, table_name: str):
        """Validate input content is shorter than the MySQL Max Len for
        a BlobField.
        content (str): str content to check len of
        RAISES (ValueError) if the len of content is longer than the configured
            MYSQL_MAX_LEN
        """
        if self.db_id == "mysql" and len(content) >= MYSQL_MAX_LEN:
            raise ValueError(
                (
                    f"Can't add JSON example to MySQL database: blob is "
                    f"longer than {MYSQL_MAX_LEN} characters. This can lead "
                    f"to MySQL truncating your data. If possible, segment "
                    f"your examples into smaller chunks or limit what you're "
                    f"including in the data. You can also change the field "
                    f"type to mediumblob and set the environment variable "
                    f"{ENV_VARS.MYSQL_MAX_LEN}=16777215.\n"
                    f"ALTER TABLE {table_name} MODIFY content mediumblob;"
                )
            )

    def _get_st_inputs_by_hashes(
        self,
        input_hashes: List[int],
        select_fields: List[Mapped] = [
            StructuredInputModel.id,
            StructuredInputModel.hash,
        ],
        batch_size: int = 64,
    ) -> Iterator[StructuredInputModel]:
        """Efficiently query the database for StructuredInputModel records with
        a hash in the provided input_hashes list. Batches the input_hashes
        by batch_size to avoid errors on too many parameters for SQLite queries

        Args:
            input_hashes (List[int]): List of input_hashes to query for
            select_fields (List[Mapped]): Columns to include in select query.
                This defaults to just id and hash since those are the primary uses
            batch_size (int) batch size to use in splitting up input_hashes query.

        Yields:
            Iterator[StructuredInputModel]:
        """
        for ih_batch in partition_all(batch_size, input_hashes):
            query = (
                StructuredInputModel.select(*select_fields)
                .where(StructuredInputModel.hash << ih_batch)
                .order_by(StructuredInputModel.id)
            )
            for st_inp in query.iterator():
                yield st_inp

    def add_st_examples(
        self,
        examples: List[_ExampleT],
        dataset_name: str,
        session_id: str,
        batch_size: int = 64,
    ) -> None:
        """Add structured tasks to a dataset under a session_id.
        For each task, get or create the input,
        then create the example record pointing to the correct input.
        examples (List[_ExampleT]): The structured examples to add.
        dataset_name (str): The name of the dataset to add the examples to.
        session_id (str): The name of the dataset to add the examples to.
        """
        # Execute all Database queries and inserts atomically
        with self.db.atomic():
            # First fetch the Dataset and ensure it's a Structured Dataset
            dataset = self.get_st_dataset(dataset_name)

            # Query for any inputs already saved to the DB
            input_hashes = [eg.input_hash for eg in examples]
            st_inputs_found = self._get_st_inputs_by_hashes(input_hashes)

            # Build a map of input_hash: StructuredInputModel.id to use when building examples
            st_inputs_map = {inp.hash: inp.id for inp in st_inputs_found}

            # Build a list of StructuredInputModels to create
            examples_wo_inputs = [
                eg for eg in examples if eg.input_hash not in st_inputs_map
            ]
            st_inputs_to_create: Dict[int, StructuredInputModel] = {}
            for eg in examples_wo_inputs:
                st_input_val = (
                    eg.input.dict()
                    if isinstance(eg.input, BaseModel)
                    else dict(eg.input)
                )
                st_input_content = srsly.json_dumps(st_input_val)
                self._validate_mysql_maxlen(st_input_content, "structured_input")
                st_input = StructuredInputModel(
                    hash=eg.input_hash, content=st_input_content
                )
                st_inputs_map[eg.input_hash] = st_input.id
                st_inputs_to_create[eg.input_hash] = st_input

            # Inputs need to be created first since
            # they get referenced by each example record
            created_inputs = _do_bulk_create(
                self,
                StructuredInputModel,
                list(st_inputs_to_create.values()),
                batch_size=batch_size,
            )
            for st_inp in created_inputs:
                st_inputs_map[st_inp.hash] = st_inp.id

            # Build and bulk create all the example rows
            db_examples = []
            for eg in examples:
                st_input = st_inputs_map[eg.input_hash]
                st_example_content = srsly.json_dumps(eg.to_dict(exclude={"input"}))
                self._validate_mysql_maxlen(st_example_content, "structured_example")
                st_eg = StructuredExampleModel(
                    task_hash=eg.task_hash,
                    answer=eg.answer,
                    input=st_input,
                    content=st_example_content,
                )
                db_examples.append(st_eg)

            created_examples = _do_bulk_create(
                self, StructuredExampleModel, db_examples, batch_size=batch_size
            )
            example_ids = [eg.id for eg in created_examples]
            self.st_link(dataset, example_ids, session_id=session_id)
            log(
                f"DB: Added {len(examples)} Structured Examples to Dataset: {dataset_name}"
            )

    def st_link(
        self,
        dataset: Dataset,
        example_ids: List[int],
        session_id: str,
        batch_size: int = 64,
    ) -> None:
        """Link a list of StructuredExampleModel records with a dataset using a session_id.
        Creates a set of records in the StructuredLinkModel table.
        dataset_name (str): Dataset to associate examples with
        example_ids (List[int]): List of StructuredExampleModel ids
        session_id (str): The str session/annotator_id to associate these records with
        batch_size (int): Batch size to run bulk create with. Defaults to 256.
        """
        with self.db.atomic():
            links = [
                StructuredLinkModel(
                    session_id=session_id, dataset=dataset, example=eg_id
                )
                for eg_id in example_ids
            ]
            StructuredLinkModel.bulk_create(links, batch_size=batch_size)

    def get_st_dataset_examples(
        self,
        dataset_name: str,
        *,
        session_ids: Optional[List[str]] = None,
        answers: Optional[List[Answer]] = None,
        parse_as: Optional[Type[_ExampleT]] = None,
    ) -> List[_ExampleT]:
        """Get structured examples for a dataset
        dataset_name (str): The dataset name.
        session_ids (List[str]): List of session_ids to filter by
        answers (List[str]): List of answers to filter by
        parse_as (Type[_ExampleT]): Structured Example type to parse the unstructured example as
            (can be the base Example or any registered subtype)
        RETURNS (List[_ExampleT]): List of Structured Example objects associated with this dataset
        """
        examples = list(
            self.iter_st_dataset_examples(
                dataset_name=dataset_name,
                session_ids=session_ids,
                answers=answers,
                parse_as=parse_as,
            )
        )
        log(
            f"DB: Finished Loading Structured dataset '{dataset_name}' ({len(examples)} examples)"
        )
        return examples

    def iter_st_dataset_examples(
        self,
        dataset_name: str,
        *,
        session_ids: Optional[List[str]] = None,
        answers: Optional[List[Literal["accept", "reject", "ignore"]]] = None,
        parse_as: Optional[Type[_ExampleT]] = None,
    ) -> Iterator[_ExampleT]:
        """Get structured examples for a dataset
        dataset_name (str): The dataset name.
        parse_as (Type[_ExampleT]): Structured Example type to parse the unstructured example as
            (can be the base Example or any registered subtype)
        RETURNS (Iterator[_ExampleT]): List of Structured Example objects associated with this dataset
        """
        dataset = self.get_st_dataset(dataset_name)
        query = (
            StructuredExampleModel.select()
            .join(StructuredLinkModel)
            .join(Dataset)
            .where(Dataset.id == dataset.id)
        )
        if session_ids is not None:
            query = query.where(StructuredLinkModel.session_id << session_ids)
        if answers is not None:
            query = query.where(StructuredExampleModel.answer << answers)
        log(f"DB: Loading Structured dataset '{dataset_name}'")
        for eg in query.iterator():
            st_eg = eg.load()
            st_eg["input"] = eg.input.load()
            task_type_name = st_eg.pop("__class__")[1:]
            registered_type = registry.example_types.get(task_type_name)
            parse_as = parse_as if parse_as is not None else registered_type
            yield cast(_ExampleT, parse_as.from_dict(st_eg))

    def get_st_dataset_examples_from_unst(
        self,
        dataset_name: str,
        *,
        input_keys: Optional[List[str]] = None,
        server_ann_keys: Optional[List[str]] = None,
        user_ann_keys: Optional[List[str]] = None,
        parse_as: Type[_ExampleT] = _StructExample,
    ) -> List[_ExampleT]:
        """Load examples from the unstructured Example table and
        parse them as Structured Examples. This requires providing which keys of each task
        should go in which section of the Structured Example, just like the standard
        `from_unst_user` classmethod constructor for the Structured Example model.

        Records in the Example table represent annotated data so each unstructured Example record
        is treated as user anotation data and passed through the `Example.from_unst_user` classmethod.

        dataset_name (str): Name of the dataset to get examples for.
        input_keys (Optional[List[str]]): Optional list of keys to parse into `input`.
            Defaults to the cls's configured `input_keys`
        server_ann_keys (Optional[List[str]]): Optional list of keys to parse into `server_anns`.
            Defaults to the cls's configured `server_ann_keys`
        user_ann_keys (Optional[List[str]]): Optional list of keys to parse into `user_anns`.
            Defaults to the cls's configured `user_ann_keys`
        parse_as (Type[_ExampleT]): Structured Example type to parse the unstructured example as
            (can be the base Example or any registered subtype)

        RETURNS (List[_ExampleT]): List of Structured Example objects
        """
        dataset = self.get_unst_dataset(dataset_name)
        query = (
            Example.select().join(Link).join(Dataset).where(Dataset.id == dataset.id)
        )
        st_examples = []
        for eg in query.iterator():
            unst_eg = eg.load()
            st_eg = parse_as.from_unst_user(
                unst_eg,
                input_keys=input_keys,
                server_ann_keys=server_ann_keys,
                user_ann_keys=user_ann_keys,
                db=self,
            )
            st_examples.append(st_eg)
        return st_examples

    def get_st_sessions_examples_from_unst(
        self,
        session_ids: List[str],
        *,
        input_keys: Optional[List[str]] = None,
        server_ann_keys: Optional[List[str]] = None,
        user_ann_keys: Optional[List[str]] = None,
        parse_as: Type[_ExampleT] = _StructExample,
    ) -> List[_ExampleT]:
        """Load examples from the unstructured Example table and
        parse them as Structured Examples. This requires providing which keys of each task
        should go in which section of the Structured Example, just like the standard
        `from_unst_user` classmethod constructor for the Structured Example model.

        Records in the Example table represent annotated data so each unstructured Example record
        is treated as user anotation data and passed through the `Example.from_unst_user` classmethod.

        session_ids (List[str]): Names of session datasets to get examples for
        input_keys (Optional[List[str]]): Optional list of keys to parse into `input`.
            Defaults to the cls's configured `input_keys`
        server_ann_keys (Optional[List[str]]): Optional list of keys to parse into `server_anns`.
            Defaults to the cls's configured `server_ann_keys`
        user_ann_keys (Optional[List[str]]): Optional list of keys to parse into `user_anns`.
            Defaults to the cls's configured `user_ann_keys`
        parse_as (Type[_ExampleT]): Structured Example type to parse the unstructured example as
            (can be the base Example or any registered subtype)

        RETURNS (List[_ExampleT]): List of Structured Example objects
        """
        if session_ids is None or len(session_ids) == 0:
            raise ValueError("One or more sessions are required")
        unst_session_datasets = [
            self.get_unst_dataset(session_id) for session_id in session_ids
        ]
        query = (
            Example.select()
            .join(Link)
            .join(Dataset)
            .where(Dataset.id == unst_session_datasets)
        )
        st_examples = []
        for eg in query.iterator():
            unst_eg = eg.load()
            st_eg = parse_as.from_unst_user(
                unst_eg,
                input_keys=input_keys,
                server_ann_keys=server_ann_keys,
                user_ann_keys=user_ann_keys,
                db=self,
            )
            st_examples.append(st_eg)
        return st_examples

    def count_st_dataset(
        self,
        name: str,
        session_id: Optional[str] = None,
        answer: Optional[Answer] = None,
    ) -> int:
        """Count the number of examples in a Structured Dataset
        name (str): The Structured dataset name.
        session_id: Return the number of examples for this session_id only
        RETURNS (int): The number of examples in the dataset.
        """
        dataset = self.get_st_dataset(name)
        query = (
            StructuredExampleModel.select()
            .join(StructuredLinkModel)
            .join(Dataset)
            .where(Dataset.id == dataset.id)
        )
        if session_id is not None:
            query = query.where(StructuredLinkModel.session_id == session_id)
        if answer is not None:
            query = query.where(StructuredExampleModel.answer == answer)
        count = query.count()
        return count


def get_unique_file_name(
    folder_name: Union[str, Path],
    file_base: Union[str, Path],
    file_extension: str = "jsonl",
) -> Path:
    """Get a file name based on the input arguments that is guaranteed to be
    unique in the target folder on disk.
    """
    out = Path(folder_name) / f"{file_base}.{file_extension}"
    count = 0
    while out.is_file() is True:
        out = Path(folder_name) / f"{file_base}.{count}.{file_extension}"
        count += 1
    return out


def get_unique_folder_name(parent_folder: Union[str, Path], folder_base: str) -> Path:
    """Get a folder name based on the input arguments that is guaranteed to be
    unique in the parent folder on disk.
    """
    parent = Path(parent_folder)
    out = parent / folder_base
    count = 0
    while out.is_dir() is True:
        out = parent / f"{folder_base}.{count}"
        count += 1
    return out


def get_data_path(
    env_key: Optional[str] = None, fallback_name: Optional[str] = None
) -> str:
    # make it privite in v2
    if env_key is None:
        root = Path(get_prodigy_path(fallback_name))
    else:
        root = Path(os.environ.get(env_key, get_prodigy_path(fallback_name)))
    result_folder = Path(root)
    if not result_folder.exists():
        result_folder.mkdir()
    return str(result_folder)


def get_trash_path() -> str:
    return get_data_path(ENV_VARS.TRASH, "trash")


def get_exports_path() -> str:
    return get_data_path(ENV_VARS.EXPORTS, "exports")


def get_prodigy_path(sub_folder: Optional[str] = None) -> str:
    """Get the full path to either the active prodigy folder, or a subfolder of
    it. First look in the current working directory for a prodigy file, and
    fallback to the PRODIGY_HOME folder of the current user.
    """
    root = Path(os.environ.get(ENV_VARS.HOME, Path.home() / ".prodigy"))
    cwd = Path.cwd()
    for filename in [".prodigy.json", "prodigy.json"]:
        if (cwd / filename).exists():
            root = cwd
    if sub_folder is not None:
        root = root / sub_folder
    return str(root)


def _do_bulk_create(
    db: "Database", Model: Type[_ModelT], instances: List[_ModelT], batch_size: int = 64
) -> List[_ModelT]:
    """Bulk insert unsaved Model instances. This will raise a ValueError
    if run outside a Database transaction.
    Model (Type[_ModelT]): Model type to create records for
    instances (List[_ModelT]): Instances of Model type to insert into the database
    batch_size (int): Batch size to insert with. Needed for SQLite's param limit.
    RETURNS (List[_ModelT]): List of model instance primary key ids
    """
    if not db.db.in_transaction():
        raise BulkCreateNotInTransaction(db)

    if isinstance(db.db.obj, orm.PostgresqlDatabase):
        Model.bulk_create(instances, batch_size=batch_size)
        final_instances = instances
    else:
        # Only PostgreSQL has a RETURNING clause that can sets the primary keys
        # of the created instance after bulk_create.
        # For SQLite and MySQL we just have to insert 1 row at a time to get these IDs back.
        # If you don't need the ids back, just use PeeweeModel.bulk_create directly.
        final_instances = []
        for instance in instances:
            instance.save()
            final_instances.append(instance)
    return final_instances
