from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

from prodigy.errors import ProdigyError
from prodigy.util import ANNOTATOR_ID_ATTR, VIEW_ID_ATTR


class MetricError(ProdigyError):
    """Base class for metric errors"""

    ...


class MultipleViewIdsError(MetricError):
    def __init__(self, view_ids: List[str]):
        self.msg = (
            f"Multiple view IDs found in the dataset: {', '.join(view_ids)}. "
            f"The inter-annotator agreement requires that all annotators were exposed to the same type of task."
        )


class MultipleBinaryLabelsError(MetricError):
    def __init__(self, labels: List[str]):
        self.msg = f"Multiple binary labels found in the dataset: {', '.join(labels)}. "


class MissingAnnotatorId(MetricError):
    def __init__(self, task_hash: Optional[Any]):
        self.msg = (
            f"Annotator ID is missing in example with task_hash: {task_hash} "
            f"It is expected under {ANNOTATOR_ID_ATTR} key."
        )


class MissingViewId(MetricError):
    def __init__(self, task_hash: Optional[Any]):
        self.msg = (
            f"View ID is missing in example with task_hash: {task_hash} "
            f"It is expected under {VIEW_ID_ATTR} key."
        )


class SingleAnnotatorError(MetricError):
    def __init__(self):
        self.msg = (
            "Only one annotator ID found in the dataset. "
            "The inter-annotator agreement requires at least two annotators."
        )


class MismatchedAnnotatorsError(MetricError):
    def __init__(self, not_found: List[str], found: List[str]):
        self.msg = f"Requested annotators: {', '.join(not_found)} were not found in the dataset. Found annotators: {', '.join(found)}."


class MismatchedLabelsError(MetricError):
    def __init__(self, not_found: List[str], found: List[str]):
        self.msg = f"Requested labels: {', '.join(not_found)} were not found in the dataset. Found labels: {', '.join(found)}."


class IntraAnnotatorTaskDuplicates(MetricError):
    def __init__(self, annotator_id, input_hash):
        self.msg = f"Cannot build reliability matrix: multiple annotations of a single task `{input_hash}` from annotator `{annotator_id}`."


class NoAnnotationsFound(MetricError):
    def __init__(self, labels: Optional[List] = None):
        self.msg = (
            "Not enough evidence found for IAA calculation. This might be because either the incorrect `annotation_type` was selected, "
            "or there's not enough overlap for the subset of labels requested."
        )
        if labels:
            self.msg += f" Make sure that the specified labels: {str(labels)} are present in the dataset(s)."


class NoLabelsError(MetricError):
    def __init__(self, labels: Optional[List] = None):
        self.msg = "No labels found in the dataset for the annotation_type selected"


class NoCoincidentAnnotationsFound(MetricError):
    def __init__(self):
        self.msg = (
            "Fewer than 2 coincident example found. To compute inter-annotator agreement examples "
            "must be annotated by at least two annotators."
        )


class AnnotationTypeError(MetricError):
    def __init__(self, user_ann_type: str, data_ann_type: str):
        self.msg = (
            f"Annotation type mismatch. User annotation type: {user_ann_type} does not match "
            f"data annotation type: {data_ann_type}."
        )


class MetricConfigValidationError(MetricError):
    def __init__(
        self,
        title: Optional[str],
        errors: Union[Sequence[Mapping[str, Any]], Iterable[Dict[str, Any]]],
    ):
        errors_lst = [
            f"Parameter: {error['loc'][0]} ->  {error['msg']}" for error in errors
        ]
        if title is None:
            self.msg = f"Invalid config: " f"{', '.join(errors_lst)}"
        else:
            self.msg = f"Invalid {title} config: " f"{', '.join(errors_lst)}"


class MetricRegistryError(MetricError):
    def __init__(self, args: Tuple[Any, ...]):
        self.msg = f"Metric registry error: {', '.join(args)}"
