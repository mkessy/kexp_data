import json
from collections import defaultdict
from dataclasses import asdict, dataclass
from itertools import combinations
from typing import Dict, Iterable, List, Literal, Optional, Set, Tuple, Union

import numpy as np
from wasabi import msg

from prodigy.components.metrics._util import (
    VALUE_GETTERS,
    _build_reliability_table,
    _get_avg_annotations_per_example,
    _get_coincident_examples,
    _get_single_annotation_examples,
    _validate_dataset,
)
from prodigy.components.metrics.base import Metric, prodigy_metric
from prodigy.components.metrics.errors import MetricError
from prodigy.structured_types import SpansAnns, SpansManualAnns
from prodigy.types import TaskType, TextManualSpan, TextSpan


@dataclass
class IaaSpanStats:
    """Stores IAA Span metric computation.
    Provides methods to render the results as a string."""

    n_examples: int
    n_categories: int
    n_coincident_examples: int
    n_single_annotation: int
    n_annotators: int
    avg_raters_per_example: float
    pairwise_f1: float
    pairwise_recall: float
    pairwise_precision: float
    confusion_matrix: np.ndarray
    normalized_confusion_matrix: np.ndarray
    metrics_per_label: Dict[str, Dict[str, float]]


class IaaSpan(Metric[Dict[str, IaaSpanStats]]):
    """Compute inter-annotator agreement (IAA) for span-level annotations using pairwise F1 score.
    labels (Optional[List[str]]): A list of labels to use for the metric. If not provided, it will be inferred from the dataset.
    annotators (List[str]): A list of annotators to use for the metric. If not provided, it will be inferred from the dataset.
    partial (Optional[bool]): Whether to allow partial matches. If True, partial matches will be considered an agreement. Defaults to False.
    """

    def __init__(
        self,
        labels: Optional[List[str]] = None,
        annotators: Optional[List[str]] = None,
        partial: bool = False,
    ):
        super().__init__()
        # init params for metric computation
        self._annotation_type: Literal["spans"] = "spans"
        self._cli_labels: Optional[List[str]] = labels
        self._labels: List[str] = []
        self._cli_annotators: Optional[list[str]] = annotators
        self._annotators: List[str] = []
        self._view_ids: Set[str] = set()
        self._partial: bool = partial

        # init states for metric computation
        self._examples: List[TaskType] = []
        self._reliability_table: np.ndarray = np.array([])
        self._pairwise_cms: List[np.ndarray] = []
        self._confusion_matrix: np.ndarray = np.array([])
        self._results_per_label: Dict[str, IaaSpanStats] = {}
        self._value_getter = VALUE_GETTERS["spans"]
        self._results: IaaSpanStats = IaaSpanStats(
            n_examples=0,
            n_categories=0,
            n_coincident_examples=0,
            n_single_annotation=0,
            n_annotators=0,
            avg_raters_per_example=0.0,
            pairwise_f1=0.0,
            pairwise_recall=0.0,
            pairwise_precision=0.0,
            confusion_matrix=np.array([]),
            normalized_confusion_matrix=np.array([]),
            metrics_per_label=defaultdict(dict),
        )

    def measure(self, tasks: Iterable[TaskType]) -> None:
        """Update the metric states: examples, reliability_table & confusion matrix with new data.
        Compute the results on the updated states.
        tasks: (Iterable[TaskType]) An iterable of structured tasks to update the metric states with.
        """
        self._examples.extend(tasks)
        self._annotators, self._labels, self._view_ids = _validate_dataset(
            examples=self._examples,
            cli_labels=self._cli_labels,
            cli_annotators=self._cli_annotators,
            annotation_type=self._annotation_type,
        )
        self._reliability_table = _build_reliability_table(
            examples=self._examples,
            labels=self._labels,
            annotators=self._annotators,
            annotation_type=self._annotation_type,
            value_getter=self._value_getter,
        )
        self._update_cms()
        self._update_results()

    def get_result(self) -> IaaSpanStats:
        """Returns the current metric result.
        RETURNS: (IaaSpanStats) IAA span stats."""
        # To facilitate writing common pretty print functions for all metrics
        return self._results

    def to_dict(self) -> Dict:
        result = self.get_result()
        result.metrics_per_label = dict(result.metrics_per_label)
        result.normalized_confusion_matrix = result.normalized_confusion_matrix.tolist()
        result.confusion_matrix = result.confusion_matrix.tolist()
        return asdict(result)

    def to_disk(self, output_path: str) -> None:
        """Serialize the metric result to a file.
        path (Union[str, Path]): Path to the file to serialize the result to."""
        result_str = json.dumps(self.to_dict(), indent=2)
        with open(output_path, "w") as file_:
            try:
                file_.write(result_str)
                msg.info(f"Results written to {output_path}")
            except ValueError:
                raise MetricError(f"Couldn't write to file: {output_path}")

    def _update_cms(self) -> None:
        """Updates the confusion matrix for each pair of annotators"""

        labels = self._labels + ["0"]  # add "0" label for false negatives
        self._reset_confusion_matrix(len(labels))
        # get all combination of annotator indices
        for ann1_idx, ann2_idx in combinations(range(0, len(self._annotators)), 2):
            # relevant slice of reliability table
            coincident_egs = self._get_coincident_examples(ann1_idx, ann2_idx)
            pairwise_confusion_matrix: np.ndarray = (
                self._build_pairwise_confusion_matrix(coincident_egs, labels)
            )
            self._confusion_matrix += pairwise_confusion_matrix
            self._pairwise_cms.append(pairwise_confusion_matrix)

    def _normalize_confusion_matrix(self) -> np.ndarray:
        """Normalize the confusion matrix by the number of annotators"""
        row_sums = self._confusion_matrix.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = np.nan
        cmn = np.nan_to_num(self._confusion_matrix / row_sums, nan=0.0)
        return cmn

    def _build_pairwise_confusion_matrix(
        self, coincident_egs: np.ndarray, labels: List[str]
    ) -> np.ndarray:
        """Builds a pairwise confusion matrix for a pair of annotators"""
        pairwise_confusion_matrix = np.zeros((len(labels), len(labels)))
        for eg in coincident_egs:
            true_labels = eg[0]
            pred_labels = eg[1]
            single_eg_confusion_matrix = self._build_single_eg_confusion_matrix(
                true_labels, pred_labels, labels
            )
            pairwise_confusion_matrix += single_eg_confusion_matrix
        return pairwise_confusion_matrix

    def _build_single_eg_confusion_matrix(
        self,
        true_labels: Union[SpansAnns, SpansManualAnns, None],
        pred_labels: Union[SpansAnns, SpansManualAnns, None],
        labels: List[str],
    ) -> np.ndarray:
        """Builds a confusion matrix for a single example"""
        labels2int: Dict[str, int] = {label: i for i, label in enumerate(labels)}
        true_spans = (
            true_labels.spans
            if (true_labels is not None and true_labels.spans is not None)
            else []
        )
        pred_spans = (
            pred_labels.spans
            if (pred_labels is not None and pred_labels.spans is not None)
            else []
        )
        true_by_span = _index_by_span(labels2int, true_spans)
        pred_by_span = _index_by_span(labels2int, pred_spans)
        true_by_token = _index_by_token(labels2int, true_spans)
        pred_by_token = _index_by_token(labels2int, pred_spans)
        eg_matrix = _get_matrix(
            labels2int,
            true_spans,
            true_by_span,
            true_by_token,
            pred_spans,
            pred_by_span,
            pred_by_token,
            partial=self._partial,
        )
        return eg_matrix

    def _get_coincident_examples(self, ann1_idx: int, ann2_idx: int) -> np.ndarray:
        """Returns the examples annotated by both annotators"""
        # Select rows where neither ann1_idx col nor ann2_idx col is -1
        relevant_columns = self._reliability_table[:, [ann1_idx, ann2_idx]]
        mask = (relevant_columns[:, 0] != -1) & (relevant_columns[:, 1] != -1)
        coincident_egs = relevant_columns[mask]
        return coincident_egs

    def _update_results(self) -> None:
        self._results.n_examples = len(self._examples)
        self._results.n_categories = len(self._labels)
        self._results.n_coincident_examples = _get_coincident_examples(self._examples)
        self._results.n_single_annotation = _get_single_annotation_examples(
            self._examples
        )
        self._results.n_annotators = len(self._annotators)
        self._results.avg_raters_per_example = _get_avg_annotations_per_example(
            self._examples
        )
        self._compute_agreement()

    def _compute_agreement(self) -> None:
        tp = np.diag(self._confusion_matrix)
        fp = np.sum(self._confusion_matrix, axis=0) - tp
        fn = np.sum(self._confusion_matrix, axis=1) - tp
        precision = np.nan_to_num(tp / (tp + fp), nan=0.0)
        recall = np.nan_to_num(tp / (tp + fn), nan=0.0)
        f1 = np.nan_to_num(2 * (precision * recall) / (precision + recall), nan=0.0)
        total_support = sum(tp) + sum(fn)
        for label_idx, label in enumerate(self._labels):
            self._results.metrics_per_label[label]["p"] = precision[label_idx]
            self._results.metrics_per_label[label]["r"] = recall[label_idx]
            self._results.metrics_per_label[label]["f1"] = f1[label_idx]
            self._results.metrics_per_label[label]["support"] = (
                tp[label_idx] + fn[label_idx]
            )
        self._update_macro_avg(total_support)
        self._results.confusion_matrix = self._confusion_matrix
        self._results.normalized_confusion_matrix = self._normalize_confusion_matrix()

    def _reset_confusion_matrix(self, dim: int) -> None:
        self._confusion_matrix = np.zeros((dim, dim))

    def _update_macro_avg(self, total_support: int) -> None:
        """Computes aggregate metrics from per label metrics"""

        def _get_avg(metric: str) -> float:
            return round(
                sum(
                    [
                        self._results.metrics_per_label[label][metric]
                        for label in self._labels
                    ]
                )
                / len(self._labels),
                2,
            )

        self._results.pairwise_precision = _get_avg("p")
        self._results.pairwise_recall = _get_avg("r")
        self._results.pairwise_f1 = _get_avg("f1")


@prodigy_metric("prodigy.metrics.IaaSpan.v1")
def make_iaa_span_metric(
    labels: Optional[List[str]] = None,
    annotators: Optional[List[str]] = None,
    partial: bool = False,
) -> IaaSpan:
    """Initialize an IAA metric for span-level annotations.
    labels (List[str]): A list of labels to use for the metric computation. If not specified all labels will be used.
    annotators (List[str]): A list of annotators to use for the metric computation. If not specified, annotators will be inferred from the dataset.
    RETURNS (IaaSpan): An IaaSpan metric object.
    """
    return IaaSpan(labels, annotators, partial)


def _get_label(
    labels2int: Dict[str, int], span: Union[TextSpan, TextManualSpan]
) -> int:
    if span.label is None:
        return labels2int["0"]
    else:
        return labels2int.get(span.label, labels2int["0"])


def _get_key(span: Union[TextSpan, TextManualSpan]) -> Tuple[int, int]:
    return (span.start, span.end)


def _index_by_span(
    labels2int: Dict[str, int], spans: Union[List[TextSpan], List[TextManualSpan]]
) -> Dict[Tuple[int, int], int]:
    return {_get_key(span): _get_label(labels2int, span) for span in spans}


def _get_span_by_token_idx(
    token_idx: int, spans: Union[List[TextSpan], List[TextManualSpan]]
) -> Optional[Tuple[int, int]]:
    for span in spans:
        if token_idx in _get_tokens(span):
            return _get_key(span)
    return None


def _get_tokens(span: Union[TextManualSpan, TextSpan]) -> List[int]:
    # Maybe this should be character?
    # shrug
    # yes it should
    return list(range(span.start, span.end + 1))


def _index_by_token(
    labels2int: Dict[str, int], anns: Union[List[TextSpan], List[TextManualSpan]]
) -> Dict[int, int]:
    output = {}
    for span in anns:
        label = _get_label(labels2int, span)
        for token_idx in _get_tokens(span):
            output[token_idx] = label
    return output


def _get_matrix(
    labels2int: Dict[str, int],
    true_spans: Union[List[TextSpan], List[TextManualSpan]],
    true_by_span: Dict[Tuple[int, int], int],
    true_by_token: Dict[int, int],
    pred_spans: Union[List[TextSpan], List[TextManualSpan]],
    pred_by_span: Dict[Tuple[int, int], int],
    pred_by_token: Dict[int, int],
    partial: bool,
) -> np.ndarray:
    eg_matrix: np.ndarray = np.zeros((len(labels2int), len(labels2int)))
    if true_spans == pred_spans == []:
        eg_matrix[labels2int["0"], labels2int["0"]] += 1
    elif true_spans == [] and pred_spans == []:
        # all true spans are false positives
        # no need to consider partials because there are no true spans
        for p_span in pred_spans:
            p_label = _get_label(labels2int, p_span)
            eg_matrix[labels2int["0"], p_label] += 1  # false negative
    elif true_spans != [] and pred_spans == []:
        # all true spans are false positives
        # no need to consider partials because there are no pred spans
        for t_span in true_spans:
            t_label = _get_label(labels2int, t_span)
            eg_matrix[t_label, labels2int["0"]] += 1  # false positive
    else:
        partials = set()
        for t_span in true_spans:
            t_label = _get_label(labels2int, t_span)
            key = _get_key(t_span)
            if key in pred_by_span:
                p_label = pred_by_span[key]
                eg_matrix[t_label, p_label] += 1
            else:
                if partial:
                    # We haven't found a fully matching span
                    # so we are checking whether we have a partial match.
                    # * If partial match, record it
                    # * If no partial, record false pos
                    found_partial = False
                    for token_idx in _get_tokens(t_span):
                        p_token_label = pred_by_token.get(token_idx)
                        if t_label == p_token_label:
                            # Found partial match
                            eg_matrix[t_label, p_token_label] += 1
                            found_partial = True
                            partials.add(_get_span_by_token_idx(token_idx, pred_spans))
                            break
                    if not found_partial:
                        eg_matrix[t_label, labels2int["0"]] += 1
                else:
                    # We haven't found a fully matching span
                    # so we record a false positive
                    eg_matrix[t_label, labels2int["0"]] += 1
        # Now we go over the predicted spans to see if there are
        # any false negatives
        for p_span in pred_spans:
            p_label = _get_label(labels2int, p_span)
            key = _get_key(p_span)
            if key in true_by_span:
                continue
            if key in partials:
                continue
            else:
                eg_matrix[labels2int["0"], p_label] += 1
    return eg_matrix
