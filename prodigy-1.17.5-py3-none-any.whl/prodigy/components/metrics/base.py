import abc
import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    Iterable,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
)

from catalogue import RegistryError
from confection import Config, ConfigValidationError
from spacy.cli._util import parse_config_overrides
from spacy.util import load_config

from prodigy.components.metrics.errors import (
    MetricConfigValidationError,
    MetricRegistryError,
)
from prodigy.types import TaskType
from prodigy.util import registry

_MetricT = TypeVar("_MetricT", bound="Metric")
_MetricResultT = TypeVar("_MetricResultT")

# Base metric class
class Metric(Generic[_MetricResultT]):
    """Abstract base class for a metric to be computed over a Prodigy dataset.
    Implements `from_config` method for initializing an instance from a confection config as a string or file. The config should contain
    the section [metric] and provide the reference to a registered metric factory function e.g.:
    ```
    [metric]
    @metrics = "prodigy.metrics.MyMteric.v1
    param1 = 1
    param2 = ["a","b","c"]
    ```
    If no config is provided the class generates a default config string using the provided name of a registered metric factory function.
    `from_config` is an expected way to initialize a Metric object. It will set `name` and `config` attributes (both deafult to None).
    Metric also implements `to_string` and `to_disk` methods for a simple serialization of results of Dict or Dataclass type.
    Subclasses should implement `__init__()`, `measure()`, `get_result()` & `reset()` methods.
    """

    def __init__(
        self,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.name = None
        self.config = None

    @classmethod
    def from_config(
        cls,
        name: str,
        config: Optional[Union[Path, str, Dict]] = None,
        overrides: Optional[Tuple[str, ...]] = None,
    ) -> "Metric":
        """Initialize the metric from a config.
        name (str): Name of the registered metric factory function.
        config (Optional[Union[Path, str, Dict]]): config string/dict or path to the .cfg file.
        overrides (Optional[str]): overrides to the config.
        RETURN: Metric instance."""
        if config is None:
            config = cls._get_default_metric_config(name)
        resolved_config = resolve_config(name, config, overrides)
        metric_obj = resolved_config.get("metric")
        assert isinstance(metric_obj, cls)
        metric_obj.name = name
        metric_obj.config = resolved_config
        return metric_obj

    @abc.abstractmethod
    def measure(self, examples: Iterable[TaskType]):
        """Updates the states and the results based on the new data.
        examples: Iterable of new tasks to update the metric with."""
        ...

    @abc.abstractmethod
    def get_result(self) -> _MetricResultT:
        """Returns the result of the metric computation based on the current metric states.
        RETURNS (_MetricResultT): Metric result."""
        ...

    @abc.abstractmethod
    def reset(self) -> None:
        """Reset the metric state(s)."""
        ...

    def to_dict(self) -> Dict:
        """Try to convert the result object to a Dict for a simple serialization.
        RETURNS (dict): Result as Dict.
        RAISES: ValueError if result is not of Dict or Dataclass type.
        """
        res_obj = self.get_result()
        res_dict = None
        if is_dataclass(res_obj):
            res_dict = asdict(res_obj)
        elif isinstance(res_obj, Dict):
            res_dict = res_obj
        if not res_dict:
            raise ValueError("Couldn't convert the result object to Dict.")
        return res_dict

    def to_string(self) -> str:
        """Serialize metric results in Dict or Dataclass format to a string. Should be overridden for custom serialization of _MetricResultT.
        RETURNS (str): Serialized result as str.
        RAISES: ValueError if result is not of Dict or Dataclass type."""
        try:
            res_dict = self.to_dict()
        except ValueError:
            raise NotImplementedError(
                "Default `to_string` supports result as a dictionary or a dataclass. Otherwise, a custom implementation is required."
            )
        return json.dumps(res_dict, indent=2)

    def to_disk(self, filepath: Union[Path, str]) -> None:
        """Write metric results to a file. The result is serialized using `to_string` method. Should be overridden for custom serialization or _MetricResultT other than Dict or Dataclass.
        filepath (str): Path to write the result to."""
        path = Path(filepath) if isinstance(filepath, str) else filepath
        with path.open("w", encoding="utf8") as file_:
            try:
                file_.write(self.to_string())
            except ValueError:
                raise NotImplementedError(
                    "Default `to_disk` supports result as a dictionary or a dataclass. Otherwise, a custom implementation is required."
                )

    @classmethod
    def _get_default_metric_config(cls, metric_name: str) -> str:
        return f'[metric]\n@metrics = "{metric_name}"'


# Metric decorator
def prodigy_metric(name: str) -> Callable[[Callable], Callable]:
    """Decorator to register a function for constructing a metric class."""

    def metric_maker_wrapper(
        metric_maker: Callable[..., Type[_MetricT]]
    ) -> Callable[..., Type[_MetricT]]:
        registry.metrics.register(name, func=metric_maker)  # type: ignore only visible at runtime
        return metric_maker

    return metric_maker_wrapper


# Utilities
def resolve_config(
    metric_name: str,
    config: Union[str, Path, Dict],
    overrides: Optional[Tuple[str, ...]] = None,
) -> Dict[str, Any]:
    """
    Loads and resolves the metric config and its overrides.
    If no .cfg file is provided, the default config is loaded with the name of the registered constructor in the `[metric]` section.
    metric_name: name of the registered metric factory function.
    config: path to the confection .cfg file.
    overrides: tuple of config overrides in the form of key=value e.g: ('--metric.annotation_type=binary',)).
    RETURNS: resolved config dict.
    RAISES: RegistryError if the metric_name is not registered.
            ConfigValidationError if the config is invalid.
    """
    overrides_dict = {}
    if overrides is not None:
        overrides_dict = parse_config_overrides(list(overrides))
    if isinstance(config, Path):
        config_obj = load_config(config, overrides_dict)
    elif isinstance(config, Dict):
        config_obj = Config(config)
    else:
        config_obj = Config().from_str(text=config, overrides=overrides_dict)
    try:
        resolved = registry.resolve(config_obj)
    except ConfigValidationError as err:
        raise MetricConfigValidationError(title=err.title, errors=err.errors)
    except RegistryError as err:
        raise MetricRegistryError(args=err.args)
    return resolved
