from collections import defaultdict
from itertools import groupby
from typing import Callable, Dict, List, Literal, Optional, Set, Tuple, Union

import numpy as np

from prodigy.components.metrics.errors import (
    AnnotationTypeError,
    IntraAnnotatorTaskDuplicates,
    MetricError,
    MismatchedAnnotatorsError,
    MismatchedLabelsError,
    MissingAnnotatorId,
    MissingViewId,
    MultipleBinaryLabelsError,
    MultipleViewIdsError,
    NoAnnotationsFound,
    NoLabelsError,
    SingleAnnotatorError,
)
from prodigy.structured_types import SpansManualAnns
from prodigy.types import TaskType
from prodigy.util import (
    ANNOTATOR_ID_ATTR,
    INPUT_HASH_ATTR,
    TASK_HASH_ATTR,
    VIEW_ID_ATTR,
    msg,
)

_NO_ANNOTATION: int = (
    -1
)  # constant to mark the absence of annotation from a given annotator


def _validate_dataset(
    examples: List[TaskType],
    cli_labels: Optional[List[str]],
    cli_annotators: Optional[List[str]],
    annotation_type: Literal["spans", "binary", "multiclass", "multilabel"],
) -> Tuple[List[str], List[str], Set[str]]:
    """Infer the annotators labels and view_ids from the dataset and validate against CLI arguments if provided.
    RAISES: MissingAnnotatorID if annotator_id is not found in the meta dict of the Task.
            SingleAnnotatorError if there is only one annotator in the dataset.
            MismatchedAnnotatorsError if the annotators provided via CLI do not match the annotators found in the dataset.
            MismatchedLabelsError if the labels provided via CLI do not match the labels found in the dataset.
    """
    data_annotators, data_labels, view_ids = _get_attributes(examples, annotation_type)
    # validate that view_id is unique for all examples
    if len(view_ids) > 1:
        raise MultipleViewIdsError(view_ids=list(view_ids))
    annotators = _validate_annotators(cli_annotators, data_annotators)
    labels = _validate_labels(cli_labels, data_labels, annotation_type)
    return annotators, labels, view_ids


def _get_attributes(
    examples: List[TaskType],
    annotation_type: Literal["spans", "binary", "multiclass", "multilabel"],
) -> Tuple[set, set, set]:
    """Get the annotators, labels and view_ids from the dataset for validation.
    RETURNS: (Tuple[set, set, set]) A tuple of annotators, labels and view_ids.
    """
    annotators = set()
    labels = set()
    view_ids = set()
    for example in examples:
        view_id = example.get(VIEW_ID_ATTR)
        if view_id is None:
            raise MissingViewId(task_hash=example.get(TASK_HASH_ATTR))
        view_ids.add(view_id)
        annotator_id = example.get(ANNOTATOR_ID_ATTR)
        if annotator_id is None:
            raise MissingAnnotatorId(task_hash=example.get(TASK_HASH_ATTR))
        annotators.add(annotator_id)
        if annotation_type == "binary":
            labels.add(example.get("label"))
        elif annotation_type == "spans":
            if example.get("spans") is not None:
                labels.update(set([span.get("label") for span in example.get("spans")]))  # type: ignore
        elif annotation_type in ("multiclass", "multilabel"):
            labels.update(set(example.get("accept", [])))
        else:
            raise MetricError(f"Unsupported annotation_type: {annotation_type}")
    return annotators, labels, view_ids


def _validate_annotators(
    cli_annotators: Optional[List[str]], data_annotators: Set[str]
) -> List[str]:
    """Validate that there are at least 2 annotators and that the annotators specified on CLI match the dataset.
    cli_annotators: (list) A list of annotators provided via CLI.
    data_annotators: (set) A set of annotators collected from the dataset.
    RAISES: SingleAnnotatorError if there is only one annotator in the dataset.
            MismatchedAnnotatorsError if the annotators provided via CLI do not match the annotators found in the dataset.
    """
    annotators: List[str] = []
    if cli_annotators:
        diff = set(cli_annotators).difference(data_annotators)
        if diff:
            raise MismatchedAnnotatorsError(
                not_found=list(diff), found=list(data_annotators)
            )
        else:
            annotators = cli_annotators
    else:
        annotators = list(data_annotators)
    if len(annotators) < 2:
        raise SingleAnnotatorError()

    msg.info(f"Using {len(annotators)} annotator IDs: {', '.join(annotators)}")
    return annotators


def _validate_labels(
    cli_labels: Optional[List[str]],
    data_labels: Set[str],
    annotation_type: Literal["spans", "binary", "multiclass", "multilabel"],
) -> List[str]:
    """Validate that the labels specified on CLI match the dataset and that that binary label is unique.
    cli_labels: (list) A list of labels provided via CLI.
    data_labels: (set) A set of labels collected from the dataset.
    RAISES: MismatchedLabelsError if the annotators provided via CLI do not match the annotators found in the dataset.
            MultipleBinaryLabelsError if the binary label is not unique.
    """
    labels: List[str] = []
    if cli_labels:
        diff = set(cli_labels).difference(data_labels)
        if diff:
            raise MismatchedLabelsError(not_found=list(diff), found=list(data_labels))
        else:
            # Careful to make a copy, as we're returning.
            # We don't want to return a reference to CLI
            # labels. If the user modifies the value after
            # we return, they might have a bad time.
            labels = list(cli_labels)
    else:
        if annotation_type != "binary":
            labels = list(data_labels)
            if len(labels) == 0:
                raise NoLabelsError()
            else:
                msg.info(
                    f"Using {len(labels)} labels: {', '.join([str(label) for label in labels])}"
                )
    # validate that binary annotations have only one label
    if annotation_type == "binary" and len(labels) > 1:
        raise MultipleBinaryLabelsError(labels=[str(label) for label in labels])
    return labels


def _has_unique_annotations(annotations) -> bool:
    """Validate that a set of annotations is unique by `key`"""
    return len(set(a.get(ANNOTATOR_ID_ATTR) for a in annotations)) == len(annotations)


def _is_matrix_valid(matrix: np.ndarray) -> bool:
    """Checks that the matrix is filled with single value."""
    if matrix.size == 0:
        return True
    elif np.all(matrix is None):
        return False
    elif np.all((matrix == -1) | (matrix == 0)):
        return False
    return True


def _get_answer(example: TaskType) -> int:
    if example.get("answer") == "accept":
        return 1
    elif example.get("answer") == "reject":
        return 0
    else:
        return _NO_ANNOTATION


def _get_choice(example: TaskType) -> Union[str, int]:
    if example.get("answer") == "accept":
        annotations = example.get("accept", [])
        if len(annotations) == 1:
            return annotations[0]
        elif len(annotations) == 0:
            return _NO_ANNOTATION
        else:
            raise AnnotationTypeError(
                user_ann_type="multiclass", data_ann_type="multilabel"
            )
    return _NO_ANNOTATION


def _get_contains(
    example: TaskType,
    value: str,
) -> int:
    """Used with functools.partial in build_reliability_table for multilabel case."""
    if example.get("answer") == "accept":
        annotations = example.get("accept")
        if annotations is None:
            return 0
        return 1 if value in annotations else 0
    return _NO_ANNOTATION


def _get_spans(example: TaskType) -> Union[SpansManualAnns, None, int]:
    if example.get("answer") == "accept":
        spans = example.get("spans")
        tokens = example.get("tokens")
        if spans:
            if tokens is None:
                raise MetricError("Cannot compute metrics: missing tokens")

            return SpansManualAnns(spans=spans, tokens=tokens)
        else:
            return None  # no spans were annotated
    return _NO_ANNOTATION  # no answer was given


VALUE_GETTERS: Dict[str, Callable] = {
    "binary": _get_answer,
    "multiclass": _get_choice,
    "multilabel": _get_contains,
    "spans": _get_spans,
}


def _build_reliability_table(
    examples: List[TaskType],
    labels: List[str],
    annotators: List[str],
    annotation_type: Literal["binary", "multiclass", "multilabel", "spans"],
    value_getter: Callable,
) -> np.ndarray:
    """Converts a dataset to an (N x A) reliability matrix, where N is the number
    of unique examples keyed by `_input_hash` and A is the number of unique annotators
    given by `_annotator_id`, and the value is the annotation given by annotator A to example N
    (or _NO_ANNOTATION if not annotated)"""
    # Initialize the index mapping from task hashes to lists of examples by annotator.
    # Need to make sure the inner dict keys are in the right order to make output
    # deterministic and have all annotators (even if the list is empty at the end)
    indexed = defaultdict(lambda: {ann_id: [] for ann_id in sorted(annotators)})
    for eg in examples:
        # filter out examples from excluded annotators
        if eg[ANNOTATOR_ID_ATTR] not in annotators:
            continue
        indexed[eg[INPUT_HASH_ATTR]][eg[ANNOTATOR_ID_ATTR]].append(eg)
    n_tasks = len(indexed)
    labels2int = {label: i for i, label in enumerate(labels)}
    reliability_matrix = np.ndarray((n_tasks, len(annotators)), dtype=object)
    for i, (input_hash, by_annotator) in enumerate(indexed.items()):
        for j, (annotator_id, annotations) in enumerate(by_annotator.items()):
            if len(annotations) == 1:
                value = value_getter(annotations[0])
                if annotation_type == "multiclass":
                    # Missing labels can happen when a subset of labels was requested
                    # so ignoring these examples
                    value = labels2int.get(value, _NO_ANNOTATION)
                reliability_matrix[i, j] = value
            elif len(annotations) == 0:
                reliability_matrix[i, j] = -1
            else:
                raise IntraAnnotatorTaskDuplicates(annotator_id, input_hash)
    if not _is_matrix_valid(reliability_matrix):
        raise NoAnnotationsFound()
    return reliability_matrix


def _format_number(number: float, ndigits: int = 2) -> str:
    """Formats a number rounding to `ndigits`, without truncating trailing 0s,
    as happens with `round(number, ndigits)`"""
    return f"{number:.{ndigits}f}"


def _get_coincident_examples(examples: List[TaskType]) -> int:
    """Returns the number of examples with coincident annotations."""
    grouped_by_task = groupby(
        sorted(examples, key=lambda x: x[INPUT_HASH_ATTR]), lambda x: x[INPUT_HASH_ATTR]
    )
    return sum(1 for _, group in grouped_by_task if len(list(group)) >= 2)


def _get_single_annotation_examples(examples: List[TaskType]) -> int:
    """Returns the number of examples with coincident annotations."""
    grouped_by_task = groupby(
        sorted(examples, key=lambda x: x[INPUT_HASH_ATTR]), lambda x: x[INPUT_HASH_ATTR]
    )
    return sum(1 for _, group in grouped_by_task if len(list(group)) == 1)


def _get_avg_annotations_per_example(examples: List[TaskType]) -> float:
    """Returns the average number of annotations per example."""
    grouped_by_task = groupby(
        sorted(examples, key=lambda x: x[INPUT_HASH_ATTR]), lambda x: x[INPUT_HASH_ATTR]
    )
    groups_lens = [len(list(group)) for _, group in grouped_by_task]
    return sum(groups_lens) / len(groups_lens)
