import json
from collections import Counter
from dataclasses import asdict, dataclass
from functools import partial
from itertools import chain, product
from pathlib import Path
from typing import (
    Callable,
    Dict,
    Iterable,
    List,
    Optional,
    Tuple,
)
from typing_extensions import Literal

import numpy as np
from wasabi import msg

from prodigy.components.metrics.errors import (
    MetricError,
    NoAnnotationsFound,
    NoCoincidentAnnotationsFound,
)
from prodigy.types import TaskType

from ._util import (
    _NO_ANNOTATION,
    VALUE_GETTERS,
    _build_reliability_table,
    _validate_dataset,
)
from .base import Metric, prodigy_metric


@dataclass
class IaaDocStats:
    """Stores the results of IAA Doc metric computation."""

    n_examples: int
    n_categories: int
    n_coincident_examples: int
    n_single_annotation: int
    n_annotators: int
    avg_raters_per_example: float
    percent_agreement: float
    kripp_alpha: float
    gwet_ac2: float


class IaaDoc(Metric[Dict[str, IaaDocStats]]):
    """Compute inter-annotator agreement (IAA) for document-level annotations using Percent Agreement, Krippendorff's Alpha, and Gwet's AC1 as metrics.
    The algorithm implementation is ported from: https://github.com/pmbaumgartner/prodigy-iaa.
    annotation_type (str): The type of annotation. Can be "binary", "multiclass" or "multilabel". The type of annotation determines
    what key from the Task will be used to collect annotations. For "binary" annotations, the "answer" key will be used.
    For "multiclass" & "multilabel" annotations, the "accept" key will be used unless a custom key is specified.
    labels (List[str]): A list of labels to use for the metric. Only needed for "multilabel" annotation type.
    annotators (List[str]): A list of annotators to use for the metric. If not provided, it will be inferred from the dataset.
    """

    def __init__(
        self,
        annotation_type: Literal["binary", "multiclass", "multilabel"],
        labels: Optional[List[str]],
        annotators: Optional[List[str]],
    ):
        super().__init__()
        # init params for metric computation
        self._annotation_type: Literal[
            "binary", "multiclass", "multilabel"
        ] = annotation_type
        self._cli_labels: Optional[List[str]] = labels if labels else None
        self._labels: List[str] = []
        self._cli_annotators: Optional[List[str]] = annotators if annotators else None
        self._annotators: List[str] = []
        self._weighting: Callable = self._identity_weighting

        # init states for metric computation , these states will be updated in
        # the `update` method and used as input to the `get_result`` method
        self._examples: List[TaskType] = []
        self._agreement_table_per_label: Dict[str, np.ndarray] = {}
        self._reliability_table_per_label: Dict[str, np.ndarray] = {}
        self._results_per_label: Dict[str, IaaDocStats] = {}

    def measure(self, tasks: Iterable[TaskType]) -> None:
        """Update the metric states: examples, reliability_table_per_label & agreement_table_per_label with new data.
        Compute the results on the updated states.
        tasks: (Iterable[Task]) An iterable of structured tasks to update the metric states with.
        """
        value_getter = VALUE_GETTERS[self._annotation_type]
        self._examples.extend(tasks)
        self._annotators, self._labels, _ = _validate_dataset(
            self._examples,
            self._cli_labels,
            self._cli_annotators,
            self._annotation_type,
        )
        if self._annotation_type in ("binary", "multiclass"):
            self._reliability_table_per_label["_all"] = _build_reliability_table(
                self._examples,
                self._labels,
                self._annotators,
                self._annotation_type,
                value_getter,
            )
            self._agreement_table_per_label["_all"] = self._build_agreement_table(
                self._reliability_table_per_label["_all"]
            )
            stats = self._compute_agreement(
                self._agreement_table_per_label["_all"],
                self._reliability_table_per_label["_all"],
                "_all",
            )
            self._results_per_label["_all"] = stats
        elif self._annotation_type == "multilabel":
            for label in self._labels:
                label_value_getter = partial(value_getter, value=label)
                try:
                    reliability_table = _build_reliability_table(
                        self._examples,
                        self._labels,
                        self._annotators,
                        self._annotation_type,
                        label_value_getter,
                    )
                except NoAnnotationsFound:
                    raise NoAnnotationsFound(labels=[label])
                self._reliability_table_per_label[label] = reliability_table
                self._agreement_table_per_label[label] = self._build_agreement_table(
                    reliability_table
                )
                self._results_per_label[label] = self._compute_agreement(
                    self._agreement_table_per_label[label],
                    self._reliability_table_per_label[label],
                    label,
                )

    def get_result(self) -> Dict[str, IaaDocStats]:
        """Returns the current metric result.
        RETURNS: (Dict[str, IaaDocStats]) A dictionary of IAA doc stats."""
        return self._results_per_label

    def to_disk(self, output_path: str) -> None:
        result_str = ""
        if self._annotation_type == "multilabel":
            multilabel_result_dict = {}
            for label, stats in self.get_result().items():
                multilabel_result_dict[label] = asdict(stats)
                result_str = json.dumps(multilabel_result_dict, indent=2)
        else:
            result_str = json.dumps(asdict(self.get_result()["_all"]), indent=2)
        path = Path(output_path)
        with path.open("w", encoding="utf8") as file_:
            try:
                file_.write(result_str)
                msg.info(f"Results written to {output_path}")
            except ValueError:
                raise MetricError(f"Couldn't write to file: {output_path}")

    def _identity_weighting(self, annot_k: float, annot_l: float) -> float:
        """These measures provide a weighting metric option where the output is [0, 1]. This defines agreement if the two
        values are equal.
        We could consider exposing this as a parameter to the user.
        """
        return float(annot_k == annot_l)

    def _build_agreement_table(self, reliability_matrix: np.ndarray) -> np.ndarray:
        """Converts a (N x A) data matrix into an (N x K) agreement matrix, containing the
        number of values for each of K categories for each example.
        """
        categories = set(chain.from_iterable(reliability_matrix))
        categories.discard(_NO_ANNOTATION)
        agreement_matrix: np.ndarray = np.empty(
            shape=(0, len(categories), 2), dtype=[("first", object), ("second", int)]
        )
        for row in reliability_matrix:
            counter = _category_counter(categories)
            counter.update([r for r in row if r != _NO_ANNOTATION])
            new_row = np.array([list(t) for t in counter.items()], dtype=object)
            agreement_matrix = np.append(agreement_matrix, [new_row], axis=0)
        return agreement_matrix

    def _compute_agreement(
        self, agreement_table: np.ndarray, reliability_table: np.ndarray, label: str
    ) -> IaaDocStats:
        """From: https://github.com/pmbaumgartner/prodigy-iaa
        This calculates Percent Agreement, Krippendorff's Alpha, and Gwet's AC1. Most variable names
        follow the equations from from 'Gwet, Kilem L. “On Krippendorff’s Alpha Coefficient,” 2015.' with
        a few exceptions to distinguish variables per metric.
        Inputs are: (1) (N x K) agreement table, where N is number of unique examples and K is the number of categories
        and the value is the count of each of K categories per example
        and (2) (N x A) reliability table, where N is the number
        of unique examples, A is the number of unique annotators,
        and the value is the annotation given by annotator A to example N
        (or None if not annotated)
        """
        raters_per_example = ri = np.sum(agreement_table[:, :, 1], axis=1)
        categories = agreement_table[0][:, 0]
        n_annotators = len(reliability_table[0])
        n_categories = len(categories)
        # Krippendorff's Alpha percent expected (PE) + percent agreement (PA)
        # uses only rows with more than 1 rater
        # AC1 uses full agreement table for PE
        coincidence_ix = _find_indices(raters_per_example, lambda x: x != 1)
        if len(coincidence_ix) <= 1:
            raise NoCoincidentAnnotationsFound()
        coincident_agreement_table = agreement_table[coincidence_ix]
        coincident_raters_per_example = ri_c = raters_per_example[coincidence_ix]
        # These are named different from the paper because we want to distinguish them.
        n_c = len(coincidence_ix)
        n_a = len(raters_per_example)

        rbar = sum(coincident_raters_per_example) / n_c

        # Some summary statistics to display
        avg_raters_per_example = sum(raters_per_example) / n_a
        n_single_annotation = n_a - n_c

        kripp_pa, ac_pa = self._calculate_pa(
            categories, coincident_agreement_table, ri_c, rbar, n_c
        )
        kripp_pe, ac_pe = self._calculate_pe(
            categories,
            reliability_table,
            agreement_table,
            ri,
            coincidence_ix,
            rbar,
        )

        percent_agreement = ac_pa
        try:
            if kripp_pe > 0.9:
                if label == "_all":
                    msg.warn(
                        f"The agreement expected by chance for this dataset is very high ({round(kripp_pe,3)}). "
                        "This usually happens when the annotations fall into the same category most of the time. "
                        "This keeps Krippendorff's Alpha very low regardless of the actual agreement. "
                        "Consult percent agreement/ Gwet's A2 for a better estimate of iaa for this dataset. "
                        "See K. L. Gwet, “On Krippendorff’s Alpha Coefficient,” p. 16, 2015 for discussion."
                    )
                else:
                    msg.warn(
                        f"The agreement expected by chance for label '{label}' is very high ({round(kripp_pe,3)}). "
                        "This usually happens when the annotations fall into the same category most of the time. "
                        "This keeps Krippendorff's Alpha very low regardless of the actual agreement. "
                        "Consult percent agreement/ Gwet's A2 for a better estimate of iaa for this dataset. "
                        "See K. L. Gwet, “On Krippendorff’s Alpha Coefficient,” p. 16, 2015 for discussion."
                    )
            kripp_alpha = (kripp_pa - kripp_pe) / (1 - kripp_pe)
        except ZeroDivisionError:
            kripp_alpha = 0
        ac2 = (ac_pa - ac_pe) / (1 - ac_pe)
        iaa_doc_stats = IaaDocStats(
            n_examples=sum(raters_per_example),
            n_annotators=n_annotators,
            n_categories=len(self._labels) if self._annotation_type == "multilabel" else n_categories,  # type: ignore
            n_single_annotation=n_single_annotation,
            n_coincident_examples=n_c,
            avg_raters_per_example=avg_raters_per_example,
            percent_agreement=percent_agreement,
            kripp_alpha=kripp_alpha,
            gwet_ac2=ac2,
        )
        return iaa_doc_stats

    def _calculate_pa(
        self,
        categories: np.ndarray,
        coincident_agreement_table: np.ndarray,
        coincident_raters_per_example: np.ndarray,
        rbar: float,
        len_coincidence_ix: int,
    ) -> Tuple[float, float]:
        ri_c = coincident_raters_per_example
        n_c = len_coincidence_ix
        kripp_pa_sum = 0
        ac_pa_sum = 0
        for i, counts_arr in enumerate(coincident_agreement_table):
            counts = {row[0]: row[1] for row in counts_arr}
            kripp_pa_i = 0
            ac_pa_i = 0
            for k in categories:
                r_ik = counts[k]
                rbar_ik = self._calculate_rbar_ik(categories, k, r_ik)
                kripp_p_ai_k = (r_ik * (rbar_ik - 1)) / (rbar * (ri_c[i] - 1))
                kripp_pa_i += kripp_p_ai_k
                # p_ai_k is the different calculation between the two
                try:
                    ac_pa_ik = (r_ik * (rbar_ik - 1)) / (ri_c[i] * (ri_c[i] - 1))
                except ZeroDivisionError:
                    ac_pa_ik = 0
                ac_pa_i += ac_pa_ik
            kripp_pa_sum += kripp_pa_i
            ac_pa_sum += ac_pa_i

        kripp_pa_prime = kripp_pa_sum / n_c
        kripp_pa = ((1 - (1 / (rbar * n_c))) * kripp_pa_prime) + (1 / (rbar * n_c))

        # AC also differs in that it uses this "raw" pa and not pa_prime in a later equation
        ac_pa = ac_pa_sum / n_c
        return kripp_pa, ac_pa

    def _calculate_pe(
        self,
        categories: np.ndarray,
        reliability_table: np.ndarray,
        agreement_table: np.ndarray,
        raters_per_example: np.ndarray,
        coincidence_ix: np.ndarray,
        rbar: float,
    ) -> Tuple[float, float]:
        ri = raters_per_example
        n_a = len(raters_per_example)
        codes_per_category = _category_counter(categories)
        codes_per_category.update(
            chain.from_iterable(reliability_table[coincidence_ix])
        )
        codes_per_category = {
            k: v for k, v in codes_per_category.items() if k is not None
        }
        average_category_per_unit = {
            k: v / len(coincidence_ix) for k, v in codes_per_category.items()
        }
        kripp_pi_k = {k: v / rbar for k, v in average_category_per_unit.items()}

        kripp_pe = sum(
            self._weighting(k, l) * kripp_pi_k[k] * kripp_pi_k[k]
            for k, l in product(categories, categories)  # noqa: E741
        )

        ac_pi_k = {}
        for category in categories:
            cat_sums = 0
            for i, counts_arr in enumerate(agreement_table):
                counts = {row[0]: row[1] for row in counts_arr}
                if ri[i] == 0:
                    continue
                v = counts[category] / ri[i]
                cat_sums += v
            ac_pi_k[category] = cat_sums / n_a

        tw = sum(
            self._weighting(k, l)
            for k, l in product(categories, categories)  # noqa: E741
        )
        try:
            ac_pe = (tw / (len(categories) * (len(categories) - 1))) * (
                sum(ac_pi_k[k] * (1 - ac_pi_k[k]) for k in ac_pi_k)
            )
        except ZeroDivisionError:
            ac_pe = 0

        return kripp_pe, ac_pe

    def _calculate_rbar_ik(self, categories, k, r_ik):
        rbar_ik = 0
        for l in categories:  # noqa: E741
            v = self._weighting(k, l) * r_ik
            rbar_ik += v
        return rbar_ik


def _format_number(number: float, ndigits: int = 2) -> str:
    """Formats a number rounding to `ndigits`, without truncating trailing 0s,
    as happens with `round(number, ndigits)`"""
    return f"{number:.{ndigits}f}"


def _category_counter(keys):
    """Initializes the counter of predefined categories."""
    return Counter({k: 0 for k in keys})


def _find_indices(array: np.ndarray, condition: Callable) -> np.ndarray:
    """Finds the indices of the array that satisfy the condition."""
    return np.where(condition(array))[0]


@prodigy_metric("prodigy.metrics.IaaDoc.v1")
def make_iaa_doc_metric(
    annotation_type: Literal["binary", "multiclass", "multilabel"],
    labels: Optional[List[str]] = None,
    annotators: Optional[List[str]] = None,
) -> IaaDoc:
    """Initialize an IAA metric for document-level annotations.
    annotation_type (str): The type of annotation. Can be "binary", "multiclass", or "multilabel".
    labels (Optional[List[str]]): Optional list of labels. If not provided, it will be inferred from the dataset.
    annotators: (Optional[List[str]]) Optional list of annotators. If not provided, it will be inferred from the dataset.
    RETURNS (IaaDoc): An IaaDoc metric object.
    """
    return IaaDoc(annotation_type, labels, annotators)
