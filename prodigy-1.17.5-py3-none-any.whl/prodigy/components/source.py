# pyright: reportMissingImports=false

import abc
import csv
from contextlib import contextmanager
from io import DEFAULT_BUFFER_SIZE, TextIOWrapper
from pathlib import Path
from typing import (
    IO,
    ClassVar,
    Dict,
    Generic,
    Iterable,
    Iterator,
    List,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
    cast,
)
from typing_extensions import Literal, Self

import srsly

from ..errors import ProdigyError
from ..structured_types import Example
from ..types import Answer, TaskType
from ..util import bytes_to_b64, get_mimetype, msg, registry
from .db import Database

__all__ = [
    "Source",
    "DatasetSource",
    "FileSource",
    "TextFileSource",
    "ListSource",
    "GeneratorSource",
    "ParquetFileSource",
    "load_jsonl_file",
    "load_json_file",
    "load_text_file",
    "load_csv_file",
    "load_audio_files",
    "load_video_files",
    "load_noop",
]

_ItemT = TypeVar("_ItemT")
_ExampleT = TypeVar("_ExampleT", bound=Union[Example, TaskType])


IMAGE_FILE_EXT = (".jpg", ".jpeg", ".png", ".gif", ".svg")
AUDIO_FILE_EXT = (".mp3", ".m4a", ".wav")
VIDEO_FILE_EXT = (".mpeg", ".mpg", ".mp4")

# read 512 bytes at a time from files
_FILESOURCE_DEFAULT_BUFFER_SIZE = DEFAULT_BUFFER_SIZE // 16


class Source(Generic[_ItemT], abc.ABC):
    @abc.abstractproperty
    def countable(self) -> bool:
        ...

    @abc.abstractproperty
    def is_open(self) -> bool:
        ...

    @abc.abstractproperty
    def position(self) -> int:
        ...

    @abc.abstractproperty
    def size(self) -> Optional[int]:
        ...

    def __len__(self) -> int:
        if self.size is None:
            raise TypeError("Cannot get length of unknown size.")
        return self.size

    @abc.abstractmethod
    def read(self) -> Iterator[_ItemT]:
        # Not sure what to call this. I think 'read' gives
        # the sense that there's a marker inside that will
        # advance?
        ...

    @abc.abstractmethod
    def copy(self: Self) -> Self:
        ...

    @abc.abstractmethod
    @contextmanager
    def open(self) -> Iterator[None]:
        ...

    @abc.abstractmethod
    def close(self) -> None:
        ...

    def __iter__(self) -> Iterator[_ItemT]:
        # Not at all sure this is a good idea...
        if self.is_open:
            yield from self.read()
        else:
            with self.open():
                yield from self.read()


_IOT = TypeVar("_IOT", bound=Union[IO[bytes], IO[str]])


class _VariableChunkSizeTextIOWrapper(TextIOWrapper):
    def __init__(
        self,
        buffer: IO[bytes],
        encoding: Optional[str] = None,
        errors: Optional[str] = None,
        newline: Optional[str] = None,
        line_buffering: bool = False,
        write_through: bool = False,
        chunk_size: int = DEFAULT_BUFFER_SIZE,
    ) -> None:
        super().__init__(
            buffer, encoding, errors, newline, line_buffering, write_through
        )
        self._CHUNK_SIZE = chunk_size


class FileSource(Source[_IOT]):
    # Allow subclasses to specify whether it's a binary file.
    # This makes the typing cleaner (you can declare type as
    # TextFileSource, and it'll default the encoding correctly.)
    countable: ClassVar[bool] = False
    is_binary: ClassVar[bool] = False
    default_encoding: ClassVar[Optional[str]] = "utf-8"
    default_buffer_size: ClassVar[int] = _FILESOURCE_DEFAULT_BUFFER_SIZE
    encoding: Optional[str]
    # Map file paths to the index in the sizes and sizes cumsum
    # lists
    _paths: Dict[Path, int]
    # Size of each file
    _sizes: Tuple[int]
    # Cumulative sum after reading each file.
    # (i.e. sizes_cumsum[0] == _sizes[0]
    # and sizes_cumsum[-1] == sum(sizes)
    _sizes_cumsum: Tuple[int]
    # Current byte position.
    _current_file: Optional[IO[bytes]]
    _current_i: int
    _is_open: bool
    _open_files: List[IO[bytes]]
    _buffer_size: int

    @classmethod
    def from_path(
        cls: Type[Self], path: Path, *, extension: Optional[str] = None
    ) -> Self:
        path = Path(path)
        path_sizes = {p: p.stat().st_size for p in _iter_files(path, extension)}
        return cls(path_sizes)

    def __init__(
        self,
        path_sizes: Dict[Path, int],
        *,
        encoding: Optional[str] = None,
        buffer_size: Optional[int] = None,
    ):
        if not self.__class__.is_binary:
            self.encoding = encoding or self.__class__.default_encoding
        elif encoding is not None:
            raise ValueError(
                "Cannot set encoding on FileSource subclass specified as binary"
            )
        else:
            self.encoding = None
        sizes_cumsum: List[int] = []
        total_size = 0
        for size in path_sizes.values():
            total_size += size
            sizes_cumsum.append(total_size)
        self._sizes_cumsum = tuple(sizes_cumsum)
        self._sizes = tuple(path_sizes.values())
        self._paths = {p: i for i, p in enumerate(path_sizes)}
        self._current_file = None
        self._current_i = 0
        self._open_files = []
        self._is_open = False
        self._buffer_size = (
            buffer_size
            if buffer_size is not None
            else self.__class__.default_buffer_size
        )

    @property
    def is_open(self) -> bool:
        return self._is_open

    @property
    def position(self) -> int:
        if self._current_file is None and self._current_i == 0:
            return 0
        elif self._current_file is None:
            # Before current file
            return self._sizes_cumsum[self._current_i - 1]
        elif self._current_file.closed:
            # At end of current file
            return self._sizes_cumsum[self._current_i]
        else:
            # Inside current file
            _position = max(0, self._current_file.tell() - self._buffer_size)
            if self._current_i > 0:
                _position += self._sizes_cumsum[self._current_i - 1]
            return _position

    def read(self) -> Iterator[IO]:
        for path, i in self._paths.items():
            if i < self._current_i:
                # I guess this could suck a bit if the file
                # list is enormous and you're stopping and
                # starting reads a lot. We should probably
                # reorganize the data structure for the paths.
                continue
            raw_file, wrapped = self._open_file(path)
            self._current_file = raw_file
            self._current_i = i
            if i > 0:
                prev_file = self._open_files[i - 1]
                if not prev_file.closed:
                    prev_file.close()
            self._open_files.append(self._current_file)
            yield wrapped

    @property
    def size(self) -> int:
        return self._sizes_cumsum[-1]

    def copy(self: Self) -> Self:
        return self.__class__({p: size for p, size in zip(self._paths, self._sizes)})

    @contextmanager
    def open(self) -> Iterator[None]:
        if self._open_files:
            # TODO: Should this be an error?
            raise IOError("Source has open files before open")
        if self.is_open:
            # TODO: Should this be an error?
            raise IOError("Source is marked as open")
        self._is_open = True
        yield
        self.close()

    def close(self) -> None:
        for file_ in self._open_files:
            if not file_.closed:
                file_.close()
        self._is_open = False
        self._open_files = []

    def _open_file(self, path: Path) -> Tuple[IO[bytes], _IOT]:
        # We need to keep the raw file around, for "current_file".
        # tell() doesn't work on the decoded file.
        raw_file = path.open("rb")
        if self.encoding is None:
            return raw_file, cast(_IOT, raw_file)
        else:
            wrapped = _VariableChunkSizeTextIOWrapper(
                raw_file, encoding=self.encoding, chunk_size=self._buffer_size
            )
            return raw_file, cast(_IOT, wrapped)


class TextFileSource(FileSource[IO[str]]):
    is_binary = False
    default_encoding = "utf8"


class BinaryFileSource(FileSource[IO[bytes]]):
    is_binary = True
    default_encoding = None


class ListSource(Source[_ItemT]):
    countable: ClassVar[bool] = True
    _items: List[_ItemT]
    _position: int
    _is_open: bool

    def __init__(self, items: List[_ItemT]):
        self._items = items
        self._position = 0
        self._is_open = False

    @property
    def is_open(self) -> bool:
        return self._is_open

    @property
    def position(self) -> int:
        return self._position

    @property
    def size(self) -> int:
        return len(self._items)

    def read(self) -> Iterator[_ItemT]:
        if not self.is_open:
            # TODO: Raise own error class
            raise IOError("Source was not open")
        for item in self._items[self._position :]:
            self._position += 1
            yield item

    def copy(self: Self) -> Self:
        return self.__class__(list(self._items))

    @contextmanager
    def open(self, i: int = 0) -> Iterator[None]:
        self._is_open = True
        self._position = i
        yield
        self.close()

    def close(self) -> None:
        self._is_open = False


class GeneratorSource(Source[_ItemT]):
    countable: ClassVar[bool] = False
    _items: Iterator[_ItemT]
    _position: int
    _is_open: bool
    _length: Optional[int]

    def __init__(self, items: Iterator[_ItemT], length: Optional[int] = None):
        self._items = items
        self._length = length
        self._position = 0
        self._is_open = False

    @property
    def is_open(self) -> bool:
        return self._is_open

    @property
    def position(self) -> int:
        return self._position

    @property
    def size(self) -> Optional[int]:
        return self._length

    def __len__(self) -> int:
        if self._length is None:
            raise TypeError(
                "Cannot get length of generator source and no length was provided."
            )
        return self._length

    def read(self) -> Iterator[_ItemT]:
        for item in self._items:
            self._position += 1
            yield item

    def copy(self: Self) -> Self:
        # TODO: Raise not supported error
        raise TypeError()

    @contextmanager
    def open(self, i: int = 0) -> Iterator[None]:
        if i < self._position:
            raise ValueError(
                f"Calling .open() with i={i} while position is {self._position}"
            )
        for _ in range(i):
            next(self._items)
        yield

    def close(self) -> None:
        pass


class DatasetSource(Source[_ExampleT]):
    countable: ClassVar[bool] = True
    _db: Database
    _name: str
    _answer: Literal["all", "accept", "reject", "ignore"]
    _items: List[_ExampleT]
    _position: int
    _is_open: bool

    def __init__(
        self,
        db: Database,
        name: str,
        *,
        answer: Literal["all", "accept", "reject", "ignore"],
        structured: bool = False,
    ):
        self._db = db
        self._name = name
        self._answer = answer
        self._structured = structured
        self._position = 0
        self._is_open = False
        self._items = DatasetSource._get_dataset_items(
            db, name, structured=structured, answer=answer
        )

    @property
    def is_open(self) -> bool:
        return self._is_open

    @property
    def position(self) -> int:
        return self._position

    @staticmethod
    def _get_dataset_items(
        db: Database,
        name: str,
        structured: bool = False,
        answer: Literal["all", "accept", "reject", "ignore"] = "all",
    ) -> List[_ExampleT]:
        include_answers: List[Answer] = ["accept", "reject", "ignore"]
        if answer != "all":
            include_answers = [answer]
        if structured:
            data = db.get_st_dataset_examples(name, answers=include_answers)
        else:
            dataset = db.get_dataset_by_name(name)
            if dataset.structured:
                st_data = db.get_st_dataset_examples(name)
                data = [eg.to_unst() for eg in st_data]
            else:
                data = cast(List[TaskType], db.get_dataset_examples(name))
            data = [eg for eg in data if eg["answer"] in include_answers]
        return cast(List[_ExampleT], data)

    @property
    def size(self) -> int:
        return len(self._items)

    def read(self) -> Iterator[_ExampleT]:
        if not self.is_open:
            # TODO: Raise our own error class.
            raise IOError("Source was not open")
        position = self._position
        for eg in self._items[position:]:
            self._position += 1
            answer = _get_answer(eg)
            if self._answer == "all" or answer == self._answer:
                yield eg

    @contextmanager
    def open(self) -> Iterator[None]:
        if self.is_open:
            # TODO: Raise own error
            raise IOError("Source was open")
        self._items = DatasetSource._get_dataset_items(
            self._db, self._name, structured=self._structured
        )
        self._position = 0
        self._is_open = True
        yield
        self.close()

    def close(self) -> None:
        self._is_open = False

    def copy(self: Self) -> Self:
        return self.__class__(self._db, self._name, answer=self._answer)


def _import_optional_pyarrow():
    try:
        import pyarrow.parquet as pq
    except ImportError:
        raise ImportError(
            "The ParquetFileSource requires the pyarrow library. "
            "You can install it with pip: `pip install pyarrow==11.0.0"
        )
    else:
        return pq


class ParquetFileSource(FileSource):
    countable: ClassVar[bool] = True
    is_binary = True

    @classmethod
    def from_path(
        cls: Type[Self], path: Path, *, extension: Optional[str] = "parquet"
    ) -> Self:
        pq = _import_optional_pyarrow()
        return cls(
            {p: pq.read_metadata(p).num_rows for p in _iter_files(path, extension)}
        )

    def __init__(
        self,
        path_sizes: Dict[Path, int],
        *,
        encoding: Optional[str] = None,
        batch_size: int = 10,
    ):
        super().__init__(path_sizes, encoding=encoding)
        self._pq = _import_optional_pyarrow()
        self._position = 0
        self._batch_size = batch_size

    @property
    def position(self) -> int:
        return self._position

    def read(self) -> Iterator[Dict]:
        for path, _ in self._paths.items():
            table = self._pq.read_table(path)
            for batch in table.to_batches(self._batch_size):
                for row in batch.to_pylist():
                    self._position += 1
                    yield row


def _maybe_count_lines(path: Path, max_lines: int = 100_000) -> Optional[int]:
    count = 0
    for _ in path.open():
        count += 1
        if count >= max_lines:
            return None
    return count


class JSONLFileCountError(ProdigyError):
    def __init__(self, path: Path, max_lines: int):
        self.path = path
        self.max_lines = max_lines

    def msg(self) -> str:
        return f"JSONL file {self.path} exceeded the maximum lines {self.max_lines}."


class JSONLFileSource(FileSource):
    countable: ClassVar[bool] = True

    @classmethod
    def from_path(
        cls: Type[Self],
        path: Path,
        *,
        extension: Optional[str] = "jsonl",
        max_lines: int = 100_000,
    ) -> Self:
        path_sizes = {}
        for p in _iter_files(path, extension):
            count = _maybe_count_lines(p, max_lines)
            if count is None:
                raise JSONLFileCountError(p, max_lines)
            path_sizes[p] = count
        return cls(path_sizes)

    def __init__(
        self,
        path_sizes: Dict[Path, int],
        *,
        encoding: Optional[str] = None,
        batch_size: int = 10,
    ):
        super().__init__(path_sizes, encoding=encoding)
        self._position = 0
        self._batch_size = batch_size

    @property
    def position(self) -> int:
        return self._position

    def read(self) -> Iterator[Dict]:
        for path, i in self._paths.items():
            if i < self._current_i:
                continue
            raw_file, wrapped = self._open_file(path)
            self._current_file = raw_file
            self._current_i = i
            if i > 0:
                prev_file = self._open_files[i - 1]
                if not prev_file.closed:
                    prev_file.close()
            self._open_files.append(self._current_file)
            for line in wrapped:
                self._position += 1
                item = srsly.json_loads(line)
                if not isinstance(item, dict):
                    raise TypeError(
                        f"Expected JSON line to be loaded as a dict but got {type(item)}"
                    )
                yield item


def _get_answer(eg: Union[Example, TaskType]) -> Optional[str]:
    return eg.answer if isinstance(eg, Example) else eg.get("answer")


# Sample loader functions. Need to work out how to manage this
# for v1.12.


@registry.source_loaders.register("jsonl")
def load_jsonl_file(
    source: Union[Source[IO[str]], TextIOWrapper], stdin: bool = False
) -> Iterator[Dict]:
    if stdin:
        assert isinstance(source, TextIOWrapper)
        yield from load_jsonl_source(source)
    else:
        for file_ in source:
            yield from load_jsonl_source(file_)


def load_jsonl_source(source: Union[IO[str], str, TextIOWrapper]) -> Iterator[Dict]:
    for line in source:
        item = srsly.json_loads(str(line))
        if not isinstance(item, dict):
            # TODO: Better error
            raise TypeError("Unexpected type loaded from source")
        yield item


@registry.source_loaders.register("json")
def load_json_file(
    source: Union[Source[IO[str]], TextIOWrapper], stdin: bool = False
) -> Iterator[Dict]:
    if stdin:
        assert isinstance(source, TextIOWrapper)
        yield from load_json_source(source.read())
    else:
        for file_ in source:
            assert not isinstance(file_, str)
            yield from load_json_source(file_.read())


def load_json_source(source: str) -> Iterator[Dict]:
    data = srsly.json_loads(source)
    if isinstance(data, dict):
        data = [data]
    elif isinstance(data, (type(None), int, float, str, bool)):
        # TODO: Better error
        raise TypeError("Unexpected type loaded from source")
    for item in data:
        if not isinstance(item, dict):
            # TODO: Better error
            raise TypeError("Unexpected type loaded from source")
        yield item


@registry.source_loaders.register("text")
def load_text_file(
    source: Union[Source[IO[str]], TextIOWrapper], stdin: bool = False
) -> Iterator[Dict]:
    if stdin:
        yield from load_text_source(source)
    else:
        for f in source:
            if isinstance(f, str) or isinstance(f, Path):
                file_path = Path(f)
                if not file_path.exists():
                    msg.fail(f"Can't find file {f}", file_path.resolve(), exits=1)
                f = file_path.open("r", encoding="utf8")
            yield from load_text_source(f)


def load_text_source(source: Union[Source[IO[str]], TextIOWrapper]) -> Iterator[Dict]:
    for line in source:
        if line != "":
            yield {"text": str(line).strip()}


@registry.source_loaders.register("csv")
def load_csv_file(
    source: Union[Source[IO[str]], TextIOWrapper], stdin: bool = False
) -> Iterator[Dict]:
    if stdin:
        assert isinstance(source, TextIOWrapper)
        yield from load_csv_source(source)
    else:
        for f in source:
            if isinstance(f, str) or isinstance(f, Path):
                file_path = Path(f)
                if not file_path.exists():
                    msg.fail(f"Can't find file {f}", file_path.resolve(), exits=1)
                f = file_path.open("r", encoding="utf8")
            yield from load_csv_source(f)


def load_csv_source(source: IO[str]) -> Iterator[Dict]:
    reader = csv.DictReader(source)
    for row in reader:
        row = {key.lower(): value for key, value in row.items() if isinstance(key, str)}
        text = row.get("text", "")
        if text == "":
            continue
        task = {"text": text}
        if "label" in row:
            task["label"] = row["label"]
        if "meta" in row:
            task["meta"] = {"meta": row["meta"]}
        yield task


@registry.source_loaders.register("image")
def load_image_files(source: Source[IO[bytes]]) -> Iterator[Dict]:
    yield from _load_binary_file_base64(source, "image", IMAGE_FILE_EXT)


@registry.source_loaders.register("audio")
def load_audio_files(source: Source[IO[bytes]]) -> Iterator[Dict]:
    yield from _load_binary_file_base64(source, "audio", AUDIO_FILE_EXT)


@registry.source_loaders.register("video")
def load_video_files(source: Source[IO[bytes]]) -> Iterator[Dict]:
    yield from _load_binary_file_base64(source, "video", VIDEO_FILE_EXT)


def _load_binary_file_base64(
    source: Source[IO[bytes]], input_key: str, file_ext: Optional[Iterable[str]] = None
) -> Iterator[Dict]:
    for f in source:
        if isinstance(f, str) or isinstance(f, Path):
            file_path = Path(f)
            if not file_path.exists():
                msg.fail(f"Can't find file {f}", str(file_path.resolve()), exits=1)
            f = file_path.open("rb")

        file_path = Path(f.name)
        if file_ext is not None and file_path.suffix not in file_ext:
            continue
        mimetype = get_mimetype(file_path)
        data = bytes_to_b64(f.read(), mimetype)
        yield cast(
            TaskType,
            {
                input_key: data,
                "text": file_path.stem,
                "meta": {"file": file_path.parts[-1], "path": str(file_path)},
                "path": str(file_path),
            },
        )


def load_noop(source: Source[_ExampleT]) -> Iterator[_ExampleT]:
    yield from source


def _iter_files(parent: Path, extension: Optional[str]) -> Iterator[Path]:
    queue = [parent]
    for path in queue:
        if path.is_dir():
            queue.extend(path.iterdir())
        elif extension is None or path.suffix == f".{extension}":
            yield path
