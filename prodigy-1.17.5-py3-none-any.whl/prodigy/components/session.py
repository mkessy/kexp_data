import itertools as it
from queue import Queue
from timeit import default_timer as timer
from typing import Callable, Dict, Iterable, List, Optional, Set, Tuple

from ..structured_types import get_input_hash
from ..util import log
from .stream import QueueItem, Stream


class Session:
    """Representation of a Prodigy Annotator Session with a queue of tasks to pull from
    as well as temporary storage opened, but unanswered tasks.

    Components
    Tasks Queue: Annotation Tasks represented as a queue to present to the Annotator
    Open Tasks: As a task is pulled off the Tasks queue,
        we add it to the Session History. The History is basically a buffer that waits until
        answers are actually received from the annotator. If no answers (or only a partial batch
        of answers) are received before the annotator asks for more examples
        (e.g. they refresh their browser) the Feed will return tasks from the Session History
        In practice, Session History will be very small per session (max about Feed batch_size * 2)
    """

    id: str
    _progress: Optional[float]
    _stream: Stream
    _batch_size: int
    _total_annotated: int
    _target_annotated: int
    _timestamp: float
    _tasks: Queue
    # Keys of answers we've received
    _answered_input_hashes: Set[int]
    _answered_task_hashes: Set[int]
    # Mapping of open tasks (keyed by key)
    _open_tasks: Dict[int, Tuple[float, QueueItem]]

    def __init__(
        self,
        session_id: str,
        stream: Stream,
        batch_size: int,
        *,
        answered_input_hashes: Optional[Set[int]] = None,
        answered_task_hashes: Optional[Set[int]] = None,
        total_annotated: int = 0,
        target_annotated: int = 0,
    ):
        self.id = session_id
        self._stream = stream
        self._batch_size = batch_size
        self._timestamp = timer()
        self._open_tasks = {}
        self._sent_ids = set()
        self._answered_input_hashes = answered_input_hashes or set()
        self._answered_task_hashes = answered_task_hashes or set()
        self.last_update_value = None
        self._total_annotated = total_annotated
        self._session_annotated = 0
        self._target_annotated = target_annotated
        self._progress = 0.0
        self._stolen_keys = set()

    @property
    def total_annotated(self):
        return self._total_annotated

    @property
    def session_annotated(self):
        return self._session_annotated

    @property
    def target_annotated(self):
        return self._target_annotated

    @property
    def progress(self) -> float:
        # Assert for type check. We want to use assert to narrow types
        # rather than cast, because if we're wrong we want to know about it.
        assert self._progress is not None
        return self._progress

    @property
    def stream(self) -> Stream:
        return self._stream

    @property
    def timestamp(self) -> float:
        """Timestamp for when this session was last accessed.
        Used to re-queue any tasks that have been open past the
        Feed timeout setting
        RETURNS (float): Time in seconds returned by timeit.default_timer
        """
        return self._timestamp

    @property
    def stolen_keys(self) -> Set[int]:
        return self._stolen_keys

    def reset_stream(self, stream: Stream) -> None:
        self._stream = stream
        self._open_tasks = {}

    def increment_annotations(self, i: int) -> None:
        self._total_annotated += i
        self._session_annotated += i

    def get_questions(
        self,
        n: int,
        *,
        exclude_input_hashes: Set[int],
        exclude_task_hashes: Set[int],
        task_router: Callable[[Dict], List[str]],
        other_sessions: Optional[List["Session"]] = None,
        steal_work: bool = True,
    ) -> List[QueueItem]:
        """Get a batch of up to `n` samples for a given queue_id.

        A short batch is returned if the stream is exhausted.
        """
        if n < 1:
            raise ValueError(
                f"Session.get_questions(n={n}), n must be strictly positive"
            )
        results = []
        seen_input_hashes = self._answered_input_hashes.union(exclude_input_hashes)
        seen_task_hashes = self._answered_task_hashes.union(exclude_task_hashes)
        timestamp = timer()
        open_items = [item for key, (ts, item) in self._open_tasks.items()]
        queue_items = self.stream.iter_queue(task_router, self.id)
        for item in it.chain(open_items, queue_items):
            if (
                item.key not in seen_task_hashes
                and get_input_hash(item.data) not in seen_input_hashes
            ):
                results.append(item)
                seen_task_hashes.add(item.key)
                if len(results) == n:
                    break

        if steal_work and len(results) == 0 and other_sessions is not None:
            results.extend(
                self.steal_work(results, n, other_sessions, exclude=seen_task_hashes)
            )
        for item in results:
            self._open_tasks[item.key] = (timestamp, item)
        return results

    def receive_answers(
        self,
        answers: List[Dict],
        keys: List[int],
        progress: Optional[float],
    ) -> None:
        for key in keys:
            if key in self._open_tasks:
                self._open_tasks.pop(key)
        self._progress = progress
        self._answered_task_hashes.update(keys)

    def close_task(self, key: int) -> None:
        if key in self._open_tasks:
            self._open_tasks.pop(key)

    def steal_work(
        self,
        batch: List[QueueItem],
        n: int,
        sessions: List["Session"],
        *,
        exclude: Set[int] = set(),
    ) -> List[QueueItem]:
        """Used for work stealing from other sessions. This can happen in a
        multi-annotator, non-overlapping feed when.
        1. Session "a" opens a batch but doesn't complete annotations
        2. Session "b" answers all questions left in the stream until it's empty.
        Each task in the feed needs to annotated at least once so we allow
        Session "b" to "steal" work from Session "a". Tasks are queued 1 at a time.
        session (Session): Current session
        """
        stealable = []
        # If we've got an answer to that task, don't steal it.
        unstealable = set(self._answered_task_hashes).union(exclude)
        # If we have that task open, don't steal it.
        unstealable.update(self._open_tasks.keys())
        # If the task is in our batch, don't steal it.
        unstealable.update({item.key for item in batch})
        for session in sorted(sessions, key=lambda s: s.timestamp):
            unstealable.update(session.stolen_keys)
            for timestamp, item in session.iter_open():
                if item.key not in unstealable:
                    stealable.append((timestamp, session, item))
                    unstealable.add(item.key)
        stolen: List[QueueItem] = []
        for timestamp, session, item in stealable:
            session.close_task(item.key)
            self._stolen_keys.add(item.key)
            stolen.append(item)
            log(
                f"SESSION: {self.id} has stolen item with hash {item.key} from {session.id}"
            )
            break

        return stolen

    def iter_open(self) -> Iterable[Tuple[float, QueueItem]]:
        for timestamp, item in self._open_tasks.values():
            yield timestamp, item
