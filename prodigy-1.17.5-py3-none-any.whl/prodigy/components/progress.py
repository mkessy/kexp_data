import math
import random
from typing import TYPE_CHECKING, List, Optional, Union

from ..types import TaskType
from ..util import log

if TYPE_CHECKING:
    from ..core import Controller
    from .session import Session


class ProgressEstimator:
    """Do gradient descent to predict the i where loss is 0.01, given
    samples of the loss (and the known timestep, i). Loss is transformed
    to logspace, so we can use a linear model."""

    def __init__(self) -> None:
        self.i = 0
        self.data = []

    def __call__(
        self, ctrl, update_return_value: Optional[Union[int, float]] = None
    ) -> Union[None, bool, float]:
        loss = update_return_value
        if loss is None:
            return False
        self.i += 1
        logloss = math.log(loss + 1e-8)
        self.data.append((logloss, self.i))
        w = 0.0
        b = 0.0
        for _ in range(100):
            random.shuffle(self.data)
            for logloss, i in self.data:
                predict_i = w * logloss + b
                gradient = predict_i - i
                w -= 0.001 * gradient * logloss
                b -= 0.001 * gradient
        predicted_finish = w * math.log(max(loss, 0.01)) + b
        progress = self.i / max(self.i + 10, predicted_finish)
        log("PROGRESS: Estimating progress of %.4f" % progress)
        return progress


class TargetTotalProgressEstimator:
    """Calculate Progress based on the `total_examples_target` setting.
    Progress is quotient of number of examples annotated and the configured target.
    """

    def __call__(
        self,
        ctrl: "Controller",
        session: "Session",
        answers: List[TaskType],
        update_return_value: Optional[Union[int, float]],
    ) -> Optional[float]:
        progress = None
        target_total = ctrl.target_annotated

        if target_total is None or target_total <= 0:
            return progress
        # If we have a target total configured, use it
        # and check how many examples have already been annotated
        # in the database.
        if ctrl.overlap is True or ctrl.annotations_per_task is not None:
            sess_total = ctrl.get_total_by_session(session.id)
            progress = sess_total / target_total
        else:
            progress = ctrl.total_annotated / target_total
        return progress


class SourceProgressEstimator:
    """Progress calculated based on the relative source position and size."""

    def __call__(
        self,
        ctrl: "Controller",
        session: "Session",
        answers: List[TaskType],
        update_return_value: Optional[Union[int, float]],
    ) -> Optional[float]:
        stream = session.stream
        if not stream.source_size:
            return None

        progress = stream.source_position / stream.source_size
        return progress
