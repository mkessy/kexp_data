from contextlib import contextmanager
from types import ModuleType
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Tuple

from wasabi.util import NO_UTF8

from .._util import color
from ..errors import RecipeError
from ..types import StreamType, TaskType
from ..util import msg


def get_diff(score: float, prev_score: Optional[float]) -> Tuple[Optional[float], str]:
    if prev_score is None:
        return None, " "
    diff = round(score - prev_score, 2)
    icons = {"up": "+" if NO_UTF8 else "▲", "down": "-" if NO_UTF8 else "▼"}
    icon = " " if diff == 0 else icons["up"] if diff > 0 else icons["down"]
    return diff, icon


def get_plotext(show_plot: bool) -> Optional[ModuleType]:
    if show_plot is True:
        try:
            import plotext  # pyright: ignore
        except ImportError:
            cmd = "pip install plotext==4.2.0"
            raise RecipeError("Train curve plots require the plotext library", cmd)
        else:
            return plotext


@contextmanager
def train_curve_printer(
    pipes: List[str], default_scores: Dict[str, str], show_plot: bool = False
) -> Iterator[Callable[[float, Dict[str, Any], Dict[str, Any]], None]]:
    plt = get_plotext(show_plot)
    row_widths = [4] + [6] * (len(pipes) + 1)
    row_aligns = ["r"] + ["r"] * (len(pipes) + 2)
    diffs = []
    scores = {}

    def result(factor: float, sc: Dict[str, Any], prev_sc: Dict[str, Any]) -> None:
        if not sc:
            return
        w_score = sc["score"]
        prev_w_score = prev_sc["score"] if prev_sc else None
        w_diff, w_icon = get_diff(w_score, prev_w_score)
        if w_diff is not None:
            diffs.append(w_diff)
        scores[factor] = w_score
        results = [f"{factor:.0%}", f"{w_score:.2f} {w_icon}"]
        for pipe in pipes:
            key = default_scores[pipe]
            score = sc["other_scores"][key]
            prev_score = prev_sc["other_scores"][key] if prev_sc else None
            _, icon = get_diff(score, prev_score)
            results.append(f"{score:.2f} {icon}")
        msg.row(results, widths=row_widths, aligns=row_aligns)

    print("")  # noqa: T201
    header = ["%", "Score"] + pipes
    msg.row(header, widths=row_widths)
    msg.row([width * "-" for width in row_widths], widths=row_widths)
    yield result

    if show_plot and plt is not None:
        print("")  # noqa: T201
        x = [factor for factor in scores]
        y = [score for score in scores.values()]
        plt.plot(x, y)
        # Workaround for plotext v2 and v3
        if hasattr(plt, "figsize"):
            plt.figsize(40, 12)
            plt.nocolor()
        else:
            plt.plotsize(40, 12)
            plt.colorless()
        plt.yticks(y, [f"{acc:.2f}" for acc in y])
        plt.xticks(x, [f"{factor:.0%}" for factor in x])
        plt.show()

    if len(diffs):
        print("")  # noqa: T201
        last_diff = diffs[-1]
        if last_diff == 0:
            msg.warn("Accuracy stayed the same in the last sample")
        elif last_diff > 0:
            msg.good("Accuracy improved in the last sample")
        else:
            msg.fail("Accuracy decreased in the last sample")
        msg.text(
            "As a rule of thumb, if accuracy increases in the last segment, "
            "this could indicate that collecting more annotations of the same "
            "type will improve the model further."
        )


def format_label(task: TaskType, default_label: str = "n/a") -> str:
    label = default_label
    label_bg = task.get("answer", "theme")
    if "options" in task:
        selected = task.get("accept", [])
        label = ",".join([str(opt) for opt in selected]) if selected else default_label
    else:
        label = task.get("label", default_label)
    return color(f" {label.upper()} ", "black", label_bg)


def format_spans(task: TaskType) -> str:
    text = task.get("text", "")
    spans = task.get("spans", [])
    result = ""
    offset = 0
    if not spans:
        return text
    for span in spans:
        label = span.get("label")
        label_bg = span.get("answer", task.get("answer", "theme"))
        start = span.get("start", 0)
        end = span.get("end", 0)
        result += text[offset:start]
        result += color(f" {text[start:end]} ", "black", "highlight")
        if label:
            result += color(f" {label} ", "black", label_bg)
        offset = end
    result += text[offset:]
    return result


def pretty_print(
    stream: StreamType, views: Iterable[str] = ["spans", "textcat"]
) -> None:
    for task in stream:
        result = []
        if "textcat" in views:
            result.append(format_label(task))
        if "spans" in views:
            result.append(format_spans(task))
        else:
            result.append(task.get("text", ""))
        print(f"{' '.join(result)}\n")  # noqa: T201
