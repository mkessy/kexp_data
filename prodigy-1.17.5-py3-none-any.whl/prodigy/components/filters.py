from typing import Callable, Iterable, Iterator, Optional, Set, Union
from typing_extensions import TypeVar

from ..structured_types import Example
from ..types import StreamType
from ..util import INPUT_HASH_ATTR, TASK_HASH_ATTR, log, msg
from .db import Database
from .decorators import support_both_streams

_StructExampleT = TypeVar("_StructExampleT", bound=Example, default=Example)


@support_both_streams(stream_arg="stream")
def filter_empty(
    stream: StreamType, key: Union[str, object], skip: bool = True
) -> StreamType:
    """Filter out empty examples from stream.

    stream (iterable): The stream to filter.
    key (str): The task key to check.
    skip (bool): Skip empty examples instead of raising a ValueError.
    YIELDS (dict): The filtered annotation examples.
    """
    log(f"FILTER: Filtering out empty examples for key '{key}'")
    for eg in stream:
        if key not in eg or not eg[key]:
            if skip:
                log(f"FILTER: Skipping invalid '{key}' task", eg)
                continue
            raise ValueError(f"Invalid '{key}' task: {eg}")
        yield eg


@support_both_streams(stream_arg="stream")
def filter_duplicates(
    stream: StreamType,
    by_input: bool = False,
    by_task: bool = True,
    warn_threshold: float = 0.4,
    warn_fn: Callable = msg.warn,
) -> StreamType:
    """Filter duplicates from an incoming stream.

    stream (iterable): The stream of examples.
    by_input (bool): Filter examples based on the input hash.
    by_task (bool): Filter examples based on the task hash.
    YIELDS (dict): The filtered annotation examples.
    """
    log("FILTER: Filtering duplicates from stream", locals())
    seen = set()
    total = 0
    skipped = 0
    yielded = 0
    for eg in stream:
        total += 1
        if by_input and eg[INPUT_HASH_ATTR] in seen:
            skipped += 1
            continue
        if by_task and eg[TASK_HASH_ATTR] in seen:
            skipped += 1
            continue
        yield eg
        yielded += 1
        if by_input:
            seen.add(eg[INPUT_HASH_ATTR])
        if by_task:
            seen.add(eg[TASK_HASH_ATTR])
    _warn_too_many_exclusions(total, skipped, yielded, warn_threshold, warn_fn)


def filter_duplicates_st(
    stream: Iterator[_StructExampleT],
    by_input: bool = False,
    by_task: bool = True,
    warn_threshold: float = 0.4,
    warn_fn: Callable = msg.warn,
) -> Iterator[_StructExampleT]:
    """Filter duplicates from an incoming stream.

    stream (Iterator[_StructExampleT]): The stream of examples.
    by_input (bool): Filter examples based on the input hash.
    by_task (bool): Filter examples based on the task hash.
    YIELDS (dict): The filtered annotation examples.
    """
    log("FILTER: Filtering duplicates from stream", locals())
    seen = set()
    total = 0
    skipped = 0
    yielded = 0
    for eg in stream:
        total += 1
        if by_input and eg.input_hash in seen:
            skipped += 1
            continue
        if by_task and eg.task_hash in seen:
            skipped += 1
            continue
        yield eg
        yielded += 1
        if by_input:
            seen.add(eg.input_hash)
        if by_task:
            seen.add(eg.task_hash)
    _warn_too_many_exclusions(total, skipped, yielded, warn_threshold, warn_fn)


def _warn_too_many_exclusions(
    total: int, skipped: int, yielded: int, warn_threshold: float, warn_fn: Callable
) -> None:
    # This warning covers a case where a user has a dataset that contains lots of
    # duplicates and so the stream becomes exhausted quickly despite the user
    # thinking it's a large dataset.
    ratio = skipped / total if total != 0 else 0
    if ratio > warn_threshold:
        warn_fn(
            f"Warning: filtered {ratio:.0%} of entries because they were duplicates. "
            f"Only {yielded} items were shown out of {total}. You may want to "
            f"deduplicate your dataset ahead of time to get a better understanding "
            f"of your dataset size."
        )


@support_both_streams(stream_arg="stream")
def filter_inputs(stream: StreamType, input_ids: Set[int]) -> StreamType:
    """Filter out specific input hashes from a stream.

    stream (iterable): The stream of examples.
    input_ids (set): The input hashes to filter.
    YIELDS (dict): The filtered annotation examples.
    """
    for eg in stream:
        if eg.get(INPUT_HASH_ATTR) not in input_ids:
            yield eg


@support_both_streams(stream_arg="stream")
def filter_tasks(stream: StreamType, task_ids: Set[int]) -> StreamType:
    """Filter out specific task hashes from a stream.

    stream (iterable): The stream of examples.
    task_ids (set): The task hashes to filter.
    YIELDS (dict): The filtered annotation examples.
    """
    for eg in stream:
        if eg.get(TASK_HASH_ATTR) not in task_ids:
            yield eg


@support_both_streams(stream_arg="stream")
def filter_datasets(
    stream: StreamType,
    db: Database,
    dataset_names: Iterable[str],
    exclude_by: str = "task",
) -> StreamType:
    """Filter out tasks based on a the hashes from a list of dataset_names

    stream (Iterable[dict]): The stream of examples
    db (Database): The prodigy database
    dataset_names (Iterable[str]): Datasets to get examples to exclude
    exclude_by (str, optional): Exclude by the task or input hash. One of 'task' or 'input'
    YIELDS (dict): The filtered annotation examples.
    """
    if hasattr(db, "reconnect"):
        db.reconnect()
    if dataset_names and db:
        if exclude_by == "task":
            exclude_hashes = db.get_task_hashes(*dataset_names)
            stream = filter_tasks(stream, exclude_hashes)
        elif exclude_by == "input":
            exclude_hashes = db.get_input_hashes(*dataset_names)
            stream = filter_inputs(stream, exclude_hashes)
    return stream


def fetch_exclude_hashes(
    db: Database, dataset_names: Iterable[str], exclude_by: Optional[str] = "task"
) -> Set[int]:
    """Fetch hashes for examples in multiple datasets
    db (Database): Database object
    dataset_names (Iterable[str]): Dataset names to fetch examples from
    exclude_by (Optional[str]): One of 'task' for 'input'.
    RETURNS (Set[int]): Set of either task or input hashes used for filtering
    """
    if exclude_by not in ("task", "input"):
        raise ValueError("Argument `exclude_by` must be one of 'task' or 'input'")
    result = set()
    if dataset_names and db:
        if exclude_by == "task":
            result = db.get_task_hashes(*dataset_names)
        else:
            result = db.get_input_hashes(*dataset_names)
    return result


@support_both_streams(stream_arg="stream")
def filter_seen_before(
    stream: StreamType, cache_stream: StreamType, exclude_by: str = "input"
) -> StreamType:
    """Adapts the stream to no longer pass examples if it appears in another stream"""
    # Get all hashes in the cache
    exclude_attr = INPUT_HASH_ATTR if exclude_by == "input" else TASK_HASH_ATTR
    cache_ids = {eg.get(exclude_attr) for eg in cache_stream}
    log(f"FILTER: Found {len(cache_ids)} hashes in cache stream.")
    total = 0
    # Return examples not in cache
    for eg in stream:
        if eg.get(exclude_attr) not in cache_ids:
            total += 1
            yield eg
    log(f"FILTER: Filtered {total} examples from stream.")
