from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Union
from typing_extensions import Literal, ParamSpec, Protocol, TypedDict

if TYPE_CHECKING:
    from .components.db import Database
    from .components.session import Session
    from .components.stream import Stream
    from .core import Controller
    from .types import RecipeSettingsType, ScoredStreamType, StreamType, TaskType


# Generic ParamSpec for Protocols that accept arbitrary *args, **kwargs
_P = ParamSpec("_P")


class PredictProtocol(Protocol[_P]):
    def __call__(
        self, __stream: StreamType, *args: _P.args, **kwargs: _P.kwargs
    ) -> ScoredStreamType:
        ...


class UpdateProtocol(Protocol[_P]):
    def __call__(
        self, __examples: List[TaskType], *args: _P.args, **kwargs: _P.kwargs
    ) -> Optional[float]:
        ...


class ModelProtocol(Protocol):
    __call__: PredictProtocol
    update: UpdateProtocol


class ProgressProtocol(Protocol):
    def __call__(
        self,
        ctrl: "Controller",
        update_return_value: Optional[Union[int, float]] = None,
    ) -> Union[None, bool, float]:
        ...


class ProgressNewProtocol(Protocol):
    def __call__(
        self,
        ctrl: "Controller",
        session: "Session",
        answers: List[Dict],
        update_return_value: Optional[Union[int, float]],
    ) -> Optional[float]:
        ...


class BeforeDBProtocol(Protocol):
    def __call__(self, __answers: List[Dict]) -> List[Dict]:
        ...


class OnLoadProtocol(Protocol):
    def __call__(self, __ctrl: "Controller") -> None:
        ...


class OnExitProtocol(Protocol):
    def __call__(self, __ctrl: "Controller") -> None:
        ...


class ValidateAnswerProtocol(Protocol):
    def __call__(self, __answer: Dict) -> None:
        ...


class SessionFactoryProtocol(Protocol):
    def __call__(self, ctrl: "Controller", session_id: str) -> "Session":
        ...


class GetSessionIDProtocol(Protocol):
    def __call__(self) -> str:
        ...


class TaskRouterProtocol(Protocol):
    def __call__(self, ctrl: "Controller", session_id: str, item: Dict) -> List[str]:
        ...


class RecipeEventHookProtocol(Protocol[_P]):
    def __call__(
        self, __ctrl: "Controller", *args: _P.args, **kwargs: _P.kwargs
    ) -> Any:
        ...


class ControllerComponentsDict(TypedDict, total=False):
    # Most of these types are Optional at the recipe level
    # but the type gets narrowed at the Controller level
    # We can't expect a user to know they need to cast or provide
    # some noop function to satisfy the type checker
    before_db: Optional[BeforeDBProtocol]
    config: Dict[str, Any]
    dataset: str
    db: Union[None, Literal[False], "Database"]
    exclude: Optional[List[str]]
    get_session_id: Optional[GetSessionIDProtocol]
    metrics: Callable
    # I would've preferred to make this a protocol, but I don't
    # know how to make it flexible enough w.r.t. kwargs.
    event_hooks: Optional[Dict[str, RecipeEventHookProtocol]]
    on_exit: Optional[OnExitProtocol]
    on_load: Optional[OnLoadProtocol]
    progress: Optional[ProgressProtocol]
    task_router: Optional[TaskRouterProtocol]
    session_factory: Optional[SessionFactoryProtocol]
    stream: Union[Stream, StreamType]
    update: Optional[UpdateProtocol]
    validate_answer: Optional[ValidateAnswerProtocol]
    view_id: str


class RecipeFuncProtocol(Protocol[_P]):
    def __call__(
        self, *args: _P.args, **kwargs: _P.kwargs
    ) -> Union["Controller", ControllerComponentsDict, "RecipeSettingsType", Any]:
        ...
