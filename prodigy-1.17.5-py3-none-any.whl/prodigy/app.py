# pyright: reportUndefinedVariable=false, reportGeneralTypeIssues=false, reportOptionalMemberAccess=false, reportOptionalIterable=false, reportPrivateImportUsage=false, reportUnboundVariable=false, reportOptionalSubscript=false
import copy
import os
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple, Union

import peewee
import srsly
import uvicorn
from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request
from fastapi.exception_handlers import http_exception_handler
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import HTMLResponse, Response
from starlette.staticfiles import StaticFiles
from starlette.status import (
    HTTP_400_BAD_REQUEST,
    HTTP_403_FORBIDDEN,
)
from uvicorn.config import LOGGING_CONFIG as UVICORN_LOGGING_CONFIG

from . import about
from .auth import (
    JWT_COOKIE_NAME,
    JWT_FALLBACK_EXPIRE,
    add_company_auth,
    company_auth_configured,
    encode_token,
    get_frontend_auth_dependency,
    get_jwt_auth_dependency,
    get_jwt_config,
    get_requesting_session_id,
    maybe_get_current_user,
)
from .components.db import Database, PeeweeConnectionState, connect, db_state_default
from .core import Controller
from .env_vars import ENV_VARS, get_log_level
from .errors import (
    MaxSessionsExceededError,
    NoSessionFeedOverlapError,
    RecipeError,
    UnauthorizedSessionIdRequestError,
)
from .types import (
    APIAnswersRequest,
    APIAnswersResponse,
    APIAnswerValidateRequest,
    APIAnswerValidateResponse,
    APILogRequest,
    APIQuestionsResponse,
    APISessionQuestionsRequest,
    APIVersionResponse,
    SessionID,
)
from .util import ensure_path, get_valid_sessions, log, msg

API_DOCSTRING = "REST endpoints used for interacting with Prodigy tasks"
STATIC_DIR = Path(__file__).parent / "static"
CONFIG = {}
CONTROLLER = None

# Prevent uvicorn from logging our log messages again
_uvicorn_log_config = copy.deepcopy(UVICORN_LOGGING_CONFIG)


def set_controller(controller: Controller, config: Dict[str, Any]) -> None:
    """Prepare a controller/config for hosting the prodigy application and API endpoints"""
    global CONTROLLER, CONFIG
    config["view_id"] = controller.view_id
    config["batch_size"] = controller.batch_size
    config["version"] = about.__version__
    instructions = config.get("instructions")
    if instructions:
        help_path = Path(instructions)
        if not help_path.is_file():
            raise RecipeError("Can't read instructions", help_path)
        with help_path.open("r", encoding="utf8") as f:
            config["instructions"] = f.read()
    for setting in ["db_settings", "api_keys"]:
        if setting in config:
            config.pop(setting)

    _mount_local_static_files(config, "javascript", ".js")
    _mount_local_static_files(config, "global_css", ".css")
    _log_static_urls(config)

    CONFIG = config
    CONTROLLER = controller


def _mount_local_static_files(
    config: Dict[str, Any], key_prefix: str, file_ext: str
) -> None:
    """Mount any configured local JS/CSS directory to the app and update
    the configured `javascript_urls` and `global_css_urls` configs so they
    can be dynamically loaded in the frontend.
    Updates config dict inplace before setting global CONFIG variable
    """

    static_dir_key = f"{key_prefix}_dir"
    urls_key = f"{key_prefix}_urls"

    static_dir = config.get(static_dir_key)
    if static_dir is None:
        return

    static_dir = ensure_path(static_dir)
    mount_path = mount_user_files(static_dir, base_url=f"/user_files/{key_prefix}")
    config.setdefault(urls_key, [])
    for file in static_dir.glob(f"**/*{file_ext}"):
        log(f"API: Mounting {file_ext} file: {file}")
        relative_mount_path = file.relative_to(static_dir).as_posix()
        config[urls_key].append(f"{mount_path}/{relative_mount_path}")


def _log_static_urls(config: Dict[str, Any]) -> None:
    for url in config.get("global_css_urls", []):
        log(f"API: Loading Global CSS: {url}")

    for url in config.get("javascript_urls", []):
        log(f"API: Loading JavaScript: {url}")


async def _reset_peewee_state(peewee_db: Union[peewee.Proxy, peewee.Database]):
    """Ensure PeeWee state is reset for a Proxy or a Database instance,
    operates inplace if peewee_db is provided and is either a peewee.Proxy
    or a peewee.Database object.

    NOTE: Since we're using a ContextVar for the state,
        this needs to be an async function.
        See: https://fastapi.tiangolo.com/advanced/sql-databases-peewee/#set-database-state-in-the-dependency-get_db
        for more details on the async vs sync PeeWee dependencies

    peewee_db (Union[peewee.Proxy, peewee.Database]): Peewee Proxy or Database
        object to reset the internal ContextVar state for.
    """
    # If it's a Peewee proxy, extract the DB to monkeypatch it
    if isinstance(peewee_db, peewee.Proxy):
        peewee_db = peewee_db.obj
    # If it's Peewee, monkeypatch it
    if isinstance(peewee_db, peewee.Database):
        # Prodigy.db.Database could have monkeypatched it already
        if not isinstance(peewee_db._state, PeeweeConnectionState):
            peewee_db._state = PeeweeConnectionState()
        # Reset the context var state so that other tasks in this async context use
        # the same DB session
        peewee_db._state._state.set(db_state_default.copy())
        peewee_db._state.reset()


async def _connect_and_reset_db_state():
    """Connect to the configured database. If the Database implementation
    has an internal "db" attr, try to reset the peewee state.

    NOTE: Since we're using a ContextVar for the state,
        this needs to be an async function.
        See: https://fastapi.tiangolo.com/advanced/sql-databases-peewee/#set-database-state-in-the-dependency-get_db
        for more details on the async vs sync PeeWee dependencies
    """
    database = connect()
    if hasattr(database, "db") and isinstance(
        database.db, (peewee.Proxy, peewee.Database)
    ):
        await _reset_peewee_state(database.db)
    return database


def _get_db(database: Database = Depends(_connect_and_reset_db_state)):
    """Get the currently configured Database, reconnect, yield, then close
    at the end of the request.
    """
    try:
        if database and hasattr(database, "reconnect"):
            database.reconnect()
        yield database
    finally:
        if database and hasattr(database, "close"):
            database.close()


def _get_controller(database: Database = Depends(_get_db)) -> Iterator[Controller]:
    """FastAPI Dependency for refreshing the Controller
    Database connection for each Request
    RETURNS (Controller): Controller with a reset Database and clean PeeWee State
    """
    global CONTROLLER
    assert CONTROLLER is not None, "controller is undefined!"
    CONTROLLER.set_db(database)
    return CONTROLLER


def get_config() -> Dict[str, Any]:
    global CONFIG
    return CONFIG


#
# Application Configuration
#

app = FastAPI(title="Prodigy", description=API_DOCSTRING, version=about.__version__)

if company_auth_configured():
    # Add /login, /login/callback, and /logout routes + Auth exception handlers
    add_company_auth(app)


def mount_user_files(local_path: Path, base_url: str = "/user_files") -> str:
    """Callback to serve a local directory. Used in file loaders to make
    large files like audio or videos available via an URL.

    local_path (unicode / Path): A local directory.
    RETURNS (unicode): The base URL for the served files, e.g. /user_files.
    """
    log(f"API: Mounting static {base_url} from local path: {local_path}")
    app.mount(base_url, StaticFiles(directory=local_path), name="user_files")
    return base_url


def read_files(path: Path) -> Tuple[str, str, str]:
    """Read the static content once, to avoid reading on each request."""
    index_html = (path / "index.html").read_text(encoding="utf8")
    javascript = (path / "bundle.js").read_text(encoding="utf8")
    favicon = (path / "favicon.ico").read_bytes()
    return index_html, javascript, favicon


INDEX_HTML, JAVASCRIPT, FAVICON = read_files(STATIC_DIR)
app.mount("/fonts", StaticFiles(directory=str(STATIC_DIR / "fonts")))

#
# Auth
#


def assert_known_session(session_id):
    """Raise a FastAPI error if the given session_id doesn't match the user specified
    list. If the user hasn't specified a list of sessions, any are allowed.
    """
    sessions = get_valid_sessions()
    if sessions is None:
        return
    if session_id is None:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN,
            detail="a registered session id is required for this task",
        )
    if session_id not in sessions:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN,
            detail="session is not present in recipe specified list",
        )


static = APIRouter()
routes = APIRouter()

static_auth_dep = get_frontend_auth_dependency(app)
jwt_auth_dep = get_jwt_auth_dependency(app)


#
# API
#


def serve_main() -> HTMLResponse:
    """Serve the main React application and set a httponly cookie
    that enables the client page to make calls to the server."""
    response = HTMLResponse(INDEX_HTML)
    expire = os.getenv(ENV_VARS.JWT_EXPIRE_SECONDS, JWT_FALLBACK_EXPIRE)
    secret, audience = get_jwt_config(default_config=True)
    issuer = os.getenv(ENV_VARS.HOST, audience)
    token = encode_token(secret, audience, issuer, expire)
    response.set_cookie(
        JWT_COOKIE_NAME,
        value=token,
        domain=issuer,
        httponly=True,
        max_age=expire,
        expires=expire,
    )
    return response


async def maybe_get_current_user_session_id(
    controller: Controller = Depends(_get_controller),
    current_user: Any = Depends(maybe_get_current_user),
):
    session_id = None
    if current_user is not None:
        session_id = f"{controller.dataset}-{current_user.id}"
    return session_id


@static.get("/")
def static_root():
    return serve_main()


@static.get("/index.html")
def static_index():
    return serve_main()


@static.get("/bundle.js")
def static_bundle():
    return Response(JAVASCRIPT, media_type="application/javascript")


@static.get("/favicon.ico")
def static_favicon():
    return Response(FAVICON, media_type="image/x-icon")


@routes.get(
    "/version", response_model=APIVersionResponse, dependencies=[Depends(jwt_auth_dep)]
)
def version():
    return dict(
        name="prodigy",
        description=about.__summary__,
        author=about.__author__,
        author_email=about.__email__,
        url=about.__uri__,
        version=about.__version__,
        license=about.__license__,
    )


@routes.get("/health")
@routes.get("/healthz")
def get_health():
    return {"status": "alive"}


def _json_serialize_value(value: Any) -> Optional[Any]:
    if srsly.is_json_serializable(value):
        return value
    elif isinstance(value, Path):
        return str(value)
    else:
        return None


def _serialize_config() -> Dict[str, Any]:
    """Serialize the config for the API response"""
    config = {}
    for key, value in get_config().items():
        serialized_value = _json_serialize_value(value)
        if serialized_value is not None:
            config[key] = serialized_value
    return config


@routes.get("/project", dependencies=[Depends(jwt_auth_dep)])
def get_project(controller: Controller = Depends(_get_controller)):
    log("GET: /project", get_config())
    assert_known_session(None)
    config = _serialize_config()
    config["progress_kind"] = controller.progress_kind
    return config


@routes.get("/project/{session_id}", dependencies=[Depends(jwt_auth_dep)])
def get_session_project(
    session_id: str,
    controller: Controller = Depends(_get_controller),
):
    assert_known_session(session_id)
    config = _serialize_config()
    # We're in a named session here, so we want to show the totals for the
    # given session, not the whole dataset
    config["total"] = controller.total_annotated_by_session.get(session_id, 0)
    config["progress_kind"] = controller.progress_kind
    config["auth_enabled"] = os.getenv("PRODIGY_OIDC_AUTH_ENABLED")
    return config


def _shared_get_questions(
    controller: Controller,
    session_id: Optional[str] = None,
    excludes: Optional[List[int]] = None,
) -> Dict[str, Any]:
    """Because of route decorators we can't call through
    to another route by invoking the fn directly. Move the
    shared logic here into a plain fn"""
    try:
        tasks = controller.get_questions(session_id=session_id, excludes=excludes)
    except (MaxSessionsExceededError, NoSessionFeedOverlapError) as e:
        msg.warn(e.msg)
        raise HTTPException(
            status_code=HTTP_400_BAD_REQUEST,
            detail={"type": type(e).__name__, "message": e.msg},
        )
    out_session = session_id if session_id is not None else controller.session_id
    total = controller.total_annotated
    if session_id and controller.overlap:
        total = controller.total_annotated_by_session.get(session_id, 0)

    response = {
        "tasks": tasks,
        "total": total,
        "progress": controller.get_progress(session_id),
        "session_id": out_session,
    }
    log(f"RESPONSE: /get_session_questions ({len(tasks)} examples)", response)
    return response


@routes.get(
    "/get_questions",
    response_model=APIQuestionsResponse,
    dependencies=[Depends(jwt_auth_dep)],
)
def get_questions(
    controller: Controller = Depends(_get_controller),
):
    """Get the next batch of tasks to annotate.
    RETURNS (dict): {'tasks': list, 'total': int, 'progress': float}
    """
    return _shared_get_questions(controller, None)


@routes.post(
    "/get_session_questions",
    response_model=APIQuestionsResponse,
    dependencies=[Depends(jwt_auth_dep)],
)
def get_session_questions(
    req: APISessionQuestionsRequest,
    controller: Controller = Depends(_get_controller),
    current_user_session_id: Optional[str] = Depends(maybe_get_current_user_session_id),
):
    """Get the next batch of tasks to annotate for a given session_id

    RETURNS (dict): {'tasks': list, 'total': int, 'progress': float, 'session_id': str}
    """
    log("POST: /get_session_questions")
    session_id = get_requesting_session_id(req.session_id, current_user_session_id)
    return _shared_get_questions(controller, session_id, excludes=req.excludes)


@routes.post(
    "/set_session_aliases",
    response_model=SessionID,
    dependencies=[Depends(jwt_auth_dep)],
)
def set_session_aliases(
    req: SessionID,
    controller: Controller = Depends(_get_controller),
    current_user_session_id: Optional[str] = Depends(maybe_get_current_user_session_id),
):
    """Set the list of past session_ids to associate with a current session_id. This
    is useful for recipes that require overlap but want to exclude questions an annotator
    has seen before in a previous session for the same task.

    RETURNS (dict): {'session_id': str}
    """
    log("POST: /set_session_aliases")
    session_id = get_requesting_session_id(req.session_id, current_user_session_id)
    controller.set_session_aliases(session_id, req.aliases)
    return {"session_id": session_id}


@routes.post("/end_session", dependencies=[Depends(jwt_auth_dep)])
def end_session(
    req: SessionID,
    controller: Controller = Depends(_get_controller),
    current_user_session_id: Optional[str] = Depends(maybe_get_current_user_session_id),
):
    """Tell the prodigy controller that it can release the resources held for the
    given session_id.
    """
    log("POST: /end_session")
    session_id = get_requesting_session_id(req.session_id, current_user_session_id)
    response = controller.end_session(session_id)
    log(f"RESPONSE: /end_session ({response})")
    return response


@routes.post(
    "/validate_answer",
    response_model=APIAnswerValidateResponse,
    dependencies=[Depends(jwt_auth_dep)],
)
def validate_answer(
    req: APIAnswerValidateRequest, controller: Controller = Depends(_get_controller)
):
    """Validate an answer that the user intends to submit. This should only
    be called if a validation function has been provided by the recipe.
    """
    log("POST: /validate_answer")
    if controller.validate_answer:
        try:
            controller.validate_answer(req.answer)
        except Exception as e:
            return {"ok": False, "message": str(e)}
    return {"ok": True, "message": None}


@routes.post(
    "/give_answers",
    response_model=APIAnswersResponse,
    dependencies=[Depends(jwt_auth_dep)],
)
def give_answers(
    req: APIAnswersRequest,
    controller: Controller = Depends(_get_controller),
    current_user_session_id: Optional[str] = Depends(maybe_get_current_user_session_id),
):
    """Receive annotated answers, e.g. from the web app.

    answers (list): A list of task dictionaries with an added `"answer"` key.
    session_id (str): The session id string that points to a dataset
    RETURNS (dict): {'progress': float}
    """
    session_id = get_requesting_session_id(req.session_id, current_user_session_id)
    answers = req.answers
    id_info = f", session ID '{session_id}'" if session_id else ""
    log(f"POST: /give_answers (received {len(answers)}{id_info})", answers)
    try:
        controller.receive_answers(
            answers, session_id=session_id, annotator_id=req.annotator_id
        )
    except (MaxSessionsExceededError, NoSessionFeedOverlapError) as e:
        msg.warn(e.msg)
        raise HTTPException(
            status_code=HTTP_400_BAD_REQUEST,
            detail={"type": type(e).__name__, "message": e.msg},
        )

    response = {
        "progress": controller.get_progress(session_id),
    }
    log("RESPONSE: /give_answers", response)
    return response


@routes.post("/event/{name}", dependencies=[Depends(jwt_auth_dep)])
def trigger_event(
    name: str, body: Dict[str, Any], controller: Controller = Depends(_get_controller)
) -> Any:
    """Trigger an event hook. Arbitrary event handlers can be
    registered by Prodigy recipes. The return value of the
    event hook function is returned. A 404 error is raised
    if no event handler of that name is registered.
    """
    if name not in controller.recipe_event_hooks:
        names = repr(list(controller.recipe_event_hooks.keys()))
        raise HTTPException(
            status_code=404, detail=f"No event hook named {name}. Valid names: {names}"
        )
    return controller.call_event(name, body)


@routes.post("/log", dependencies=[Depends(jwt_auth_dep)])
def post_log(req: APILogRequest):
    """Log a message from the Prodigy Front End to the Prodigy console"""
    msg.warn(f"Front End Log - {req.timestamp}: {req.message}")
    log(f"RESPONSE: /log {req.timestamp}: {req.message}", req.data)


app.include_router(static, tags=["static"], dependencies=[Depends(static_auth_dep)])
app.include_router(routes, tags=["api"])


async def unauthorized_request_exception_handler(
    request: Request, exc: UnauthorizedSessionIdRequestError
):
    msg.warn(exc.msg)
    http_exc = HTTPException(
        status_code=HTTP_403_FORBIDDEN,
        detail={"type": type(exc).__name__, "message": exc.msg},
    )
    return await http_exception_handler(request, http_exc)


app.add_exception_handler(
    UnauthorizedSessionIdRequestError, unauthorized_request_exception_handler
)


def server(
    controller: Controller, config: Dict[str, Any], server_url: Optional[str] = None
) -> None:
    """Serve the Prodigy REST API.

    controller (prodigy.core.Controller): The initialized controller.
    config (dict): Configuration settings, e.g. via a prodigy.json or recipe.
    server_url (str): Optional alternative server URL to display.
    """
    set_controller(controller, config)

    port = os.getenv(ENV_VARS.PORT, config.get("port", 8080))
    host = os.getenv(ENV_VARS.HOST, config.get("host", "localhost"))
    if config.get("cors", True):
        cors_origin = os.environ.get(ENV_VARS.CORS_ORIGIN, None)
        # If JWTs are configured, specify allow credentials and the cors origin
        if get_jwt_config() != (None, None) and cors_origin is not None:
            allowed_origins = cors_origin
            if isinstance(allowed_origins, str):
                allowed_origins = allowed_origins.split(",")
            log(f"CORS: initialized with specific origins: {allowed_origins}")
        else:
            log('CORS: initialized with wildcard "*" CORS origins')
            allowed_origins = ["*"]
        app.add_middleware(
            CORSMiddleware,
            allow_origins=allowed_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    if server_url is None:
        server_url = f"http://{host}:{port}"

    if company_auth_configured():
        msg.info("Prodigy Company Auth Enabled")
        log(
            f"API: Prodigy Company Auth Enabled with Settings: {app.state.auth.settings}"
        )

    msg.text(
        f"Starting the web server at {server_url} ...",
        "Open the app in your browser and start annotating!",
        icon="emoji",
        spaced=True,
    )

    # uvicorn doesn't seem to accept our log levels via getLogger, so we also
    # pass it in explicitly here
    uvicorn.run(
        app,
        host=host,
        port=int(port),
        log_level=get_log_level(),
        log_config=_uvicorn_log_config,
    )
    controller.save()
