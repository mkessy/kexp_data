import functools
import importlib.util
import inspect
import math
import threading
from collections import Counter
from inspect import signature
from pathlib import Path
from timeit import default_timer as timer
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    List,
    Optional,
    Set,
    Tuple,
    TypeVar,
    Union,
    cast,
)
from typing_extensions import Literal

from radicli import Arg, Command

from .cli import get_converters
from .components.db import Database, connect
from .components.progress import (
    ProgressEstimator,
    SourceProgressEstimator,
    TargetTotalProgressEstimator,
)
from .components.routers import full_overlap, no_overlap, route_average_per_task
from .components.session import Session
from .components.stream import Stream
from .components.validate import Validator, validate_config, validate_recipe
from .errors import (
    MaxSessionsExceededError,
    NoSessionFeedOverlapError,
)
from .protocols import (
    BeforeDBProtocol,
    ControllerComponentsDict,
    GetSessionIDProtocol,
    OnExitProtocol,
    OnLoadProtocol,
    ProgressNewProtocol,
    ProgressProtocol,
    RecipeEventHookProtocol,
    RecipeFuncProtocol,
    SessionFactoryProtocol,
    TaskRouterProtocol,
    UpdateProtocol,
    ValidateAnswerProtocol,
)
from .structured_types import Example
from .types import TaskType
from .util import (
    ANNOTATOR_ID_ATTR,
    INPUT_HASH_ATTR,
    PRODIGY_HOME,
    SESSION_ID_ATTR,
    TASK_HASH_ATTR,
    VIEW_ID_ATTR,
    add_global_config,
    deep_merge_dicts,
    get_config,
    get_timestamp_session_id,
    get_valid_sessions,
    log,
    msg,
    obfuscate_secret_config,
    registry,
)


class Controller:
    batch_size: int
    before_db: Optional[BeforeDBProtocol]
    dataset: Union[str, Literal[False], None]
    db: Database
    exclude: Optional[List[str]]
    force_order: bool
    home: str
    on_load: Optional[OnLoadProtocol]
    on_exit: Optional[OnExitProtocol]
    overlap: Union[bool, int, float]
    steal_work: bool
    annotations_per_task: Optional[float]
    session_id: str
    session_factory: SessionFactoryProtocol
    state_lock: threading.Lock
    stream: Stream
    task_router: TaskRouterProtocol
    update: Optional[UpdateProtocol]
    validate_answer: Optional[ValidateAnswerProtocol]
    validator: Optional[Validator]
    view_id: str
    recipe_event_hooks: Dict[str, RecipeEventHookProtocol]
    _using_default_router: bool
    _exclude_by: Literal["input", "task"]
    _last_update_return: Union[None, int, float, bool]
    _progress_func: Optional[ProgressNewProtocol]
    _session_aliases: Dict[str, Tuple[str, ...]]
    _sessions: Dict[str, Session]
    _default_session: Optional[Session]
    _using_custom_router: bool

    @classmethod
    def from_components(
        cls,
        name: str,
        components: ControllerComponentsDict,
        config_overrides: Optional[Dict[str, Any]] = None,
    ) -> "Controller":
        dataset = components.get("dataset")
        config = dict(components.get("config", {}))
        config["dataset"] = dataset
        config["recipe_name"] = name
        config = add_global_config(get_config(), config)
        # Add the config overrides last so they don't get overwritten by globals
        if config_overrides is not None:
            config = deep_merge_dicts(config, config_overrides)

        assert "stream" in components
        assert "view_id" in components
        # TODO Vincent -> Don't we have sensible defaults for these? The recipe tests
        #                 seem to assume so.
        # assert "update" in components
        # assert "db" in components

        # If original stream is not a Stream, assume generator
        # TODO v2: deprecate this behavior.
        stream = components["stream"]
        if not isinstance(components["stream"], Stream):
            if not hasattr(components["stream"], "__iter__"):
                raise ValueError(
                    "Stream needs to be iterable. Are you sure you're passing a generator?"
                )
            stream = Stream.from_iterable(components["stream"])

        # TODO Vincent -> I've added a custom validator here for now
        if config.get("validate", True):
            validate_recipe(name, cast(Dict[str, Any], components))

        total_examples_target = config.get("total_examples_target", None)
        update = components.get("update")
        if update is None:
            update = _noop_update
        default_progress_component = _get_default_progress_component(
            total_examples_target, update
        )
        progress = components.get("progress", default_progress_component)
        return cls(
            dataset=dataset,
            view_id=components["view_id"],
            stream=stream,
            update=update,
            db=components.get("db", True),
            progress=progress,
            on_load=components.get("on_load"),
            on_exit=components.get("on_exit"),
            before_db=components.get("before_db"),
            task_router=components.get("task_router"),
            session_factory=components.get("session_factory"),
            validate_answer=components.get("validate_answer"),
            get_session_id=components.get("get_session_id"),
            exclude=components.get("exclude"),
            config=config,
            metrics=components.get("metrics"),
            recipe_event_hooks=components.get("event_hooks", {}),
        )

    def __init__(
        self,
        dataset: Union[str, Literal[False], None],
        view_id: str,
        stream: Union[Iterable, Stream],
        update: UpdateProtocol,
        db: Union[None, bool, str, Database],
        progress: Union[None, ProgressProtocol, ProgressNewProtocol],
        on_load: Optional[OnLoadProtocol],
        on_exit: Optional[OnExitProtocol],
        before_db: Optional[BeforeDBProtocol],
        validate_answer: Optional[ValidateAnswerProtocol],
        get_session_id: Optional[GetSessionIDProtocol],
        exclude: Optional[List[str]],
        config: dict,
        metrics: Optional[Callable],
        *,
        task_router: Optional[TaskRouterProtocol] = None,
        session_factory: Optional[SessionFactoryProtocol] = None,
        recipe_event_hooks: Optional[Dict[str, RecipeEventHookProtocol]] = None,
    ) -> None:
        # Okay there's a lot going on in this init and settings
        # are being computed from multiple places. To keep this
        # a bit more organized, we'll do things in the following
        # order:
        # 1. Unpack local variables. This includes getting
        # stuff from the config. We want to get to where we'd be
        # if we had these as arguments of the function.
        # Once we've unpacked, we shouldn't be making new
        # local variable assignments.
        # 2. Modify variables. This includes any appending,
        # setting etc that we had to do based on the unpacks
        # above.
        # 3. Validate. This is where any errors should be raised.
        # 4. Set private attributes. These should be direct
        # non-conditional assignments. Alphabetize these.
        # 5. Set public attributes. Again, direct non-conditional
        # assignments. Alphabetize.
        # 6. Log. This is where logging stuff should be printed.
        # 7. Local method calls (e.g. connect_db)
        log("CONTROLLER: Initialising from recipe")
        log("CONTROLLER: Recipe Config", obfuscate_secret_config(config))
        # Unpack local variables
        batch_size = config.get("batch_size", 10)
        default_history_size = config.get("history_size", 10_000)
        exclude = [] if exclude is None else list(exclude)
        exclude_by = cast(Literal["input", "task"], config.get("exclude_by", "task"))
        exclude_attr = TASK_HASH_ATTR if exclude_by == "task" else INPUT_HASH_ATTR
        get_session_id = get_session_id or get_timestamp_session_id
        max_sessions = config.get("max_sessions", 100)
        overlap = config.get("feed_overlap", False)
        annotations_per_task = config.get("annotations_per_task", None)
        recipe_event_hooks = (
            dict(recipe_event_hooks) if recipe_event_hooks is not None else {}
        )

        # VINCENT TODO: I'm loading total_examples_target from the config per
        #  https://prodi.gy/docs/install, but there is also a `auto_count_stream` variable
        # I'm wondering what to do with this, since we might also receive a file as
        # source in the future.
        target_total_annotated = config.get("total_examples_target", None)
        if progress is not None:
            progress = _translate_old_progress_protocol(progress)
        # Application-wide lock to ensure that writes don't race
        state_lock = threading.Lock()
        timestamp = timer()
        validate = config.get("validate", True)
        validator = Validator(view_id) if validate else None
        # Modify local variables
        if not isinstance(stream, Stream):
            # We don't want to support this long-term, but
            # for v1.12, we want to stay backwards compatible
            # if they simply pass in a Stream object.
            stream = Stream.from_iterable(stream)

        # Use user-provided task_router or generate one from `feed_overlap/annotations_per_task` setting
        using_custom_router = task_router is not None
        if using_custom_router:
            log("CONTROLLER: Using a custom task router defined by user.")
        task_router = task_router or _get_default_task_router(
            overlap, annotations_per_task
        )

        # Exit if parameters with overlappig semantics with regards to task routing are combined
        if annotations_per_task and using_custom_router:
            msg.fail(
                "Cannot set `annotations_per_task` while using a custom task router",
                exits=True,
            )
        if overlap and annotations_per_task:
            msg.fail(
                "Cannot set `feed_overlap` to true while `annotations_per_task` is passed",
                exits=True,
            )
        if overlap and using_custom_router:
            msg.fail(
                "Cannot set `feed_overlap` to true while using a custom task router",
                exits=True,
            )

        if overlap is True:
            # For full overlap to work, the Stream needs to track
            # history so set the history size here if it's at -1.
            history_size = stream.max_history_size
            if history_size == -1 and stream.source_size is not None:
                history_size = stream.source_size
            if history_size == -1:
                history_size = default_history_size
            stream.set_max_history_size(history_size)

        # Assume users can steal work, unless configured otherwise
        steal_work = config.get("allow_work_stealing", True)

        if validate_answer:
            # This setting makes sure that the frontend knows to send the example
            # to the validation endpoint.
            config["validate_answer"] = True
        # Automatically exclude current dataset
        if (
            config.get("auto_exclude_current", True)
            and dataset
            and dataset not in exclude
        ):
            exclude.append(dataset)

        # Validate
        if exclude_by not in ("task", "input"):
            raise ValueError(f"Invalid exclude_by: {exclude_by}. Expected: task, input")

        if validator is not None:
            validate_config(config)

        if stream.is_empty:
            msg.fail(
                "Error while validating stream: no first example. ",
                (
                    "This likely means that your 'loader' could not find any examples in the 'source'. "
                    "Ensure you're using a source with some examples and that not all examples "
                    "are being filtered out by preprocessing functions in your recipe. "
                    "This can also mean all the examples in your stream have been "
                    "annotated in datasets included in your --exclude recipe parameter."
                ),
                exits=1,
            )

        # Assign to privates
        self._exclude_by = exclude_by
        self._exclude_attr = exclude_attr
        self._max_sessions = max_sessions
        self._last_update_return = None
        self._sessions = {}
        self._timeout_seconds = 3600
        self._timestamp = timestamp
        self._get_session_id = get_session_id
        self._default_session = None
        self._session_aliases = {}
        self._dataset_history = {}
        self._session_history = {}
        self._session_annotated = 0
        self._session_annotated_by_session = Counter()
        self._session_queued_by_session = Counter()
        self._target_annotated = target_total_annotated
        self._annotated_at_start = None

        # Assign to publics
        self.batch_size = batch_size
        self.before_db = before_db
        self.config = config
        self.dataset = dataset
        self.exclude = exclude
        self.home = PRODIGY_HOME
        self.metrics = metrics
        self.on_exit = on_exit
        self.on_load = on_load
        self.recipe_event_hooks = recipe_event_hooks
        self.overlap = overlap
        self.annotations_per_task = annotations_per_task
        self._progress_func = progress
        self.session_id = get_session_id()
        self.state_lock = state_lock
        self.stream = stream
        self.task_router = task_router
        self._using_custom_router = using_custom_router
        self.update = update
        self.validate_answer = validate_answer
        self.view_id = view_id
        if dataset in (False, None):
            log(f"CONTROLLER: Not using a datsaset ({dataset})")
        if get_session_id is not get_timestamp_session_id:
            log(
                f"CONTROLLER: Using custom function to assign session ID: {self.session_id}",
                repr(get_session_id),
            )
        self.session_factory = session_factory or _get_default_session_factory()
        self.validator = validator

        self.db = self.connect_db(db)
        if self.on_load is not None:
            log("CONTROLLER: Calling recipe's on_load() method")
            self._cb_on_load(self)
        self._annotated_at_start = (
            self.db.count_dataset(self.dataset) if self.dataset else 0
        )
        self.steal_work = steal_work

        # If the allowed sessions are given then the sessions are known upfront.
        # and we need to ensure that they around for the task router.
        allowed_sessions = get_valid_sessions()
        if allowed_sessions:
            for name in allowed_sessions:
                self.confirm_session(self.get_session_name(name))

    @property
    def progress(self) -> Optional[float]:
        # TODO: Deprecate for v2
        return self.get_progress(session_id=None)

    @property
    def target_annotated(self) -> Optional[int]:
        return self._target_annotated

    @property
    def total_annotated(self) -> int:
        # TODO MH: I'm not sure how the annotation counts are supposed to work.
        # Should this ever be None?
        if self._annotated_at_start is None:
            return 0
        else:
            return self._annotated_at_start + self.session_annotated

    @property
    def total_annotated_by_session(self) -> Counter:
        return Counter({sess.id: sess.total_annotated for sess in self.get_sessions()})

    @property
    def all_session_ids(self) -> Set[str]:
        return set(self._sessions.keys())

    @property
    def session_annotated(self) -> int:
        total = 0
        for sess in self.get_sessions():
            total += sess.session_annotated
        return total

    @property
    def session_annotated_by_session(self) -> Counter:
        return Counter(
            {
                sess.id: sess.session_annotated
                for sess in self.get_sessions()
                if sess.id != self.session_id
            }
        )

    @property
    def exclude_by(self) -> Literal["task", "input"]:
        return self._exclude_by

    # I want to get rid of the Optional on the callbacks,
    # by remapping None to noop functions for them.
    # However, this feels like a bit of a break risk for v1.12.
    # So I'm using private properties for them instead.
    @property
    def _cb_before_db(self) -> BeforeDBProtocol:
        return self.before_db or _noop_before_db

    @property
    def _cb_on_load(self) -> OnLoadProtocol:
        return self.on_load or _noop_on_load

    @property
    def _cb_on_exit(self) -> OnExitProtocol:
        return self.on_exit or _noop_on_exit

    @property
    def _cb_progress(self) -> ProgressNewProtocol:
        return self._progress_func or _noop_progress

    @property
    def _cb_update(self) -> UpdateProtocol:
        return self.update or _noop_update

    @property
    def session_ids(self) -> List[str]:
        return [s.id for s in self.get_sessions()]

    @property
    def progress_kind(self) -> str:
        if self._progress_func is None:
            return "noop"
        if isinstance(self._progress_func, SourceProgressEstimator):
            return "source"
        if isinstance(self._progress_func, TargetTotalProgressEstimator):
            return "target"
        return getattr(self._progress_func, "kind", "custom")

    def get_sessions(self) -> List[Session]:
        return list(self._sessions.values())

    def add_session(self, session: Session, n_history: int = -1) -> None:
        self._sessions[session.id] = session
        self.stream.ensure_queue(session.id, n_history=n_history)

    def get_progress(
        self, session_id: Optional[str] = None
    ) -> Optional[Union[int, float]]:
        """Get Progress for a given session (or the default session if None)
        The progress is calculated for the session by the progress
        callback.

        RETURNS (Union[int, float]): If float, will be treated as a percentage (between 0.0 and 1.0).
            If int, will be treated as a percentage out of 100.
        """
        if session_id is None and self.overlap is not False:
            return None
        session = self._get_session(session_id)
        progress = self._cb_progress(self, session, [], self._last_update_return)
        if progress is not None:
            progress = round(progress, 3)
        return progress

    def get_total_by_session(self, session_id: str) -> int:
        total = 0
        if self.db and session_id in self.db:
            total = self.db.count_dataset(session_id)
        return total

    def get_dataset_named_sessions(self, dataset: str) -> List[str]:
        dataset_session_ids = self.db.get_dataset_sessions(dataset)
        return [s for s in dataset_session_ids if s.startswith(f"{dataset}-")]

    def ensure_session(self, session_id: str) -> None:
        """Create a session dataset with the boolean flag True"""
        if self.db and self.dataset not in (False, None):
            dataset_meta = self.db.get_meta(self.dataset)
            self.db.add_dataset(session_id, dataset_meta or {}, session=True)

    def set_session_aliases(self, session_id: str, session_ids: List[str]) -> None:
        """Associate a number of session with the given session_id for exclusion purposes"""
        self._session_aliases[session_id] = tuple(session_ids)

    def get_questions(
        self, session_id: Optional[str] = None, excludes: Optional[List[int]] = None
    ) -> List[TaskType]:
        log(f"CONTROLLER: Getting batch of questions for session: {session_id}")
        exclude_task_hashes = set() if excludes is None else set(excludes)
        exclude_input_hashes = set()
        session = self._get_session(session_id)
        other_sessions = [s for s in self._sessions.values() if s.id != session.id]
        # Partially apply the controller/session into the task_router callback. This gives the callback
        # the controller, while letting the stream call the callback without access to the controller.
        router = functools.partial(self.task_router, self, session.id)
        with self.state_lock:
            batch = session.get_questions(
                self.batch_size,
                task_router=router,
                other_sessions=other_sessions,
                exclude_input_hashes=exclude_input_hashes,
                exclude_task_hashes=exclude_task_hashes,
                steal_work=self.steal_work,
            )
        questions = []
        for item in batch:
            # Just converts Structured Tasks to Unstructured Tasks for now if we are
            # using structured streams.
            task = item.data.to_unst() if isinstance(item.data, Example) else item.data
            # Add interface ID to task. This way, we can always reconstruct
            # pretty much exactly what the annotator saw, based on a single task.
            config_view_id = task.get("config", {}).get("view_id")
            if task.get("pages"):
                task[VIEW_ID_ATTR] = self.view_id
                validator = Validator(task[VIEW_ID_ATTR])
                validator.check(task)
            elif config_view_id:
                task[VIEW_ID_ATTR] = config_view_id
                validator = Validator(task[VIEW_ID_ATTR])
                validator.check(task)
            else:
                task[VIEW_ID_ATTR] = self.view_id
                if self.validator:
                    self.validator.check(task)
            questions.append(task)
        return questions

    def receive_answers(
        self,
        answers: List[TaskType],
        session_id: Optional[str] = None,
        annotator_id: Optional[str] = None,
    ) -> None:
        log(f"CONTROLLER: Receiving {len(answers)} answers")
        with self.state_lock:
            self.db.reconnect()
            session = self._get_session(session_id)
            # TODO: The previous code modified these in-place,
            # so I've preserved that. Hopefully we don't depend on that...
            session_id = session_id if session_id else self.session_id
            for a in answers:
                a[ANNOTATOR_ID_ATTR] = annotator_id if annotator_id else session_id
                a[SESSION_ID_ATTR] = session_id
            log(
                f"Controller: received answers for session {session.id}: {len(answers)}"
            )
            update_return = self._cb_update(list(answers))
            self._last_update_return = update_return
            mod_answers = self._cb_before_db(answers)
            _validate_before_db_answers(answers, mod_answers)
            self._db_add_examples(mod_answers, session.id)
            session.increment_annotations(len(answers))
            progress = self._cb_progress(self, session, mod_answers, update_return)
            keys = [a[TASK_HASH_ATTR] for a in mod_answers]
            session.receive_answers(mod_answers, keys, progress)

    def call_event(self, event_name: str, kwargs: Dict) -> None:
        if event_name not in self.recipe_event_hooks:
            raise KeyError(f"No event hook: {event_name}.")
        log(f"CONTROLLER: Calling event {event_name}")
        hook = self.recipe_event_hooks[event_name]
        return hook(self, **kwargs)

    def end_session(self, session_id: str) -> Dict[str, bool]:
        log(f"CONTROLLER: Ending session {session_id}")
        with self.state_lock:
            if session_id in self._sessions:
                del self._sessions[session_id]
                return {"ended": True}
            else:
                return {"ended": False}

    def save(self) -> None:
        if (
            self.session_annotated > 0
            and self.db not in (None, False)
            and self.dataset not in (False, None)
        ):
            if hasattr(self.db, "save"):
                self.db.save()
            print("")  # noqa: T201
            text = f"Saved {self.session_annotated} annotations to database {self.db.db_name}"
            msg.good(text)
            msg.text(f"Dataset: {self.dataset}")
            msg.text(f"Session ID: {self.session_id}")
            print("")  # noqa: T201

        if self.on_exit and hasattr(self.on_exit, "__call__"):
            log("CONTROLLER: Calling recipe's on_exit() method")
            self._cb_on_exit(self)

    def connect_db(self, db: Union[None, bool, str, Database]) -> Database:
        if db in (True, False, None):
            db = connect()
        elif isinstance(db, str):
            db = connect(db)
        if self.dataset in (True, False, None):
            return db
        if self.dataset not in db:
            if not self.config.get("auto_create", True):
                err = f"Can't find '{self.dataset}' in database {db.db_name}"
                raise ValueError(err)
            else:
                db.add_dataset(self.dataset)
                msg.text(f"Added dataset {self.dataset} to database {db.db_name}.")
        dataset_meta = db.get_meta(self.dataset)
        if self.dataset not in (False, None):
            db.add_dataset(self.session_id, dataset_meta or {}, session=True)
        return db

    def set_db(self, db: Database) -> None:
        """Set the Controller db to a new instance"""
        self.db = db

    def _get_session(self, session_id: Optional[str] = None) -> Session:
        """Get the current session based on a session_id.
        If no session_id and no overlap, assume this is a single annotator project
        and return the default session.
        If overlap is set and no session_id provided raise exception.
        session_id (Optional[str]): The Session ID
        create: (bool): Create session if it doesn't exist. If False, return the default session
        RETURNS (Session): Current session
        """
        if session_id is None and self.overlap:
            raise NoSessionFeedOverlapError(
                self.overlap, self.annotations_per_task, self._using_custom_router
            )
        if session_id is None and self.annotations_per_task:
            raise NoSessionFeedOverlapError(
                self.overlap, self.annotations_per_task, self._using_custom_router
            )
        if session_id is None and self._using_custom_router:
            raise NoSessionFeedOverlapError(
                self.overlap, self.annotations_per_task, self._using_custom_router
            )
        elif session_id is None:
            if not self._default_session:
                self._default_session = self.session_factory(self, self.session_id)
            return self._default_session
        else:
            return self.confirm_session(session_id)

    def confirm_session(self, session_id: str) -> Session:
        """Makes sure that the session exists."""
        if session_id not in self._sessions:
            if len(self._sessions) >= self._max_sessions:
                raise MaxSessionsExceededError(session_id, self._max_sessions)
            self._sessions[session_id] = self.session_factory(self, session_id)
        return self._sessions[session_id]

    def get_session_name(self, name: str) -> str:
        """Pass in a name for a user to get the correct session_id."""
        return f"{self.dataset}-{name}"

    def _db_add_examples(self, answers: List[Dict], session_id: str) -> None:
        if self.dataset in (None, False):
            return
        self.ensure_session(session_id)
        self.db.add_examples(answers, [self.dataset, session_id])
        log(
            f"CONTROLLER: Added {len(answers)} answers to dataset '{self.dataset}' "
            f"in database {self.db.db_name}"
        )

    def reset_stream(self, new_stream: Stream, prepend_old_wrappers: bool = False):
        """Reset the stream of the controller and all sessions.

        This method is meant to be used as a helper for event hooks that want
        to reset the examples for all users"""
        log("CONTROLLER: Resetting the stream.")
        # The user may have added their own wrappers beforehand themselves _while_
        # they want the old wrappers to be applied first. Other users may have no
        # custom wrappers to apply, but might still be interested in copying the
        # old ones just the same. The `prepend_old_wrappers` utility tries to make *this* easy.
        old_wrappers = []
        if prepend_old_wrappers:
            old_wrappers = self.stream.wrappers
        self.stream = new_stream
        if prepend_old_wrappers:
            self.stream.set_wrappers(old_wrappers + new_stream.wrappers)
        # We need to ensure the queue for everyone (edge case)
        # otherwise the stream isn't aware of who it can steal from.
        for sess in self.get_sessions():
            self.stream.ensure_queue(sess.id)
        # Now we can safely reset the streams on each session
        for sess in self.get_sessions():
            sess.reset_stream(self.stream)


def _get_default_task_router(
    feed_overlap: bool, annotations_per_task: Optional[float] = None
) -> TaskRouterProtocol:
    # In this case we handle the default like before v1.12
    if annotations_per_task:
        log(
            f"CONTROLLER: Using `route_average_per_task` router with {annotations_per_task=}"
        )
        return route_average_per_task(annotations_per_task)

    if feed_overlap:
        log("CONTROLLER: Using `full_overlap` router.")
        return full_overlap

    log("CONTROLLER: Using `no_overlap` router.")
    return no_overlap


def _get_default_progress_component(
    total_examples_target: Optional[int], update: UpdateProtocol
):
    if total_examples_target is not None:
        progress_component = TargetTotalProgressEstimator()
    elif update is not _noop_update:
        progress_component = ProgressEstimator()
    else:
        progress_component = SourceProgressEstimator()
    return progress_component


def _get_default_session_factory() -> SessionFactoryProtocol:
    return _session_factory


def _session_factory(ctrl: Controller, session_id: str) -> Session:
    total_annotated = 0
    session_history_hashes = None

    # Make sure that we don't forget about the previous annotations.
    if ctrl.db not in (False, None) and isinstance(ctrl.dataset, str):
        session_history_hashes = _get_session_history_hashes(ctrl, session_id)
        if session_id in ctrl.db:
            total_annotated = ctrl.db.count_dataset(session_id, session=True)

    ctrl.stream.ensure_queue(session_id)
    session = Session(
        session_id,
        ctrl.stream,
        batch_size=ctrl.batch_size,
        answered_input_hashes=(
            session_history_hashes if ctrl.exclude_by == "input" else None
        ),
        answered_task_hashes=(
            session_history_hashes if ctrl.exclude_by == "task" else None
        ),
        total_annotated=total_annotated,
        target_annotated=ctrl.target_annotated or 0,
    )
    ctrl.add_session(session)
    return session


def _get_session_history_hashes(
    ctrl: Controller, session_id: Optional[str]
) -> Set[int]:
    """Get task or input hashes (based on Controller._exclude_by setting)
    for previously annotated examples to exclude
    from the examples shown to each session.

    Ok a lot needs to happen here to ensure no duplicates are shown to annotators.

    1. Datasets passed via --exclude should always have their hashes excluded no matter what.
    2. If overlap is True, only exclude hashes from the current session
    3. If overlap is False, exclude hashes from all sessions (i.e. the main ctrl dataset)
    4. If annotations_per_task is set, exclude hashes from the current session
        so as not to show a single annotator duplicates. However, we also need to do a check to see
        how many times a task has been annotated by other users. So in this case we'll exclude the
        current session and also potentially exclude other sessions if the task has been annotated
        more than annotations_per_task times.

    session_id (Optional[str]): Current session_id
    RETURNS (Set[int]) Input or Task hashes previously seen
    """
    if not ctrl.db or ctrl.dataset in (False, None):
        return set()

    main_dataset = ctrl.dataset
    ctrl_exclude = list(ctrl.exclude) if ctrl.exclude else []
    # 1. These datasets should always be excluded. They were passed via --exclude
    # and should never be shown to annotators
    always_exclude_datasets = set([ds for ds in ctrl_exclude if ds != main_dataset])

    if ctrl.overlap is True:
        # If overlap is True, only return hashes for this session,
        # not all the other sessions
        assert session_id is not None
        datasets_to_exclude = always_exclude_datasets.union({session_id})
        seen_hashes = ctrl.db.get_hashes(*datasets_to_exclude, kind=ctrl.exclude_by)

    elif ctrl.annotations_per_task is not None:
        # If annotations_per_task is set, we need to exclude the current session's
        # already seen hashes so annotators never get duplicates of stuff they've already annotated
        assert session_id is not None
        datasets_to_exclude = always_exclude_datasets.union({session_id})
        session_seen_hashes = ctrl.db.get_hashes(
            *datasets_to_exclude, kind=ctrl.exclude_by
        )

        # After excluding the current session's seen hashes, we need to also exclude
        # hashes from the main dataset that have been completed.
        min_card = math.ceil(ctrl.annotations_per_task)

        # Get the hashes of tasks that have been completed at least min_card times
        # according to the type of `ctrl.annotations_per_task`.
        # Add these to the set of seen_hashes for the current session.
        other_sessions_completed_hashes = ctrl.db.get_hashes_min_cardinality(
            main_dataset, n=min_card, kind=ctrl.exclude_by
        )
        seen_hashes = session_seen_hashes.union(other_sessions_completed_hashes)
    else:
        # Overlap is False and annotations_per_task is None. This is the default
        # case and we just exclude the hashes in the main dataset and datasets
        # provided to --exclude since each task should only be annotated once.
        datasets_to_exclude = set(ctrl_exclude)
        seen_hashes = ctrl.db.get_hashes(*datasets_to_exclude, kind=ctrl.exclude_by)
    return seen_hashes


def _validate_before_db_answers(before: List[Dict], after: List[Dict]) -> None:
    if not isinstance(after, list):
        msg.fail(
            f"Wrong data returned by before_db. Expected list of "
            f"answers, but got: {type(after)}. Did you return "
            f"the modified examples correctly?"
        )
    if len(before) != len(after):
        msg.warn(
            f"Received {len(after)} to add to database after "
            f"before_db (original answers: {len(before)})"
        )


def _translate_old_progress_protocol(
    func: Union[ProgressProtocol, ProgressNewProtocol]
) -> ProgressNewProtocol:
    def wrapper(
        ctrl: Controller,
        session: Session,
        answers: List[Dict],
        update_return_value: Optional[Union[int, float]],
    ) -> Optional[Union[int, float]]:
        func_ = cast(ProgressProtocol, func)
        return func_(ctrl, update_return_value=update_return_value)

    sig = inspect.signature(func)
    params = list(sig.parameters.values())
    if len(params) == 4:
        # This isn't a very good check, but I don't know
        # that we want to force people to use the correct
        # type annotations. Maybe we should check for positional
        # vs keywords at least?
        return cast(ProgressNewProtocol, func)
    else:
        return wrapper


def _noop_before_db(answers: List[Dict]) -> List[Dict]:
    return answers


def _noop_on_exit(ctrl: Controller) -> None:
    return None


def _noop_on_load(*a, **k) -> None:
    return None


def _noop_progress(
    ctrl: Controller,
    session: Session,
    answers: List[Dict],
    update_return_value: Optional[float],
) -> None:
    return None


def _noop_update(answers: List[TaskType]) -> None:
    return None


_RecipeT = TypeVar("_RecipeT", bound=RecipeFuncProtocol)


def convert_recipe_annots(
    key: str, annots: Tuple[str, str, Optional[str], Optional[Callable[[str], Any]]]
) -> Arg:
    """Convert args from tuple style to Radicli Arg objects."""
    if len(annots) > 4:
        annots = annots[:4]
    help, style, short, at = annots
    converter = at if at not in (str, int, float, bool, Path) else None
    is_pos = style == "positional"
    return Arg(
        None if is_pos else f"--{key.replace('_', '-')}",
        None if is_pos or not short else f"-{short}",
        help=help,
        converter=converter,
    )


def is_server_recipe(components: Any) -> bool:
    """Whether the return values of a recipe require the annotation server."""
    return isinstance(components, Controller) or (
        isinstance(components, dict) and "stream" in components
    )


def recipe(name: str, **annotations) -> Callable[[_RecipeT], _RecipeT]:
    def recipe_decorator(recipe_func: _RecipeT) -> _RecipeT:
        args = {}
        for key, annot in annotations.items():
            arg = annot if isinstance(annot, Arg) else convert_recipe_annots(key, annot)
            args[key] = arg
        allow_extra = "_extra" in signature(recipe_func).parameters
        converters = get_converters()
        cmd = Command.from_function(
            name, args, recipe_func, converters=converters, allow_extra=allow_extra
        )
        set_recipe(name, cmd)
        return recipe_func

    return recipe_decorator


def set_recipe(name: str, func: Command) -> None:
    """Register a recipe command with a name.

    name (unicode): Name of the recipe.
    func (Command): Recipe command.
    """
    registry.recipes.register(name, func=func)


def get_recipe(name: str) -> Optional[Command]:
    """Get a recipe for a given name.

    name (unicode): The recipe name.
    RETURNS (Command): The recipe command if found, otherwise None.
    """
    if name in registry.recipes:
        return registry.recipes.get(name)
    return None


def import_code(code_path: Optional[Union[str, Path]]) -> None:
    """Helper to import Python file to make custom registered functions
    and recipes available.
    """
    # Note: Using msg.fail here since this runs before the CLI context
    if code_path is not None:
        if not Path(code_path).exists():
            msg.fail("Path to Python code not found", str(code_path), exits=1)
        try:
            spec = importlib.util.spec_from_file_location("custom_code", str(code_path))
            assert spec is not None
            assert spec.loader is not None
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
        except Exception as e:
            msg.fail(f"Couldn't load Python code: {code_path}", str(e), exits=1)
