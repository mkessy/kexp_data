import copy
from typing import TYPE_CHECKING, Callable, Iterable, List, Optional, Tuple, Union, cast

from spacy.language import Language
from spacy.tokens import Doc
from spacy.training import Example
from spacy.util import registry as spacy_registry

from ..components.db import connect
from ..components.decorators import support_both_streams
from ..components.filters import filter_seen_before
from ..components.preprocess import (
    add_annot_name,
    add_tokens,
    add_view_id,
    make_raw_doc,
    make_spancat_suggestions,
    resolve_labels,
)
from ..components.stream import get_stream
from ..core import Arg, recipe
from ..errors import RecipeError
from ..models.matcher import PatternMatcher
from ..protocols import ControllerComponentsDict
from ..types import ExistingFilePath, LabelsType, SourceType, StreamType, TaskType
from ..util import (
    ANNOTATOR_ID_ATTR,
    INPUT_HASH_ATTR,
    get_pipe_labels,
    log,
    msg,
    set_hashes,
)

if TYPE_CHECKING:
    from spacy.pipeline import SpanCategorizer


@recipe(
    "spans.manual",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline for tokenization or blank:lang (e.g. blank:en)"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    patterns=Arg("--patterns", "-pt", help="Path to match patterns file"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    highlight_chars=Arg("--highlight-chars", "-C", help="Allow highlighting individual characters instead of tokens"),
    suggester=Arg("--suggesters", "-sg", help="Name of suggester function registered in spaCy's 'misc' registry. Will be used to validate annotations as they're submitted. Use the -F option to provide a custom Python file"),
    use_annotations=Arg("--use-annotations", "-A", help="Use annotations from the specified spaCy model."),
    # fmt: on
)
def manual(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    patterns: Optional[ExistingFilePath] = None,
    exclude: List[str] = [],
    highlight_chars: bool = False,
    suggester: Optional[str] = None,
    use_annotations: bool = False,
) -> ControllerComponentsDict:
    """
    Annotate potentially overlapping and nested spans in the data. If
    patterns are provided, their matches are highlighted in the example, if
    available. The tokenizer is used to tokenize the incoming texts so the
    selection can snap to token boundaries. You can also set --highlight-chars
    for character-based highlighting.
    """
    log("RECIPE: Starting recipe spans.manual", locals())
    view_id = "spans_manual"
    labels = get_pipe_labels(label, nlp.pipe_labels.get("spancat", []))
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)

    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )
    if patterns is not None:
        pattern_matcher = PatternMatcher(
            nlp, combine_matches=True, all_examples=True, allow_overlap=True
        )
        pattern_matcher = pattern_matcher.from_disk(patterns)
        stream.apply(lambda d: (eg for _, eg in pattern_matcher(d)))
    # Add "tokens" key to the tasks, either with words or characters
    stream.apply(add_tokens, nlp=nlp, stream=stream)
    validate_func = (
        validate_with_suggester(nlp, suggester, use_annotations=use_annotations)
        if suggester
        else None
    )

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "validate_answer": validate_func,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "ner_manual_highlight_chars": highlight_chars,
            "auto_count_stream": True,
        },
    }


def validate_with_suggester(
    nlp: Language,
    suggester_name: str,
    *,
    use_annotations: bool,
) -> Callable[[TaskType], None]:
    msg.info(f"Validating annotations against suggester function '{suggester_name}'")
    suggester = spacy_registry.get("misc", suggester_name)()

    def validate_answer(answer: TaskType) -> None:
        spans = answer.get("spans", [])
        if not spans:  # No need to run suggester if we don't have spans
            pass
        # Don't allow spans that are not compatible with the provided suggester
        words = [t["text"] for t in answer["tokens"]]
        spaces = [t.get("ws", True) for t in answer["tokens"]]
        doc = Doc(nlp.vocab, words=words, spaces=spaces)
        # Add annotations from other components
        if use_annotations:
            doc = nlp(doc)
        suggested_spans = suggester([doc])
        suggested_span_tuples = [(s[0], s[1]) for s in suggested_spans.data]
        text = answer["text"]
        annotated = {
            ((s["token_start"], s["token_end"] + 1)): text[s["start"] : s["end"]]
            for s in spans
        }
        for annotated_tuple, text in annotated.items():
            if annotated_tuple not in suggested_span_tuples:
                start, end = annotated_tuple
                err = (
                    f"Span with token offsets {start}:{end} ({text}) "
                    f"is not compatible with the provided suggester function "
                    f"'{suggester_name}'."
                )
                raise ValueError(err)

    return validate_answer


@recipe(
    "spans.correct",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with a span categorizer"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    update=Arg("--update", "-UP", help="Whether to update the model during annotation"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    component=Arg("--component", "-c", help="Name of spancat component in the pipeline"),
    # fmt: on
)
def correct(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    update: bool = False,
    exclude: List[str] = [],
    component: str = "spancat",
) -> ControllerComponentsDict:
    """
    Correct a span categorizer predicting potentially overlapping and nested
    spans. Requires a spaCy pipeline with a trained SpanCategorizer and will
    show all spans in the given group.
    """
    log("RECIPE: Starting recipe spans.correct", locals())
    view_id = "spans_manual"
    if component not in nlp.pipe_names:
        raise RecipeError(
            f"Can't find component '{component}' in pipeline"
            "Make sure that the pipeline you're using includes a trained span "
            "categorizer that you can correct. If your component has a different "
            "name, you can use the --component option to specify it.",
        )
    labels, key = get_span_labels(nlp, label=label, component=component)
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )
    stream.apply(preprocess_stream, stream, nlp, labels=labels, key=key)

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "update": get_update(nlp, key=key) if update else None,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "auto_count_stream": True,
        },
    }


@support_both_streams(stream_arg="stream")
def preprocess_stream(
    stream: StreamType,
    nlp: Language,
    *,
    labels: Optional[List[str]],
    key: str,
    set_annotations: bool = True,
) -> StreamType:
    stream = add_tokens(nlp, stream)  # type: ignore
    if set_annotations:
        spacy_model = f"{nlp.meta['lang']}_{nlp.meta['name']}"
        # Add a 'spans' key to each example, with predicted spans
        texts = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(texts, as_tuples=True, batch_size=10):
            task = copy.deepcopy(eg)
            spans = []
            for span in doc.spans[key]:
                if labels and span.label_ not in labels:
                    continue
                spans.append(
                    {
                        "token_start": span.start,
                        "token_end": span.end - 1,
                        "start": span.start_char,
                        "end": span.end_char,
                        "text": span.text,
                        "label": span.label_,
                        "source": spacy_model,
                        "input_hash": eg[INPUT_HASH_ATTR],
                    }
                )
            task["spans"] = spans
            task = set_hashes(task)
            yield task
    else:
        yield from stream


def get_update(nlp: Language, *, key: str) -> Callable[[List[TaskType]], None]:
    def update(answers: List[TaskType]) -> None:
        log(f"RECIPE: Updating model with {len(answers)} answers")
        examples = []
        for eg in answers:
            if eg["answer"] == "accept":
                doc = make_raw_doc(nlp, eg)
                ref = make_raw_doc(nlp, eg)
                doc.spans[key] = [
                    span
                    for span in (
                        doc.char_span(span["start"], span["end"], label=span["label"])
                        for span in eg.get("spans", [])
                    )
                    if span is not None
                ]
                examples.append(Example(doc, ref))
        nlp.update(examples)

    return update


def get_span_labels(
    nlp: Language, *, label: Optional[List[str]], component: str = "spancat"
) -> Tuple[List[str], str]:
    model_labels = nlp.pipe_labels.get(component, [])
    labels = get_pipe_labels(label, model_labels)
    pipe = cast("SpanCategorizer", nlp.get_pipe(component))
    key = pipe.key
    log(f"""RECIPE: Reading spans from key '{key}': doc.spans["{key}"]""")
    return labels, key


@recipe(
    "spans.model-annotate",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with an entity recognizer"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    model_alias=Arg(help="Annotator alias on behalf of the model"),
    labels=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    component=Arg("--component", "-c", help="Name of NER component in the pipeline"),
    # fmt: on
)
def spans_model_annotate(
    dataset: str,
    nlp: Language,
    source: Union[str, Iterable[dict]],
    model_alias: str,
    labels: Optional[List[str]] = None,
    loader: Optional[str] = None,
    component: str = "spancat",
) -> None:
    """
    Generates annotations directly via a model.
    """
    log("RECIPE: Starting recipe spans.model-annotate", locals())
    stream = get_stream(source, loader=loader, rehash=True, input_key="text")
    # TODO: Counting all the items in a stream might go awry for _huge_ files.
    #       We should come back to this later with a utility function
    total = sum(1 for _ in stream.copy())

    labels = resolve_labels(nlp, component, recipe_labels=labels)

    # If the dataset already exists we should make sure that there we don't add duplicates
    db = connect()
    if dataset in db.datasets:
        already_annotated = (
            ex
            for ex in db.iter_dataset_examples(dataset)
            if ex[ANNOTATOR_ID_ATTR] == model_alias
        )
        stream.apply(filter_seen_before, stream=stream, cache_stream=already_annotated)

    stream.apply(
        make_spancat_suggestions,
        stream=stream,
        nlp=nlp,
        component=component,
        labels=labels,
        show_progress_bar=True,
        progress_bar_total=total,
    )
    stream.apply(add_tokens, nlp=nlp, stream=stream)
    stream.apply(add_annot_name, name=model_alias)

    # we're adding view_id here to make sure we can compute IAA metrics
    # for the LLM annotations.
    # IAA metrics require that all annotations were completed with the same
    # view_id to ensure the consistency of annotation conditions.
    stream.apply(add_view_id, view_id="spans_manual")

    db = connect()
    # The "user" can also be seen as a session, so make sure we add that
    db.add_dataset(model_alias, session=True)
    # Write the examples to the dataset and session set
    db.add_examples(stream, [dataset, model_alias])
