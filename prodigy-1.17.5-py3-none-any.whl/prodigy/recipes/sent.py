import copy
from typing import List, Optional

from spacy.language import Language

from ..components.decorators import support_both_streams
from ..components.preprocess import add_tokens
from ..components.sorters import prefer_uncertain
from ..components.stream import get_stream
from ..core import Arg, recipe
from ..protocols import ControllerComponentsDict
from ..types import SourceType, StreamType
from ..util import (
    BINARY_ATTR,
    INPUT_HASH_ATTR,
    SENT_START_LABEL,
    ensure_component,
    log,
    set_hashes,
)
from .pos import get_update_binary, normalize_softmax_outputs, score_binary


@recipe(
    "sent.teach",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with a senter"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    # fmt: on
)
def teach(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    exclude: List[str] = [],
) -> ControllerComponentsDict:
    """
    Collect the best possible training data for a sentence recognizer
    model with the model in the loop. Based on your annotations, Prodigy will
    decide which questions to ask next.
    """
    log("RECIPE: Starting recipe sent.teach", locals())
    component = "senter"
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    labels = nlp.pipe_labels.get("senter", [])
    ensure_component(nlp, component)
    nlp = normalize_softmax_outputs(nlp, component)
    stream.apply(add_tokens, nlp=nlp, stream=stream)
    stream.apply(
        lambda d: prefer_uncertain(
            score_binary(nlp=nlp, stream=d, labels=labels, component=component),
            algorithm="probability",
        )
    )

    return {
        "view_id": "pos",
        "dataset": dataset,
        "stream": stream,
        "update": get_update_binary(nlp, component=component),
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
        },
    }


@recipe(
    "sent.correct",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline that sets sentence boundaries"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    # fmt: on,
)
def correct(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    exclude: List[str] = [],
) -> ControllerComponentsDict:
    """
    Create gold data for sentence boundaries by correcting a model's
    predictions.
    """
    log("RECIPE: Starting recipe sent.correct", locals())
    view_id = "pos_manual"
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )
    stream.apply(preprocess_stream, nlp=nlp)

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": [SENT_START_LABEL],
            "exclude_by": "input",
            "auto_count_stream": True,
            "allow_newline_highlight": True,
        },
    }


@support_both_streams(stream_arg="stream")
def preprocess_stream(stream: StreamType, nlp: Language) -> StreamType:
    """Add a 'spans' key to each example, with predicted tags."""
    spacy_model = f"{nlp.meta['lang']}_{nlp.meta['name']}"
    stream = add_tokens(nlp, stream)  # type: ignore
    texts = ((eg["text"], eg) for eg in stream)
    for doc, eg in nlp.pipe(texts, as_tuples=True, batch_size=10):
        task = copy.deepcopy(eg)
        spans = []
        for i, token in enumerate(doc):
            if token.is_sent_start:
                spans.append(
                    {
                        "token_start": i,
                        "token_end": i,
                        "start": token.idx,
                        "end": token.idx + len(token.text),
                        "text": token.text,
                        "label": SENT_START_LABEL,
                        "source": spacy_model,
                        "input_hash": eg[INPUT_HASH_ATTR],
                    }
                )
        task["spans"] = spans
        task[BINARY_ATTR] = False
        task = set_hashes(task)
        yield task
