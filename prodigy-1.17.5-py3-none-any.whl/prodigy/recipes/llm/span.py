from pathlib import Path
from typing import Iterable, List, Optional, Union

import srsly
from spacy.cli._util import parse_config_overrides
from spacy_llm.tasks import SpanCatTask
from spacy_llm.util import assemble

from ...components.db import connect
from ...components.filters import filter_seen_before
from ...components.preprocess import (
    add_answer,
    add_tokens,
    add_view_id,
    get_llm_task,
    make_spancat_suggestions,
    msg,
    resolve_labels,
)
from ...components.stream import _source_is_dataset, get_stream
from ...core import Arg, recipe
from ...protocols import ControllerComponentsDict
from ...util import DEFAULT_LLM_BATCH_SIZE, get_timestamp_session_id, log


@recipe(
    # fmt: off
    "spans.llm.correct",
    dataset=Arg(help="Dataset to save answers to"),
    config_path=Arg(help="Path to the spacy-llm config file"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    component=Arg("--component", "-c", help="Name of the component to use for annotation"),
    # fmt: on
)
def llm_correct_spans(
    dataset: str,
    config_path: Path,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    component: str = "llm",
    _extra: List[str] = [],
) -> ControllerComponentsDict:
    """
    Perform zero- or few-shot annotation with the aid of large language models.
    """
    log("RECIPE: Starting recipe spans.llm.correct", locals())
    config_overrides = parse_config_overrides(list(_extra)) if _extra else {}
    config_overrides[f"components.{component}.save_io"] = True
    # In case of API auth errors the following call to `assemble` will throw a UserWarning
    # rather than an Exception, which makes it hard for us to gracefully handle here.
    nlp = assemble(config_path, overrides=config_overrides)
    labels = resolve_labels(nlp, component)
    llm_task = get_llm_task(nlp, component)
    if not isinstance(llm_task, SpanCatTask):
        msg.fail(
            "Invalid spacy-llm Task Type for recipe 'ner.llm.correct'."
            f"Expected task type: {SpanCatTask}. "
            f"Provided task type: {type(llm_task)}. ",
            "Modify your spacy-llm config or use a different LLM recipe.",
            exits=1,
        )

    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
    )

    stream.apply(add_tokens, nlp=nlp, stream=stream)
    stream.apply(
        make_spancat_suggestions,
        nlp=nlp,
        component=component,
        labels=labels,
        batch_size=3,
    )

    return {
        "dataset": dataset,
        "view_id": "blocks",
        "stream": stream,
        "config": {
            "batch_size": DEFAULT_LLM_BATCH_SIZE,
            "labels": labels,
            "exclude_by": "input",
            "blocks": [
                {"view_id": "spans_manual"},
                {"view_id": "llm_io"},
            ],
        },
    }


@recipe(
    # fmt: off
    "spans.llm.fetch",
    config_path=Arg(help="Path to the spacy-llm config file"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    output=Arg(help="Dataset or file path to save the output to"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    component=Arg("--component", "-c", help="Name of the component to use for annotation"),
    resume=Arg("--resume", "-r", help="Resume fetch from the output file"),
    # fmt: on
)
def llm_fetch_spans(
    config_path: Path,
    source: Union[str, Iterable[dict]],
    output: Union[str, Path],
    loader: Optional[str] = None,
    resume: bool = False,
    component: str = "llm",
    _extra: List[str] = [],
) -> None:
    """Get bulk zero- or few-shot suggestions with the aid of a large language model

    This recipe allows you to get LLM queries upfront, which can help if you want
    multiple annotators or reduce the waiting time between API calls.
    """
    log("RECIPE: Starting recipe spans.llm.fetch", locals())
    config_overrides = parse_config_overrides(list(_extra)) if _extra else {}
    config_overrides[f"components.{component}.save_io"] = True
    # In case of API auth errors the following call to `assemble` will throw a UserWarning
    # rather than an Exception, which makes it hard for us to gracefully handle here.
    nlp = assemble(config_path, overrides=config_overrides)
    labels = resolve_labels(nlp, component)
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
    )

    stream.apply(add_tokens, nlp=nlp, stream=stream)

    if resume:
        msg.info(f"RECIPE: Resuming from previous output: {output}")
        resume_stream = get_stream(output)
        stream.apply(filter_seen_before, resume_stream)

    total = sum(1 for _ in stream.copy())
    stream.apply(
        make_spancat_suggestions,
        nlp=nlp,
        component=component,
        labels=labels,
        batch_size=DEFAULT_LLM_BATCH_SIZE,
        show_progress_bar=True,
        progress_bar_total=total,
    )
    # we're adding view_id here to make sure we can compute IAA metrics
    # for the LLM annotations.
    # IAA metrics require that all annotations were completed with the same
    # view_id to ensure the consistency of annotation conditions.
    stream.apply(add_view_id, view_id="spans_manual")
    stream.apply(add_answer, "accept")

    if _source_is_dataset(output, loader=None):
        dataset = str(output).replace("dataset:", "")
        msg.info(f"RECIPE: Writing fetched data to dataset: {dataset}")

        # Mocking the session_id as if done via Prodigy interface.
        session_id = get_timestamp_session_id()
        db = connect()
        if dataset not in db:
            db.add_dataset(dataset)
        db.add_dataset(session_id, session=True)
        db.add_examples(stream, datasets=[dataset])
    else:
        msg.info(f"RECIPE: Writing fetched data to local file: {output}")
        srsly.write_jsonl(output, stream)
