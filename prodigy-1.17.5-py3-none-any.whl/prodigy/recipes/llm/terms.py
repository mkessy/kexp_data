from pathlib import Path
from typing import List

import tqdm
from spacy.cli._util import parse_config_overrides
from spacy_llm.util import assemble

from ...components.db import connect
from ...components.llm import confirm_correct_task, terms_generator_task  # noqa
from ...core import Arg, recipe
from ...util import log, msg, set_hashes


@recipe(
    # fmt: off
    "terms.llm.fetch",
    dataset=Arg(help="Dataset to save annotations to"),
    config_path=Arg(help="Path to the spacy-llm config file"),
    topic=Arg(help="Description of the topic that you're interested in"),
    n_requests=Arg("--n-requests", "-r", help="Number of requests to send"),
    auto_accept=Arg("--auto-accept", "-a", help="Automatically accept all the examples"),
    component=Arg("--component", "-c", help="Name of the spacy-llm component that generates terms"),
    # fmt: on
)
def terms_llm_fetch(
    dataset: str,
    config_path: Path,
    topic: str,
    n_requests: int = 5,
    auto_accept: bool = False,
    component: str = "llm",
    _extra: List[str] = [],
) -> None:
    """Generate terms related to a topic using the spacy-llm component."""
    log("RECIPE: Starting recipe terms.llm.fetch", locals())
    # Validate the config file
    confirm_correct_task(config_path, "prodigy.Terms.v1")

    # Handle config parsing
    config_overrides = parse_config_overrides(list(_extra)) if _extra else {}
    nlp = assemble(config_path, overrides=config_overrides)
    config_overrides[f"components.{component}.save_io"] = True
    nlp.initialize()

    # Resume if need be
    terms = set()
    db = connect()
    if dataset in db:
        terms = set(ex["text"] for ex in db.get_dataset_examples(dataset))
        msg.info(f"Resuming from `{dataset}`. Total terms = {len(terms)}", spaced=True)

    # Initialize the progress bar to update description.
    pbar = tqdm.tqdm(range(n_requests), total=n_requests)
    for i in pbar:
        doc = nlp(topic)
        new_terms = set(doc._.terms).difference(terms)
        terms.update(new_terms)
        pbar.set_description(f"Made request {i + 1}. Total terms = {len(terms)}")
        stream = (
            set_hashes({"text": term, "meta": {"topic": topic}}) for term in new_terms
        )
        if auto_accept:
            stream = ({**ex, "answer": "accept"} for ex in stream)
        db.add_examples(stream, datasets=[dataset])
    msg.good(f"Found a total of {len(terms)} terms.", spaced=True)
