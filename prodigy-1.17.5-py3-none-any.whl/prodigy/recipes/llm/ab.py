import itertools as it
import random
import time
import warnings
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from statistics import NormalDist
from typing import Any, Dict, List, Optional, Union

import srsly
from jinja2 import DebugUndefined, Template
from spacy.language import Language
from spacy_llm.util import assemble_from_config, load_config

from ...components.db import connect
from ...components.llm import confirm_correct_task, textprompter_task  # noqa
from ...components.stream import Stream
from ...components.tournament import GlickoTournament
from ...core import Arg, recipe
from ...protocols import ControllerComponentsDict
from ...util import log, msg, set_hashes


@dataclass
class PromptConfigPair:
    template_path: Path
    config_path: Path
    template: Template
    nlp: Language

    def __str__(self):
        return f"[{self.template_path.name} + {self.config_path.name}]"

    def generate(self, **input_data):
        doc = self.nlp(self.template.render(**input_data))
        return doc._.response[0].strip()


def ensure_option_selected_when_accept(eg):
    if eg["answer"] == "accept":
        selected = eg.get("accept", [])
        assert len(selected) == 1, "You must select an example when accepting."


def load_template(path: Union[str, Path]) -> Template:
    if not isinstance(path, Path):
        path = Path(path)
    if not path.suffix == ".jinja2":
        msg.fail(
            "The --prompt-path (-p) parameter expects a .jinja2 file.",
            exits=1,
        )
    with path.open("r", encoding="utf8") as file_:
        text = file_.read()
    return Template(text, undefined=DebugUndefined)


def on_exit(self, ctrl):
    examples = ctrl.db.get_dataset_examples(ctrl.dataset)
    counts = Counter({k: 0 for k in self.prompts.keys()})
    # Get last example per ID
    for eg in examples:
        selected = eg.get("accept", [])
        if not selected or len(selected) != 1 or eg["answer"] != "accept":
            continue
        counts[selected[0]] += 1
    print("")  # noqa: T201
    if not counts:
        msg.warn("No answers found", exits=0)
    msg.divider("Evaluation results", icon="emoji")
    # Handle edge case when both are equal:
    nr1, nr2 = counts.most_common(2)
    if nr1[1] == nr2[1]:
        msg.good("It's a draw!")
    else:
        pref, _ = nr1
        msg.good(f"You preferred {pref}")
    rows = [(name, count) for name, count in counts.most_common()]
    msg.table(rows, aligns=("l", "r"))


def print_prob_table(t: GlickoTournament):
    win_order = t.top_k(k=len(t._ratings))
    first_name = win_order[0]
    first_mu, first_sigma = t._ratings[t._name2idx(first_name)]

    data = []
    for idx_other in range(1, len(win_order)):
        other_name = win_order[idx_other]
        other_mu, other_sigma = t._ratings[t._name2idx(other_name)]
        n_matches = sum(
            1
            for match in t.match_log
            if (first_name in match) and (other_name in match)
        )

        mu = other_mu - first_mu
        sigma = first_sigma + other_sigma

        data.append(
            [
                f"{first_name} > {other_name}",
                f"{round(NormalDist(mu=mu, sigma=sigma).cdf(0), 2):.2f}",
                f"{n_matches}",
            ]
        )
    msg.divider(f"Current winner: {first_name}")
    msg.table(
        data,
        header=("comparison", "prob", "trials"),
        aligns=("l", "r", "r"),
        max_col=100,
    )


@recipe(
    # fmt: off
    "ab.llm.tournament",
    dataset=Arg(help="Dataset to save answers to"),
    inputs_path=Arg(help="Path to jsonl inputs"),
    prompt_path=Arg(help="Path to path/folder with jinja2 prompt template(s)"),
    config_path=Arg(help="Path to path/folder with spacy-llm config(s)"),
    display_template_path=Arg("--display-template", "-dp", help="Template for summarizing the arguments"),
    no_random=Arg("--no-random", "-NR", help="Don't randomize the two options and sort them instead"),
    resume=Arg("--resume", "-r", help="Resume from the dataset, replaying the matches in them"),
    nometa=Arg("--no-meta", "-nm", help="Don't display the meta information at the bottom of the card"),
    # fmt: on
)
def llm_tournament(
    dataset: str,
    inputs_path: Path,
    prompt_path: Path,
    config_path: Path,
    display_template_path: Optional[Path] = None,
    no_random: bool = False,
    resume: bool = False,
    nometa: bool = False,
) -> ControllerComponentsDict:
    """
    A/B evaluation of LLM responses, for prompt engineering and/or optimal backend selection, comparing
    _many_ prompts and llm config files in a tournament.
    """
    db = connect()

    # The tournament might go on for a while, so we keep cycling here.
    # This is also a bit of an anti-pattern because we _want_ there to be
    # duplicates here. This is why we're not using a `Stream`
    inputs_cycle = it.cycle(srsly.read_jsonl(inputs_path))

    display = None
    if display_template_path:
        display = load_template(display_template_path)

    # The prompt path can be a folder or a Path to a single file.
    if prompt_path.is_dir():
        prompt_paths = list(prompt_path.glob("*.jinja2"))
    else:
        prompt_paths = [prompt_path]

    # The prompt path can be a folder or a Path to a single file.
    if config_path.is_dir():
        config_paths = list(config_path.glob("*.cfg"))
    else:
        config_paths = [config_path]

    n_combos = len(prompt_paths) * len(config_paths)
    if n_combos < 2:
        msg.fail(
            "You need to pass at least two prompts or at least two config files.",
            exits=True,
        )

    combos: Dict[str, PromptConfigPair] = {}
    for config_path in config_paths:
        # The task for this recipe is a bit of an anti-pattern for spacy-llm because
        # it doesn't really provide a prompt. This causes a prompt_template() warning,
        # which we'll skip for this recipe because it's not relevant for the user.
        warnings.filterwarnings(
            "ignore",
            message=".*prompt_template",
        )

        # First, we need to validate the config file
        confirm_correct_task(config_path, "prodigy.TextPrompter.v1")

        def remove_cache(config: Dict):
            """Turns off any BatchCache settings"""
            # Is there a cleaner way to do this? It feels like we have to
            # loop and assume something about the name.
            for comp_name, component in config["components"].items():
                for setting_name, settings in component.items():
                    if isinstance(settings, dict):
                        for key, value in settings.items():
                            if str(value).startswith("spacy.BatchCache"):
                                log(
                                    "RECIPE: Found cache setting in spaCy-LLM. Turning it off for this recipe."
                                )
                                settings["path"] = None

        # Ensure that the cache is turned off for this recipe.
        config = load_config(config_path)
        remove_cache(config)
        nlp = assemble_from_config(config)
        nlp.initialize()

        # Generate the config/prompt pairs
        for template_path in prompt_paths:
            pair = PromptConfigPair(
                template_path=template_path,
                config_path=config_path,
                template=load_template(template_path),
                nlp=nlp,
            )
            combos[str(pair)] = pair

    tournament = GlickoTournament(options=list(combos.keys()))

    def update(examples: List[Dict], show_table=True) -> None:
        """To update the stream, the internal tournament needs to be updated."""
        for ex in examples:
            # It's technically possible to accept the answer without actually selecting an item.
            if (ex["answer"] == "accept") and ex["accept"]:
                option_a = ex["options"][0]["id"]
                option_b = ex["options"][1]["id"]
                winner_idx = ex["accept"][0]
                tournament.update(
                    name_i=option_a, name_j=option_b, outcome=option_a == winner_idx
                )
        if show_table:
            print_prob_table(t=tournament)

    if resume:
        log("RECIPE: About to replay tournament by resuming from dataset")
        # Replay all items where both candidates appear in current prompt-set.
        if dataset in db.datasets:
            for ex in db.get_dataset_examples(dataset):
                p1 = ex["options"][0]["id"]
                p2 = ex["options"][1]["id"]
                if (p1 in combos) and (p2 in combos):
                    update([ex], show_table=False)
        print_prob_table(t=tournament)

    def make_stream(inputs):
        for input_data in inputs:
            log("RECIPE: Generating new candidates.")
            tic = time.time()
            name1, name2 = tournament.top_k()
            log(f"RECIPE: Picked {name1} and {name2}.")
            candidate1 = combos[name1]
            candidate2 = combos[name2]
            eg: Dict[str, Any] = {
                "options": [
                    {"id": name1, "text": candidate1.generate(**input_data)},
                    {"id": name2, "text": candidate2.generate(**input_data)},
                ]
            }
            if display:
                eg["text"] = display.render(**input_data)
            if not no_random:
                random.shuffle(eg["options"])
            if not nometa:
                eg["meta"] = input_data
            toc = time.time()
            log(f"RECIPE: Candidate generation took {toc - tic}s.")
            yield set_hashes(eg)

    return {
        "dataset": dataset,
        "view_id": "choice",
        "stream": Stream.from_iterable(make_stream(inputs_cycle)),
        "update": update,
        "validate_answer": ensure_option_selected_when_accept,
        "config": {
            "batch_size": 1,
            "choice_auto_accept": True,
            "exclude_by": "input",
            "global_css": ".prodigy-content{line-height: 1.2;};",
        },
    }
