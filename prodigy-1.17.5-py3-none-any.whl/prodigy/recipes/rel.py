import copy
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple, Union

import srsly
from spacy.language import Language
from spacy.tokens import Doc, Span, Token
from spacy.util import filter_spans

from ..components.stream import get_stream
from ..core import Arg, recipe
from ..errors import RecipeError
from ..models.matcher import (
    create_matcher,
    create_phrase_matcher,
    parse_pattern_name,
    parse_patterns,
)
from ..protocols import ControllerComponentsDict
from ..types import (
    ExistingFilePath,
    LabelsType,
    SourceType,
    StreamType,
)
from ..util import log, msg

NP_LABEL = "NP"
PATTERN_LABEL = "PATTERN"
TOKEN_LIMIT = 300
MatcherType = Callable[[Doc], List[Tuple[int, int, int]]]


@recipe(
    "rel.manual",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline or blank:lang (e.g. blank:en)"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated relation label(s) to annotate or text file with one label per line"),
    span_label=Arg("--span-label", "-sl", help="Comma-separated span label(s) to annotate or text file with one label per line"),
    patterns_path=Arg("--patterns", "-pt", help="Patterns file for defining custom spans to be added"),
    disable_patterns_path=Arg("--disable-patterns", "-dpt", help="Patterns file for defining tokens to disable (make unselectable)"),
    add_ents=Arg("--add-ents", "-AE", help="Add entities predicted by the model"),
    add_nps=Arg("--add-nps", "-AN", help="Add noun phrases (if noun chunks rules are available), based on tagger and parser"),
    wrap=Arg("--wrap", "-W", help="Wrap lines in the UI by default (instead of showing tokens in one row)"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    hide_arrow_heads=Arg("--hide-arrow-heads", "-HA", help="Hide the arrow heads visually"),
    # fmt: on
)
def manual(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    span_label: Optional[LabelsType] = None,
    exclude: List[str] = [],
    patterns_path: Union[ExistingFilePath, List[Dict[str, Any]], None] = None,
    disable_patterns_path: Union[ExistingFilePath, List[Dict[str, Any]], None] = None,
    add_ents: bool = False,
    add_nps: bool = False,
    wrap: bool = False,
    hide_arrow_heads: bool = False,
) -> ControllerComponentsDict:
    """Annotate relationships between words and spans of text."""
    log("RECIPE: Starting recipe rel.manual", locals())
    view_id = "relations"
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        is_binary=False,
        view_id=view_id,
    )
    check_nlp(nlp, add_ents=add_ents, add_nps=add_nps)
    if add_nps and span_label and NP_LABEL not in span_label:
        # Add NP label if we know we need it and user hasn't set it
        span_label.append(NP_LABEL)
    # Set up combined token/phrase matchers with additional merge and disable patterns
    matcher, patterns = setup_matchers(nlp, patterns_path)
    disable_matcher, disable_patterns = setup_matchers(nlp, disable_patterns_path)
    stream = stream.apply(
        preprocess_stream,
        stream,
        nlp,
        matcher=matcher if patterns else None,
        disable_matcher=disable_matcher if disable_patterns else None,
        span_label=span_label,
        add_nps=add_nps,
        add_ents=add_ents,
    )
    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": label,
            "relations_span_labels": span_label,
            "exclude_by": "input",
            "wrap_relations": wrap,
            "custom_theme": {"cardMaxWidth": "90%"},
            "hide_relations_arrow": hide_arrow_heads,
            "auto_count_stream": True,
        },
    }


def setup_spans(
    spans: Iterable[Span],
    span_label: Optional[List[str]],
    span_type: str,
    default_label: Optional[str] = None,
) -> List[Span]:
    result = []
    for span in spans:
        all_labels = [*span_label, NP_LABEL] if span_label else [NP_LABEL]
        if span_type == "pattern":
            new_label, _ = parse_pattern_name(span.label_)
        else:
            new_label = span.label_ or default_label or span_type.upper()
        if span_label is not None and new_label not in all_labels:
            continue
        span._.type = span_type
        span._.label = new_label
        # Set token attributes so they can be targeted by disable patterns
        for token in span:
            token._.label = new_label
            token._.type = span_type
        result.append(span)
    return result


def preprocess_stream(
    stream: StreamType,
    nlp: Language,
    *,
    matcher: Optional[MatcherType],
    disable_matcher: Optional[MatcherType],
    span_label: Optional[List[str]],
    add_nps: bool,
    add_ents: bool,
) -> StreamType:
    # Register token extensions to store info about the spans/tokens
    Span.set_extension("type", default=None, force=True)
    Span.set_extension("label", default=None, force=True)
    Token.set_extension("type", default=None, force=True)
    # we need the label default value to be a string so that it is not ignored by Matcher
    Token.set_extension("label", default="None", force=True)
    Token.set_extension("disabled", default=False, force=True)
    # Adding tokens manually instead of using the full add_tokens wrapper
    # so we have more control over the Doc preprocessing
    data_tuples = ((eg["text"], copy.deepcopy(eg)) for eg in stream)
    warned = False
    for doc, eg in nlp.pipe(data_tuples, as_tuples=True, batch_size=10):
        # If we have pre-defined tokens in the examples, use those to
        # construct a Doc manually
        if "tokens" in eg:
            words = [token["text"] for token in eg["tokens"]]
            spaces = [token.get("ws", True) for token in eg["tokens"]]
            doc = Doc(nlp.vocab, words=words, spaces=spaces)
            for i, token in enumerate(eg["tokens"]):
                if token.get("disabled"):
                    doc[i]._.disabled = True
        if len(doc) >= TOKEN_LIMIT and not warned:
            msg.warn(
                f"Long example with {len(doc)} tokens detected. This can "
                f"potentially lead to slower rendering and annotation in "
                f"the web app. Consider splitting your texts into smaller "
                f"chunks or sentences."
            )
            warned = True
        matches = matcher(doc) if matcher else []
        spans = []
        n_skipped = 0
        curr_spans = []  # "spans" already present in input data
        for s in eg.get("spans", []):
            c_span = doc.char_span(s["start"], s["end"], s["label"])
            if c_span:
                curr_spans.append(c_span)
            else:
                n_skipped += 1
        spans.extend(setup_spans(curr_spans, span_label, "span"))
        if add_nps:
            spans.extend(setup_spans(doc.noun_chunks, span_label, "np", NP_LABEL))
        if add_ents:
            spans.extend(setup_spans(doc.ents, span_label, "ent"))
        match_spans = [Span(doc, s, e, match_id) for match_id, s, e in matches]
        spans.extend(setup_spans(match_spans, span_label, "pattern", PATTERN_LABEL))
        all_spans = []
        for span in filter_spans(spans):
            span_obj = {
                "text": span.text,
                "start": span.start_char,
                "token_start": span.start,
                "token_end": span.end - 1,
                "end": span.end_char,
                "type": span._.type,
                "label": span._.label,
            }
            all_spans.append(span_obj)
        eg["spans"] = all_spans
        if n_skipped > 0:
            msg.warn(
                f"Skipped {n_skipped} span(s) that were already present "
                f"in the input data because the tokenization didn't match."
            )
        # Apply the disable patterns last, so they can use the information of the merge patterns
        disable_matches = disable_matcher(doc) if disable_matcher else []
        for _, start, end in disable_matches:
            for token in doc[start:end]:
                token._.disabled = True
        tokens = []
        for i, token in enumerate(doc):
            token = {
                "text": token.text,
                "start": token.idx,
                "end": token.idx + len(token.text),
                "id": i,
                "ws": bool(token.whitespace_),
                "disabled": token._.disabled,
            }
            tokens.append(token)
        eg["tokens"] = tokens
        yield eg


def check_nlp(nlp: Language, *, add_ents: bool, add_nps: bool) -> None:
    spacy_model = f"{nlp.meta['lang']}_{nlp.meta['name']}"
    # fmt: off
    if add_ents and "ner" not in nlp.pipe_names:
        msg.warn(
            "Adding entities typically requires a named entity recognizer, "
            f"but no 'ner' component was found in the pipeline of model '{spacy_model}'."
        )
    if add_nps and ("parser" not in nlp.pipe_names or "tagger" not in nlp.pipe_names):
        msg.warn(
            "Adding noun phrases typically requires a tagger and parser. "
            f"One or both weren't found in the pipeline of model '{spacy_model}'."
        )
    if add_nps and "noun_chunks" not in nlp.Defaults.syntax_iterators:
        msg.warn(
            "Adding noun phrases requires noun chunk rules in the "
            f"language data, but none were for language '{nlp.lang}'. "
            "To specify your own merge rules, you can use the --merge-patterns argument."
        )
    # fmt: on


def setup_matchers(
    nlp: Language,
    source_patterns: Optional[Union[ExistingFilePath, List[Dict[str, Any]]]],
    default_label: str = PATTERN_LABEL,
) -> Tuple[MatcherType, List[Dict[str, Any]]]:
    if source_patterns is None:
        patterns = []
    elif source_patterns and isinstance(source_patterns, (str, Path)):
        patterns = srsly.read_jsonl(source_patterns)
    else:
        patterns = source_patterns
    final_patterns = []
    for pattern in patterns:
        if not isinstance(pattern, dict) or "pattern" not in pattern:
            raise RecipeError(
                "Invalid pattern found. Patterns should be dicts with a key"
                '"pattern" and an optional "label".',
                pattern,
            )
        # TODO: should we assume that the user always want to use all patterns
        # and pattern matches? It's different from how the other recipes behave
        # but it could lead to confusion if users forget to include pattern
        # labels in --span-label
        if "label" not in pattern:
            pattern["label"] = default_label
        final_patterns.append(pattern)
    token_patterns, phrase_patterns, _ = parse_patterns(final_patterns)
    matcher = create_matcher(nlp, token_patterns)
    phrase_matcher = create_phrase_matcher(nlp, phrase_patterns)

    def combined_matcher(doc):
        matches = matcher(doc)
        phrase_matches = phrase_matcher(doc)
        return matches + phrase_matches

    return combined_matcher, final_patterns
