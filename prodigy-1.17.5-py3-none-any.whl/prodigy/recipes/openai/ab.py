# pyright: reportUndefinedVariable=false, reportGeneralTypeIssues=false
import itertools as it
from math import erf, sqrt
from pathlib import Path
from typing import Dict, List, cast

import srsly

from ...components.db import connect
from ...components.openai import (
    OpenAIPromptAB,
    PromptInput,
    get_api_credentials,
    load_template,
)
from ...components.tournament import GlickoTournament
from ...core import recipe
from ...util import log, msg


def ensure_option_selected_when_accept(eg):
    if eg["answer"] == "accept":
        selected = eg.get("accept", [])
        assert len(selected) == 1, "You must select an example when accepting."


@recipe(
    # fmt: off
    "ab.openai.prompts",
    dataset=("Dataset to save answers to", "positional", None, str),
    inputs_path=("Path to jsonl inputs", "positional", None, Path),
    display_template_path=("Template for summarizing the arguments", "positional", None, Path),
    prompt1_template_path=("Path to the first jinja2 prompt template", "positional", None, Path),
    prompt2_template_path=("Path to the second jinja2 prompt template", "positional", None, Path),
    model=("GPT-3 model to use for responses", "option", "m", str),
    batch_size=("Batch size to send to OpenAI API", "option", "b", int),
    temperature=("Temperature between 0 and 1 that controls GPT-3's randomness", "option", "t", float),
    verbose=("Print extra information to terminal", "flag", "v", bool),
    no_random=("Don't randomize which annotation is shown as correct", "flag", "NR", bool,),
    repeat=("How often to send the same prompt to OpenAI", "option", "r", int),
    nometa=("Don't display the meta information at the bottom of the card", "flag", "nm", bool,),
    # fmt: on
)
def openai_prompts(
    dataset: str,
    inputs_path: Path,
    display_template_path: Path,
    prompt1_template_path: Path,
    prompt2_template_path: Path,
    model: str = "text-davinci-003",
    batch_size: int = 10,
    temperature: float = 0.9,
    verbose: bool = False,
    no_random: bool = False,
    repeat: int = 1,
    nometa: bool = False,
):
    """
    A/B evaluation of OpenAI responses, for prompt engineering.

    A/B evaluation is basically a blind "taste test". Results are produced
    from two experimental conditions (in this case, responses from two
    prompts). The annotator is shown the response pair, without knowing which
    condition produced which response. The annotator marks which one is better,
    and the response is recorded.

    At the end of annotation, the results are tallied up, so you can see whether
    one condition produces better results than the other. This lets you apply
    a sound methodology to subjective decisions.
    """
    msg.warn(
        "The `ab.openai.prompts` recipe is deprecated and will be removed in Prodigy v2. "
        "To ensure continued support and improved functionality we recommend using the `ab.llm.tournament` recipe instead: "
        "https://prodi.gy/docs/recipes/#ab.llm.tournament. "
        "Please refer to our docs for more details: https://prodi.gy/docs/large-language-models#how"
    )
    api_key, api_org = get_api_credentials(model)
    inputs = [PromptInput(**x) for x in cast(List[Dict], srsly.read_jsonl(inputs_path))]

    display = load_template(display_template_path)
    prompt1 = load_template(prompt1_template_path)
    prompt2 = load_template(prompt2_template_path)
    stream = OpenAIPromptAB(
        display=display,
        prompts={
            prompt1_template_path.name: prompt1,
            prompt2_template_path.name: prompt2,
        },
        inputs=inputs,
        openai_api_org=api_org,
        openai_api_key=api_key,
        openai_model=model,
        batch_size=batch_size,
        verbose=verbose,
        randomize=not no_random,
        openai_temperature=temperature,
        repeat=repeat,
        show_meta=not nometa,
    )

    return {
        "dataset": dataset,
        "view_id": "choice",
        "stream": stream,
        "on_exit": stream.on_exit,
        "validate_answer": ensure_option_selected_when_accept,
        "config": {
            "batch_size": batch_size,
            "choice_auto_accept": True,
            "exclude_by": "input",
            "global_css": ".prodigy-content{line-height: 1.2;};",
        },
    }


class NormalDist:
    """Normal distribution of a random variable.

    Vendored from Python3.8's statistics module. This object can be
    dropped when we drop support for Python3.7.
    """

    __slots__ = {
        "_mu": "Arithmetic mean of a normal distribution",
        "_sigma": "Standard deviation of a normal distribution",
    }

    def __init__(self, mu=0.0, sigma=1.0):
        "NormalDist where mu is the mean and sigma is the standard deviation."
        if sigma < 0.0:
            raise ValueError("sigma must be non-negative")
        self._mu = float(mu)
        self._sigma = float(sigma)

    def cdf(self, x):
        "Cumulative distribution function.  P(X <= x)"
        if not self._sigma:
            raise ValueError("cdf() not defined when sigma is zero")
        return 0.5 * (1.0 + erf((x - self._mu) / (self._sigma * sqrt(2.0))))


@recipe(
    # fmt: off
    "ab.openai.tournament",
    dataset=("Dataset to save answers to", "positional", None, str),
    inputs_path=("Path to jsonl inputs", "positional", None, Path),
    display_template_path=("Template for summarizing the arguments", "positional", None, Path),
    prompt_template_folder=("Path to folder with jinja2 prompt template", "positional", None, Path),
    model=("GPT-3 model to use for responses", "option", "m", str),
    batch_size=("Batch size to send to OpenAI API", "option", "b", int),
    temperature=("Temperature between 0 and 1 that controls GPT-3's randomness", "option", "t", float),
    verbose=("Print extra information to terminal", "flag", "v", bool),
    no_random=("Don't randomize which annotation is shown as correct", "flag", "NR", bool,),
    resume=("Resume from the dataset, replaying the matches in them", "flag", "r", bool,),
    nometa=("Don't display the meta information at the bottom of the card", "flag", "nm", bool,),
    # fmt: on
)
def openai_tournament(
    dataset: str,
    inputs_path: Path,
    display_template_path: Path,
    prompt_template_folder: Path,
    model: str = "text-davinci-003",
    batch_size: int = 1,
    temperature: float = 0.9,
    verbose: bool = False,
    no_random: bool = False,
    resume: bool = False,
    nometa: bool = False,
):
    """
    A/B evaluation of OpenAI responses, for prompt engineering, comparing
    _many_ prompts in a tournament.
    """
    msg.warn(
        "The `ab.openai.tournament` recipe is deprecated and will be removed in Prodigy v2. "
        "To ensure continued support and improved functionality we recommend using the `ab.llm.tournament` recipe instead: "
        "https://prodi.gy/docs/recipes/#ab.llm.tournament. "
        "Please refer to our docs for more details: https://prodi.gy/docs/large-language-models#how"
    )
    db = connect()
    api_key, api_org = get_api_credentials(model)

    # The tournament might go on for a while, so we keep cycling here.
    inputs = it.cycle(
        [PromptInput(**x) for x in cast(List[Dict], srsly.read_jsonl(inputs_path))]
    )

    display = load_template(display_template_path)
    prompts = {
        p.name: load_template(p) for p in prompt_template_folder.glob("*.jinja2")
    }

    if len(prompts) < 2:
        msg.fail(
            f"You need to pass at least two prompts. Found only {len(prompts)} in {prompt_template_folder}.",
            exits=True,
        )

    tournament = GlickoTournament(options=list(prompts.keys()))
    stream = OpenAIPromptAB(
        display=display,
        prompts=prompts,
        inputs=inputs,
        openai_api_org=api_org,
        openai_api_key=api_key,
        openai_model=model,
        batch_size=batch_size,
        verbose=verbose,
        randomize=not no_random,
        openai_temperature=temperature,
        repeat=1,  # The stream already cycles, so repeat can be 1
        tournament=tournament,
        show_meta=not nometa,
    )

    def print_prob_table(t: GlickoTournament):
        win_order = t.top_k(k=len(t._ratings))
        first_name = win_order[0]
        first_mu, first_sigma = t._ratings[t._name2idx(first_name)]

        data = []
        for idx_other in range(1, len(win_order)):
            other_name = win_order[idx_other]
            other_mu, other_sigma = t._ratings[t._name2idx(other_name)]
            n_matches = sum(
                1
                for match in t.match_log
                if (first_name in match) and (other_name in match)
            )

            mu = other_mu - first_mu
            sigma = first_sigma + other_sigma

            data.append(
                [
                    f"P({first_name} > {other_name})",
                    f"{round(NormalDist(mu=mu, sigma=sigma).cdf(0), 2):.2f}",
                    f"{n_matches}",
                ]
            )
        msg.divider(f"Current winner: {first_name}")
        msg.table(
            data,
            header=("comparison", "prob", "trials"),
            aligns=("l", "r", "r"),
            max_col=100,
        )

    if resume:
        log("RECIPE: About to replay tournament by resuming from dataset")
        # Replay all items where both candidates appear in current prompt-set.
        if dataset in db.datasets:
            for ex in db.get_dataset_examples(dataset):
                p1 = ex["options"][0]["id"]
                p2 = ex["options"][1]["id"]
                if (p1 in prompts) and (p2 in prompts):
                    stream.update([ex])

    def update(examples):
        stream.update(examples=examples)
        print_prob_table(t=tournament)

    return {
        "dataset": dataset,
        "view_id": "choice",
        "stream": stream,
        "update": update,
        "validate_answer": ensure_option_selected_when_accept,
        "config": {
            "batch_size": batch_size,
            "choice_auto_accept": True,
            "exclude_by": "input",
            "global_css": ".prodigy-content{line-height: 1.2;};",
        },
    }
