# pyright: reportUndefinedVariable=false, reportGeneralTypeIssues=false, reportOptionalMemberAccess=false, reportOptionalIterable=false, reportPrivateImportUsage=false, reportUnboundVariable=false, reportOptionalSubscript=false
from functools import reduce
from pathlib import Path
from typing import List

import requests
import srsly
from tqdm import tqdm

from ...components.openai import get_api_credentials, load_template, retry
from ...core import recipe
from ...util import OPENAI_DEFAULTS, log, msg


@recipe(
    # fmt: off
    "terms.openai.fetch",
    query=("Query to send to OpenAI", "positional", None, str),
    output_path=("Path to save the output", "positional", None, Path),
    seeds=("One or more comma-seperated seed phrases.", "option", "s", lambda d: d.split(",")),
    n=("The minimum number of items to generate", "option", "n", int),
    model=("GPT-3 model to use for completion", "option", "m", str),
    prompt_path=("Path to jinja2 prompt template", "option", "p", Path),
    resume=("Resume by loading in text examples from output file.", "flag", "r", bool),
    temperature=("OpenAI temperature param", "option", "t", float),
    top_p=("OpenAI top_p param", "option", "tp", float),
    best_of=("OpenAI best_of param", "option", "bo", int),
    n_batch=("OpenAI batch size param", "option", "nb", int),
    max_tokens=("Max tokens to generate per call", "option", "mt", int),
    # fmt: on
)
def openai_fetch_terms(
    query: str,
    output_path: Path,
    seeds: List[str] = [],
    n: int = 100,
    model: str = "text-davinci-003",
    prompt_path: Path = OPENAI_DEFAULTS.TERMS_PROMPT_PATH,
    resume: bool = False,
    temperature=1.0,
    top_p=1.0,
    best_of=10,
    n_batch=10,
    max_tokens=100,
):
    """Get bulk term suggestions from the OpenAI API, using zero-shot learning.

    The results can then be corrected using the `prodigy textcat.manual` recipe and
    turned into patterns via `prodigy terms.to-patterns`.
    """
    log("RECIPE: Starting recipe terms.openai.fetch", locals())
    msg.warn(
        "The `terms.openai.fetch` recipe is deprecated and will be removed in Prodigy v2. "
        "To ensure continued support and improved functionality we recommend using the `ner.llm.correct` recipe instead: "
        "https://prodi.gy/docs/recipes/#terms.llm.fetch. "
        "Please refer to our docs for more details: https://prodi.gy/docs/large-language-models#how"
    )
    template = load_template(prompt_path)
    # The `best_of` param cannot be less than the amount we batch.
    if best_of < n_batch:
        best_of = n_batch

    # Start collection of terms. If we resume we also fill seed terms with file
    # contents.
    terms = []
    if resume:
        if output_path.exists():
            examples = srsly.read_jsonl(output_path)
            terms.extend([e["text"] for e in examples])

    # Mimic behavior from Prodigy terms recipe to ensure that seed terms also
    # appear in output
    for seed in seeds:
        if seed not in terms:
            srsly.write_jsonl(
                output_path,
                [{"text": seed, "meta": {"openai_query": query}}],
                append=True,
                append_new_line=False,
            )

    # Ensure we have access to correct environment variables and construct
    # headers
    api_key, api_org = get_api_credentials(model)
    headers = {
        "Authorization": f"Bearer {api_key}",
        "OpenAI-Organization": api_org,
        "Content-Type": "application/json",
    }

    # This recipe may overshoot the target, but we keep going until we have at
    # least `n`
    pbar = tqdm(total=n)
    while len(terms) < n:
        prompt = template.render(n=n, examples=seeds + terms, query=query)
        log("Prompt to OpenAI", details=prompt)

        resp = retry(
            lambda: requests.post(
                OPENAI_DEFAULTS.COMPLETIONS_ENDPOINT,
                headers=headers,
                json={
                    "model": model,
                    "prompt": [prompt],
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    "top_p": top_p,
                    "n": min(n_batch, best_of),
                    "best_of": best_of,
                },
                timeout=45,
            ),
            n=1,
            timeout_s=30,
        )

        # Report on any other error that might happen, the most typical use-case
        # is catching the maximum context length of 4097 tokens when the prompt
        # gets big.
        if resp.status_code != 200:
            msg.fail(
                f"Received status code {resp.status_code} from OpenAI: {resp.reason}",
                exits=1,
            )

        # Cast to a set to make sure we remove duplicates
        choices = resp.json()["choices"]
        sets_of_terms = [set(_parse_terms(c["text"])) for c in choices]
        parsed_terms = list(reduce(lambda a, b: a.union(b), sets_of_terms))

        # Save intermediate results into file, in-case of a hiccup
        srsly.write_jsonl(
            output_path,
            [{"text": t, "meta": {"openai_query": query}} for t in parsed_terms],
            append=True,
            append_new_line=False,
        )

        # Make the terms list bigger and re-use terms in next prompt.
        terms.extend(parsed_terms)
        pbar.update(len(terms))
    pbar.close()


def _parse_terms(completion: str) -> List[str]:
    if "\n" not in completion:
        # Sometimes it only returns a single item. For example, when there are
        # many, many seeds around.
        lines = [completion]
    else:
        # Other times we cannot assume the final item will have had sufficient
        # tokens available to complete the term, so we have to discard it.
        lines = [item for item in completion.split("\n") if len(item)]
        lines = lines[:-1]
    return [item.replace("-", "").strip() for item in lines]
