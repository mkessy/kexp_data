# pyright: reportUndefinedVariable=false, reportGeneralTypeIssues=false
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Union
from typing_extensions import Self

import spacy
import srsly
from tqdm import tqdm

from ...components.openai import (
    GLOBAL_STYLE,
    OpenAISuggester,
    PromptExample,
    ResponseParserProtocol,
    get_api_credentials,
    get_resume_stream,
    load_template,
    normalize_label,
    read_prompt_examples,
)
from ...components.preprocess import add_view_id
from ...components.stream import get_stream
from ...core import recipe
from ...types import StreamType, TaskType
from ...util import OPENAI_DEFAULTS, log, msg


@dataclass
class TextCatPromptExample(PromptExample):
    """An example to be passed into an OpenAI TextCat prompt."""

    text: str
    answer: str
    reason: str

    @classmethod
    def from_prodigy(cls, example: Dict[str, Any], labels: List[str]) -> Self:
        """Create a prompt example from Prodigy's format."""
        if "text" not in example:
            raise ValueError("Cannot make PromptExample without text")

        full_text = example["text"]
        reason = example["meta"].get("reason")
        if len(labels) == 1:
            answer = example.get("answer", "reject")
        else:
            answer = ",".join(example.get("accept", []))
        return cls(text=full_text, answer=answer, reason=reason)


def make_textcat_response_parser(labels: List[str]) -> ResponseParserProtocol:
    def _parse_response(
        text: str, example: Optional[TaskType] = None
    ) -> Dict[str, Any]:
        output: Dict[str, str] = {}
        if text and any(k in text.lower() for k in ("answer", "reason")):
            for line in text.strip().split("\n"):
                if line and ":" in line:
                    key, value = line.split(":", 1)
                    # To make parsing easier, we normalize the answer returned by
                    # OpenAI (lower-case). We also normalize the labels so that we
                    # can match easily.
                    output[key.strip().lower()] = normalize_label(value.strip())
        else:
            output = {"answer": "", "reason": ""}

        example = _fmt_binary(output) if len(labels) == 1 else _fmt_multi(output)
        return example

    def _fmt_binary(response: Dict[str, str]) -> Dict:
        """Parse binary TextCat where the 'answer' key means it's a positive class."""
        return {
            "answer": response["answer"].lower(),
            "label": labels[0],
            "meta": {
                "answer": response["answer"].upper(),
                "reason": response["reason"],
            },
        }

    def _fmt_multi(response: Dict[str, str]) -> Dict:
        """Parse multilabel TextCat where the 'accept' key is a list of positive labels."""
        return {
            "options": [{"id": label, "text": label} for label in labels],
            "answer": "accept",
            "meta": {
                "reason": response.get("reason", ""),
                "GPT-3_answer": response.get("answer", ""),
            },
            "accept": list(
                filter(None, [s.strip() for s in response["answer"].split(",")])
            ),
        }

    return _parse_response


@recipe(
    # fmt: off
    "textcat.openai.correct",
    dataset=("Dataset to save answers to", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    labels=("Labels (comma delimited)", "option", "L", lambda s: s.split(",")),
    lang=("Language to initialize spaCy model", "option", "l", str),
    model=("GPT-3 model to use for completion", "option", "m", str),
    batch_size=("Batch size to send to OpenAI API", "option", "b", int),
    segment=("Split sentences", "flag", "S", bool),
    prompt_path=("Path to the .jinja2 prompt template", "option", "p", Path),
    examples_path=("Examples file to help define the task", "option", "e", Path),
    max_examples=("Max examples to include in prompt", "option", "n", int),
    exclusive_classes=("Make the classification task exclusive", "flag", "E", bool),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    verbose=("Print extra information to terminal", "flag", "v", bool),
    # fmt: on
)
def openai_correct_textcat(
    dataset: str,
    source: Union[str, Iterable[dict]],
    labels: List[str],
    lang: str = "en",
    model: str = "text-davinci-003",
    batch_size: int = 10,
    segment: bool = False,
    prompt_path: Path = OPENAI_DEFAULTS.TEXTCAT_PROMPT_PATH,
    examples_path: Optional[Path] = None,
    max_examples: int = 2,
    exclusive_classes: bool = False,
    loader: Optional[str] = None,
    verbose: bool = False,
):
    """
    Perform zero- or few-shot annotation with the aid of GPT-3. Prodigy will
    infer binary or multilabel classification based on the number of labels in
    --labels. You can also set the -E flag to make the classification task exclusive.
    """
    msg.warn(
        "The `textcat.openai.correct` recipe is deprecated and will be removed in Prodigy v2. "
        "To ensure continued support and improved functionality we recommend using the `textcat.llm.correct` recipe instead: "
        "https://prodi.gy/docs/recipes/#textcat-llm.correct. "
        "Please refer to our docs for more details: https://prodi.gy/docs/large-language-models#how"
    )
    log("RECIPE: Starting recipe textcat.openai.correct", locals())
    api_key, api_org = get_api_credentials(model)
    examples = read_prompt_examples(examples_path, example_class=TextCatPromptExample)
    nlp = spacy.blank(lang)

    if segment:
        nlp.add_pipe("sentencizer")

    if not labels:
        msg.fail("No --labels argument set", exits=1)
    msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")

    if not exclusive_classes and len(labels) == 1:
        msg.warn(
            "Binary classification should always be exclusive. Setting "
            "`exclusive_classes` parameter to True"
        )
        exclusive_classes = True

    labels = [normalize_label(label) for label in labels]

    # Create OpenAISuggester with GPT-3 parameters
    openai = OpenAISuggester(
        response_parser=make_textcat_response_parser(labels=labels),
        prompt_template=load_template(prompt_path),
        labels=labels,
        max_examples=max_examples,
        segment=segment,
        openai_api_org=api_org,
        openai_api_key=api_key,
        openai_n=1,
        openai_model=model,
        openai_retry_timeout_s=10,
        openai_read_timeout_s=20,
        openai_n_retries=10,
        render_vars={"exclusive_classes": exclusive_classes},
        prompt_example_class=TextCatPromptExample,
        verbose=verbose,
    )
    for eg in examples:
        openai.add_example(eg)

    # Set up the stream
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )

    def to_stream(stream: StreamType, batch_size, nlp):
        for ex in openai(stream, batch_size=batch_size, nlp=nlp):
            yield ex

    stream.apply(to_stream, batch_size=batch_size, nlp=nlp)

    # Set up the Prodigy UI
    return {
        "dataset": dataset,
        "view_id": "blocks",
        "stream": stream,
        "update": openai.update,
        "config": {
            "labels": openai.labels,
            "batch_size": batch_size,
            "exclude_by": "input",
            "choice_style": "single" if exclusive_classes else "multiple",
            "blocks": [
                {"view_id": "classification" if len(labels) == 1 else "choice"},
                {
                    "view_id": "html",
                    "html_template": OPENAI_DEFAULTS.TEXTCAT_HTML_TEMPLATE,
                },
            ],
            "show_flag": True,
            "global_css": GLOBAL_STYLE,
        },
    }


@recipe(
    # fmt: off
    "textcat.openai.fetch",
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    output_path=("Path to save the output", "positional", None, Path),
    labels=("Labels (comma delimited)", "option", "L", lambda s: s.split(",")),
    lang=("Language to use for tokenizer.", "option", "l", str),
    model=("GPT-3 model to use for completion", "option", "m", str),
    prompt_path=("Path to jinja2 prompt template", "option", "p", Path),
    examples_path=("Examples file to help define the task", "option", "e", Path),
    max_examples=("Max examples to include in prompt", "option", "n", int),
    batch_size=("Batch size to send to OpenAI API", "option", "b", int),
    segment=("Split sentences", "flag", "S", bool),
    exclusive_classes=("Make the classification task exclusive", "flag", "E", bool),
    resume=("Resume fetch from the output file", "flag", "r", bool),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    verbose=("Print extra information to terminal", "flag", "v", bool),
    # fmt: on
)
def openai_fetch_textcat(
    source: str,
    output_path: Path,
    labels: List[str],
    lang: str = "en",
    model: str = "text-davinci-003",
    batch_size: int = 10,
    segment: bool = False,
    prompt_path: Path = OPENAI_DEFAULTS.TEXTCAT_PROMPT_PATH,
    examples_path: Optional[Path] = None,
    max_examples: int = 2,
    exclusive_classes: bool = False,
    resume: bool = False,
    loader: Optional[str] = None,
    verbose: bool = False,
):
    """
    Get bulk textcat suggestions from the OpenAI API, using zero-shot or
    few-shot learning. The results can then be corrected using the
    `textcat.manual` recipe.  This approach lets you get OpenAI queries upfront,
    which can help if you want multiple annotators or reduce the waiting time
    between API calls.
    """
    msg.warn(
        "The `textcat.openai.fetch` recipe is deprecated and will be removed in Prodigy v2. "
        "To ensure continued support and improved functionality we recommend using the `textcat.llm.fetch` recipe instead: "
        "https://prodi.gy/docs/recipes/#textcat-llm.fetch. "
        "Please refer to our docs for more details: https://prodi.gy/docs/large-language-models#how"
    )
    log("RECIPE: Starting recipe textcat.openai.fetch", locals())
    api_key, api_org = get_api_credentials(model)
    examples = read_prompt_examples(examples_path, example_class=TextCatPromptExample)
    nlp = spacy.blank(lang)

    if segment:
        nlp.add_pipe("sentencizer")

    if not labels:
        msg.fail("No --labels argument set", exits=1)
    msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")

    if not exclusive_classes and len(labels) == 1:
        msg.warn(
            "Binary classification should always be exclusive. Setting "
            "`exclusive_classes` parameter to True"
        )
        exclusive_classes = True

    # Create OpenAISuggester with GPT-3 parameters
    labels = [normalize_label(label) for label in labels]
    openai = OpenAISuggester(
        response_parser=make_textcat_response_parser(labels=labels),
        prompt_template=load_template(prompt_path),
        labels=labels,
        max_examples=max_examples,
        segment=segment,
        openai_api_org=api_org,
        openai_api_key=api_key,
        openai_n=1,
        openai_model=model,
        openai_retry_timeout_s=10,
        openai_read_timeout_s=20,
        openai_n_retries=10,
        render_vars={"exclusive_classes": exclusive_classes},
        prompt_example_class=TextCatPromptExample,
        verbose=verbose,
    )
    for eg in examples:
        openai.add_example(eg)

    # Set up the stream
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=False, input_key="text"
    )

    # we're adding view_id here to make sure we can compute IAA metrics
    # for the LLM annotations.
    # IAA metrics require that all annotations were completed with the same
    # view_id to ensure the consistency of annotation conditions.
    stream.apply(
        add_view_id, view_id="classification" if len(labels) == 1 else "choice"
    )

    # If we want to resume, we take the path to the cache and
    # compare the hashes with respect to our inputs.
    if resume:
        msg.info(f"Resuming from previous output file: {output_path}")
        stream = get_resume_stream(stream, srsly.read_jsonl(output_path))

    stream = openai(tqdm(stream), batch_size=batch_size, nlp=nlp)
    srsly.write_jsonl(output_path, stream, append=resume, append_new_line=False)
