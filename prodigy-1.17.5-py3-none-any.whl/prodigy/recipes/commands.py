# pyright: reportPrivateImportUsage=false
import platform
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple, Type, Union, cast

import spacy
import srsly
from peewee import OperationalError
from radicli import Arg

from .. import about
from ..components.db import DatasetNotStructured, connect
from ..components.loaders import get_loader
from ..components.stream import get_stream
from ..core import recipe
from ..errors import RecipeError
from ..structured_types import Example, StructuredExampleError
from ..types import ExistingFilePath, SourceType
from ..util import (
    INPUT_HASH_ATTR,
    PRODIGY_HOME,
    TIMESTAMP_ATTR,
    get_timestamp_session_id,
    log,
    msg,
    registry,
    set_hashes,
)


@recipe(
    "stats",
    set_id=Arg(help="Optional dataset to show stats for"),
    list_datasets=Arg("--list-datasets", "-l", help="Print list of all datasets"),
    list_sessions=Arg("--list-sessions", "-ls", help="Print list of all sessions"),
    no_format=Arg("--no-format", "-nf", help="Don't pretty-print results"),
    silent=Arg("--silent", "-S", help="Don't print anything, just return"),
)
def stats(
    set_id: Optional[str] = None,
    list_datasets: bool = False,
    list_sessions: bool = False,
    no_format: bool = False,
    silent: bool = False,
) -> Optional[Dict[str, Any]]:
    """
    Print Prodigy and database statistics. Specifying a dataset ID will show
    detailed stats for the set.
    """
    DB = connect()

    try:
        import prodigy_company_plugins  # noqa

        license_type = "Prodigy Company"
    except ImportError:
        license_type = "Prodigy Personal"

    stats: Dict[str, Any] = {
        "prodigy_stats": {
            "version": about.__version__,
            "license_type": license_type,
            "location": str(Path(__file__).parent.parent),
            "prodigy_home": PRODIGY_HOME,
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "spacy_version": spacy.__version__,
            "database_name": DB.db_name,
            "database_id": DB.db_id,
            "total_datasets": len(DB.datasets),
            "total_sessions": len(DB.sessions),
        }
    }
    if (list_datasets or list_sessions) and len(DB.datasets):
        stats["datasets"] = DB.datasets
    if list_sessions and len(DB.sessions):
        stats["sessions"] = DB.sessions
    if set_id:
        if set_id not in DB:
            raise RecipeError(f"Can't find '{set_id}' in database {DB.db_name}")
        DB.get_dataset_by_name(set_id)
        examples = DB.get_dataset_examples(set_id)
        meta = DB.get_meta(set_id)
        n_examples = len(examples)
        decisions = Counter()
        for eg in examples:
            if "answer" in eg:
                decisions[eg["answer"]] += 1
            elif "spans" in eg:
                for span in eg["spans"]:
                    if "answer" in span:
                        decisions[span["answer"]] += 1
        assert isinstance(meta, dict)
        stats["dataset_stats"] = {
            "dataset": set_id,
            "created": meta.get("created"),
            "description": meta.get("description"),
            "author": meta.get("author"),
            "annotations": n_examples,
            "accept": decisions["accept"],
            "reject": decisions["reject"],
            "ignore": decisions["ignore"],
        }
    if silent:
        return stats
    if no_format:
        print(srsly.json_dumps(stats))  # noqa: T201
    else:
        for key, values in stats.items():
            title = key.replace("_", " ").title()
            msg.divider(title, icon="emoji")
            if isinstance(values, list):
                msg.text(", ".join(values), spaced=True)
            else:
                msg.table(
                    {
                        k.replace("_", " ").title().replace("Spacy", "spaCy"): v
                        for k, v in values.items()
                    }
                )


@recipe(
    "drop",
    # fmt: off
    set_id=Arg(help="Name of dataset to remove"),
    batch_size=Arg("--batch-size", "-n", help="Delete examples in batches of the given size"),
    # fmt: on
)
def drop(set_id: str, batch_size: int = 128) -> None:
    """
    Remove a dataset. Can't be undone. For a list of all dataset and session
    IDs in the database, use `prodigy stats -ls`.
    """
    DB = connect()
    examples_before = DB.count_examples()
    if set_id not in DB:
        raise RecipeError(f"Can't find '{set_id}' in database {DB.db_name}")
    try:
        dropped = DB.drop_dataset(set_id, batch_size)
    except OperationalError as e:
        # See: https://support.prodi.gy/t/error-when-prodigy-drop/928
        if "too many SQL variables" in str(e):
            raise RecipeError(
                f"Unable to delete dataset '{set_id}' because a database limit "
                f"on the number of query variables was reached. On some systems "
                f"this limit is quite low, so using a custom batch size may "
                f"resolve the issue. Try: prodigy drop -n 500 {set_id}",
            )
        else:
            raise RecipeError(f"Database error: unable to delete dataset '{set_id}'", e)
    if not dropped:
        raise RecipeError(f"Can't remove '{set_id}' from database {DB.db_name}")
    examples_after = DB.count_examples()
    msg.good(f"Removed '{set_id}' from database {DB.db_name}")
    msg.good(
        f"Removed {examples_before - examples_after} examples from database {DB.db_name}"
    )


def _get_st_example_type(name: Optional[str] = None) -> Type[Example]:
    if name is None or name not in registry.example_types:
        return Example
    return registry.example_types.get(name)


def _get_keys_help(field: str, keys_attr: str) -> str:
    return (
        f"Optional list of keys to parse into the Structured Example `{field}`."
        f"Defaults to configured `{keys_attr}` of the "
        "registered Example for the `--structured-example-type` option."
    )


@recipe(
    "db-in",
    # fmt: off
    set_id=Arg(help="Dataset to import annotations to"),
    in_file=Arg(help="Path to input annotation file"),
    answer=Arg("--answer", "-a", help="Set this answer key if none is present"),
    overwrite=Arg("--overwrite", "-O", help="Overwrite existing answers"),
    loader=Arg("--loader", "-lo", help="Loader to use"),
    rehash=Arg("--rehash", "-R", help="Update and overwrite all hashes"),
    dry=Arg("--dry", "-D", help="Perform a dry run"),
    import_format=Arg("--import-format", "-if", help="'structured' if importing from a file with examples in the Structured Example format or 'unstructured' if data is in the original Prodigy task format."),
    save_format=Arg("--save-format", "-sf", help= "'structured' to save data in the Structured Example format or 'unstructured' to save data in the original unstructured Prodigy Example format."),
    structured_example_type=Arg("--example-type", "-et", help="Registered Name for Custom Structured Example SubType"),
    input_keys=Arg("--input-keys", "-ik", help=_get_keys_help("input", "input_keys")),
    server_ann_keys=Arg("--server-ann-keys", "-sk", help=_get_keys_help("server_anns", "server_ann_keys")),
    user_ann_keys=Arg("--user-ann-keys", "-uk", help=_get_keys_help("user_anns", "user_ann_keys")),
    # fmt: on
)
def db_in(
    set_id: str,
    in_file: ExistingFilePath,
    loader: Optional[str] = None,
    answer: Literal["accept", "reject", "ignore"] = "accept",
    overwrite: bool = False,
    rehash: bool = False,
    dry: bool = False,
    import_format: Literal["structured", "unstructured"] = "unstructured",
    save_format: Literal["structured", "unstructured"] = "unstructured",
    structured_example_type: Optional[str] = None,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
    user_ann_keys: Optional[List[str]] = None,
) -> None:
    """
    Import annotations to the database. Supports all formats loadable by
    Prodigy including the new Structured Example format.
    """
    if import_format == "unstructured" and save_format == "structured":
        if structured_example_type is None and (
            input_keys is None or user_ann_keys is None
        ):
            msg.fail(
                "To ensure the correct parsing of an unstructured dataset either a "
                "structured_example_type or both input_keys and server_ann_keys "
                "must be specified.",
                exits=1,
            )
    DB = connect()
    in_path = Path(in_file)
    if not in_path.exists() or not in_path.is_file():
        msg.fail("Not a valid input file", str(in_file), exits=1)
    session_id = get_timestamp_session_id()
    if import_format == "structured":
        loader_func = get_loader("jsonl")
        data = loader_func(in_file)
        added_answers = 0
        st_examples: List[Example] = []
        for st_task_dict in data:
            st_task_name = st_task_dict.pop("__class__", structured_example_type)
            StructuredExampleType = _get_st_example_type(st_task_name)
            try:
                st_task = StructuredExampleType.from_dict(st_task_dict)
            except (StructuredExampleError, ValueError) as e:
                msg.fail(
                    "Failed to convert to Structured Example before saving.",
                    str(e),
                    exits=1,
                )
            else:
                if st_task.answer is None or overwrite:
                    st_task.answer = answer
                    added_answers += 1
                st_examples.append(st_task)

        if save_format == "structured":
            to_save = st_examples
        elif save_format == "unstructured":
            to_save = [eg.to_unst() for eg in st_examples]

    elif import_format == "unstructured":
        loader_func = get_loader(loader, file_path=in_file)
        data = loader_func(in_file)
        examples = []
        added_answers = 0
        for task in data:
            task = set_hashes(task, overwrite=rehash)
            if "answer" not in task or overwrite:
                task["answer"] = answer
                added_answers += 1
            examples.append(task)

        if save_format == "structured":
            to_save = []
            StructuredExampleType = _get_st_example_type(structured_example_type)
            for eg in examples:
                try:
                    structured_eg = StructuredExampleType.from_unst_user(
                        eg,
                        input_keys=input_keys,
                        server_ann_keys=server_ann_keys,
                        user_ann_keys=user_ann_keys,
                    )
                except (StructuredExampleError, ValueError) as e:
                    msg.fail(
                        "Failed to convert to Structured Example before saving.",
                        str(e),
                        exits=1,
                    )
                else:
                    to_save.append(structured_eg)

        elif save_format == "unstructured":
            to_save = [dict(eg) for eg in examples]

    if not dry:
        if set_id not in DB:
            structured = save_format == "structured"
            DB.add_dataset(set_id, structured=structured)
            msg.good(
                f"Created {save_format} dataset '{set_id}' in database {DB.db_name}"
            )

        if save_format == "structured":
            DB.add_st_examples(cast(List[Example], to_save), set_id, session_id)
        elif save_format == "unstructured":
            DB.add_dataset(session_id, session=True)
            DB.add_examples(
                cast(List[Dict[str, Any]], to_save), datasets=[set_id, session_id]
            )
    n_total = len(to_save)
    msg.good(
        f"Imported {n_total} annotated examples and saved them to '{set_id}' "
        f"(session {session_id}) in database {DB.db_name}",
        f'Found and keeping existing "answer" in {n_total - added_answers} examples',
    )


@recipe(
    "db-out",
    # fmt: off
    set_id=Arg(help="Name of dataset to export"),
    out_dir=Arg(help="Path to output directory"),
    answer=Arg("--answer", "-a", help="Only export annotations with this answer"),
    flagged_only=Arg("--flagged-only", "-F", help="Only export flagged annotations"),
    dry=Arg("--dry", "-D", help="Perform a dry run"),
    export_format=("Export data as either 'structured' or 'unstructured' tasks.", "option", "ef", str, ["structured", "unstructured"]),
    structured_example_type=Arg("--example-type", "-et", help="Registered Name for Custom Structured Example SubType"),
    input_keys=Arg("--input-keys", "-ik", help=_get_keys_help("input", "input_keys")),
    server_ann_keys=Arg("--server-ann-keys", "-sk", help=_get_keys_help("server_anns", "server_ann_keys")),
    user_ann_keys=Arg("--user-ann-keys", "-uk", help=_get_keys_help("user_anns", "user_ann_keys")),
    # fmt: on
)
def db_out(
    set_id: str,
    out_dir: Optional[Union[str, Path]] = None,
    answer: Optional[Literal["accept", "reject", "ignore"]] = None,
    flagged_only: bool = False,
    dry: bool = False,
    export_format: Literal["structured", "unstructured"] = "unstructured",
    structured_example_type: Optional[str] = None,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
    user_ann_keys: Optional[List[str]] = None,
) -> None:
    """
    Export annotations from the database. Files will be exported in
    Prodigy's unstructured JSONL format by default. To export files with the new Structured Example JSONL format,
    provide the '--export-format structured' option.
    """
    DB = connect()
    if set_id not in DB:
        msg.fail(f"Can't find '{set_id}' in database {DB.db_name}", exits=1)

    if export_format == "unstructured":
        if structured_example_type:
            msg.fail(
                "Can't set `--structured-example-type` while `--export-format` is unstructured.",
                exits=1,
            )

    if export_format == "structured":
        if (
            structured_example_type
            and structured_example_type not in registry.example_types
        ):
            msg.fail(
                f"Can't find {structured_example_type} in registry. Use --input-keys and --user-ann-keys instead.",
                exits=1,
            )

    out_file = None
    if out_dir is not None:
        out_dir = Path(out_dir)
        if not out_dir.exists():
            out_dir.mkdir()
        out_file = out_dir / f"{set_id}.jsonl"

    try:
        _ = DB.get_st_dataset(set_id)
        ds_is_structured = True
    except DatasetNotStructured:
        ds_is_structured = False

    if ds_is_structured is False and export_format == "structured":
        if structured_example_type is None and (
            input_keys is None or user_ann_keys is None
        ):
            msg.fail(
                "To ensure the correct parsing of an unstructured dataset "
                "either a 'structured_example_type' or both 'input_keys' and 'user_ann_keys' "
                "must be specified.",
                exits=1,
            )

    if ds_is_structured:
        StructuredExampleType = _get_st_example_type(structured_example_type)
        examples = DB.get_st_dataset_examples(set_id, parse_as=StructuredExampleType)
        if flagged_only:
            examples = [eg for eg in examples if eg.meta.get("flagged")]
        if answer:
            examples = [eg for eg in examples if eg.answer == answer]

        if export_format == "structured":
            serialized = [eg.to_dict() for eg in examples]
        elif export_format == "unstructured":
            serialized = [eg.to_unst() for eg in examples]
    else:
        if export_format == "structured":
            StructuredExampleType = _get_st_example_type(structured_example_type)
            examples = DB.get_st_dataset_examples_from_unst(
                set_id,
                input_keys=input_keys,
                server_ann_keys=server_ann_keys,
                user_ann_keys=user_ann_keys,
                parse_as=StructuredExampleType,
            )
            if flagged_only:
                examples = [eg for eg in examples if eg.meta.get("flagged")]
            if answer:
                examples = [eg for eg in examples if eg.answer == answer]
            serialized = [eg.to_dict() for eg in examples]
        elif export_format == "unstructured":
            examples = DB.get_dataset_examples(set_id)
            if flagged_only:
                examples = [eg for eg in examples if eg.get("flagged")]
            if answer:
                examples = [eg for eg in examples if eg.get("answer") == answer]
            serialized = [dict(eg) for eg in examples]

    if out_file is None:
        for eg in serialized:
            print(srsly.json_dumps(eg))  # noqa: T201
    else:
        if not dry:
            srsly.write_jsonl(out_file, serialized)
            msg.good(
                f"Exported {len(serialized)} annotations from '{set_id}' in database {DB.db_name}",
                str(out_file.resolve()),
            )


@recipe(
    "db-merge",
    in_sets=Arg(help="Comma-separated datasets to merge"),
    out_set=Arg(help="Name of new dataset for merged data"),
    rehash=Arg("--rehash", "-R", help="Force-update all task and input hashes"),
    dry=Arg("--dry", "-D", help="Perform a dry run"),
)
def db_merge(
    in_sets: List[str], out_set: str, rehash: bool = False, dry: bool = False
) -> None:
    """
    Merge two or more existing datasets into a new set. Keeps a copy of the
    original datasets and creates a new set for the merged examples.
    """
    DB = connect()
    for set_id in in_sets:
        if set_id not in DB:
            raise RecipeError(f"Can't find dataset '{set_id}' in database")
    if out_set in DB and len(DB.get_dataset_examples(out_set)):
        raise RecipeError(
            f"Output dataset '{out_set}' already exists and includes examples",
            "This can lead to unexpected results. Please use a new dataset.",
        )
    if out_set not in DB:
        if not dry:
            DB.add_dataset(out_set)
        msg.good(f"Created dataset '{out_set}'")
    merged = []
    for set_id in in_sets:
        examples = DB.get_dataset_examples(set_id)
        if rehash:
            examples = [set_hashes(eg, overwrite=True) for eg in examples]
        merged += examples
        log(f"RECIPE: Adding {len(examples)} examples from '{set_id}'")
    if not dry:
        DB.add_examples(merged, datasets=[out_set])
    msg.good(
        f"Merged {len(merged)} examples from {len(in_sets)} datasets",
        f"Created merged dataset '{out_set}'",
    )


@recipe(
    "progress",
    # fmt: off
    datasets=Arg(help="Comma-separated datasets to use"),
    interval=Arg("--interval", "-i", help="Interval to calculate progress for"),
    source=Arg("--source", "-s", help="Optional source data to use for progress calculation (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader for source (guessed from file extension if not set)"),
    # fmt: on
)
def progress(
    datasets: List[str],
    interval: Literal["day", "week", "month", "year"] = "month",
    source: Optional[SourceType] = None,
    loader: Optional[str] = None,
) -> List[List[Union[str, int]]]:
    """
    View the progress on one or more datasets over time. Uses the timestamp
    added to annotations in Prodigy v1.11+ to group annotations and falls back
    to dataset creation timestamp for data created with older versions. If a
    source is provided, the annotations will be compared against the examples in
    the data to calculate the percentage of how many examples in the data are
    annotated.
    """

    def get_timestamp_key(
        ts: datetime, interval: str
    ) -> Tuple[Tuple[int, int, int, int], str]:
        year = ts.year
        month = ts.strftime("%b")
        week = ts.strftime("%V")
        day = ts.strftime("%d")
        if interval == "year":
            return ((ts.year, 0, 0, 0), f"{year}")
        if interval == "month":
            return ((ts.year, ts.month, 0, 0), f"{month} {year}")
        if interval == "week":
            return ((ts.year, ts.month, int(week), 0), f"{month} {year} (week {week})")
        if interval == "day":
            return ((ts.year, ts.month, int(week), ts.day), f"{day} {month} {year}")
        raise ValueError(f"Invalid interval: {interval}")

    DB = connect()
    all_examples = []
    n_examples = 0
    for set_id in set(datasets):
        if set_id not in DB:
            raise RecipeError(f"Can't find dataset '{set_id}' in database")
        examples = DB.get_dataset_examples(set_id)
        meta = DB.get_meta(set_id)  # keep meta for created timestamp fallback
        assert isinstance(meta, dict)
        all_examples.append((examples, set_id, meta["created"]))
        n_examples += len(examples)
    msg.good(f"Loaded {n_examples} annotations from {len(datasets)} datasets")

    source_hashes = None
    if source is not None:
        stream = get_stream(source, loader=loader, rehash=True, dedup=True)
        source_hashes = set([eg[INPUT_HASH_ATTR] for eg in stream])
        msg.good(f"Loaded {len(source_hashes)} unique examples from source")

    examples_by_ts = Counter()
    uniques_by_ts = defaultdict(set)
    print_keys_by_ts = {}
    no_ts_count = 0
    no_ts_sets = set()
    for examples, name, created in all_examples:
        for eg in examples:
            timestamp = eg.get(TIMESTAMP_ATTR)
            if timestamp:
                ts = datetime.utcfromtimestamp(timestamp)
            else:
                ts = created
                no_ts_count += 1
                no_ts_sets.add(name)
            key, print_key = get_timestamp_key(ts, interval)
            examples_by_ts[key] += 1
            uniques_by_ts[key].add(eg[INPUT_HASH_ATTR])
            print_keys_by_ts[key] = print_key
    data = []
    cumsum = 0
    cumsum_unique = 0
    for key, counts in sorted(examples_by_ts.items()):
        uniques = uniques_by_ts[key]
        cumsum += counts
        cumsum_unique += len(uniques)
        row = [print_keys_by_ts[key], counts, len(uniques), cumsum, cumsum_unique]
        if source_hashes is not None:
            annots = [eg_hash for eg_hash in uniques if eg_hash in source_hashes]
            row.append(len(annots))
            row.append(f"{len(annots) / len(source_hashes):.1%}")
        data.append(row)
    header = ["", "New", "Unique", "Total", "Unique"]
    aligns = ["l", "r", "r", "r", "r"]
    info = {
        "New": "New annotations collected in interval",
        "Total": "Total annotations collected",
        "Unique": "Unique examples (not counting multiple annotations of same example)",
    }
    if source_hashes is not None:
        header += ["In source", "Progress"]
        aligns += ["r", "r"]
        info["In source"] = "Total annotations on examples in source data"
        info["Progress"] = "Percentage of examples annotated in source data"
    msg.table(info, title="Legend")
    msg.table(
        data, title="Annotation Progress", header=header, aligns=aligns, divider=True
    )
    if no_ts_count:
        msg.warn(
            f'No "{TIMESTAMP_ATTR}" found in {no_ts_count} annotations from '
            f"datasets: {', '.join(no_ts_sets)}. Maybe the data was created "
            f"with Prodigy v1.10 or lower? Using dataset creation time as a fallback."
        )
    return data
