import copy
from typing import Callable, Iterable, List, Optional, Tuple, Union

import murmurhash
from spacy.language import Language
from spacy.tokens.doc import SetEntsDefault  # type: ignore
from spacy.tokens.span import Span
from spacy.training import Example
from spacy.util import filter_spans

from ..components.db import connect
from ..components.decorators import support_both_streams
from ..components.filters import filter_seen_before
from ..components.preprocess import (
    add_annot_name,
    add_tokens,
    add_view_id,
    make_ner_suggestions,
    make_raw_doc,
    resolve_labels,
    split_sentences,
)
from ..components.sorters import prefer_uncertain
from ..components.source import GeneratorSource
from ..components.stream import Stream, get_stream, load_noop
from ..core import Arg, recipe
from ..errors import RecipeError
from ..models.matcher import PatternMatcher
from ..models.ner import EntityRecognizerModel, ensure_sentencizer
from ..protocols import ControllerComponentsDict
from ..types import (
    ExistingFilePath,
    LabelsType,
    SourceType,
    StreamType,
    TaskType,
)
from ..util import (
    ANNOTATOR_ID_ATTR,
    BINARY_ATTR,
    INPUT_HASH_ATTR,
    TASK_HASH_ATTR,
    combine_models,
    copy_nlp,
    get_pipe_labels,
    log,
    msg,
    set_hashes,
)
from .compare import get_printer as get_compare_printer
from .compare import get_questions as get_compare_questions


@recipe(
    "ner.teach",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with an entity recognizer"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    patterns=Arg("--patterns", "-pt", help="Path to match patterns file"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    unsegmented=Arg("--unsegmented", "-U", help="Don't split sentences"),
    # fmt: on
)
def teach(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    patterns: Optional[ExistingFilePath] = None,
    exclude: List[str] = [],
    unsegmented: bool = False,
) -> ControllerComponentsDict:
    """
    Collect the best possible training data for a named entity recognition
    model with the model in the loop. Based on your annotations, Prodigy will
    decide which questions to ask next.
    """
    log("RECIPE: Starting recipe ner.teach", locals())
    spacy_model = f"{nlp.meta['lang']}_{nlp.meta['name']}"
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    ensure_sentencizer(nlp)
    log(f"RECIPE: Creating entity recognizer annotation model using {spacy_model}")
    model = EntityRecognizerModel(nlp, label=label)
    orig_nlp = copy_nlp(nlp)
    if label is not None and patterns is None:
        log("RECIPE: Making sure all labels are in the model", label)
        ner_labels = nlp.pipe_labels.get("ner", nlp.pipe_labels.get("beam_ner", []))
        for label_name in label:
            if label_name not in ner_labels:
                msg.info(f"Available labels in model {spacy_model}: {ner_labels}")
                raise RecipeError(
                    f"Can't find label '{label_name}' in model {spacy_model}",
                    "ner.teach will only show entities with one of the "
                    "specified labels. If a label is not available in the "
                    "model, Prodigy won't be able to propose entities for "
                    "annotation. To add a new label, you can specify a "
                    "patterns file containing examples of the new entity "
                    "as the --patterns argument or pre-train your model "
                    "with examples of the new entity and load it back in.",
                )
    if patterns is None:
        predict = model
        update = model.update
    else:
        matcher = PatternMatcher(nlp, filter_labels=label).from_disk(patterns)
        log("RECIPE: Created PatternMatcher and loaded in patterns", patterns)
        # Combine the NER model with the PatternMatcher to annotate both
        # match results and predictions, and update both models.
        predict, update = combine_models(model, matcher)  # type: ignore
    if not unsegmented:
        stream.apply(split_sentences, nlp=orig_nlp, stream=stream)
    stream.apply(lambda examples: prefer_uncertain(predict(examples)))

    return {
        "view_id": "ner",
        "dataset": dataset,
        "stream": stream,
        "update": update,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "label": ", ".join(label) if label else "all",
        },
    }


@recipe(
    "ner.manual",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline for tokenization or blank:lang (e.g. blank:en)"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    patterns=Arg("--patterns", "-pt", help="Path to match patterns file"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    highlight_chars=Arg("--highlight-chars", "-C", help="Allow highlighting individual characters instead of tokens"),
    # fmt: on
)
def manual(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    patterns: Optional[ExistingFilePath] = None,
    exclude: List[str] = [],
    highlight_chars: bool = False,
) -> ControllerComponentsDict:
    """
    Mark spans by token. Requires only a tokenizer and no entity recognizer,
    and doesn't do any active learning. If patterns are provided, their matches
    are highlighted in the example, if available. The recipe will present
    all examples in order, so even examples without matches are shown. If
    character highlighting is enabled, no "tokens" are saved to the database.
    """
    log("RECIPE: Starting recipe ner.manual", locals())
    view_id = "ner_manual"
    labels = get_pipe_labels(label, nlp.pipe_labels.get("ner", []))
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        is_binary=False,
        view_id=view_id,
    )
    if patterns is not None:
        pattern_matcher = PatternMatcher(nlp, combine_matches=True, all_examples=True)
        pattern_matcher = pattern_matcher.from_disk(patterns)
        stream.apply(lambda examples: (eg for _, eg in pattern_matcher(examples)))
    # Add "tokens" key to the tasks, either with words or characters
    stream.apply(add_tokens, nlp=nlp, stream=stream)

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "ner_manual_highlight_chars": highlight_chars,
        },
    }


@recipe(
    "ner.correct",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with an entity recognizer"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    update=Arg("--update", "-UP", help="Whether to update the model during annotation"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    unsegmented=Arg("--unsegmented", "-U", help="Don't split sentences"),
    component=Arg("--component", "-c", help="Name of NER component in the pipeline"),
    # fmt: on
)
def correct(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    update: bool = False,
    exclude: List[str] = [],
    unsegmented: bool = False,
    component: str = "ner",
) -> ControllerComponentsDict:
    """
    Create gold data for NER by correcting a model's suggestions.
    """
    log("RECIPE: Starting recipe ner.correct", locals())
    view_id = "ner_manual"
    if component not in nlp.pipe_names:
        raise RecipeError(
            f"Can't find component '{component}' in pipeline.",
            "Make sure that the pipeline you're using includes a trained entity "
            "recognizer that you can correct. If your component has a different "
            "name, you can use the --component option to specify it.",
        )
    labels, no_missing = get_ner_labels(nlp, label=label, component=component)
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )
    stream = preprocess_stream(stream, nlp, labels=labels, unsegmented=unsegmented)

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "update": get_update(nlp, no_missing=no_missing) if update else None,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
        },
    }


@support_both_streams(stream_arg="stream")
def preprocess_stream(
    stream: StreamType,
    nlp: Language,
    *,
    labels: Optional[List[str]],
    unsegmented: bool,
    set_annotations: bool = True,
) -> StreamType:
    if not unsegmented:
        stream = split_sentences(nlp, stream)  # type: ignore
    stream = add_tokens(nlp, stream)  # type: ignore
    if set_annotations:
        spacy_model = f"{nlp.meta['lang']}_{nlp.meta['name']}"
        # Add a 'spans' key to each example, with predicted entities
        texts = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(texts, as_tuples=True, batch_size=10):
            task = copy.deepcopy(eg)
            spans = []
            for ent in doc.ents:
                if labels and ent.label_ not in labels:
                    continue
                spans.append(ent)
            for span in eg.get("spans", []):
                spans.append(doc.char_span(span["start"], span["end"], span["label"]))
            spans = filter_spans(spans)
            span_dicts = []
            for ent in spans:
                span_dicts.append(
                    {
                        "token_start": ent.start,
                        "token_end": ent.end - 1,
                        "start": ent.start_char,
                        "end": ent.end_char,
                        "text": ent.text,
                        "label": ent.label_,
                        "source": spacy_model,
                        "input_hash": eg[INPUT_HASH_ATTR],
                    }
                )
            task["spans"] = span_dicts
            task[BINARY_ATTR] = False
            task = set_hashes(task)
            yield task
    else:
        yield from stream


def get_ner_labels(
    nlp: Language, *, label: Optional[List[str]], component: str = "ner"
) -> Tuple[List[str], bool]:
    model_labels = nlp.pipe_labels.get(component, [])
    labels = get_pipe_labels(label, model_labels)
    # Check if we're annotating all labels present in the model or a subset
    no_missing = len(set(labels).intersection(set(model_labels))) == len(model_labels)
    return labels, no_missing


def get_update(nlp: Language, *, no_missing: bool) -> Callable[[List[TaskType]], None]:
    def update(answers: List[TaskType]) -> None:
        log(f"RECIPE: Updating model with {len(answers)} answers")
        examples = []
        for eg in answers:
            if eg["answer"] == "accept":
                doc = make_raw_doc(nlp, eg)
                ref = make_raw_doc(nlp, eg)
                spans: list[Span] = [
                    span
                    for span in (
                        doc.char_span(span["start"], span["end"], label=span["label"])
                        for span in eg.get("spans", [])
                    )
                    if span is not None
                ]
                value = SetEntsDefault.outside if no_missing else SetEntsDefault.missing
                if spans:
                    ref.set_ents(spans, default=value)
                    examples.append(Example(doc, ref))
        nlp.update(examples)

    return update


@recipe(
    "ner.silver-to-gold",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    silver_sets=Arg(help="Comma-separated datasets to convert"),
    nlp=Arg(help="Loadable spaCy pipeline with an entity recognizer"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    # fmt: on
)
def silver_to_gold(
    dataset: str,
    silver_sets: List[str],
    nlp: Language,
    label: Optional[LabelsType] = None,
) -> ControllerComponentsDict:
    """
    Take existing "silver" datasets with binary accept/reject annotations,
    merge the annotations to find the best possible analysis given the
    constraints defined in the annotations, and manually edit it to create
    a perfect and complete "gold" dataset.
    """

    def filter_stream(stream: StreamType) -> StreamType:
        # make_best uses all labels in the model, so we need to filter by label here
        for eg in stream:
            eg["spans"] = [s for s in eg.get("spans", []) if s["label"] in labels]
            yield eg

    log("RECIPE: Starting recipe ner.silver-to-gold", locals())
    DB = connect()
    data: List[TaskType] = []
    for set_id in silver_sets:
        if set_id not in DB:
            raise RecipeError(f"Can't find input dataset '{set_id}' in database")
        examples = DB.get_dataset_examples(set_id)
        data += examples
    log(f"RECIPE: Loaded {len(data)} examples from {len(silver_sets)} dataset(s)")
    labels = get_pipe_labels(label, nlp.pipe_labels.get("ner", []))
    # Initialize Prodigy's entity recognizer model, which uses beam search to
    # find all possible analyses and outputs (score, example) tuples,
    # then merge all annotations and find the best possible analyses
    model = EntityRecognizerModel(nlp, label=labels)
    stream = model.make_best(data)
    stream = Stream(GeneratorSource(iter(stream)), loader=load_noop, wrappers=[])
    stream.apply(filter_stream)
    stream.apply(add_tokens, nlp=nlp, stream=stream)

    return {
        "dataset": dataset,
        "view_id": "ner_manual",
        "stream": stream,
        "config": {"lang": nlp.lang, "labels": labels},
    }


@recipe(
    "ner.eval-ab",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    before_nlp=Arg(help="Loadable spaCy pipeline with an entity recognizer"),
    after_nlp=Arg(help="Loadable spaCy pipeline with an entity recognizer"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    unsegmented=Arg("--unsegmented", "-U", help="Don't split sentences"),
    # fmt: on
)
def ab_evaluate(
    dataset: str,
    before_nlp: Language,
    after_nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    exclude: List[str] = [],
    unsegmented: bool = False,
) -> ControllerComponentsDict:
    """
    Evaluate an NER model and build an evaluation set from a stream.
    """
    log("RECIPE: Starting recipe ner.eval-ab", locals())

    def get_tasks(
        nlp: Language, labels: Optional[List[str]], stream: StreamType, name: str
    ) -> StreamType:
        tuples = ((eg["text"], eg) for eg in stream)
        for i, (doc, eg) in enumerate(nlp.pipe(tuples, as_tuples=True, batch_size=10)):
            spans = []
            for ent in doc.ents:
                label = ent.label_
                if not labels or label in labels:
                    start = ent.start_char
                    end = ent.end_char
                    spans.append({"start": start, "end": end, "label": label})
            task = {
                "id": i,
                "input": {"text": eg["text"]},
                "output": {"text": eg["text"], "spans": spans},
            }
            task[INPUT_HASH_ATTR] = murmurhash.hash(name + str(i))
            task[TASK_HASH_ATTR] = murmurhash.hash(name + str(i))
            yield task

    ensure_sentencizer(before_nlp)
    ensure_sentencizer(after_nlp)
    before_stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if not unsegmented:
        before_stream.apply(split_sentences, nlp=before_nlp, stream=before_stream)
    after_stream = before_stream.copy_restarted()

    before_stream.apply(
        get_tasks, nlp=before_nlp, labels=label, stream=before_stream, name="before"
    )
    after_stream.apply(
        get_tasks, nlp=after_nlp, labels=label, stream=after_stream, name="after"
    )

    @support_both_streams(stream_arg="stream")
    def ensure_hashes(stream):
        for ex in stream:
            yield set_hashes(ex)

    compare_stream = ensure_hashes(
        get_compare_questions(before_stream, after_stream, True)
    )
    on_exit = get_compare_printer("Before", "After")

    return {
        "view_id": "choice",
        "dataset": dataset,
        "stream": compare_stream,
        "on_exit": on_exit,
        "exclude": exclude,
    }


@recipe(
    "ner.model-annotate",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with an entity recognizer"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    model_alias=Arg(help="Annotator alias on behalf of the model"),
    labels=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    component=Arg("--component", "-c", help="Name of NER component in the pipeline"),
    # fmt: one
)
def ner_model_annotate(
    dataset: str,
    nlp: Language,
    source: Union[str, Iterable[dict]],
    model_alias: str,
    labels: Optional[List[str]] = None,
    loader: Optional[str] = None,
    component: str = "ner",
) -> None:
    """
    Generates annotations directly via a model.
    """
    log("RECIPE: Starting recipe ner.model-annotate", locals())

    stream = get_stream(source, loader=loader, rehash=True, input_key="text")
    # TODO: Counting all the items in a stream might go awry for _huge_ files.
    #       We should come back to this later with a utility function
    total = sum(1 for _ in stream.copy())

    labels = resolve_labels(nlp, component, recipe_labels=labels)

    # If the dataset already exists we should make sure that there we don't add duplicates
    db = connect()
    if dataset in db.datasets:
        already_annotated = (
            ex
            for ex in db.iter_dataset_examples(dataset)
            if ex[ANNOTATOR_ID_ATTR] == model_alias
        )
        stream.apply(filter_seen_before, stream=stream, cache_stream=already_annotated)

    stream.apply(
        make_ner_suggestions,
        stream=stream,
        nlp=nlp,
        component=component,
        labels=labels,
        show_progress_bar=True,
        progress_bar_total=total,
    )
    stream.apply(add_tokens, nlp=nlp, stream=stream)
    stream.apply(add_annot_name, name=model_alias)
    # we're adding view_id here to make sure we can compute IAA metrics
    # for the LLM annotations.
    # IAA metrics require that all annotations were completed with the same
    # view_id to ensure the consistency of annotation conditions.
    stream.apply(add_view_id, view_id="ner_manual")

    db = connect()
    # The "user" can also be seen as a session, so make sure we add that
    db.add_dataset(model_alias, session=True)
    # Write the examples to the dataset and session set
    db.add_examples(stream, [dataset, model_alias])
