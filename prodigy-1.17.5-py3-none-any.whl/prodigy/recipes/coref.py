from typing import List, Optional

from spacy.language import Language

from ..core import Arg, recipe
from ..errors import RecipeError
from ..protocols import ControllerComponentsDict
from ..types import LabelsType, SourceType
from .rel import manual as rel_manual

DEFAULT_LABELS = ["COREF"]
DEFAULT_POS = ["NOUN", "PROPN", "PRON", "DET"]
DEFAULT_POSS_PRON = ["PRP$"]
DEFAULT_NER_LABELS = ["PERSON", "ORG"]
NP_LABEL = "NP"


@recipe(
    "coref.manual",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline or blank:lang (e.g. blank:en)"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Label(s) to use for coreference relation"),
    pos_tags=Arg("--pos-tags", "-ps", help="List of coarse-grained POS tags to enable for annotation"),
    poss_pron_tags=Arg("--pos-pron-tags", "-pp", help="List of fine-grained tag values for possessive pronoun to use in patterns"),
    ner_labels=Arg("--ner-labels", "-nl", help="List of NER labels to use if model has entity recognizer"),
    show_arrow_heads=Arg("--show-arrow-heads", "-SA", help="Show the arrow heads visually"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude")
    # fmt: on
)
def manual(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: LabelsType = LabelsType(DEFAULT_LABELS),
    exclude: List[str] = [],
    pos_tags: List[str] = DEFAULT_POS,
    poss_pron_tags: List[str] = DEFAULT_POSS_PRON,
    ner_labels: List[str] = DEFAULT_NER_LABELS,
    show_arrow_heads: bool = False,
) -> ControllerComponentsDict:
    """Create training data for coreference resolution. Coreference resolution
    is the challenge of linking ambiguous mentions such as "her" or "that woman"
    back to an antecedent providing more context about the entity in question.

    This recipe allows you to focus on nouns, proper nouns and pronouns
    specifically, by disabling all other tokens. You can customize the labels
    used to extract those using the recipe arguments.
    """
    if "tagger" not in nlp.pipe_names:
        raise RecipeError(
            "No tagger found in pipeline",
            "The provided model should have a 'tagger' component to allow "
            "pattern matching on the POS tags for efficient coreference annotation.",
        )
    patterns = [
        {
            "label": NP_LABEL,
            "pattern": [
                {"POS": "DET", "TAG": {"NOT_IN": poss_pron_tags}, "OP": "?"},
                {"POS": "ADJ", "OP": "*"},
                # Proper nouns but no entities, otherwise this custom pattern
                # would overwrite them
                {
                    "POS": {"IN": ["PROPN", "NOUN"]},
                    "OP": "+",
                    "ENT_TYPE": {"NOT_IN": ner_labels},
                },
            ],
        }
    ]
    disable_patterns = [
        # Other POS tags but no tokens in our previously matched NPs
        [{"POS": {"NOT_IN": pos_tags}, "_": {"label": {"NOT_IN": [NP_LABEL]}}}]
    ]
    disable_patterns = [{"pattern": pat} for pat in disable_patterns]
    components = rel_manual(
        dataset,
        nlp,
        source,
        loader,
        label=label,
        exclude=exclude,
        patterns_path=patterns,
        disable_patterns_path=disable_patterns,
        add_ents=True,
        add_nps=False,
        wrap=True,
        hide_arrow_heads=not show_arrow_heads,
    )
    return components
