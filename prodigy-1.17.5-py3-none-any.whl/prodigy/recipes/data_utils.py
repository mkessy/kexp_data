# pyright: reportUndefinedVariable=false, reportGeneralTypeIssues=false
import logging
import random
from collections import Counter, defaultdict
from functools import partial
from typing import (
    Callable,
    Dict,
    Iterable,
    Iterator,
    List,
    Optional,
    Sequence,
    Set,
    Tuple,
    Union,
)

from spacy.cli._util import string_to_list
from spacy.language import Language
from spacy.tokens import Doc, SpanGroup
from spacy.tokens.doc import SetEntsDefault
from spacy.training.example import Example
from spacy.util import filter_spans
from thinc.api import Config

from ..components.db import Database, connect
from ..components.preprocess import convert_options_to_cats, split_pages
from ..components.validate import validate
from ..errors import RecipeError
from ..types import (
    DepExample,
    NerExample,
    PosExample,
    SpansExample,
    TaskType,
    TextcatExample,
)
from ..util import (
    BINARY_ATTR,
    COREF_DEFAULT_PREFIX,
    EVAL_PREFIX,
    INPUT_HASH_ATTR,
    MISSING_HASHES_WARNING_KEY,
    MISSING_VALUE,
    NER_DEFAULT_INCORRECT_KEY,
    SENT_INSIDE_LABEL,
    SENT_START_LABEL,
    SPANCAT_DEFAULT_KEY,
    VIEW_ID_ATTR,
    first_warning,
    get_config,
    hashes_missing,
    is_neg_label,
    msg,
    neg_to_pos_label,
    set_hashes,
)

# Specific logger for outputting info about data conversion / merging
logger = logging.getLogger("prodigy:data")
logger_stream_handler = logging.StreamHandler()
logger_stream_handler.setFormatter(logging.Formatter("%(message)s"))
logger.addHandler(logger_stream_handler)


def merge_corpus(
    nlp: Language,
    pipes: Dict[str, Tuple[List[str], List[str]]],
    *,
    eval_split: float = 0.0,
) -> Dict[str, Callable[[Language], Iterable[Example]]]:
    default_fill = SetEntsDefault.outside
    # determine relevant span keys from the nlp pipeline components
    ner_incorrect_key = NER_DEFAULT_INCORRECT_KEY
    ner_pipe = None
    if "ner" in nlp.pipe_names:
        ner_pipe = nlp.get_pipe("ner")
    elif "beam_ner" in nlp.pipe_names:
        ner_pipe = nlp.get_pipe("beam_ner")
    if ner_pipe and hasattr(ner_pipe, "incorrect_spans_key"):
        ner_incorrect_key = ner_pipe.incorrect_spans_key
    spans_key = SPANCAT_DEFAULT_KEY
    if "spancat" in nlp.pipe_names:
        spans_key = nlp.get_pipe("spancat").key
    coref_prefix = COREF_DEFAULT_PREFIX
    if "coref" in nlp.pipe_names:
        coref_prefix = nlp.get_pipe("coref").prefix

    reader_factories = {
        "ner": partial(
            create_ner_reader,
            default_fill=default_fill,
            incorrect_key=ner_incorrect_key,
        ),
        "textcat": partial(create_textcat_reader, exclusive=True),
        "textcat_multilabel": partial(create_textcat_reader, exclusive=False),
        "parser": create_parser_reader,
        "tagger": create_tagger_reader,
        "senter": create_senter_reader,
        "spancat": partial(
            create_spancat_reader,
            spans_key=spans_key,
        ),
        "experimental_coref": partial(create_coref_reader, coref_prefix=coref_prefix),
    }
    readers = {}
    for pipe, (train_sets, eval_sets) in pipes.items():
        if pipe in reader_factories:
            readers[pipe] = reader_factories[pipe](train_sets, eval_sets)
    corpus = create_merged_corpus(**readers, eval_split=eval_split)
    return corpus


def merge_data(
    nlp: Language,
    ner_datasets: Union[str, Sequence[str]] = tuple(),
    textcat_datasets: Union[str, Sequence[str]] = tuple(),
    textcat_multilabel_datasets: Union[str, Sequence[str]] = tuple(),
    tagger_datasets: Union[str, Sequence[str]] = tuple(),
    senter_datasets: Union[str, Sequence[str]] = tuple(),
    parser_datasets: Union[str, Sequence[str]] = tuple(),
    spancat_datasets: Union[str, Sequence[str]] = tuple(),
    coref_datasets: Union[str, Sequence[str]] = tuple(),
    *,
    eval_split: float = 0.0,
) -> Tuple[List[Doc], List[Doc], Dict[str, Tuple[List[str], List[str]]]]:
    pipes = get_datasets_from_cli(
        ner_datasets,
        textcat_datasets,
        textcat_multilabel_datasets,
        tagger_datasets,
        senter_datasets,
        parser_datasets,
        spancat_datasets,
        coref_datasets,
    )
    merged_corpus = merge_corpus(nlp=nlp, pipes=pipes, eval_split=eval_split)

    train_docs = [eg.reference for eg in merged_corpus["train"](nlp)]
    dev_docs = [eg.reference for eg in merged_corpus["dev"](nlp)]
    return train_docs, dev_docs, pipes


def load_examples(db: Database, datasets: Iterable[str] = tuple()) -> List[TaskType]:
    """Load examples from a Prodigy database. Not returning ignored cases.

    db (Database): The database to load from.
    datasets (Iterable[str]): The names of the datasets.
    RETURNS (List[dict]): All examples from the datasets.
    """
    result = []
    for set_id in datasets:
        if set_id not in db:
            raise RecipeError(f"Can't find '{set_id}' in database '{db.db_name}'")
        examples = db.get_dataset_examples(set_id) or []
        examples = split_pages(examples)
        for eg in examples:
            if eg.get("answer") != "ignore":
                if first_warning(
                    f"{MISSING_HASHES_WARNING_KEY}-{hex(id(db))}",
                    lambda: hashes_missing(eg),
                ):
                    msg.warn(
                        "Prodigy automatically assigned an input/task hash to an example "
                        "that was loaded from the Prodigy database. That should not happen "
                        "to data that was annotated with Prodigy."
                        "Please check your datasets for missing _input_hash/_task_hash keys. "
                        "You may have loaded in data via `prodigy db-in` without hashing. "
                        "This automatic hashing will be deprecated as of Prodigy v2 because it "
                        "can lead to unwanted duplicates in custom recipes if the examples deviate "
                        "from the default assumptions. More information can found on the docs: "
                        "https://prodi.gy/docs/api-components#set_hashes"
                    )
                result.append(set_hashes(eg, overwrite=True))
    return result


def get_datasets_from_cli(
    ner: Union[Sequence[str], str],
    textcat: Union[Sequence[str], str],
    textcat_multilabel: Union[Sequence[str], str],
    tagger: Union[Sequence[str], str],
    senter: Union[Sequence[str], str],
    parser: Union[Sequence[str], str],
    spancat: Union[Sequence[str], str],
    coref: Union[Sequence[str], str],
) -> Dict[str, Tuple[List[str], List[str]]]:
    """Load training and evaluation sets based on list specified on the CLI.
    Takes care of converting a comma-separated string of names if needed, ensures
    that data is available and supports evaluation sets with the eval: prefix.

    *args (Union[Sequence[str], str]): The dataset names.
    RETURNS (Dict[str, Tuple[List[str], List[str]]]): The loaded examples, keyed
        by component name, as a tuple of training and evaluation examples.
    """
    set_names = {
        "ner": ner,
        "tagger": tagger,
        "senter": senter,
        "parser": parser,
        "spancat": spancat,
        "experimental_coref": coref,
        "textcat": textcat,
        "textcat_multilabel": textcat_multilabel,
    }
    pipes = {}
    for name, value in set_names.items():
        if isinstance(value, str):
            value = string_to_list(value) if value else []
        train_sets = [n for n in value if not n.startswith(EVAL_PREFIX)]
        eval_sets = [n[len(EVAL_PREFIX) :] for n in value if n.startswith(EVAL_PREFIX)]
        if eval_sets and not train_sets:
            raise RecipeError(
                f"Evaluation data but no training data provided for component '{name}'",
                "Make sure to specify at lease one dataset to use for training.",
            )
        if train_sets:
            pipes[name] = (train_sets, eval_sets)
    if not pipes:
        raise RecipeError(
            "You need to specify at least one training dataset using one of the CLI options",
            ", ".join(f"--{c}" for c in set_names),
        )
    return pipes


def get_datasets_from_cli_eval(
    ner: Union[Sequence[str], str],
    textcat: Union[Sequence[str], str],
    textcat_multilabel: Union[Sequence[str], str],
    tagger: Union[Sequence[str], str],
    senter: Union[Sequence[str], str],
    parser: Union[Sequence[str], str],
    spancat: Union[Sequence[str], str],
    coref: Union[Sequence[str], str],
) -> Dict[str, List[str]]:
    """Load evaluation sets based on list specified on the CLI.
    Takes care of converting a comma-separated string of names if needed, ensures
    that data is available and supports evaluation sets with the eval: prefix.

    *args (Union[Sequence[str], str]): The dataset names.
    RETURNS (Dict[str, Tuple[List[str], List[str]]]): The loaded examples, keyed
        by component name, with a value of a list of evaluation examples.
    """
    set_names = {
        "ner": ner,
        "tagger": tagger,
        "senter": senter,
        "parser": parser,
        "spancat": spancat,
        "experimental_coref": coref,
        "textcat": textcat,
        "textcat_multilabel": textcat_multilabel,
    }
    pipes = {}
    for name, value in set_names.items():
        if isinstance(value, str):
            value = string_to_list(value) if value else []
        eval_sets = []
        for n in value:
            if n.startswith(EVAL_PREFIX):
                eval_sets.append(n[len(EVAL_PREFIX) :])
            else:
                eval_sets.append(n)
        pipes[name] = eval_sets
    if not pipes:
        raise RecipeError(
            "You need to specify at least one eval dataset using one of the CLI options",
            ", ".join(f"--{c}" for c in set_names),
        )
    return pipes


def add_prodigy_readers(
    pipes: Dict[str, Tuple[List[str], List[str]]],
    config: Config,
    corpus_config: Config,
    *,
    eval_split: float,
    sample_size: float = 1.0,
) -> Config:
    # Removing the standard spaCy readers and adding the Prodigy reader instead
    del config["corpora"]
    config = corpus_config.merge(config)
    C = config["corpora"]
    C["eval_split"] = eval_split
    C["sample_size"] = sample_size
    # need to rename because spaCy config validation requires the key to be `experimental_coref``
    C["experimental_coref"] = C.pop("coref")
    for pipe_name, (train_sets, eval_sets) in pipes.items():
        C[pipe_name]["datasets"] = train_sets
        C[pipe_name]["eval_datasets"] = eval_sets

    for block in [
        "ner",
        "textcat",
        "textcat_multilabel",
        "tagger",
        "parser",
        "senter",
        "spancat",
        "experimental_coref",
    ]:
        if block not in pipes:
            del C[block]
    if "ner" in pipes:
        C["ner"]["default_fill"] = SetEntsDefault.outside.value
    return config


def validate_examples(
    examples: Iterable[TaskType], component: str, active: bool = True
) -> Iterator[TaskType]:
    """Validate examples for a given component to make sure they have the
    correct format. Yields validated examples so it can be wrapped around an
    iterable of examples as they're being processed.

    examples (Iterable[dict]): The annotation examples.
    component (str): Pipeline component examples are intended for.
    active (bool): Whether validation is active.
    YIELDS (dict): The validated example.
    """
    schemas = {
        "ner": NerExample,
        "textcat": TextcatExample,
        "textcat_multilabel": TextcatExample,
        "tagger": PosExample,
        "parser": DepExample,
        "spancat": SpansExample,
        "coref": DepExample,
        "senter": SpansExample,
    }
    schema = schemas.get(component)
    for eg in examples:
        if active and schema:
            error_msg = f"Invalid data for component '{component}'"
            validate(schema, eg, error_msg=error_msg)
        yield eg


def create_ner_annotations(
    examples: List[TaskType],
    texts_by_input: Dict[str, str],
    *,
    validate: bool,
    labels: Set[str],
    default_fill: SetEntsDefault = SetEntsDefault.outside,
    incorrect_key: str = NER_DEFAULT_INCORRECT_KEY,
) -> Tuple[
    Dict[int, Tuple[bool, List[Tuple]]], Callable[[Tuple[bool, List[Tuple]], Doc], bool]
]:
    """Create annotation for the named entity recognizer component.

    examples (List[dict]): The examples created with Prodigy.
    texts_by_input (Dict[int, str]): Mapping of input hashes to texts, will be
        updated in place if the examples contain hashes not present.
    validate (bool): Whether to validate examples.
    labels (Set[str]): The labels for the component. Will be updated in place.
    default_fill (str): Whether unlabelled tokens are considered to be
        "missing" or "outside" in general.
    incorrect_key (str): The key in doc.spans that will hold the negative
        (rejected) examples.
    RETURNS (Dict, Callable): The is_binary flag and generated offsets keyed
        by input hash, and a callable to set them on a Doc object.
    """
    ner_by_input = {}
    for eg in validate_examples(examples, "ner", active=validate):
        answer = eg.get("answer", "accept")
        spans = eg.get("spans", [])
        if answer == "ignore":
            continue
        if answer == "reject" and len(spans) == 0:
            continue
        # parse offsets from current example
        span_offsets = []
        for span in spans:
            answer = span.get("answer", answer)
            label = span["label"]
            offsets = (span["start"], span["end"], label, answer)
            span_offsets.append(offsets)
            if is_neg_label(label):
                if label in labels:
                    labels.remove(label)
            else:
                labels.add(label)
        # merge with other annotations from same texts
        input_hash = eg[INPUT_HASH_ATTR]
        texts_by_input.setdefault(input_hash, eg.get("text"))
        prev_binary, prev_offsets = ner_by_input.get(input_hash, (None, []))
        curr_binary = eg.get(BINARY_ATTR)
        if curr_binary is None and eg.get(VIEW_ID_ATTR) == "ner":
            # when legacy data used the "ner" interface, it's from ner.teach a.k.a. binary
            curr_binary = True
        # If either of the annotations is a complete one (binary=False), pick that one
        if prev_binary is False:
            pass
        elif curr_binary is False:
            ner_by_input[input_hash] = (curr_binary, span_offsets)
        else:
            prev_offsets.extend([s for s in span_offsets if s not in prev_offsets])
            ner_by_input[input_hash] = (prev_binary or curr_binary, prev_offsets)

    def set_annotations(input_data: Tuple[bool, List[Tuple]], doc: Doc) -> bool:
        """
        input (Tuple[bool, List[Tuple]]): Input generated from ner_by_input:
            a boolean describing whether the data is binary, and the list
            of actual span offsets.
        doc (Doc): A Doc object to set the annotations on.
        RETURNS (bool): Whether the annotations could be set.
        """
        is_binary, offsets = input_data
        correct_spans = []
        correct_tuples = []
        incorrect_tuples = []  # TODO: does not cater for overlapping rejected spans!
        for start, end, label, answer in offsets:
            is_neg = is_neg_label(label)
            if is_neg:
                label = neg_to_pos_label(label)
            span = doc.char_span(start, end, label)
            if span is None:  # mismatched tokenization
                return False
            if answer == "accept" and not is_neg:
                correct_spans.append(span)
                correct_tuples.append((start, end, label))
            elif answer == "reject" and is_neg:
                correct_spans.append(span)
                correct_tuples.append((start, end, label))
            else:
                incorrect_tuples.append((start, end, label))
        incorrect_spans = [
            doc.char_span(start, end, label)
            for (start, end, label) in incorrect_tuples
            if (start, end, label) not in correct_tuples
        ]
        correct_spans = filter_spans(correct_spans)
        doc.spans[incorrect_key] = incorrect_spans
        if is_binary is True or len(incorrect_spans) > 0:
            doc.set_ents(correct_spans, default=SetEntsDefault.missing)
        elif is_binary is False:
            doc.set_ents(correct_spans, default=SetEntsDefault.outside)
        else:
            doc.set_ents(correct_spans, default=default_fill)
        return True

    return ner_by_input, set_annotations


def create_spancat_annotations(
    examples: List[TaskType],
    texts_by_input: Dict[int, str],
    *,
    validate: bool,
    labels: Set[str],
    spans_key: str = SPANCAT_DEFAULT_KEY,
) -> Tuple[
    Dict[int, List[Tuple[int, int, str, str]]],
    Callable[[List[Tuple[int, int, str, str]], Doc], bool],
]:
    """Create annotation for the spancat component.

    examples (List[dict]): The examples created with Prodigy.
    texts_by_input (Dict[int, str]): Mapping of input hashes to texts, will be
        updated in place if the examples contain hashes not present.
    validate (bool): Whether to validate examples.
    labels (Set[str]): The labels for the component. Will be updated in place.
    spans_key (str): The key in doc.spans that holds the training data.
    RETURNS (Dict, Callable): The generated offsets keyed by input hash,
        and a callable to set them on a Doc object.
    """
    spancat_by_input = {}
    for eg in validate_examples(examples, "spancat", active=validate):
        spans = eg.get("spans", [])
        answer = eg.get("answer", "accept")
        if answer in ["ignore", "reject"]:
            continue
        # parse offsets from current example
        span_offsets = []
        for span in spans:
            answer = span.get("answer", answer)
            label = span["label"]
            span_offsets.append((span["start"], span["end"], label, answer))
            labels.add(label)
        # merge with other annotations from same texts
        input_hash = eg[INPUT_HASH_ATTR]
        texts_by_input.setdefault(input_hash, eg.get("text"))
        offsets = spancat_by_input.get(input_hash, [])
        offsets.extend([s for s in span_offsets if s not in offsets])
        spancat_by_input[input_hash] = offsets

    def set_annotations(offsets: List[Tuple[int, int, str, str]], doc: Doc) -> bool:
        """
        input (List[Tuple]): Input generated from spancat_by_input:
            a list of span offsets.
        doc (Doc): A Doc object to set the annotations on.
        RETURNS (bool): Whether the annotations could be set.
        """
        assert not doc.spans.get(spans_key)
        doc.spans[spans_key] = SpanGroup(doc, name=spans_key)
        for start, end, label, answer in offsets:
            if answer == "accept":
                span = doc.char_span(start, end, label=label)
                if span is None:  # mismatched tokenization, don't set anything
                    return False
                doc.spans[spans_key].append(span)
        return True

    return spancat_by_input, set_annotations


def _convert_coref_to_clusters(
    relations: List[Dict[str, Tuple[int, int]]]
) -> Dict[int, List[Tuple[int, int]]]:
    """Convert Prodigy coref relations to clusters.

    Prodigy represents coreference as head-child relations, but our model
    actually just uses clusters.
    """
    edges = defaultdict(set)

    def relation_sort(relation):
        head = relation["head_span"]
        child = relation["child_span"]
        return (head["start"], head["end"], child["start"], child["end"])

    relations.sort(key=relation_sort)

    def spanify(x):
        return (x["start"], x["end"])

    for rel in relations:
        head = spanify(rel["head_span"])
        child = spanify(rel["child_span"])

        edges[head].add(child)
        edges[child].add(head)

    # Now find the clusters using dfs
    # key is span, value is cluster ID
    clusters = {}
    cluster_id = 1

    for node, connections in edges.items():
        if node in clusters:
            continue

        clusters[node] = cluster_id

        check = list(connections)
        while check:
            cnode = check.pop()
            if cnode in clusters:
                continue
            clusters[cnode] = cluster_id
            check.extend(edges[cnode])

        cluster_id += 1

    # Technically we don't have to do this, but gathering
    # the clusters here allows us to make sure we don't
    # overwrite anything later.
    cluster2spans = defaultdict(list)
    for span, cluster in clusters.items():
        cluster2spans[cluster].append(span)
    return cluster2spans


def create_coref_annotations(
    examples: List[TaskType],
    texts_by_input: Dict[int, str],
    *,
    labels: Set[str],
    validate: bool,
    coref_prefix: str = COREF_DEFAULT_PREFIX,
) -> Tuple[
    Dict[int, List[Tuple[int, int, str, str]]],
    Callable[[List[Tuple[int, int, str, str]], Doc], bool],
]:
    """Create annotations for the coref component.

    examples (List[dict]): The examples created with Prodigy.
    texts_by_input (Dict[int, str]): Mapping of input hashes to texts, will be
        updated in place if the examples contain hashes not present.
    coref_prefix (str): The prefix for the key in doc.spans that holds the
        training data.
    RETURNS (Dict, Callable): The generated offsets keyed by input hash,
        and a callable to set them on a Doc object.
    """
    coref_rels_by_input = {}
    for eg in validate_examples(examples, "coref", active=validate):
        relations = eg.get("relations", [])
        answer = eg.get("answer", "accept")
        if answer in ["ignore", "reject"]:
            continue

        # merge with other annotations from same texts
        input_hash = eg[INPUT_HASH_ATTR]
        texts_by_input.setdefault(input_hash, eg.get("text"))
        cached_rels = coref_rels_by_input.get(input_hash, [])
        # There may be duplicates here, but they'll be ignored in conversion
        cached_rels.extend(relations)
        coref_rels_by_input[input_hash] = cached_rels

    def set_annotations(coref_rels: List[Dict[str, Tuple[int, int]]], doc: Doc) -> bool:
        """
        input (List[Tuple]): Input generated from coref_by_input:
            a list of span offsets.
        doc (Doc): A Doc object to set the annotations on.
        RETURNS (bool): Whether the annotations could be set.
        """
        clusters = _convert_coref_to_clusters(coref_rels)
        for cidx, spans in clusters.items():
            spans_key = f"{coref_prefix}{cidx}"
            assert not doc.spans.get(spans_key)
            labels.add(spans_key)
            doc.spans[spans_key] = SpanGroup(doc, name=spans_key)
            for start, end in spans:
                span = doc.char_span(start, end)
                # tokenization mismatch, can't use annotation
                # TODO is this the right behavior?
                if span is None:
                    return False
                doc.spans[spans_key].append(span)
        return True

    return coref_rels_by_input, set_annotations


def create_textcat_annotations(
    examples: List[TaskType],
    texts_by_input: Dict[int, str],
    *,
    validate: bool,
    labels: Set[str],
    exclusive: bool = False,
) -> Tuple[Dict[int, Dict[str, float]], Callable[[Dict[str, float], Doc], bool]]:
    """Create annotation for the text classifier component.

    examples (List[dict]): The examples created with Prodigy.
    texts_by_input (Dict[int, str]): Mapping of input hashes to texts, will be
        updated in place if the examples contain hashes not present.
    validate (bool): Whether to validate examples.
    labels (Set[str]): The labels for the component. Will be updated in place.
    exclusive (bool): Whether the categories are exclusive.
    RETURNS (Dict, Callable): The generated dict of categories and scores keyed
        by input hash, and a callable to set them on a Doc object.
    """
    textcat_by_input = {}
    textcat_validated = validate_examples(examples, "textcat", active=validate)
    for eg in convert_options_to_cats(textcat_validated, exclusive=exclusive):
        input_hash = eg[INPUT_HASH_ATTR]
        texts_by_input.setdefault(input_hash, eg.get("text"))
        textcat_by_input.setdefault(input_hash, {})
        cats = eg.get("cats", {})
        textcat_by_input[input_hash].update(cats)
        labels.update(cats)

    def set_annotations(cats: Dict[str, float], doc: Doc) -> bool:
        """
        cats (Dict[str, float]): A generated annotation from textcat_by_input.
        doc (Doc): A Doc object to set the annotations on.
        RETURNS (bool): Whether the annotations could be set.
        """
        for label in labels:
            if label not in cats:
                cats[label] = 0.0
        doc.cats = cats
        return True

    return textcat_by_input, set_annotations


def create_pos_annotations(
    examples: List[TaskType],
    texts_by_input: Dict[int, str],
    *,
    validate: bool,
    labels: Set[str],
    missing_value: str = MISSING_VALUE,
) -> Tuple[Dict[int, List[str]], Callable[[List[str], Doc], bool]]:
    """Create annotation for the part-of-speech tagger component.
    examples (List[dict]): The examples created with Prodigy.
    texts_by_input (Dict[int, str]): Mapping of input hashes to texts, will be
        updated in place if the examples contain hashes not present.
    validate (bool): Whether to validate examples.
    labels (Set[str]): The labels for the component. Will be updated in place.
    missing_value (str): Tag to assign to unlabelled tokens.
    RETURNS (Dict, Callable): The generated list of token-based tags keyed
        by input hash, and a callable to set them on a Doc object.
    """
    pos_by_input = {}
    for eg in validate_examples(examples, "tagger", active=validate):
        input_hash = eg[INPUT_HASH_ATTR]
        n_tokens = len(eg.get("tokens", []))
        if not n_tokens or eg.get("answer", "accept") != "accept":
            continue
        texts_by_input.setdefault(input_hash, eg.get("text"))
        pos_by_input.setdefault(input_hash, [missing_value for i in range(n_tokens)])
        for span in eg.get("spans", []):
            not_accept = span.get("answer", "accept") != "accept"
            no_tokens = "token_start" not in span or "token_end" not in span
            # Continue if span has more than 1 token (note off-by-one)
            too_long = span["token_start"] != span["token_end"]
            mismatch = span["token_start"] >= len(pos_by_input[input_hash])
            if not_accept or no_tokens or too_long or mismatch:
                continue
            pos_by_input[input_hash][span["token_start"]] = span["label"]
            labels.add(span["label"])

    def set_annotations(tags: List[str], doc: Doc) -> bool:
        """
        tags (List[str]): A generated annotation from pos_by_input.
        doc (Doc): A Doc object to set the annotations on.
        RETURNS (bool): Whether the annotations could be set.
        """
        if len(doc) != len(tags):
            return False
        for idx, tag in enumerate(tags):
            if tag is not None:
                doc[idx].tag_ = tag
        return True

    return pos_by_input, set_annotations


def create_sent_annotations(
    examples: List[TaskType],
    texts_by_input: Dict[int, str],
    *,
    validate: bool,
    labels: Set[str],
    missing_value: str = MISSING_VALUE,
) -> Tuple[Dict[int, List[str]], Callable[[List[str], Doc], bool]]:
    """Create annotation for the part-of-speech senter component.

    examples (List[dict]): The examples created with Prodigy.
    texts_by_input (Dict[int, str]): Mapping of input hashes to texts, will be
        updated in place if the examples contain hashes not present.
    validate (bool): Whether to validate examples.
    labels (Set[str]): The labels for the component. Will be updated in place.
    missing_value (str): Tag to assign to unlabelled tokens.
    RETURNS (Dict, Callable): The generated list of token-based tags keyed
        by input hash, and a callable to set them on a Doc object.
    """
    sent_by_input = {}
    for eg in validate_examples(examples, "senter", active=validate):
        input_hash = eg[INPUT_HASH_ATTR]
        tokens = eg.get("tokens", [])
        # Since this is new, we can expect annotations to always have binary attr
        default_tag = missing_value if eg.get(BINARY_ATTR, False) else SENT_INSIDE_LABEL
        if not len(tokens) or eg.get("answer", "accept") != "accept":
            continue
        texts_by_input.setdefault(input_hash, eg.get("text"))
        sent_by_input.setdefault(input_hash, [default_tag for _ in range(len(tokens))])
        for span in eg.get("spans", []):
            not_accept = span.get("answer", "accept") != "accept"
            no_tokens = "token_start" not in span or "token_end" not in span
            mismatch = span["token_start"] >= len(sent_by_input[input_hash])
            if not_accept or no_tokens or mismatch:
                continue
            # If the user has annotated more than one token as the sent start
            # we can accept that and just use the first token
            sent_by_input[input_hash][span["token_start"]] = span["label"]
        # Make sure all labels are added if available, including inside label
        for label in sent_by_input[input_hash]:
            if label != missing_value:
                labels.add(label)

    def set_annotations(tags: List[str], doc: Doc) -> bool:
        """
        tags (List[str]): A generated annotation from sent_by_input.
        doc (Doc): A Doc object to set the annotations on.
        RETURNS (bool): Whether the annotations could be set.
        """
        if len(doc) != len(tags):
            return False
        for idx, tag in enumerate(tags):
            if tag == SENT_START_LABEL:
                doc[idx].is_sent_start = True
            elif tag == SENT_INSIDE_LABEL:
                doc[idx].is_sent_start = False
        return True

    return sent_by_input, set_annotations


def create_dep_annotations(
    examples: List[TaskType],
    texts_by_input: Dict[int, str],
    *,
    validate: bool,
    labels: Set[str],
) -> Tuple[
    Dict[int, Tuple[List[str], List[int]]],
    Callable[[Tuple[List[str], List[int]], Doc], bool],
]:
    """Create annotation for the dependency parser component.

    examples (List[dict]): The examples created with Prodigy.
    texts_by_input (Dict[int, str]): Mapping of input hashes to texts, will be
        updated in place if the examples contain hashes not present.
    validate (bool): Whether to validate examples.
    labels (Set[str]): The labels for the component. Will be updated in place.
    RETURNS (Dict, Callable): The generated tuples of token-based tags and head
        indices, keyed by input hash, and a callable to set them on a Doc object.
    """
    deps_heads_by_input = {}
    for eg in validate_examples(examples, "parser", active=validate):
        input_hash = eg[INPUT_HASH_ATTR]
        n_tokens = len(eg.get("tokens", []))
        arcs = eg.get("relations", eg.get("arcs", []))
        if not n_tokens or eg.get("answer") != "accept" or len(arcs) == 0:
            continue
        texts_by_input.setdefault(input_hash, eg.get("text"))
        default_tuple = (
            [MISSING_VALUE for _ in range(n_tokens)],
            [0 for _ in range(n_tokens)],
        )
        deps_heads_by_input.setdefault(input_hash, default_tuple)
        for arc in arcs:
            if arc["head"] >= n_tokens or arc["child"] >= n_tokens:
                continue
            deps_heads_by_input[input_hash][0][arc["child"]] = arc["label"]
            deps_heads_by_input[input_hash][1][arc["child"]] = arc["head"]
            labels.add(arc["label"])

    def set_annotations(deps_heads: Tuple[List[str], List[int]], doc: Doc) -> bool:
        """
        deps_heads (Tuple[List, List]): A generated annotation from deps_heads_by_input.
        doc (Doc): A Doc object to set the annotations on.
        RETURNS (bool): Whether the annotations could be set.
        """
        deps, heads = deps_heads
        if not (len(doc) == len(deps) == len(heads)):
            return False
        for idx, head in enumerate(heads):
            doc[idx].head = doc[head]
        for idx, dep in enumerate(deps):
            if dep is not None:
                doc[idx].dep_ = dep
        return True

    return deps_heads_by_input, set_annotations


# Registered as 'prodigy.MergedCorpus.v1' in setup.cfg
def create_merged_corpus(
    *,
    ner: Optional[Callable[[Dict], Tuple[Dict, Callable]]] = None,
    textcat: Optional[Callable[[Dict], Tuple[Dict, Callable]]] = None,
    textcat_multilabel: Optional[Callable[[Dict], Tuple[Dict, Callable]]] = None,
    parser: Optional[Callable[[Dict], Tuple[Dict, Callable]]] = None,
    tagger: Optional[Callable[[Dict], Tuple[Dict, Callable]]] = None,
    senter: Optional[Callable[[Dict], Tuple[Dict, Callable]]] = None,
    spancat: Optional[Callable[[Dict], Tuple[Dict, Callable]]] = None,
    experimental_coref: Optional[Callable[[Dict], Tuple[Dict, Callable]]] = None,
    eval_split: float = 0.2,
    sample_size: float = 1.0,
) -> Dict[str, Callable[[Language], Iterable[Example]]]:
    """Create a merged training corpus. Takes care of merging all annotations on
    the same text, and combining per-component evaluation examples. This reader
    can be used in a training config in the [corpora] block.

    *args (Callable): The corpus reader for the
        component.
    eval_split (float): Percentage of examples to hold back for evaluation if
        no dedicated evaluation set is provided for the component.
    sample_size (float): Percentage of examples to sample per component. Mostly
        relevant for the train curve to train of different portions of the data.
    RETURNS (Dict[str, Callable]): "train" and "dev" corpora, both callables that
        take the nlp object and yield Example objects, as required by spaCy.
    """
    # senter before parser so that the parser can override (albeit sometimes
    # badly) the sentence boundaries
    readers = {
        "ner": ner,
        "textcat": textcat,
        "textcat_multilabel": textcat_multilabel,
        "senter": senter,
        "parser": parser,
        "tagger": tagger,
        "spancat": spancat,
        "coref": experimental_coref,
    }
    readers = {name: reader for name, reader in readers.items() if reader is not None}
    logger.info(f"Components: {', '.join(readers)}")
    validate = get_config().get("validate", True)
    data = {}
    texts_by_input = {}
    eval_texts_by_input = {}
    labels = defaultdict(set)
    # We need to handle the train/eval examples, sample size and split within
    # the readers: each annotation type should be able to provide its own
    # evaluation sets, and if we want to use a sample size (e.g. 50% of all
    # examples for the train curve), we need to take this out of the component-
    # specific datasets *before* merging them. Otherwise, a sample of 50% may
    # end up with no NER examples if only some of the total texts come with
    # NER annotations.
    logger.info(f"Merging training and evaluation data for {len(readers)} components")
    for reader_name, reader in readers.items():
        data[reader_name] = reader(
            texts_by_input,
            eval_texts_by_input,
            labels=labels[reader_name],
            validate=validate,
            sample_size=sample_size,
            eval_split=eval_split,
        )
    train_tuples = [(text, i_hash) for i_hash, text in texts_by_input.items()]
    eval_tuples = [(text, i_hash) for i_hash, text in eval_texts_by_input.items()]
    logger.info(f"Training: {len(train_tuples)} | Evaluation: {len(eval_tuples)}")

    def parse_examples(
        nlp: Language,
        is_eval: bool,
    ) -> List[Example]:
        examples = []
        skipped = Counter()
        data_tuples = eval_tuples if is_eval else train_tuples
        with nlp.select_pipes(enable=["sentencizer"]):
            for gold_doc, input_hash in nlp.pipe(data_tuples, as_tuples=True):
                for name, (train_by_input, eval_by_input, set_annots) in data.items():
                    annots_by_input = eval_by_input if is_eval else train_by_input
                    if input_hash in annots_by_input:
                        offsets = annots_by_input[input_hash]
                        not_skipped = set_annots(offsets, gold_doc)
                        if not not_skipped:
                            skipped[name] += 1
                predicted_doc = nlp.make_doc(gold_doc.text)
                examples.append(Example(predicted_doc, gold_doc))
        for name, count in skipped.items():
            if count:
                logger.debug(f"Skipped {count} examples for '{name}'")
        return examples

    logger.info(f"Labels: {' | '.join(f'{n} ({len(c)})' for n, c in labels.items())}")
    for pipe, label_set in labels.items():
        logger.debug(f"  - [{pipe}] {', '.join(label_set)}")
    return {
        "train": partial(parse_examples, is_eval=False),
        "dev": partial(parse_examples, is_eval=True),
    }


def get_train_eval_examples(
    datasets: List[str],
    eval_datasets: List[str],
    *,
    eval_split: float = 0.0,
    sample_size: float = 1.0,
    pipe: Optional[str] = None,
    train_hashes: Optional[Set[int]] = None,
    eval_hashes: Optional[Set[int]] = None,
) -> Tuple[List[TaskType], List[TaskType]]:
    """Load examples from the datasets and generate training and evaluation data.
    Will try and use the eval_split if no dedicated evaluation sets were provided.

    datasets (List[str]): Names of training datasets.
    eval_datasets (List[str]): Names of evaluation datasets.
    eval_split (float): Percentage of examples to hold back for evaluation if
        no dedicated evaluation set is provided for the component.
        Examples pertaining to the same text are counted as one.
    sample_size (float): Percentage of training examples to sample per component.
        Mostly relevant for the train curve to train of different portions of the data.
    pipe (str): Name of pipeline component, only used for logging.
    train_hashes (Set[int]): Set of text hashes already in the training set.
    eval_hashes (Set[int]): Set of text hashes already in the dev set.
    RETURNS (Tuple[List, List]): The training and evaluation examples.
    """
    DB = connect()
    examples = load_examples(DB, datasets)
    if eval_datasets:
        eval_examples = load_examples(DB, eval_datasets)
    elif eval_split not in (1.0, 0.0):
        available_hashes = set()
        if not eval_hashes:
            eval_hashes = set()
        if not train_hashes:
            train_hashes = set()
        for eg in examples:
            text_hash = int(eg[INPUT_HASH_ATTR])
            if text_hash not in eval_hashes and text_hash not in train_hashes:
                available_hashes.add(text_hash)
        total_count = len(available_hashes) + len(train_hashes) + len(eval_hashes)
        available_hashes = list(available_hashes)
        random.shuffle(available_hashes)
        add_eval = max(0, int(total_count * eval_split) - len(eval_hashes))
        eval_hashes.update(available_hashes[:add_eval])
        train_hashes.update(available_hashes[add_eval:])
        eval_examples = [eg for eg in examples if eg[INPUT_HASH_ATTR] in eval_hashes]
        examples = [eg for eg in examples if eg[INPUT_HASH_ATTR] in train_hashes]
    else:
        eval_examples = []
    if sample_size != 1.0:
        examples = examples[: int(len(examples) * sample_size)]
    # Log data stats
    eval_info = "from datasets" if eval_datasets else f"{eval_split:.0%} split"
    sample_info = f" ({sample_size:.0%} sample)" if sample_size != 1.0 else ""
    train_text = f"{len(examples)}{sample_info}"
    eval_text = f"{len(eval_examples)} ({eval_info})"
    prefix = f"  - [{pipe}] " if pipe is not None else ""
    logger.info(f"{prefix}Training: {train_text} | Evaluation: {eval_text}")
    return examples, eval_examples


# Registered as 'prodigy.NERCorpus.v1' in setup.cfg
def create_ner_reader(
    datasets: List[str],
    eval_datasets: List[str],
    default_fill: SetEntsDefault = SetEntsDefault.missing,
    incorrect_key: str = NER_DEFAULT_INCORRECT_KEY,
) -> Callable:
    def read_ner_annotations(
        by_input: Dict[int, str],
        eval_by_input: Dict[int, str],
        *,
        labels: Set[str],
        validate: bool,
        sample_size: int,
        eval_split: float,
    ) -> Tuple[Dict[int, List[str]], Callable[[List[str], Doc], bool]]:
        examples, eval_examples = get_train_eval_examples(
            datasets,
            eval_datasets,
            sample_size=sample_size,
            eval_split=eval_split,
            pipe="ner",
            train_hashes=set(by_input.keys()),
            eval_hashes=set(eval_by_input.keys()),
        )
        kwargs = {
            "validate": validate,
            "default_fill": default_fill,
            "labels": labels,
            "incorrect_key": incorrect_key,
        }
        train, set_annots = create_ner_annotations(examples, by_input, **kwargs)
        check_binary_ner(train, default_fill)
        dev, _ = create_ner_annotations(eval_examples, eval_by_input, **kwargs)
        return train, dev, set_annots

    return read_ner_annotations


# Registered as 'prodigy.SpanCatCorpus.v1' in setup.cfg
def create_spancat_reader(
    datasets: List[str],
    eval_datasets: List[str],
    spans_key: str = SPANCAT_DEFAULT_KEY,
) -> Callable:
    def read_spancat_annotations(
        by_input, eval_by_input, *, labels, validate, sample_size, eval_split
    ):
        examples, eval_examples = get_train_eval_examples(
            datasets,
            eval_datasets,
            sample_size=sample_size,
            eval_split=eval_split,
            pipe="spancat",
            train_hashes=set(by_input.keys()),
            eval_hashes=set(eval_by_input.keys()),
        )
        kwargs = {
            "validate": validate,
            "labels": labels,
            "spans_key": spans_key,
        }
        train, set_annots = create_spancat_annotations(examples, by_input, **kwargs)
        dev, _ = create_spancat_annotations(eval_examples, eval_by_input, **kwargs)
        return train, dev, set_annots

    return read_spancat_annotations


# Registered as 'prodigy.CorefCorpus.v1' in setup.cfg
def create_coref_reader(
    datasets: List[str],
    eval_datasets: List[str],
    coref_prefix: str = COREF_DEFAULT_PREFIX,
) -> Callable:
    def read_coref_annotations(
        by_input, eval_by_input, *, labels, validate, sample_size, eval_split
    ):
        examples, eval_examples = get_train_eval_examples(
            datasets,
            eval_datasets,
            sample_size=sample_size,
            eval_split=eval_split,
            pipe="coref",
            train_hashes=set(by_input.keys()),
            eval_hashes=set(eval_by_input.keys()),
        )
        kwargs = {
            "validate": validate,
            "labels": labels,
            "coref_prefix": coref_prefix,
        }
        train, set_annots = create_coref_annotations(examples, by_input, **kwargs)
        dev, _ = create_coref_annotations(eval_examples, eval_by_input, **kwargs)
        return train, dev, set_annots

    return read_coref_annotations


# Registered as 'prodigy.TextCatCorpus.v1' in setup.cfg
def create_textcat_reader(
    datasets: List[str], eval_datasets: List[str], exclusive: bool = False
) -> Callable:
    def read_textcat_annotations(
        by_input: Dict[int, str],
        eval_by_input: Dict[int, str],
        *,
        labels: Set[str],
        validate: bool,
        sample_size: int,
        eval_split: float,
    ) -> Tuple[Dict[int, List[str]], Callable[[List[str], Doc], bool]]:
        examples, eval_examples = get_train_eval_examples(
            datasets,
            eval_datasets,
            sample_size=sample_size,
            eval_split=eval_split,
            pipe="textcat" if exclusive else "textcat_multilabel",
            train_hashes=set(by_input.keys()),
            eval_hashes=set(eval_by_input.keys()),
        )
        kwargs = {"validate": validate, "exclusive": exclusive, "labels": labels}
        train, set_annots = create_textcat_annotations(examples, by_input, **kwargs)
        dev, _ = create_textcat_annotations(eval_examples, eval_by_input, **kwargs)
        return train, dev, set_annots

    return read_textcat_annotations


# Registered as 'prodigy.TaggerCorpus.v1' in setup.cfg
def create_tagger_reader(
    datasets: List[str], eval_datasets: List[str], missing_value: str = MISSING_VALUE
) -> Callable:
    def read_tagger_annotations(
        by_input: Dict[int, str],
        eval_by_input: Dict[int, str],
        *,
        labels: Set[str],
        validate: bool,
        sample_size: int,
        eval_split: float,
    ) -> Tuple[Dict[int, List[str]], Callable[[List[str], Doc], bool]]:
        examples, eval_examples = get_train_eval_examples(
            datasets,
            eval_datasets,
            sample_size=sample_size,
            eval_split=eval_split,
            pipe="tagger",
            train_hashes=set(by_input.keys()),
            eval_hashes=set(eval_by_input.keys()),
        )
        kwargs = {
            "validate": validate,
            "labels": labels,
            "missing_value": missing_value,
        }
        train, set_annots = create_pos_annotations(examples, by_input, **kwargs)
        dev, _ = create_pos_annotations(eval_examples, eval_by_input, **kwargs)
        return train, dev, set_annots

    return read_tagger_annotations


# Registered as 'prodigy.SenterCorpus.v1' in setup.cfg
def create_senter_reader(
    datasets: List[str], eval_datasets: List[str], missing_value: str = MISSING_VALUE
) -> Callable:
    def read_senter_annotations(
        by_input: Dict[int, str],
        eval_by_input: Dict[int, str],
        *,
        labels: Set[str],
        validate: bool,
        sample_size: int,
        eval_split: float,
    ) -> Tuple[Dict[int, List[str]], Callable[[List[str], Doc], bool]]:
        examples, eval_examples = get_train_eval_examples(
            datasets,
            eval_datasets,
            sample_size=sample_size,
            eval_split=eval_split,
            pipe="senter",
            train_hashes=set(by_input.keys()),
            eval_hashes=set(eval_by_input.keys()),
        )
        kwargs = {
            "validate": validate,
            "labels": labels,
            "missing_value": missing_value,
        }
        train, set_annots = create_sent_annotations(examples, by_input, **kwargs)
        dev, _ = create_sent_annotations(eval_examples, eval_by_input, **kwargs)
        return train, dev, set_annots

    return read_senter_annotations


# Registered as 'prodigy.ParserCorpus.v1' in setup.cfg
def create_parser_reader(datasets: List[str], eval_datasets: List[str]) -> Callable:
    def read_parser_annotations(
        by_input: Dict[int, str],
        eval_by_input: Dict[int, str],
        *,
        labels: Set[str],
        validate: bool,
        sample_size: int,
        eval_split: float,
    ) -> Tuple[Dict[int, List[str]], Callable[[List[str], Doc], bool]]:
        examples, eval_examples = get_train_eval_examples(
            datasets,
            eval_datasets,
            sample_size=sample_size,
            eval_split=eval_split,
            pipe="parser",
            train_hashes=set(by_input.keys()),
            eval_hashes=set(eval_by_input.keys()),
        )
        kwargs = {"validate": validate, "labels": labels}
        train, set_annots = create_dep_annotations(examples, by_input, **kwargs)
        dev, _ = create_dep_annotations(eval_examples, eval_by_input, **kwargs)
        return train, dev, set_annots

    return read_parser_annotations


def infer_spancat_suggester(
    examples: List[TaskType], nlp: Language
) -> Dict[str, Union[str, List[int]]]:
    sizes = Counter()
    n_skipped = 0
    for eg in examples:
        doc = None
        for span in eg.get("spans", []):
            if "token_end" in span and "token_start" in span:
                # Correct for different indexing in Prodigy data
                index = span["token_end"] - span["token_start"] + 1
            else:
                if doc is None:  # only tokenize once if we have to
                    doc = nlp.make_doc(eg["text"])
                char_span = doc.char_span(span["start"], span["end"])
                if char_span is None:
                    n_skipped += 1
                    continue
                index = char_span.end - char_span.start
            sizes[index] += 1
    if n_skipped:
        msg.warn(
            f"Couldn't infer all 'spancat' sizes from data: skipped {n_skipped} "
            f"spans with mismatched tokenization"
        )
    if not len(sizes):
        raise RecipeError(
            "Couldn't set up 'spancat' component: no annotated spans found in the data"
        )
    spancat_sizes = list(sorted(sizes.keys()))
    min_size = min(spancat_sizes)
    max_size = max(spancat_sizes)
    suggester_func = "spacy.ngram_range_suggester.v1"
    logger.info(
        f"Using '{suggester_func}' for 'spancat' with sizes {min_size} to "
        f"{max_size} (inferred from data)"
    )
    info = "\n".join(f"  - {c} ({v} spans)" for c, v in sorted(sizes.items()))
    logger.debug(f"Sizes: {spancat_sizes}")
    logger.debug(info)
    return {
        "@misc": suggester_func,
        "min_size": min_size,
        "max_size": max_size,
    }


def check_binary_ner(
    train_data: Tuple[bool, List[Tuple]],
    default_fill: SetEntsDefault,
    threshold: float = 0.9,
) -> None:
    """Warn if the data doesn't contain sufficient complete/outside examples."""
    if len(train_data):
        counts = Counter()
        for binary, _ in train_data.values():
            counts[binary] += 1
        nr_missing = counts[True]
        if default_fill == SetEntsDefault.missing:
            nr_missing += counts[None]
        perc_missing = nr_missing / len(train_data)
        if perc_missing > threshold:
            msg.warn(
                f"Found {perc_missing:.0%} binary annotations in the "
                f"training dataset. Final performance may be enhanced by "
                f'mixing in more "complete" annotations that contain '
                f"examples of tokens that are definitely not an entity."
            )
