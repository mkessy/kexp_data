import copy
from typing import Callable, Iterable, List, Optional, Union

from spacy.language import Language
from spacy.pipeline._parser_internals.nonproj import contains_cycle
from spacy.tokens import Doc
from spacy.training import Example

from ..components.preprocess import add_tokens, get_token, split_sentences
from ..components.sorters import prefer_uncertain
from ..components.stream import get_stream
from ..core import Arg, recipe
from ..errors import RecipeError
from ..models.dep import DependencyParserModel
from ..protocols import ControllerComponentsDict
from ..types import LabelsType, SourceType, StreamType, TaskType
from ..util import get_pipe_labels, log, msg


@recipe(
    "dep.teach",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with a parser"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    unsegmented=Arg("--unsegmented", "-U", help="Don't split sentences"),
    # fmt: on
)
def teach(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    exclude: List[str] = [],
    unsegmented: bool = False,
) -> ControllerComponentsDict:
    """
    Collect the best possible training data for a dependency parsing model with
    the model in the loop. Based on your annotations, Prodigy will decide which
    questions to ask next.
    """
    log("RECIPE: Starting recipe dep.teach", locals())
    view_id = "dep"
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )
    labels = get_pipe_labels(label, nlp.pipe_labels.get("parser", []), allow_new=False)
    spacy_model = f"{nlp.meta['lang']}_{nlp.meta['name']}"
    log(f"RECIPE: Creating dependency parser annotation model using {spacy_model}")
    model = DependencyParserModel(nlp, label=labels)
    orig_nlp = model.orig_nlp
    if not unsegmented:
        stream.apply(split_sentences, nlp=orig_nlp, stream=stream)
    stream.apply(
        add_tokens, nlp=orig_nlp, stream=stream
    )  # add tokens for faster annotation
    stream.apply(lambda d: prefer_uncertain(model(d)))

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "update": model.update,
        "exclude": exclude,
        "config": {"lang": nlp.lang},
    }


@recipe(
    "dep.correct",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with a dependency parser"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    update=Arg("--update", "-UP", help="Whether to update the model during annotation"),
    wrap=Arg("--wrap", "-W", help="Wrap lines in the UI by default (instead of showing tokens in one row)"),
    unsegmented=Arg("--unsegmented", "-U", help="Don't split sentences"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    # fmt: on
)
def correct(
    dataset: str,
    nlp: Language,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    update: bool = False,
    wrap: bool = False,
    unsegmented: bool = False,
    exclude: List[str] = [],
) -> ControllerComponentsDict:
    """
    Create gold data for dependency parsing by correcting a model's suggestions.
    """
    log("RECIPE: Starting recipe dep.correct", locals())
    view_id = "relations"
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )
    labels = get_dep_labels(nlp, label)
    stream.apply(preprocess_stream, nlp=nlp, unsegmented=unsegmented, labels=labels)

    def validate_answer(answer: TaskType) -> None:
        # Don't allow parse annotations with multiple roots, if roots are
        # annotated
        roots = [rel["label"] for rel in answer["relations"] if rel["label"] == "ROOT"]
        if len(roots) != 1:
            err = f"A valid dependency parse needs to contain exactly one root (found {len(roots)})"
            raise ValueError(err)

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "update": get_update(nlp) if update else None,
        "validate_answer": validate_answer if "ROOT" in labels else None,
        "config": {
            "lang": nlp.lang,
            "exclude_by": "input",
            "labels": labels,
            "wrap_relations": wrap,
            "custom_theme": {"cardMaxWidth": "90%", "relationHeight": 150},
            "auto_count_stream": True,
        },
    }


def get_update(nlp: Language) -> Callable[[List[TaskType]], None]:
    def update(batch: List[TaskType]) -> None:
        examples = []
        for eg in batch:
            # Check for conflicts in the parse tree. The annotations may not
            # resolve to a valid parse. If not, don't update.
            if not _is_valid_parse(eg):
                continue
            if eg["answer"] != "accept":
                continue
            examples.append(_make_gold(nlp, eg))
        nlp.update(examples)

    return update


def get_dep_labels(nlp: Language, label: Optional[List[str]]):
    spacy_model = f"{nlp.meta['lang']}_{nlp.meta['name']}"
    if "parser" not in nlp.pipe_names:
        msg.warn(f"No 'parser' component found in pipeline of model '{spacy_model}'")
    labels = get_pipe_labels(label, nlp.pipe_labels.get("parser", []))
    if "ROOT" not in labels:
        if "root" in labels:
            labels[labels.index("root")] = "ROOT"
        else:
            msg.warn("Not annotating with a 'ROOT' label")
    return labels


def preprocess_stream(
    stream: StreamType, nlp: Language, *, unsegmented: bool, labels: Optional[List[str]]
) -> StreamType:
    data_tuples = ((eg["text"], eg) for eg in stream)
    for doc, eg in nlp.pipe(data_tuples, as_tuples=True, batch_size=10):
        if not doc.has_annotation("SENT_START") and not unsegmented:
            raise RecipeError(
                "Sentence boundaries unset"
                "Add a 'sentencizer' or parser to the model or set 'unsegmented' to True.",
            )
        sents = [doc[: len(doc) - 1]] if unsegmented else doc.sents
        for sent in sents:
            eg = copy.deepcopy(eg)
            tokens = []
            relations = []
            hidden_relations = []
            for i, token in enumerate(sent):
                t_obj = get_token(token, i)
                if not unsegmented:
                    # Adjust token boundaries to sentences
                    t_obj["start"] = t_obj["start"] - sent.start_char
                    t_obj["end"] = t_obj["end"] - sent.start_char  # Not an error
                tokens.append(t_obj)
                # Don't assume that first token's i == 0
                head_index = token.head.i - token.i + i
                rel = {"child": i, "head": head_index, "label": token.dep_}
                if labels is None or token.dep_ in labels:
                    relations.append(rel)
                else:
                    hidden_relations.append(rel)
            eg["text"] = sent.text
            eg["tokens"] = tokens
            eg["relations"] = relations
            # We need to save the extra relations, even if we don't display them,
            # so that we can recover the full parse later.
            eg["hidden_relations"] = hidden_relations
            # If the data has existing "spans", we need to remove them – otherwise
            # they will be merged in the relations UI
            if "spans" in eg:
                del eg["spans"]
            yield eg


def _make_gold(nlp: Language, eg: TaskType) -> Example:
    words = [token["text"] for token in eg["tokens"]]
    deps = [None] * len(words)
    heads = [None] * len(words)
    for rel in eg["hidden_relations"] + eg["relations"]:
        deps[rel["child"]] = rel["label"]
        heads[rel["child"]] = rel["head"]
    doc = Doc(nlp.vocab, words=words)
    return Example.from_dict(doc, {"words": words, "heads": heads, "deps": deps})


def _is_valid_parse(eg: TaskType) -> bool:
    """Check for multiple heads and cycles."""
    seen = set()
    heads = {}
    relations = eg.get("relations", [])
    for rel in relations:
        if rel["child"] in seen:
            return False
        seen.add(rel["child"])
        heads[rel["child"]] = rel["head"]
    try:
        if contains_cycle(heads):
            return False
    except KeyError:
        return False
    return True
