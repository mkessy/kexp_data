import copy
import random
from functools import partial
from typing import Callable, Dict, Iterable, List, Optional, Tuple, Union

from spacy.language import Language
from spacy.training import Example

from ..components.db import connect
from ..components.filters import filter_seen_before
from ..components.preprocess import (
    add_annot_name,
    add_label_options,
    add_labels_to_stream,
    add_tokens,
    add_view_id,
    convert_options_to_cats,
    make_raw_doc,
    make_textcat_suggestions,
    resolve_labels,
)
from ..components.sorters import prefer_uncertain
from ..components.stream import get_stream
from ..core import Arg, recipe
from ..errors import RecipeError
from ..models.matcher import PatternMatcher
from ..protocols import ControllerComponentsDict
from ..types import (
    ExistingFilePath,
    LabelsType,
    ScoredStreamType,
    SourceType,
    StreamType,
    TaskType,
)
from ..util import (
    ANNOTATOR_ID_ATTR,
    INPUT_HASH_ATTR,
    combine_models,
    get_pipe_labels,
    log,
    msg,
)


@recipe(
    "textcat.teach",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline or blank:lang (e.g. blank:en)"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    patterns=Arg("--patterns", "-pt", help="Path to match patterns file"),
    exclusive=Arg("--exclusive", "-E", help="Treat classes as mutually exclusive (if not set, an example can have multiple correct classes)"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    # fmt: on
)
def teach(
    dataset: str,
    nlp: Language,
    source: SourceType,
    label: LabelsType,
    patterns: Optional[ExistingFilePath] = None,
    loader: Optional[str] = None,
    exclusive: bool = False,
    exclude: List[str] = [],
) -> ControllerComponentsDict:
    """
    Collect the best possible training data for a text classification model
    with the model in the loop. Based on your annotations, Prodigy will decide
    which questions to ask next.
    """
    log("RECIPE: Starting recipe textcat.teach", locals())
    component = add_text_classifier(nlp, label, exclusive_classes=exclusive)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    predict = get_predict_binary(nlp, labels=label)
    update = get_update_binary(nlp, component=component, exclusive=exclusive)
    if patterns is None:
        predict = predict
        update = update
    else:
        matcher = PatternMatcher(
            nlp,
            prior_correct=5.0,
            prior_incorrect=5.0,
            label_span=False,
            label_task=True,
            filter_labels=label,
            combine_matches=True,
            task_hash_keys=("label",),
        )
        matcher = matcher.from_disk(patterns)
        log("RECIPE: Created PatternMatcher and loaded in patterns", patterns)
        # Combine the textcat model with the PatternMatcher to annotate both
        # match results and predictions, and update both models.
        predict, update = combine_models((predict, update), matcher)  # type: ignore
    stream.apply(lambda d: prefer_uncertain(predict(d)))

    return {
        "view_id": "classification",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "update": update,
        "config": {"lang": nlp.lang, "labels": label},
    }


@recipe(
    "textcat.manual",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    exclusive=Arg("--exclusive", "-E", help="Treat classes as mutually exclusive (if not set, an example can have multiple correct classes)"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    accept_empty=Arg("--accept-empty", "-ae", help="Accept empty choices"),
    # fmt: on
)
def manual(
    dataset: str,
    source: SourceType,
    label: LabelsType,
    loader: Optional[str] = None,
    exclusive: bool = False,
    exclude: List[str] = [],
    accept_empty: bool = False,
) -> ControllerComponentsDict:
    """
    Manually annotate categories that apply to a text. If more than one label
    is specified, categories are added as multiple choice options. If the
    --exclusive flag is set, categories become mutually exclusive, meaning that
    only one can be selected during annotation.
    """
    log("RECIPE: Starting recipe textcat.manual", locals())
    labels = label
    has_options = len(labels) > 1
    view_id = "choice" if has_options else "classification"
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )
    if has_options:
        stream.apply(add_label_options, stream=stream, labels=label)
    else:
        stream.apply(add_labels_to_stream, stream=stream, labels=label)
        if exclusive:
            # Use the dataset to decide what's left to annotate
            db = connect()
            if dataset in db:
                db_examples = db.get_dataset_examples(dataset)
                stream.apply(lambda d: filter_accepted_inputs(db_examples, d))

    add_validator = exclusive and has_options and (not accept_empty)
    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "validate_answer": validate_exclusive if add_validator else None,
        "config": {
            "labels": labels,
            "choice_style": "single" if exclusive else "multiple",
            "choice_auto_accept": exclusive,
            "exclude_by": "input" if has_options else "task",
            "auto_count_stream": True,
        },
    }


@recipe(
    "textcat.correct",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with a text classifier"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    update=Arg("--update", "-UP", help="Whether to update the model during annotation"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    threshold=Arg("--threshold", "-t", help="Score threshold to pre-select label, e.g. 0.75 to select all labels with a score of 0.75 and above"),
    component=Arg("--component", "-c", help="Name of text classifier component in the pipeline (will be guessed from pipeline if not set)"),
    accept_empty=Arg("--accept-empty", "-ae", help="Accept empty choices"),
    # fmt: on
)
def correct(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    update: bool = False,
    exclude: List[str] = [],
    threshold: float = 0.5,
    component: Optional[str] = None,
    accept_empty: bool = False,
) -> ControllerComponentsDict:
    """
    Correct the model's predicted categories that apply to a text. Prodigy will
    infer whether the categories should be mutualy exclusive based on the
    component configuration.
    """
    log("RECIPE: Starting recipe textcat.correct", locals())
    view_id = "choice"
    labels, exclusive = get_textcat_labels(nlp, label, component=component)
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )
    stream.apply(preprocess_stream, stream, nlp, labels=labels, threshold=threshold)
    # We only want to display a radio button if there's more than one label
    # otherwise, you couldn't unselect an exclusive label
    choice_style = "single" if exclusive and len(labels) > 1 else "multiple"
    add_validator = (choice_style == "single") and (not accept_empty)
    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "update": get_update(nlp) if update else None,
        "exclude": exclude,
        "validate_answer": validate_exclusive if add_validator else None,
        "config": {
            "choice_style": choice_style,
            "choice_auto_accept": choice_style == "single",
            "exclude_by": "input",
            "auto_count_stream": not update,
        },
    }


def validate_exclusive(eg: Dict) -> None:
    selected = eg.get("accept", [])
    if eg["answer"] == "accept":
        assert (
            len(selected) == 1
        ), "Answer got accepted but no choice was selected. Either select an option or use ignore/reject."


def get_textcat_labels(
    nlp: Language, label: Optional[List[str]], *, component: Optional[str] = None
) -> Tuple[List[str], bool]:
    component = get_textcat_component(nlp.pipe_names, component)
    exclusive = infer_exclusive(nlp, component)
    msg.info(
        f"Annotating {'exclusive' if exclusive else 'non-exclusive'} categories "
        f"based on '{component}' component config"
    )
    labels = get_pipe_labels(label, nlp.pipe_labels.get(component, []))
    return labels, exclusive


def preprocess_stream(
    stream: StreamType, nlp: Language, *, labels: List[str], threshold: float
) -> StreamType:
    texts = ((eg["text"], eg) for eg in stream)
    for doc, eg in nlp.pipe(texts, as_tuples=True, batch_size=10):
        task = copy.deepcopy(eg)
        options = []
        selected = []
        for cat, score in doc.cats.items():
            if cat in labels:
                options.append({"id": cat, "text": cat, "meta": f"{score:.2f}"})
                if score >= threshold:
                    selected.append(cat)
        task["options"] = options
        task["accept"] = selected
        yield task


def get_update(nlp: Language) -> Callable[[List[TaskType]], None]:
    def update(answers: List[TaskType]) -> None:
        log(f"RECIPE: Updating model with {len(answers)} answers")
        examples = []
        for eg in answers:
            if eg["answer"] == "accept":
                selected = eg.get("accept", [])
                cats = {
                    opt["id"]: 1.0 if opt["id"] in selected else 0.0
                    for opt in eg.get("options", [])
                }
                doc = make_raw_doc(nlp, eg)
                examples.append(Example.from_dict(doc, {"cats": cats}))
        nlp.update(examples)

    return update


def get_textcat_component(pipe_names: List[str], component: Optional[str]) -> str:
    components = ["textcat", "textcat_multilabel"]
    err = (
        "Can't find component {} in pipeline. Available components: {}. Make "
        "sure that the pipeline you're using includes a trained text classifier "
        "that you can correct. If your component has a different name, you can "
        "use the --component option to specify it."
    )
    if component is None:
        for pipe in components:
            if pipe in pipe_names:
                return pipe
        raise RecipeError(err.format(f"({', '.join(components)})", pipe_names))
    if component not in pipe_names:
        raise RecipeError(err.format(f"'{component}'", pipe_names))
    return component


def filter_accepted_inputs(examples: List[TaskType], stream: StreamType) -> StreamType:
    # If a single label is annotated with --exclusive, we only want to show
    # examples that aren't yet in the dataset or examples that were not yet
    # accepted (i.e. that we don't yet know the answer for).
    accepted = set()
    for eg in examples:
        if eg["answer"] == "accept":
            accepted.add(eg[INPUT_HASH_ATTR])
    for eg in stream:
        if eg[INPUT_HASH_ATTR] not in accepted:
            yield eg


def create_examples(nlp: "Language", labels: List[str]) -> List[Example]:
    doc = nlp.make_doc("This is an example document to support shape inference.")
    cats = {label: 1.0 for label in labels}
    train_examples = [Example.from_dict(doc, {"cats": cats})]
    return train_examples


def infer_exclusive(
    nlp: "Language", component: str, default_value: bool = True
) -> bool:
    """Infer whether categories are mutually exclusive based on the component."""
    if component not in nlp.pipe_names:
        raise RecipeError(
            f"Can't infer exclusive vs. non-exclusive categories from "
            f"'{component}': not in the pipeline. Available: {nlp.pipe_names}"
        )
    model_config = nlp.get_pipe_config(component).get("model", {})
    if model_config.get("@architectures", "") == "spacy.TextCatEnsemble.v2":
        return model_config.get("linear_model", {}).get(
            "exclusive_classes", default_value
        )
    return model_config.get("exclusive_classes", default_value)


def add_text_classifier(
    nlp: Language,
    labels: List[str],
    exclusive_classes: bool = False,
    sbd_name: str = "sentencizer",
) -> str:
    if "parser" not in nlp.pipe_names and sbd_name not in nlp.pipe_names:
        nlp.add_pipe(sbd_name)
    # Add model to pipeline, if we don't have one already.
    name = "textcat" if exclusive_classes else "textcat_multilabel"
    if name not in nlp.pipe_names:
        pipe = nlp.add_pipe(name)
        get_examples = partial(create_examples, nlp, labels)
        pipe.initialize(get_examples, nlp=nlp, labels=labels)
    else:
        # If the label set didn't change, keep the same component.
        # Otherwise, create and initialize a new one with all labels.
        pipe = nlp.get_pipe(name)
        if list(sorted(labels)) != sorted(pipe.labels):
            labels.extend(pipe.labels)
            pipe = nlp.replace_pipe(name, name)
            get_examples = partial(create_examples, nlp, labels)
            pipe.initialize(get_examples, nlp=nlp, labels=labels)
    return name


def get_predict_binary(
    nlp: Language, labels: List[str], batch_size: int = 32
) -> Callable[[StreamType], ScoredStreamType]:
    def predict(stream: StreamType) -> ScoredStreamType:
        # Make (text, context) tuples to pass into nlp.pipe
        # We get back (doc, context) tuples.
        data = ((eg["text"], eg) for eg in stream)
        data = nlp.pipe(data, batch_size=batch_size, as_tuples=True)
        for doc, eg in data:
            for label in labels:
                doc_score = doc.cats[label]
                task = copy.deepcopy(eg)
                task.update(
                    {
                        "text": doc.text,
                        "label": label,
                        "score": doc.cats[label],
                        "priority": doc.cats[label],
                        "spans": [],
                    }
                )
                task.setdefault("meta", {})
                task["meta"]["score"] = doc_score
                yield task["priority"], task

    return predict


def get_update_binary(
    nlp: Language,
    *,
    component: str,
    exclusive: bool = False,
    revise: bool = False,
    drop: float = 0.0,
) -> Callable[[List[TaskType]], float]:
    history = []

    def _update(
        texts: List[str],
        cats_dicts: List[Dict[str, float]],
        losses: Dict[str, float],
        drop: float = 0.0,
    ) -> None:
        docs = list(nlp.pipe(texts, batch_size=64))
        examples = [
            Example.from_dict(doc, {"cats": cats})
            for doc, cats in zip(docs, cats_dicts)
        ]
        with nlp.select_pipes(enable=["transformer", "tok2vec", component]):
            nlp.update(examples, losses=losses, drop=drop)

    def update(examples: List[TaskType]) -> float:
        examples = convert_options_to_cats(examples, exclusive=exclusive)
        examples = [eg for eg in examples if eg["answer"] != "ignore"]
        if not examples:
            return 0.0
        texts = [eg["text"] for eg in examples]
        cats_dicts = []
        for eg in examples:
            if "cats" in eg:
                cats_dicts.append(eg["cats"])
            else:
                cats_dicts.append({})
                if eg["answer"] == "accept":
                    cats_dicts[-1][eg["label"]] = 1.0
                elif eg["answer"] == "reject":
                    cats_dicts[-1][eg["label"]] = 0.0
        losses = {}
        _update(texts, cats_dicts, losses, drop=drop)
        if revise and len(history) >= len(examples):
            while random.random() >= 0.2:
                random.shuffle(history)
                old_texts, old_cats = zip(*history[: len(examples)])
                _update(old_texts, old_cats, losses, drop=drop)
        history.extend(zip(texts, cats_dicts))
        loss = losses.get("textcat", 0.0)
        return loss

    return update


@recipe(
    "textcat.model-annotate",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with an entity recognizer"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    model_alias=Arg(help="Annotator alias on behalf of the model"),
    labels=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    threshold=Arg("--threshold", "-t", help="Set the threshold of the classification model"),
    component=Arg("--component", "-c", help="Name of NER component in the pipeline"),
    # fmt: on
)
def textcat_model_annotate(
    dataset: str,
    nlp: Language,
    source: Union[str, Iterable[dict]],
    model_alias: str,
    labels: Optional[List[str]] = None,
    loader: Optional[str] = None,
    threshold: Optional[float] = 0.5,
    component: Optional[str] = None,
) -> None:
    """
    Generates annotations directly via a model.
    """
    log("RECIPE: Starting recipe textcat.model-annotate", locals())

    stream = get_stream(source, loader=loader, rehash=True, input_key="text")
    # TODO: Counting all the items in a stream might go awry for _huge_ files.
    #       We should come back to this later with a utility function
    total = sum(1 for _ in stream.copy())

    if not component:
        textcat_in = "textcat" in nlp.pipe_names
        textcat_multi_in = "textcat_multilabel" in nlp.pipe_names
        if textcat_in and textcat_multi_in:
            msg.fail(
                "Both `textcat` and `textcat_multilabel` components in pipeline. Please specify the component.",
                exits=True,
            )
        if textcat_in:
            component = "textcat"
        elif textcat_multi_in:
            component = "textcat_multilabel"
        else:
            msg.fail(
                "Neither `textcat` nor `textcat_multilabel` components found in pipeline. Please specify the component.",
                exits=True,
            )
    labels = resolve_labels(nlp, component, recipe_labels=labels)

    # If the dataset already exists we should make sure that there we don't add duplicates
    db = connect()
    if dataset in db.datasets:
        already_annotated = (
            ex
            for ex in db.iter_dataset_examples(dataset)
            if ex[ANNOTATOR_ID_ATTR] == model_alias
        )
        stream.apply(filter_seen_before, stream=stream, cache_stream=already_annotated)

    stream.apply(
        make_textcat_suggestions,
        stream=stream,
        nlp=nlp,
        component=component,
        threshold=threshold,
        labels=labels,
        show_progress_bar=True,
        progress_bar_total=total,
    )
    stream.apply(add_tokens, nlp=nlp, stream=stream)
    stream.apply(add_annot_name, name=model_alias)

    # we're adding view_id here to make sure we can compute IAA metrics
    # for the LLM annotations.
    # IAA metrics require that all annotations were completed with the same
    # view_id to ensure the consistency of annotation conditions.
    stream.apply(
        add_view_id, view_id="classification" if len(labels) == 1 else "choice"
    )

    db = connect()
    # The "user" can also be seen as a session, so make sure we add that
    db.add_dataset(model_alias, session=True)
    # Write the examples to the dataset and session set
    db.add_examples(stream, [dataset, model_alias])
