# pyright: reportGeneralTypeIssues=false

from collections import Counter
from pathlib import Path
from typing import List, Literal, Optional, Union

import srsly
import tqdm
from spacy.language import Language

from .._util import color, log, msg
from ..components import printers
from ..components.db import connect
from ..components.stream import get_stream
from ..core import Arg, Controller, recipe
from ..errors import RecipeError
from ..models.matcher import PatternMatcher
from ..protocols import ControllerComponentsDict
from ..types import (
    ExistingFilePath,
    LabelsType,
    SourceType,
    StreamType,
)
from ..util import VIEW_ID_ATTR, get_timestamp_session_id, set_hashes


@recipe(
    "mark",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    view_id=Arg("--view-id", "-v", help="Annotation interface to use"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    # fmt :on
)
def mark(
    dataset: str,
    source: SourceType,
    view_id: Optional[str],
    label: Optional[LabelsType] = None,
    loader: Optional[str] = None,
    exclude: List[str] = [],
) -> ControllerComponentsDict:
    """
    Click through pre-prepared examples, with no model in the loop.
    """
    log("RECIPE: Starting recipe mark", locals())
    # We are forcing the hashing twice in this recipe. The first time it's to
    # prevent the warning message, the second time is to ensure that we actually use
    # the provided labels as part of the task hash.
    stream = get_stream(source, loader=loader, rehash=True, view_id=view_id)

    def ask_questions(stream: StreamType) -> StreamType:
        for eg in stream:
            if label and len(label) == 1:
                eg["label"] = label[0]
            elif label and len(label) > 1:
                eg["options"] = [{"id": lab, "text": lab} for lab in label]
            yield eg

    def print_results(ctrl: Controller) -> None:
        examples = ctrl.db.get_dataset_examples(ctrl.session_id)
        if examples:
            counts = Counter()
            for eg in examples:
                counts[eg["answer"]] += 1
            for key in ["accept", "reject", "ignore"]:
                if key in counts:
                    msg.row([key.title(), color(str(counts[key]), key)], widths=10)

    def apply_hashes(stream: StreamType):
        for e in stream:
            yield set_hashes(e, overwrite=True)

    stream.apply(ask_questions)
    stream.apply(apply_hashes)

    # Add label or label set to config if available
    config = {}
    if label and len(label) == 1:
        config["label"] = label[0]
    elif label and len(label) > 1:
        config["labels"] = label

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "on_exit": print_results,
        "config": config,
    }


@recipe(
    "match",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline or blank:lang (e.g. blank:en)"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    patterns=Arg("--patterns", "-pt", help="Path to match patterns file"),
    label_task=Arg("--label-task", "-LT", help="Assign the matched label to the task"),
    label_span=Arg("--label-span", "-LS", help="Assign the matched label to the matched span"),
    combine_matches=Arg("--combine-matches", "-C", help="Combine all matches and only show an example once"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    # fmt: on
)
def match(
    dataset: str,
    nlp: Language,
    source: SourceType,
    label: LabelsType,
    patterns: ExistingFilePath,
    loader: Optional[str] = None,
    label_task: bool = False,
    label_span: bool = False,
    combine_matches: bool = False,
    exclude: List[str] = [],
) -> ControllerComponentsDict:
    """Match patterns on a source of text."""
    log("RECIPE: Starting recipe match", locals())
    view_id = "classification" if label_task else "ner"
    matcher = PatternMatcher(
        nlp,
        label_span=label_span,
        label_task=label_task,
        filter_labels=label,
        combine_matches=combine_matches,
        task_hash_keys=("label",),
    )
    matcher = matcher.from_disk(patterns)
    log("RECIPE: Created PatternMatcher and loaded in patterns", patterns)
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )

    def remove_scores(stream: StreamType, matcher: PatternMatcher):
        for _, eg in matcher(stream):
            yield eg

    stream.apply(remove_scores, matcher=matcher)

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {"lang": nlp.lang, "auto_count_stream": True},
    }


@recipe(
    "filter-by-patterns",
    # fmt: off
    source=Arg(help="Data to filter (file path or '-' to read from standard input)"),
    output=Arg(help="Path to .jsonl file, or dataset, to write subset into"),
    nlp=Arg(help="Loadable spaCy pipeline or blank:lang (e.g. blank:en)"),
    patterns=Arg("--patterns", "-pt", help="Path to match patterns file"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to select subset of patterns"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    # fmt: on
)
def filter_by_patterns(
    source: SourceType,
    output: Union[str, Path],
    nlp: Language,
    patterns: ExistingFilePath,
    label: Optional[LabelsType] = None,
    loader: Optional[str] = None,
) -> None:
    """
    Filter the dataset based on a patterns.jsonl file. Can be useful to reduce
    a dataset down to an interesting subset for ner/textcat/spancat.
    """
    log("RECIPE: Starting recipe custom.filter", locals())
    matcher = PatternMatcher(
        nlp,
        prior_correct=5.0,
        prior_incorrect=5.0,
        label_span=False,
        label_task=False,
        filter_labels=label,
        combine_matches=True,
        task_hash_keys=("label",),
    )

    matcher = matcher.from_disk(patterns)
    if label:
        # If the user has a typo, they'd want to know about it before a large dataset is filtered.
        for lab in label:
            if lab not in matcher.labels:
                raise RecipeError(f"Label '{lab}' does not appear in patterns file")

    log("RECIPE: Created PatternMatcher and loaded in patterns", patterns)

    # Using it.tee to keep memory lightweight in the case that the original file
    # is huge. The `tee` iterator is not threadsafe, but since this stream does not
    # need to worry about multiple annotators it seems safe to use here.
    stream = get_stream(source, loader=loader, rehash=False, dedup=False)
    stream_copy = stream.copy_restarted()
    # We need the total for the progress bar
    total = sum(1 for _ in stream_copy)
    stream = (ex for _, ex in matcher(tqdm.tqdm(stream, total=total)))  # type: ignore

    if str(output).endswith(".jsonl"):
        log("RECIPE: Writing stream to file ", output)
        srsly.write_jsonl(output, stream)
    else:
        log("RECIPE: Writing stream to Prodigy dataset", output)
        output = str(output)
        DB = connect()
        session_id = get_timestamp_session_id()
        if output not in DB:
            DB.add_dataset(output)
            msg.good(f"Created dataset '{output}' in database {DB.db_name}")
        DB.add_dataset(session_id, session=True)
        DB.add_examples(list(stream), datasets=[output, session_id])


@recipe(
    "print-dataset",
    dataset=Arg(help="Dataset to print"),
    style=Arg("--style", "-s", help="Annotation type"),
)
def print_dataset(
    dataset: str, style: Literal["auto", "text", "textcat", "spans"] = "auto"
) -> None:
    """
    Pretty-print annotations from a given dataset on the command line. Supports
    plain text, text classification and NER annotations. If no `--type` is
    specified, Prodigy will try to infer it from the data via the `"_view_id"`
    that's automatically added since v1.8.
    """
    log("RECIPE: Starting recipe print-dataset", locals())
    # fmt: off
    spans_ids = ["ner", "ner_manual", "pos", "pos_manual"]
    textcat_ids = ["classification", "choice"]
    text_ids = ["text"]
    # fmt: on
    DB = connect()
    if dataset not in DB:
        raise RecipeError(f"Can't find dataset '{dataset}'")
    examples = DB.get_dataset_examples(dataset)
    if not examples:
        raise RecipeError(f"Can't load '{dataset}' from database {DB.db_name}")
    if style == "auto":
        log("RECIPE: Getting output style and view ID based on first example")
        view_id = examples[0].get(VIEW_ID_ATTR)
        if not view_id:
            err = "Use the --style option to set text, spans or textcat"
            raise RecipeError("No view ID found in data", err)
        elif view_id in textcat_ids:
            style = "textcat"
        elif view_id in spans_ids:
            style = "spans"
        elif view_id in text_ids:
            style = "text"
        else:
            supported = f"Supported: {','.join(spans_ids + textcat_ids + text_ids)}"
            raise RecipeError(f"Unsupported view ID: '{view_id}'", supported)
    printers.pretty_print(iter(examples), views=[style])


@recipe(
    "print-stream",
    nlp=Arg(help="Loadable spaCy pipeline"),
    source=Arg(help="Source data (file path)"),
    loader=Arg(help="Loader (guessed from file extension if not set)"),
)
def print_stream(
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
) -> None:
    """
    Pretty-print the model's predictions on the command line. Supports named
    entities and text categories and will display the annotations if the model
    components are available. For textcat annotations, only the category with the
    highest score is shown if the score is greater than 0.5.
    """
    log("RECIPE: Starting recipe print-stream", locals())

    def make_examples(stream: StreamType, nlp: Language) -> StreamType:
        data_tuples = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(data_tuples, as_tuples=True, batch_size=10):
            eg["spans"] = [
                {"start": e.start_char, "end": e.end_char, "label": e.label_}
                for e in doc.ents
            ]
            if doc.cats:
                max_cat = max(doc.cats, key=doc.cats.get)  # type: ignore
                eg["label"] = max_cat if doc.cats[max_cat] > 0.5 else "none"
            yield eg

    views = []
    if "ner" in nlp.pipe_names:
        views.append("spans")
    if "textcat" in nlp.pipe_names:
        views.append("textcat")
    log(f"RECIPE: Pretty-printing for views {views}")
    stream = get_stream(source, loader=loader, rehash=True, input_key="text")
    stream = make_examples(stream, nlp)
    printers.pretty_print(stream, views=views)
