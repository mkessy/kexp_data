from typing import (
    Dict,
    List,
    Literal,
    Optional,
    Union,
)

import numpy as np
from wasabi import msg
from wasabi.tables import table

from prodigy.components.metrics.errors import MetricError
from prodigy.components.metrics.iaa_doc import IaaDoc, IaaDocStats
from prodigy.components.metrics.iaa_span import IaaSpan, IaaSpanStats
from prodigy.components.stream import get_stream
from prodigy.types import LabelsType, SourceType

from ..core import Arg, recipe


def print_descriptives(iaa_stats: Union[IaaDocStats, IaaSpanStats]) -> None:
    data = {
        "Examples": iaa_stats.n_examples,
        "Categories": iaa_stats.n_categories,
        "Co-Incident Examples*": iaa_stats.n_coincident_examples,
        "Single Annotation Examples": iaa_stats.n_single_annotation,
        "Annotators": iaa_stats.n_annotators,
        "Avg. Annotations per Example": round(iaa_stats.avg_raters_per_example, 2),
    }
    aligns = ("l", "r")
    formatted = table(data, header=("Attribute", "Value"), divider=True, aligns=aligns)
    formatted += "\n* (>1 annotation)"

    msg.info("Annotation Statistics")
    print(formatted)  # noqa: T201
    print()  # noqa T201


def print_doc_stats(iaa_stats: IaaDocStats, label: Optional[str] = None) -> None:
    data = {
        "Percent (Simple) Agreement": round(iaa_stats.percent_agreement, 4),
        "Krippendorff's Alpha": round(iaa_stats.kripp_alpha, 4),
        "Gwet's AC2": round(iaa_stats.gwet_ac2, 4),
    }
    aligns = ("l", "r")
    formatted = table(data, header=("Statistic", "Value"), divider=True, aligns=aligns)
    if label or label == 0:
        msg.info("Agreement Statistics for Label: {}".format(label))
    else:
        msg.info("Agreement Statistics")
    print(formatted)  # noqa: T201
    print()  # noqa T201


def print_cm(cm: np.ndarray, labels: List[str]) -> None:
    # we want to show the "0" in the cm as None
    labels = labels + ["NONE"]
    data = []
    for idx, cm_row in enumerate(cm):
        table_row = [labels[idx]]
        for val in cm_row:
            val = round(val, 2)
            if val == "0.00":
                val = "-"
            table_row.append(val)
        data.append(tuple(table_row))
    aligns = ("l", "l", "l", "l")
    header = [""]
    header.extend([label for label in labels])
    formatted = table(
        data, header=tuple(header), divider=True, aligns=aligns, spacing=2
    )
    print(formatted)  # noqa T201


def print_spans_stats(iaa_stats: IaaSpanStats) -> None:
    data = [
        (label, round(metric["f1"], 2), int(metric["support"]))
        for label, metric in iaa_stats.metrics_per_label.items()
    ]
    aligns = ("l", "r")
    formatted = table(
        data, header=("Category", "Pairwise F1", "Support"), divider=True, aligns=aligns
    )
    msg.info("Agreement Statistics", spaced=True)
    print(formatted)  # noqa T201
    msg.info("Confusion matrix", spaced=True)
    labels = list(iaa_stats.metrics_per_label.keys())
    print_cm(iaa_stats.normalized_confusion_matrix, labels)
    print()  # noqa T201


def to_console(results: Union[Dict, IaaSpanStats], annotation_type: str) -> None:
    """Pretty print the results of the metric to console."""
    if annotation_type in ("binary", "multiclass"):
        assert isinstance(results, dict)
        print_descriptives(results["_all"])
        print_doc_stats(results["_all"])
    elif annotation_type == "multilabel":
        assert isinstance(results, dict)
        labels = list(results.keys())
        print_descriptives(results[labels[0]])
        for label, stats in results.items():
            print_doc_stats(stats, label)
    elif annotation_type == "spans":
        assert isinstance(results, IaaSpanStats)
        print_descriptives(results)
        print_spans_stats(results)
    msg.info(
        "For more information on the interpretation of the results please consult the docs at  https://prodi.gy/docs/metrics"
    )


@recipe(  # type: ignore
    "metric.iaa.doc",
    # fmt: off
    source=Arg(help="Name of a Prodigy dataset (dataset:{dataset_name}) or path to JSONL file or a dir with JSONL files"),
    annotation_type=Arg(help="The type of annotation."),
    loader=Arg("--loader", "-lo", help="Loader to use"),
    labels=Arg("--labels", "-l", help="Comma separated list of labels"),
    annotators=Arg("--annotators", "-a", help="Comma separated list of annotators to use for the metric"),
    output=Arg("--output", "-o", help="Path to write the results to"),
    # fmt: on
)
def metric_iaa_doc(
    source: SourceType,
    annotation_type: Literal["binary", "multiclass", "multilabel"],
    loader: Optional[str] = None,
    labels: Optional[LabelsType] = None,
    annotators: Optional[List[str]] = None,
    output: Optional[str] = None,
) -> None:
    """Compute a document level IAA metric on Prodigy dataset."""
    m = IaaDoc(annotation_type=annotation_type, labels=labels, annotators=annotators)
    stream = get_stream(source, loader=loader, rehash=False)
    try:
        m.measure(stream)
    except MetricError as e:
        msg.fail(e.msg, exits=True)
    result: Dict = m.get_result()
    to_console(result, annotation_type)
    if output:
        m.to_disk(output)


@recipe(  # type: ignore
    "metric.iaa.binary",
    # fmt: off
    source=Arg(help="Name of a Prodigy dataset (dataset:{dataset_name}) or path to JSONL file or a dir with JSONL files"),
    loader=Arg("--loader", "-l", help="Loader to use"),
    annotators=Arg("--annotators", "-a", "Comma separated list of annotators to use for the metric"),
    output=Arg("--output", "-o", help="Path to write the results to"),
    # fmt: on
)
def metric_iaa_binary(
    source: SourceType,
    loader: Optional[str] = None,
    annotators: Optional[List[str]] = None,
    output: Optional[str] = None,
) -> None:
    """
    Compute inter-annotator over binary accept/reject decisions on a single or multiple Prodigy datasets or JSONL files and
    print results to console.
    """
    metric_iaa_doc(
        source,
        "binary",
        loader=loader,
        annotators=annotators,
        output=output,
    )


@recipe(  # type: ignore
    "metric.iaa.span",
    # fmt: off
    source=Arg(help="Name of a Prodigy dataset (dataset:{dataset_name}) or path to JSONL file or a dir with JSONL files"),
    loader=Arg("--loader", "-lo", help="Loader to use"),
    labels=Arg("--labels", "-l", help="Comma separated list of labels"),
    annotators=Arg("--annotators", "-a", help="Comma separated list of annotators to use for the metric"),
    partial=Arg("--partial", "-P", help="Consider partial matches"),
    output=Arg("--output", "-o", help="Path to write the results to"),
    # fmt: on
)
def metric_iaa_span(
    source: SourceType,
    loader: Optional[str] = None,
    labels: Optional[LabelsType] = None,
    annotators: Optional[List[str]] = None,
    partial: bool = False,
    output: Optional[str] = None,
) -> None:
    """
    Compute span level inter-annotator agreement on a Prodigy dataset or JSONL file(s) and
    print results to console.
    """
    m = IaaSpan(labels=labels, annotators=annotators, partial=partial)
    stream = get_stream(source, loader=loader, rehash=False, input_key="text")
    try:
        m.measure(stream)
    except MetricError as e:
        msg.fail(e.msg, exits=True)

    result: IaaSpanStats = m.get_result()
    to_console(result, "spans")
    if output:
        m.to_disk(output)
