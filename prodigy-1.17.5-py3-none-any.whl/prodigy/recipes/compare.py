# pyright: reportGeneralTypeIssues=false
import random
from collections import Counter
from pathlib import Path
from typing import Callable

import srsly

from ..core import Arg, Controller, recipe
from ..protocols import ControllerComponentsDict
from ..types import ExistingFilePath, StreamType
from ..util import log, msg, set_hashes


@recipe(
    "compare",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    a_file=Arg(help="JSONL file for system responses"),
    b_file=Arg(help="JSONL file for baseline responses"),
    no_random=Arg("--no-random", "-NR", help="Don't randomize which annotation is shown as correct"),
    diff=Arg("--diff", "-D", help="Show examples as visual diff"),
    # fmt: on
)
def compare(
    dataset: str,
    a_file: ExistingFilePath,
    b_file: ExistingFilePath,
    no_random: bool = False,
    diff: bool = False,
) -> ControllerComponentsDict:
    """
    Compare output of two models and randomly assign A/B categories.
    """
    log("RECIPE: Starting recipe compare", locals())
    a_questions = srsly.read_jsonl(a_file)
    b_questions = srsly.read_jsonl(b_file)
    stream = get_questions(a_questions, b_questions, not no_random, diff)
    on_exit = get_printer(Path(a_file).name, Path(b_file).name)

    return {
        "dataset": dataset,
        "view_id": "diff" if diff is True else "choice",
        "stream": stream,
        "progress": None,
        "on_exit": on_exit,
        "config": {
            "auto_exclude_current": False,
            "choice_auto_accept": True,
            "auto_count_stream": True,
        },
    }


def get_questions(
    a_questions: StreamType,
    b_questions: StreamType,
    randomize: bool = False,
    diff: bool = False,
) -> StreamType:
    a_questions = {a["id"]: a for a in a_questions}
    b_questions = {b["id"]: b for b in b_questions}
    for id_, a in a_questions.items():
        if id_ not in b_questions:
            continue
        question = {
            **a["input"],
            "input": a["input"],
            "id": id_,
            "A": a["output"],
            "B": b_questions[id_]["output"],
        }
        if question["A"] == question["B"]:
            continue
        if randomize and random.random() >= 0.5:
            question["mapping"] = {"B": "accept", "A": "reject"}
        else:
            question["mapping"] = {"A": "accept", "B": "reject"}
        # Add options for choice interface
        question["options"] = []
        for key, answer in question["mapping"].items():
            option = question[key]
            option["id"] = key
            question["options"].append(option)
            if diff:
                question[answer] = option
        yield set_hashes(question)


def get_printer(a_file_name: str, b_file_name: str) -> Callable[[Controller], None]:
    filenames = {"A": a_file_name, "B": b_file_name}

    def _format_printer(ctrl: Controller) -> None:
        examples = ctrl.db.get_dataset_examples(ctrl.dataset)
        counts = Counter()
        answers = {}
        # Get last example per ID
        for eg in examples:
            if "answer" not in eg or "mapping" not in eg:
                continue
            if "reject" not in eg:  # task created with choice UI
                selected = eg.get("accept", [])
                if not selected or len(selected) != 1 or eg["answer"] != "accept":
                    continue
                eg["answer"] = eg["mapping"].get(selected[0])
            answers[eg["id"]] = (eg["answer"], eg["mapping"])
        for answer, mapping in answers.values():
            if answer == "ignore":
                counts["ignore"] += 1
            else:
                inverse = {v: k for k, v in mapping.items()}
                answer = inverse[answer]
                counts[answer] += 1
        print("")  # noqa: T201
        log(f"RECIPE: Calculating results with counts {counts}")
        if not counts:
            msg.warn("No answers found", exits=0)
        msg.divider("Evaluation results", icon="emoji")
        pref, _ = counts.most_common(1)[0]
        if counts["A"] == counts["B"]:
            msg.info("You had no preference")
            pref = None
        else:
            msg.good(f"You preferred {pref} ({filenames.get(pref)})")
        rows = [
            ("A", counts["A"], filenames.get("A")),
            ("B", counts["B"], filenames.get("B")),
            ("Ignored", counts["ignore"], ""),
            ("Total", sum(counts.values()), ""),
        ]
        msg.table(rows, aligns=("l", "r", "l"))

    return _format_printer
