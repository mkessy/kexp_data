import copy
from typing import Callable, List, Optional, Tuple

from spacy.language import Language
from spacy.tokens import Doc
from spacy.training import Example

from ..components.decorators import support_both_streams
from ..components.preprocess import add_tokens, split_sentences
from ..components.sorters import prefer_uncertain
from ..components.stream import get_stream
from ..core import Arg, recipe
from ..protocols import ControllerComponentsDict
from ..types import (
    LabelsType,
    ScoredStreamType,
    SourceType,
    StreamType,
    TaskType,
)
from ..util import (
    BINARY_ATTR,
    INPUT_HASH_ATTR,
    MISSING_VALUE,
    ensure_component,
    get_pipe_labels,
    log,
    pos_to_neg_label,
    set_hashes,
)


@recipe(
    "pos.teach",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with a tagger"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    unsegmented=Arg("--unsegmented", "-U", help="Don't split sentences"),
    no_filter=Arg("--no-filter", "-NF", help="Don't filter by uncertainty"),
    # fmt: on
)
def teach(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    exclude: List[str] = [],
    unsegmented: bool = False,
    no_filter: bool = False,
) -> ControllerComponentsDict:
    """
    Collect the best possible training data for a part-of-speech tagging
    model with the model in the loop. Based on your annotations, Prodigy will
    decide which questions to ask next.
    """
    log("RECIPE: Starting recipe pos.teach", locals())
    component = "tagger"
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    ensure_component(nlp, component)
    nlp = normalize_softmax_outputs(nlp, component)
    labels = get_pipe_labels(label, nlp.pipe_labels.get(component, []), allow_new=False)
    if not unsegmented:
        stream.apply(split_sentences, nlp=nlp, stream=stream)
    stream.apply(add_tokens, nlp=nlp, stream=stream)

    def remove_score(scored_stream: ScoredStreamType) -> StreamType:
        for _, eg in scored_stream:
            yield eg

    if not no_filter:
        stream.apply(
            lambda d: prefer_uncertain(
                score_binary(nlp=nlp, stream=d, labels=labels, component=component),
                algorithm="probability",
            )
        )
    else:
        stream.apply(
            lambda d: remove_score(
                score_binary(nlp=nlp, stream=d, labels=labels, component=component)
            )
        )
    return {
        "view_id": "pos",
        "dataset": dataset,
        "stream": stream,
        "update": get_update_binary(nlp, component=component),
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "label": ", ".join(labels) if label else "all",
        },
    }


@recipe(
    "pos.correct",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    nlp=Arg(help="Loadable spaCy pipeline with a tagger"),
    source=Arg(help="Data to annotate (file path or '-' to read from standard input)"),
    loader=Arg("--loader", "-lo", help="Loader (guessed from file extension if not set)"),
    label=Arg("--label", "-l", help="Comma-separated label(s) to annotate or text file with one label per line"),
    exclude=Arg("--exclude", "-e", help="Comma-separated list of dataset IDs whose annotations to exclude"),
    unsegmented=Arg("--unsegmented", "-U", help="Don't split sentences"),
    # fmt: on,
)
def correct(
    dataset: str,
    nlp: Language,
    source: SourceType,
    loader: Optional[str] = None,
    label: Optional[LabelsType] = None,
    exclude: List[str] = [],
    unsegmented: bool = False,
) -> ControllerComponentsDict:
    """
    Create gold data for part-of-speech tags by correcting a model's
    predictions.
    """
    log("RECIPE: Starting recipe pos.correct", locals())
    view_id = "pos_manual"
    labels = get_pos_labels(nlp, label)
    stream = get_stream(
        source,
        loader=loader,
        rehash=True,
        dedup=True,
        input_key="text",
        view_id=view_id,
    )
    stream.apply(preprocess_stream, nlp, labels=labels, unsegmented=unsegmented)

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "auto_count_stream": True,
        },
    }


def get_pos_labels(nlp: Language, label: Optional[List[str]]) -> List[str]:
    return get_pipe_labels(label, nlp.pipe_labels.get("tagger", []), allow_new=True)


@support_both_streams(stream_arg="stream")
def preprocess_stream(
    stream: StreamType,
    nlp: Language,
    *,
    labels: Optional[List[str]],
    unsegmented: bool,
):
    if not unsegmented:
        stream = split_sentences(nlp, stream)  # type: ignore
    stream = add_tokens(nlp, stream)  # type: ignore
    spacy_model = f"{nlp.meta['lang']}_{nlp.meta['name']}"
    # Add a 'spans' key to each example, with predicted tags.
    texts = ((eg["text"], eg) for eg in stream)
    for doc, eg in nlp.pipe(texts, as_tuples=True, batch_size=10):
        task = copy.deepcopy(eg)
        spans = []
        for i, token in enumerate(doc):
            tag = token.tag_
            if labels and tag not in labels:
                continue
            spans.append(
                {
                    "token_start": i,
                    "token_end": i,
                    "start": token.idx,
                    "end": token.idx + len(token.text),
                    "text": token.text,
                    "label": tag,
                    "source": spacy_model,
                    "input_hash": eg[INPUT_HASH_ATTR],
                }
            )
        task["spans"] = spans
        task = set_hashes(task)
        yield task


def merge_tag_annotations(
    doc: Doc, span_tuples: List[Tuple[bool, List[Tuple]]]
) -> List[Example]:
    examples = []
    token_map = {(t.idx, t.idx + len(t.text)): i for i, t in enumerate(doc)}
    tags = [MISSING_VALUE] * len(doc)
    for answer, span_tuples in span_tuples:
        for start, end, label in span_tuples:
            tag_index = token_map[(start, end)]
            # whatever is the last accepted annotation, we'll keep
            if answer == "accept":
                tags[tag_index] = label
            elif answer == "reject" and tags[tag_index] == MISSING_VALUE:
                tags[tag_index] = pos_to_neg_label(label)
    examples.append(Example.from_dict(doc, {"tags": tags}))
    return examples


def normalize_softmax_outputs(
    nlp: Language,
    name: str,
    layer_name: str = "softmax",
    normalize_attr: str = "softmax_normalize",
) -> Language:
    """In spaCy v3.4, outputs are not normalized by default since
    the most important `Tagger.set_annotations` operation just calls
    argmax anyway. This allows for some speed optimizations in spaCy
    however, we want to show annotators positive scores that make a little more
    sense.
    """
    for node in nlp.get_pipe(name).model.walk():
        if node.name == layer_name:
            if normalize_attr in node.attrs:
                node.attrs[normalize_attr] = True
    return nlp


def score_binary(
    nlp: Language,
    stream: StreamType,
    labels: Optional[List[str]],
    component: str = "tagger",
) -> ScoredStreamType:
    """Apply the tagger, generating a task for each possible tag of each
    token."""
    tagger = nlp.get_pipe(component)
    for eg in stream:
        doc = nlp.make_doc(eg["text"])
        doc_tag_scores = None
        # Run all components up until the tagger to ensure the upstream tok2vec runs etc
        for name, proc in nlp.pipeline:
            if name == component:
                doc_tag_scores = tagger.model.predict([doc])[0]
                break
            else:
                doc = proc(doc)
        assert doc_tag_scores is not None
        assert doc_tag_scores.shape == (len(doc), len(tagger.labels))
        for token in doc:
            for tag_i, tag in enumerate(tagger.labels):
                score = float(doc_tag_scores[token.i, tag_i])
                if labels and tag not in labels:
                    continue
                span = {
                    "start": token.idx,
                    "end": token.idx + len(token),
                    "token_start": token.i,
                    "token_end": token.i,
                    "label": tag,
                    "text": token.text,
                    "score": score,
                }
                task = copy.deepcopy(eg)
                task["spans"] = [span]
                if "meta" not in task:
                    task["meta"] = {}
                task["meta"]["score"] = score
                task = set_hashes(task, overwrite=True)
                task[BINARY_ATTR] = True
                yield score, task


def get_update_binary(
    nlp: Language, component: str = "tagger"
) -> Callable[[List[TaskType]], float]:
    def update(batch: List[TaskType]) -> float:
        batch = [eg for eg in batch if eg["answer"] != "ignore"]
        if not batch:
            return 0.0
        tokens_by_text = {}
        spans_by_text = {}
        for eg in batch:
            text = eg["text"]
            tokens = [
                (token["text"], token["start"], token["end"], token.get("ws", True))
                for token in eg["tokens"]
            ]
            spans = [
                (span["start"], span["end"], span["label"]) for span in eg["spans"]
            ]
            answer = eg["answer"]
            tokens_by_text[text] = tokens
            spans_by_text.setdefault(text, []).append((answer, spans))
        losses = {}
        examples = []
        for text, tokens in tokens_by_text.items():
            words = [t[0] for t in tokens]
            spaces = [t[3] for t in tokens]
            doc = Doc(nlp.vocab, words=words, spaces=spaces)
            text_examples = merge_tag_annotations(doc, spans_by_text[text])
            examples.extend(text_examples)
        nlp.update(examples, losses=losses)
        # TODO: keep track of history?
        loss = losses.get(component, 0.0)
        return loss

    return update
