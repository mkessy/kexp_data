# pyright: reportUndefinedVariable=false, reportGeneralTypeIssues=false, reportOptionalMemberAccess=false, reportOptionalIterable=false, reportPrivateImportUsage=false, reportUnboundVariable=false, reportOptionalSubscript=false
import logging
import os
import sys
from functools import reduce
from pathlib import Path
from typing import IO, Any, Dict, List, Optional, Sequence, Set, Tuple, Union

import spacy
import srsly
from spacy.cli import init_config as spacy_init_config
from spacy.cli._util import parse_config_overrides, setup_gpu, show_validation_error
from spacy.cli.evaluate import handle_scores_per_type
from spacy.cli.init_config import Optimizations, save_config
from spacy.language import Language
from spacy.tokens import DocBin
from spacy.training.initialize import init_nlp as spacy_init_nlp
from spacy.training.loggers import console_logger as spacy_console_logger
from spacy.training.loop import train as spacy_train
from spacy.util import load_config, load_config_from_str
from spacy.util import logger as spacy_logger
from thinc.api import Config, fix_random_seed

from ..components.db import connect
from ..components.printers import train_curve_printer
from ..core import Arg, recipe
from ..errors import RecipeError
from ..util import NER_DEFAULT_INCORRECT_KEY, SPANCAT_DEFAULT_KEY, log, msg
from .data_utils import (
    add_prodigy_readers,
    get_datasets_from_cli,
    infer_spancat_suggester,
    load_examples,
    logger,
    merge_data,
)

CONFIG_READER_PATH = Path(__file__).parent.parent / "default_config_reader.cfg"
# fmt: off
RECIPE_ARGS = {
    "lang": Arg("--lang", "-l", help="Language to use"),
    "ner": Arg("--ner", "-n", help="Comma-separated NER datasets"),
    "textcat": Arg("--textcat", "-tc", help="Comma-separated text classification datasets (exclusive categories)"),
    "textcat_multilabel": Arg("--textcat-multilabel", "-tcm", help="Comma-separated multi-label text classification datasets (non-exclusive categories) "),
    "tagger": Arg("--tagger", "-t", help="Comma-separated tagging datasets"),
    "senter": Arg("--senter", "-s", help="Comma-separated sentence datasets"),
    "parser": Arg("--parser", "-p", help="Comma-separated dependency parsing datasets"),
    "spancat": Arg("--spancat", "-sc", help="Comma-separated span categorizer datasets"),
    "coref": Arg("--coref", "-co", help="Comma-separated coref datasets"),
    "eval_split": Arg("--eval-split", "-es", help="Portion of examples to split off for evaluation. Defaults to 0.2."),
    "base_model": Arg("--base-model", "-m", help="Optional base model to use for config, tokenization and sentence segmentation"),
    "config": Arg("--config", "-c", help="Optional path to spaCy config.cfg file to use for training"),
    "gpu_id": Arg("--gpu-id", "-g", help="GPU ID for training on GPU or -1 for CPU"),
    "verbose": Arg("--verbose", "-V", help="Enable verbose logging"),
    "silent": Arg("--silent", "-S", help="Don't output any status or logs"),
}
# fmt: on


@recipe(
    "spacy-config",
    # fmt: off
    output_file=Arg(help="Path to save config file or - for stdout)"),
    lang=RECIPE_ARGS["lang"],
    ner=RECIPE_ARGS["ner"],
    textcat=RECIPE_ARGS["textcat"],
    textcat_multilabel=RECIPE_ARGS["textcat_multilabel"],
    tagger=RECIPE_ARGS["tagger"],
    senter=RECIPE_ARGS["senter"],
    parser=RECIPE_ARGS["parser"],
    spancat=RECIPE_ARGS["spancat"],
    coref=RECIPE_ARGS["coref"],
    eval_split=RECIPE_ARGS["eval_split"],
    config=RECIPE_ARGS["config"],
    base_model=RECIPE_ARGS["base_model"],
    verbose=RECIPE_ARGS["verbose"],
    silent=RECIPE_ARGS["silent"],
    # fmt: on
)
def prodigy_config(
    output_file: Optional[Union[str, Path]],
    lang: str = "en",
    ner: Sequence[str] = tuple(),
    textcat: Sequence[str] = tuple(),
    textcat_multilabel: Sequence[str] = tuple(),
    tagger: Sequence[str] = tuple(),
    senter: Sequence[str] = tuple(),
    parser: Sequence[str] = tuple(),
    spancat: Sequence[str] = tuple(),
    coref: Sequence[str] = tuple(),
    eval_split: float = 0.2,
    config: Optional[Union[str, Config]] = None,
    base_model: Optional[str] = None,
    verbose: bool = False,
    silent: bool = False,
) -> Config:
    """
    Generate a starter config for training from Prodigy datasets. A custom reader
    will be used that merges annotations on the same examples.
    It's recommended to use the review recipe on the different annotation types
    first to resolve conflicts properly (instead of relying on this recipe to
    just filter conflicting annotations and decide on one).
    """
    set_log_level(verbose=verbose, silent=silent)
    is_stdout = output_file is not None and str(output_file) == "-"
    silent = is_stdout or silent
    msg.divider("Generating Prodigy config", show=not silent)
    pipes = get_datasets_from_cli(
        ner,
        textcat,
        textcat_multilabel,
        tagger,
        senter,
        parser,
        spancat,
        coref,
    )
    return _prodigy_config(
        pipes,
        output_file=output_file,
        lang=lang,
        eval_split=eval_split,
        config=config,
        base_model=base_model,
        verbose=verbose,
        silent=silent,
    )


def _prodigy_config(
    pipes: Dict[str, Tuple[List[str], List[str]]],
    output_file: Optional[Union[str, Path]],
    lang: str = "en",
    eval_split: float = 0.2,
    config: Optional[Union[str, Config]] = None,
    base_model: Optional[str] = None,
    verbose: bool = False,
    silent: bool = False,
):
    set_log_level(verbose=verbose, silent=silent)
    is_stdout = output_file is not None and str(output_file) == "-"
    base_nlp = spacy.load(base_model) if base_model is not None else None
    if config is None:
        config = generate_default_config(pipes, lang, base_nlp, silent=silent)
    config = generate_config(config, base_nlp, base_model, list(pipes), silent)
    # Removing the standard spaCy readers and adding the Prodigy reader instead
    corpus_config = load_config(CONFIG_READER_PATH)
    config = add_prodigy_readers(
        pipes,
        config,
        corpus_config,
        eval_split=eval_split,
    )
    msg.good("Generated training config", show=not silent)
    # If this recipe is called as a function, we can pass in None to return only
    if output_file is not None:
        output_file = Path(output_file)
        # Make sure to suppress the log from save_config, which would otherwise refer to --paths.train
        save_config(config, output_file, is_stdout=is_stdout, silent=True)
        if not is_stdout and not silent:
            msg.good("Saved training config", output_file)
            msg.text("You can now add your data and train your pipeline:")
            print(f"python -m spacy train {output_file.parts[-1]}")  # noqa: T201
    return config


def _train(
    config: Config,
    *,
    output_dir: Optional[Union[str, Path]] = None,
    gpu_id: int,
    overrides: Dict[str, Any],
    show_label_stats: bool = False,
    silent: bool = False,
) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    # This is a small hack, but we're basically registering a custom logger so
    # we can track the full stats on each log step
    BASELINE = None
    SCORES = None

    @spacy.registry.loggers("prodigy.ConsoleLogger.v1")
    def console_logger(progress_bar: bool = False):
        spacy_setup_printer = spacy_console_logger(progress_bar)

        def setup_printer(
            nlp: Language, stdout: IO = sys.stdout, stderr: IO = sys.stderr
        ):
            spacy_log_step, finalize = spacy_setup_printer(nlp, stdout, stderr)

            def log_step(info: Optional[Dict[str, Any]]) -> None:
                nonlocal SCORES, BASELINE
                if info:
                    if BASELINE is None:
                        BASELINE = info
                    if not SCORES or info["score"] > SCORES["score"]:
                        SCORES = info
                spacy_log_step(info)

            return log_step, finalize

        return setup_printer

    original_logger = config["training"].get("logger")

    @spacy.registry.misc("prodigy.todisk_cleanup.v1")
    def create_callback():
        def cleanup_config(nlp):
            if original_logger:
                nlp.config["training"]["logger"] = original_logger
            nlp.config["training"]["before_to_disk"] = None
            return nlp

        return cleanup_config

    config["training"]["logger"] = {"@loggers": "prodigy.ConsoleLogger.v1"}
    config["training"]["before_to_disk"] = {"@misc": "prodigy.todisk_cleanup.v1"}

    msg.divider("Initializing pipeline", show=not silent)
    with show_validation_error(None, hint_fill=False):
        config = load_config_from_str(config.to_str(), overrides=overrides)
        nlp = spacy_init_nlp(config, use_gpu=gpu_id)
    msg.good("Initialized pipeline", show=not silent)
    msg.divider("Training pipeline", show=not silent)
    stdout = sys.stdout if not silent else open(os.devnull, "w", encoding="utf-8")
    output_path = Path(output_dir) if output_dir is not None else None
    if output_path is not None and not output_path.exists():
        output_path.mkdir(parents=True)
    try:
        spacy_train(nlp, output_path, use_gpu=gpu_id, stdout=stdout)
        if show_label_stats:
            handle_scores_per_type(SCORES.get("other_scores", {}), silent=silent)
        return BASELINE, SCORES
    except KeyboardInterrupt:
        msg.warn("Aborted", exits=0)
    return BASELINE, SCORES


@recipe(
    "train",
    # fmt: off
    output_dir=Arg(help="Optional output directory for the trained pipeline"),
    ner=RECIPE_ARGS["ner"],
    textcat=RECIPE_ARGS["textcat"],
    textcat_multilabel=RECIPE_ARGS["textcat_multilabel"],
    tagger=RECIPE_ARGS["tagger"],
    senter=RECIPE_ARGS["senter"],
    parser=RECIPE_ARGS["parser"],
    spancat=RECIPE_ARGS["spancat"],
    coref=RECIPE_ARGS["coref"],
    eval_split=RECIPE_ARGS["eval_split"],
    label_stats=Arg("--label-stats", "-LS", help="Show per-label scores"),
    config=RECIPE_ARGS["config"],
    base_model=RECIPE_ARGS["base_model"],
    lang=RECIPE_ARGS["lang"],
    gpu_id=RECIPE_ARGS["gpu_id"],
    verbose=RECIPE_ARGS["verbose"],
    silent=RECIPE_ARGS["silent"],
    # fmt: on
)
def train(
    output_dir: Union[str, Path] = None,
    ner: Sequence[str] = tuple(),
    textcat: Sequence[str] = tuple(),
    textcat_multilabel: Sequence[str] = tuple(),
    tagger: Sequence[str] = tuple(),
    senter: Sequence[str] = tuple(),
    parser: Sequence[str] = tuple(),
    spancat: Sequence[str] = tuple(),
    coref: Sequence[str] = tuple(),
    eval_split: float = 0.2,
    label_stats: bool = False,
    config: Optional[Union[str, Path]] = None,
    base_model: Optional[str] = None,
    lang: str = "en",
    gpu_id: int = -1,
    verbose: bool = False,
    silent: bool = False,
    _extra: List[str] = [],  # additional arguments
) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Train a spaCy pipeline from one or more datasets for different components.
    Per-component evaluation sets can be provided using the eval: prefix, e.g.
    --ner my_train_dataset,eval:my_eval_dataset. The command takes care of
    auto-generating a training config and merging all annotations on the
    same input data.
    """
    set_log_level(verbose=verbose, silent=silent)
    setup_gpu(gpu_id)
    overrides = parse_config_overrides(list(_extra))
    if config is not None:
        config = load_config(config)
    train_config = prodigy_config(
        None,
        lang=lang,
        ner=ner,
        textcat=textcat,
        textcat_multilabel=textcat_multilabel,
        tagger=tagger,
        senter=senter,
        parser=parser,
        spancat=spancat,
        coref=coref,
        eval_split=eval_split,
        config=config,
        base_model=base_model,
        verbose=verbose,
        silent=silent,
    )
    return _train(
        train_config,
        output_dir=output_dir,
        gpu_id=gpu_id,
        overrides=overrides,
        show_label_stats=label_stats,
        silent=silent,
    )


@recipe(
    "train-curve",
    # fmt: off
    ner=RECIPE_ARGS["ner"],
    textcat=RECIPE_ARGS["textcat"],
    textcat_multilabel=RECIPE_ARGS["textcat_multilabel"],
    tagger=RECIPE_ARGS["tagger"],
    senter=RECIPE_ARGS["senter"],
    parser=RECIPE_ARGS["parser"],
    spancat=RECIPE_ARGS["spancat"],
    coref=RECIPE_ARGS["coref"],
    eval_split=RECIPE_ARGS["eval_split"],
    config=RECIPE_ARGS["config"],
    base_model=RECIPE_ARGS["base_model"],
    lang=RECIPE_ARGS["lang"],
    gpu_id=RECIPE_ARGS["gpu_id"],
    n_samples=Arg("--n-samples", "-ns", help="Number of samples to take for train curve"),
    show_plot=Arg("--show-plot", "-P", help="Show a visual plot of the curve (requires the plotext library)"),
    # fmt: on
)
def train_curve(
    ner: Sequence[str] = tuple(),
    textcat: Sequence[str] = tuple(),
    textcat_multilabel: Sequence[str] = tuple(),
    tagger: Sequence[str] = tuple(),
    senter: Sequence[str] = tuple(),
    parser: Sequence[str] = tuple(),
    spancat: Sequence[str] = tuple(),
    coref: Sequence[str] = tuple(),
    eval_split: float = 0.2,
    config: Optional[str] = None,
    base_model: Optional[str] = None,
    lang: str = "en",
    gpu_id: int = -1,
    n_samples: int = 4,
    show_plot: bool = False,
    _extra: List[str] = [],  # additional arguments
) -> None:
    """
    Train a spaCy pipeline with different portions of the training examples and
    print the accuracy figures and accuracy improvements with more data. Can be
    used to get an idea of whether more annotations could improve the model.
    This recipe takes pretty much the same arguments as `train`.
    """
    set_log_level(silent=True)
    setup_gpu(gpu_id)
    msg.divider("Generating Prodigy config")
    overrides = parse_config_overrides(list(_extra))
    pipes = get_datasets_from_cli(
        ner,
        textcat,
        textcat_multilabel,
        tagger,
        senter,
        parser,
        spancat,
        coref,
    )
    return _train_curve(
        pipes,
        eval_split=eval_split,
        config=config,
        base_model=base_model,
        lang=lang,
        gpu_id=gpu_id,
        n_samples=n_samples,
        show_plot=show_plot,
        overrides=overrides,
    )


def _train_curve(
    pipes: Dict[str, Tuple[List[str], List[str]]],
    eval_split: float = 0.2,
    config: Optional[str] = None,
    base_model: Optional[str] = None,
    base_nlp: Optional[Language] = None,
    lang: str = "en",
    gpu_id: int = -1,
    n_samples: int = 4,
    show_plot: bool = False,
    overrides: Dict[str, Any] = {},
) -> None:
    if config is None:
        cfg = generate_default_config(pipes, lang, base_nlp)
    else:
        cfg = load_config(config)
    cfg = generate_config(cfg, base_nlp, base_model, list(pipes))
    # Removing the standard spaCy readers and adding the Prodigy reader instead
    corpus_config = load_config(CONFIG_READER_PATH)
    cfg = add_prodigy_readers(pipes, cfg, corpus_config, eval_split=eval_split)
    msg.good("Generated training config")
    msg.divider("Train curve diagnostic")
    spancat_key = cfg["components"].get("spancat", {}).get("spans_key", "sc")
    default_scores = {
        "ner": "ents_f",
        "parser": "dep_uas",
        "tagger": "tag_acc",
        "senter": "sents_f",
        "textcat": "cats_score",
        "textcat_multilabel": "cats_score",
        "experimental_coref": "coref_f",
        "spancat": f"spans_{spancat_key}_f",
    }
    factors = [(i + 1) / n_samples for i in range(n_samples)]
    prev_scores = None
    pcs = ", ".join([f"{fac:.0%}" for fac in factors])
    msg.text(f"Training {n_samples} times with {pcs} of the data")
    with train_curve_printer(list(pipes), default_scores, show_plot) as result:
        for i, factor in enumerate(factors):
            cfg["corpora"]["sample_size"] = factor
            baseline, scores = _train(
                cfg, gpu_id=gpu_id, overrides=overrides, silent=True
            )
            if i == 0:
                result(0, baseline, None)
                prev_scores = baseline
            result(factor, scores, prev_scores)
            prev_scores = scores


@recipe(
    "data-to-spacy",
    # fmt: off
    output_dir=Arg(help="Path to output directory"),
    ner=RECIPE_ARGS["ner"],
    textcat=RECIPE_ARGS["textcat"],
    textcat_multilabel=RECIPE_ARGS["textcat_multilabel"],
    tagger=RECIPE_ARGS["tagger"],
    senter=RECIPE_ARGS["senter"],
    parser=RECIPE_ARGS["parser"],
    spancat=RECIPE_ARGS["spancat"],
    coref=RECIPE_ARGS["coref"],
    eval_split=RECIPE_ARGS["eval_split"],
    config=RECIPE_ARGS["config"],
    base_model=RECIPE_ARGS["base_model"],
    lang=RECIPE_ARGS["lang"],
    verbose=RECIPE_ARGS["verbose"],
    # fmt: on
)
def data_to_spacy(
    output_dir: Union[str, Path],
    ner: Sequence[str] = tuple(),
    textcat: Sequence[str] = tuple(),
    textcat_multilabel: Sequence[str] = tuple(),
    tagger: Sequence[str] = tuple(),
    senter: Sequence[str] = tuple(),
    parser: Sequence[str] = tuple(),
    spancat: Sequence[str] = tuple(),
    coref: Sequence[str] = tuple(),
    eval_split: float = 0.2,
    config: Optional[Union[str, Config]] = None,
    base_model: Optional[str] = None,
    lang: str = "en",
    verbose: bool = False,
) -> None:
    """
    Combine multiple datasets, merge annotations on the same examples and output
    a file in spaCy's binary training format that you can use with `spacy train`.
    It's recommended to use the review recipe on the different annotation types
    first to resolve conflicts properly (instead of relying on this recipe to
    just filter conflicting annotations and decide on one).

    The command takes an output directory and generates all data required to
    train a pipeline with spaCy, including the config and pre-generated labels
    data to speed up the training process.
    """
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    log("RECIPE: Starting recipe data-to-spacy", locals())
    output_path = Path(output_dir)
    if output_path.exists() and not output_path.is_dir():
        raise RecipeError("Can't save to output path: not a directory", output_path)
    if not output_path.exists():
        output_path.mkdir(parents=True)
        msg.good("Created output directory")
    fix_random_seed(0)
    if base_model is not None:
        msg.info(f"Using base model '{base_model}'")
        nlp = spacy.load(base_model)
    else:
        msg.info(f"Using language '{lang}'")
        nlp = spacy.blank(lang)
        nlp.add_pipe("sentencizer")

    msg.divider("Generating data")
    train_docs, dev_docs, pipes = merge_data(
        nlp,
        ner,
        textcat,
        textcat_multilabel,
        tagger,
        senter,
        parser,
        spancat,
        coref,
        eval_split=eval_split,
    )
    if not train_docs:
        raise RecipeError(
            "No training data. This can happen if all your datasets are empty "
            "or if no valid annotations for the given component were found.",
            'For more details, make sure you\'ve set "validate": true in your '
            "prodigy.json, and use the --verbose flag for more output.",
        )
    train_path = output_path / "train.spacy"
    dev_path = output_path / "dev.spacy"
    DocBin(docs=train_docs).to_disk(train_path)
    msg.good(f"Saved {len(train_docs)} training examples", train_path)
    if dev_docs:
        DocBin(docs=dev_docs).to_disk(dev_path)
        msg.good(f"Saved {len(dev_docs)} evaluation examples", dev_path)
    else:
        msg.warn(
            "No evaluation data. You can provide dedicated evaluation sets for "
            "the different components using the eval: prefix, or set an "
            "--eval-split to hold back a percentage for evaluation. "
            "If you already have a dev set available, you can specify its "
            "correct path as the '--paths.dev' argument to 'spacy train'.",
        )

    msg.divider("Generating config")
    base_nlp = nlp if base_model is not None else None
    if config is None:
        config = generate_default_config(pipes, lang, base_nlp)
    else:
        config = load_config(config)
    config = generate_config(config, base_nlp, base_model, list(pipes))
    msg.good("Generated training config")

    msg.divider("Generating cached label data")
    config["paths"]["train"] = str(train_path)
    config["paths"]["dev"] = str(dev_path)
    # We need to initialize the nlp object here to make label_data available
    nlp = spacy_init_nlp(config)
    labels_path = output_path / "labels"
    if not labels_path.exists():
        labels_path.mkdir()
    generated_pipes = []
    for name, component in nlp.pipeline:
        if getattr(component, "label_data", None) is not None:
            generated_pipes.append(name)
            output_file = labels_path / f"{name}.json"
            srsly.write_json(output_file, component.label_data)
            msg.good(f"Saving label data for component '{name}'", output_file)
            # Not very elegant, but should work
            reader = {"@readers": "spacy.read_labels.v1", "path": str(output_file)}
            config["initialize"]["components"][name] = {"labels": reader}
    config["paths"]["train"] = None
    config["paths"]["dev"] = None
    if not generated_pipes:
        msg.info("No components to generate cached label data for")

    msg.divider("Finalizing export")
    config_path = output_path / "config.cfg"
    save_config(config, config_path, silent=True)
    msg.good("Saved training config", config_path)
    cmd = f"python -m spacy train {config_path} --paths.train {train_path} --paths.dev {dev_path}"
    print("\nTo use this data for training with spaCy, you can run:")  # noqa: T201
    print(cmd)  # noqa: T201


def generate_default_config(
    pipe_datasets: Dict[str, Tuple[List[str], List[str]]],
    lang: str,
    nlp: Optional[Language],
    *,
    silent: bool = False,
    infer_from_data: bool = True,
) -> Config:
    msg.info("Auto-generating config with spaCy", show=not silent)
    pipes = list(pipe_datasets)
    if nlp is not None and len(nlp.vocab.vectors.keys()) > 0:
        optimize = Optimizations.accuracy.value
    else:
        optimize = Optimizations.efficiency.value
    try:
        config = spacy_init_config(
            lang=lang,
            pipeline=pipes,
            optimize=optimize,
            gpu=False,
        )
    except ValueError as err:
        if "experimental_coref" in pipes:
            raise RecipeError(
                "Creating a config with the coref component requires spacy-experimental and PyTorch. "
                'To install run: python -m pip install "spacy-experimental~=0.6.1" "thinc[torch]"'
            ) from err
    if "ner" in config["components"]:
        config["components"]["ner"]["incorrect_spans_key"] = NER_DEFAULT_INCORRECT_KEY
    if "beam_ner" in config["components"]:
        config["components"]["beam_ner"][
            "incorrect_spans_key"
        ] = NER_DEFAULT_INCORRECT_KEY
    if "spancat" in config["components"]:
        config["components"]["spancat"]["spans_key"] = SPANCAT_DEFAULT_KEY
        prefix = f"spans_{SPANCAT_DEFAULT_KEY}"
        # This isn't perfect yet because the default 'spans_sc_f' will still show up. But we're setting the
        # Prodigy default to the same as the spaCy default ("sc"), so this should hopefully not come up.
        config["training"]["score_weights"][f"{prefix}_f"] = 1.0
        config["training"]["score_weights"][f"{prefix}_p"] = 0.0
        config["training"]["score_weights"][f"{prefix}_r"] = 0.0
    # TODO: not sure if we ever want this to be False, but left the setting in
    # here just in case
    if infer_from_data:
        # We reload the datasets here because all we care about is the raw data
        # and going via the readers adds too much complexity. Keeping it here
        # for simplicity but if this gets longer we can move it to helper.
        if nlp is None:
            nlp = spacy.blank(lang)
        db = connect()
        if "spancat" in config["components"]:
            train_sets, dev_sets = pipe_datasets["spancat"]
            examples = load_examples(db, [*train_sets, *dev_sets])
            suggester = infer_spancat_suggester(examples, nlp)
            config["components"]["spancat"]["suggester"] = suggester
    return config


def generate_config(
    config: Config,
    base_nlp: Optional[Language],
    base_name: Optional[Union[str, Path]],
    pipes: List[str],
    silent: bool = False,
) -> Config:
    for pipe in pipes:
        if pipe not in config["components"]:
            msg.warn(f"Component '{pipe}' is not defined in the provided config")
    if base_nlp is None or base_name is None:
        return config
    # We want to keep the nlp and training settings here (if training
    # config differs from default, e.g. for transformers)
    config["nlp"] = base_nlp.config["nlp"]
    config["training"] = base_nlp.config["training"]
    # we reset the logger to a default one, to avoid
    # forcing the user to install wandb (cf 3.0 and 3.1 spaCy models)
    del config["training"]["logger"]
    if len(base_nlp.vocab.vectors.keys()) > 0:
        config["paths"]["vectors"] = base_name
        config["initialize"]["vectors"] = "${paths.vectors}"
    config["nlp"]["pipeline"] = list(base_nlp.pipe_names)
    for pipe in pipes:
        if pipe not in config["nlp"]["pipeline"]:
            config["nlp"]["pipeline"].append(pipe)
    # Make sure we have a simple list, not a SimpleFrozenList
    # ensure we keep the downstream embedding layers (without duplicating them)

    msg.info("Using config from base model", show=not silent)
    score_names_keep = _get_score_names_to_keep(base_nlp, pipes)
    # Get a map like {"tok2vec": {"ner": "model.tok2vec"}} that tells us which
    # components are upstream embedders (i.e. have listeners downstream),
    # what components are listening to them, and also the path to the model
    # component that is connected to the listener
    listener_map = _get_listener_map(base_nlp, pipes)
    if not listener_map and not _textcat_only(config["nlp"]["pipeline"]):
        # we deal with a blank pipeline so we need to add the embedding layer manually
        # unless it's a textcat-only pipeline where, by default, we don't use tok2vec
        config["nlp"]["pipeline"].insert(0, "tok2vec")
    for component in listener_map.keys():
        # Ensure upstream embedders are in the pipeline
        if component not in config["nlp"]["pipeline"]:
            config["nlp"]["pipeline"].insert(0, component)
    for component in base_nlp.pipe_names:
        _update_component_config(
            config,
            component,
            pipes,
            base_nlp,
            base_name,
            score_names_keep,
            listener_map,
        )
    for component in config["components"].keys():
        _fix_embedding_width(config, component, base_nlp)
    # Source tokenizer and vocab from the base model
    cfg = {
        "@callbacks": "spacy.copy_from_base_model.v1",
        "tokenizer": base_name,
        "vocab": base_name,
    }
    config["initialize"]["before_init"] = cfg
    return config


def _get_score_names_to_keep(base_nlp: Language, pipes: List[str]) -> Set[str]:
    """Figure out which score names we're keeping. Remove score names for frozen components"""
    score_names_keep = set()
    for component in base_nlp.pipe_names:
        if component in pipes:
            pipe_meta = base_nlp.get_pipe_meta(component)
            for score_name in pipe_meta.scores:
                score_names_keep.add(score_name)
    return score_names_keep


def _update_component_config(
    config: Config,
    component: str,
    pipes: List[str],
    base_nlp: Language,
    base_name: str,
    score_names_keep: Set[str],
    listener_map: List[str],
) -> None:
    """Update the config for one component."""
    for _, component_map in listener_map.items():
        if component in component_map:
            embedding_model = component_map[component]
            break
    else:
        embedding_model = None
    # 1. Components should be sourced from the base model
    config["components"][component] = {"source": base_name}
    if (
        component not in pipes
        and component not in config["training"]["frozen_components"]
        and component not in ("transformer", "tok2vec")
    ):
        # 2. Freeze components we're not training
        config["training"]["frozen_components"].append(component)
        # 3. If we're freezing it, does it have a listener? If so, inline that.
        if embedding_model is not None:
            config["components"][component]["replace_listeners"] = [embedding_model]
        # 4. Fix score names
        pipe_meta = base_nlp.get_pipe_meta(component)
        for score_name in pipe_meta.scores:
            if (
                score_name in config["training"]["score_weights"]
                and score_name not in score_names_keep
            ):
                config["training"]["score_weights"][score_name] = None


# Get the width from base_nlp. This is based on a bug where
# the components.some_component.model.tok2vec.width is not
# substituted when listening to it.
def _get_embedding_width(base_nlp: Language) -> Optional[float]:
    if "tok2vec" in base_nlp.pipe_names:
        tok2vec = base_nlp.get_pipe("tok2vec")
        return tok2vec.model.get_dim("nO")
    elif "transformer" in base_nlp.pipe_names:
        transformer = base_nlp.get_pipe("transformer")
        return transformer.model.get_dim("nO")
    else:
        return None


def _fix_embedding_width(config, component, base_nlp):
    embedding_width = _get_embedding_width(base_nlp)
    if embedding_width is not None:
        # retrieve the tok2vec configuration of this component (if it exists)
        tok2vec_config = get_from_config(
            config, f"components.{component}.model.tok2vec"
        )
        if tok2vec_config:
            config_width = tok2vec_config["width"]
            # If the config refers to an interpolation string, set the explicit dimension instead
            if not isinstance(config_width, int):
                config["components"][component]["model"]["tok2vec"][
                    "width"
                ] = embedding_width


def _get_listener_map(
    base_nlp: Language, pipes: List[str]
) -> Dict[str, Dict[str, str]]:
    listener_map = {}
    for name, proc in base_nlp.pipeline:
        if getattr(proc, "listening_components", None):
            # The listener map is only populated in initialize and begin_training, not necessarily
            # on load. So we can't rely on it. We're just using the listening components property
            # to identify a component like tok2vec or transformer, that might have listeners.
            # Okay we have an upstream embedder. Are any of its listeners in the final pipeline?
            listener_map.setdefault(name, {})
            for component in getattr(proc, "listening_components", []):
                listener_map[name][component] = "model.tok2vec"
    return listener_map


def _textcat_only(pipeline: List[str]) -> bool:
    return (
        len(pipeline) == 1
        and pipeline[0] == "textcat"
        or pipeline[0] == "textcat_multilabel"
    )


def get_from_config(config: Config, path: List[str]) -> Any:
    """Get configuration value based on its setting (dot-notation)"""
    path = path.split(".")
    return reduce(lambda c, k: c.get(k, {}), path, config)


def set_log_level(*, verbose: bool = False, silent: bool = False) -> None:
    level = logging.ERROR if silent else logging.DEBUG if verbose else logging.INFO
    logger.setLevel(level)
    spacy_logger.setLevel(level)
