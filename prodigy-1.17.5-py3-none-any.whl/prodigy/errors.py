from pathlib import Path
from typing import Any, Optional


class ProdigyError(Exception):
    def __init__(self, title: str, text: Any = ""):
        self.title = title
        self.text = text
        self.msg = f"{self.title}\n{self.text}"


class RecipeError(ProdigyError):
    pass


class RecipeValidationError(ProdigyError):
    pass


class ConfigError(ProdigyError):
    pass


class MaxSessionsExceededError(ProdigyError):
    def __init__(self, session_id: str, max_sessions: int):
        self.session_id = session_id
        self.max_sessions = max_sessions
        self.msg = (
            f"The running recipe is configured for a maximum of {self.max_sessions} sessions. "
            f"Session {self.session_id} would be session {self.max_sessions + 1}. "
            f"You can increase the max number of sessions by setting the 'max_sessions' "
            f"property in your configuration"
        )


class NoSessionFeedOverlapError(ProdigyError):
    def __init__(
        self,
        feed_overlap: float,
        annotations_per_task: Optional[float],
        using_custom_router: bool,
    ):
        self.feed_overlap = feed_overlap
        self.annotations_per_task = annotations_per_task
        self.using_custom_router = using_custom_router
        self.msg = (
            "The running recipe is configured for multiple annotators using "
            "named sessions with feed_overlap=True, or via a task router setting, but a client is requesting "
            "questions using the default session. "
            "For this recipe, open the app with ?session=name added to "
            "the URL or set feed_overlap to False in your configuration."
        )


class CannotReadRecipesFileError(ProdigyError):
    def __init__(self, path: Path):
        self.msg = f"Cannot read external recipes file: {path}"


class UnauthorizedSessionIdRequestError(ProdigyError):
    """Error raised when the session id in the request does not match the session id in the token."""

    def __init__(
        self, current_user_id: str, requested_session_id: Optional[str] = None
    ):
        self.current_user_id = current_user_id
        self.requested_session_id = requested_session_id
        super().__init__(
            f"Session ID mismatch. Current User's Sesssion ID: {current_user_id}. "
            f"Requested session ID: {requested_session_id}"
        )
