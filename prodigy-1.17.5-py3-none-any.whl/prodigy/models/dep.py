import copy
import random
from collections import defaultdict
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    List,
    Optional,
    Sequence,
    Tuple,
    Union,
    cast,
)

from spacy.pipeline import DependencyParser
from spacy.tokens.doc import Doc
from spacy.training import Example
from toolz.itertoolz import partition_all, take

from ..types import ScoredStreamType, StreamType, TaskType
from ..util import INPUT_HASH_ATTR, MISSING_VALUE, copy_nlp, log, set_hashes

if TYPE_CHECKING:
    from spacy.language import Language


def merge_arcs(examples: Sequence[TaskType]) -> List[TaskType]:
    log(f"MODEL: Merging arc annotations of {len(examples)} examples")
    examples = [copy.deepcopy(eg) for eg in examples if eg.get("answer") != "ignore"]
    log(f"MODEL: Using {len(examples)} examples (without 'ignore')")
    by_input = defaultdict(list)
    for eg in examples:
        eg.setdefault("arcs", [])
        if "answer" in eg:
            for arc in eg["arcs"]:
                arc.setdefault("answer", eg["answer"])
    keys = {}
    for eg in examples:
        by_input[eg["text"]].append(eg)
        keys[eg["text"]] = True
    output = []
    for key in keys:
        group = by_input[key]
        arcs = []
        for eg in group[1:]:
            arcs.extend(eg["arcs"])
        eg = dict(group[0])
        eg.setdefault("arcs", [])
        eg["arcs"].extend(arcs)
        eg = set_hashes(eg, overwrite=True)
        output.append(eg)
    return output


class _BatchBeam:
    """Manage a set of analyses for a batch of texts."""

    # Each Parse is List[Tuple[int, int, str]], so a ParseBeam
    # is List[Parse]. Then a BatchBeam is List[ParseBeam], i.e.
    parses: List[List[List[Tuple[int, int, str]]]]
    # One score per candidate for each text in the batch.
    scores: List[List[float]]
    docs: List[Doc]
    w: int
    b: float

    def __init__(
        self, nlp: "Language", texts: Iterable[str], w: int = 4, b: float = 0.0
    ) -> None:
        # TODO: handle this better?
        docs = list(nlp.pipe(texts, disable=["ner", "parser", "tagger", "lemmatizer"]))
        parser = cast(DependencyParser, nlp.get_pipe("parser"))
        beams = parser.beam_parse(docs, beam_width=w, beam_density=b)
        parses: List[List[List[Tuple[int, int, str]]]] = []
        scores: List[List[float]] = []
        for _, beam in zip(docs, beams):
            # Start collecting for a new text. This text will
            # have multiple parses, so its type will be List[Parse]
            parses.append([])
            scores.append([])
            parse: List[Tuple[int, int, str]]
            score: float
            for score, parse in parser.moves.get_beam_parses(beam):  # type: ignore
                scores[-1].append(score)
                parses[-1].append(parse)
        self.docs = docs
        self.parses = parses
        self.scores = scores
        self.w = w
        self.b = b

    def __len__(self) -> int:
        return len(self.docs)

    def predict_best(
        self,
        gold_arcs: Sequence[List[Dict[str, Any]]] = tuple(),
        max_wrong: int = 0,
        min_right: int = 1,
    ) -> List[Optional[List[Dict[str, Union[int, str, float]]]]]:
        output: List[Optional[List[Dict[str, Union[int, str, float]]]]] = []
        for i in range(len(self.docs)):
            # This seems like it was a bug before?
            golds, incorrect_golds = _arc_dicts_to_tuples(gold_arcs[i])
            stats_parses = self.evaluate_parses(i, golds, incorrect_golds)
            for stats, parse in stats_parses:
                if (max_wrong is None or stats["wrong"] <= max_wrong) and (
                    min_right is None or stats["right"] >= min_right
                ):
                    output.append(parse)
                    break
            else:
                output.append(None)
        return output

    def evaluate_parses(
        self,
        i: int,
        golds: List[Tuple[int, int, str]],
        incorrect_golds: List[Tuple[int, int, str]],
    ) -> List[
        Tuple[Dict[str, Union[int, float]], List[Dict[str, Union[int, str, float]]]]
    ]:
        sortable = []
        for j, parse in enumerate(self.parses[i]):
            right, wrong, unk = _score_deps(parse, golds, incorrect_golds)
            prob = self.scores[i][j]
            sortable.append(((-wrong, right, prob, unk), j))
        sortable.sort(reverse=True)
        output = []
        for (neg_wrong, right, prob, unk), j in sortable:
            stats = {
                "acc": right / (right - neg_wrong + 1e-8),
                "right": right,
                "wrong": -neg_wrong,
                "unk": unk,
                "prob": prob,
                "rank": j,
            }
            output.append((stats, self.format_parse(i, j)))
        return output

    def get_arcs(self, i: int) -> List[Tuple[int, Tuple[int, int, str]]]:
        arcs = []
        seen_arcs = set()
        for rank, parse in enumerate(self.parses[i]):
            for arc in parse:
                if arc not in seen_arcs:
                    arcs.append((rank, arc))
                    seen_arcs.add(arc)
        return arcs

    def get_prob(
        self,
        dep: Optional[Tuple[int, int]] = None,
        label: Optional[str] = None,
        i: Optional[int] = None,
        w: Optional[int] = None,
    ) -> float:
        if i is not None:
            batch_parses = [self.parses[i]]
            batch_scores = [self.scores[i]]
        else:
            batch_parses = list(self.parses)
            batch_scores = list(self.scores)
        w = w or self.w
        not_prob = 1.0
        for doc_scores, doc_parses in zip(batch_scores, batch_parses):
            for score, parse in zip(doc_scores[:w], doc_parses[:w]):
                for head, child, L in parse:
                    if dep in (None, (head, child)) and label in (None, L):
                        not_prob *= 1.0 - score
        return 1.0 - not_prob

    def format_parse(self, i: int, j: int) -> List[Dict[str, Union[int, str, float]]]:
        output: List[Dict[str, Union[int, str, float]]] = []
        for head, child, label in self.parses[i][j]:
            prob = self.get_prob(i=i, dep=(head, child), label=label)
            output.append({"head": head, "child": child, "label": label, "score": prob})
        return output


def predict(
    stream: StreamType,
    nlp: "Language",
    labels: Iterable[str],
    batch_size: int,
    beam_width: int,
    min_score: float,
) -> ScoredStreamType:
    # This is nested within this scope just for code organization, to
    # make clear that this is the only places the helper is used.
    # We're not using it as a closure.
    def predict_arcs(
        nlp: "Language", stream: StreamType, batch_size: int, beam_width: int
    ) -> StreamType:
        if "lang" in nlp.meta and "name" in nlp.meta:
            model_name = nlp.meta["lang"] + "_" + nlp.meta["name"]
        else:
            model_name = "?"
        for batch in partition_all(batch_size, stream):
            log(f"MODEL: Predicting arcs for batch (batch size {batch_size})")
            batch = list(batch)
            texts = [eg["text"] for eg in batch]
            beam = _BatchBeam(nlp, texts, w=beam_width, b=0.00001)
            for i, eg in enumerate(batch):
                task = copy.deepcopy(eg)
                arcs = task.setdefault("arcs", [])
                for rank, (head, child, label) in beam.get_arcs(i):
                    arcs.append(
                        {
                            "head": head,
                            "child": child,
                            "label": label,
                            "rank": rank,
                            "score": beam.get_prob(i=i, dep=(head, child), label=label),
                            "source": model_name,
                            "input_hash": task[INPUT_HASH_ATTR],
                        }
                    )
                yield task

    stream = predict_arcs(nlp, stream, beam_width=beam_width, batch_size=batch_size)
    for batch in partition_all(batch_size, stream):
        batch = list(batch)
        for eg in batch:
            for arc in eg.get("arcs", []):
                score = arc.get("score", 1.0)
                if score <= min_score:
                    continue
                if labels and arc["label"] not in labels:
                    continue
                if arc["label"] == "punct":
                    continue
                task = copy.deepcopy(eg)
                task["arcs"] = [arc]
                if "meta" not in task:
                    task["meta"] = {}
                task["meta"]["score"] = score
                task["meta"]["rank"] = arc["rank"]
                task = set_hashes(task, overwrite=True)
                yield score, task


class DependencyParserModel:
    nlp: "Language"
    labels: Optional[List[str]] = None
    orig_nlp: "Language"
    history: List[TaskType]

    def __init__(self, nlp: "Language", label: Optional[Sequence[str]] = None) -> None:
        assert nlp is not None
        self.nlp = nlp
        self.labels = list(label) if label is not None else []
        self.orig_nlp = copy_nlp(nlp)
        self.history: List[TaskType] = []

    def __call__(
        self,
        stream: StreamType,
        batch_size: int = 64,
        beam_width: int = 32,
        min_score: float = 0.0,
    ) -> ScoredStreamType:
        return predict(
            stream,
            self.nlp,
            self.labels if self.labels is not None else [],
            batch_size,
            beam_width,
            min_score,
        )

    def update(
        self, stream: Sequence[TaskType], drop: float = 0.0, batch_size: int = 8
    ) -> float:
        stream = merge_arcs(stream)
        if not stream:
            return 0.0
        self.history.extend(stream)
        random.shuffle(self.history)
        # TODO: Find better streaming SGD algorithm
        nr_update = 1 + len(self.history) // (batch_size * 10)
        losses = {"parser": 1e-8, "skipped": 0.0}
        n = 0.0
        for batch in take(nr_update, partition_all(batch_size, self.history)):
            batch = list(batch)
            texts = [eg["text"] for eg in batch]
            arcs = [eg["arcs"] for eg in batch]
            self._update(texts, arcs, losses, drop=drop)
            n += len(batch)
        if n:
            losses["parser"] /= n
        return losses["parser"]

    def _update(
        self,
        texts: List[str],
        annots: Sequence[List[Dict[str, Any]]],
        losses: Dict[str, float],
        drop: float = 0.0,
        beam_width: int = 16,
        beam_density: float = 0.0,
    ) -> None:
        examples = []
        losses.setdefault("skipped", 0.0)
        beam = _BatchBeam(self.orig_nlp, texts, w=beam_width, b=beam_density)
        best_parses = beam.predict_best(annots, max_wrong=0, min_right=1)
        assert len(texts) == len(best_parses) == len(annots)
        for text, annot, best_parse in zip(texts, annots, best_parses):
            doc = self.nlp.make_doc(text)
            if best_parse is not None:
                heads, deps = _arc_dicts_to_arrays(best_parse, len(doc))
            else:
                heads, deps = _arc_dicts_to_arrays(annot, len(doc), answered=True)
            if [MISSING_VALUE for _ in range(len(doc))] != deps:
                example = Example.from_dict(doc, {"heads": heads, "deps": deps})
                examples.append(example)
        with self.nlp.select_pipes(enable=["transformer", "tok2vec", "parser"]):
            self.nlp.update(examples, losses=losses, drop=drop)


def _arc_dicts_to_tuples(
    arc_dicts: Sequence[Dict[str, Any]], answered: bool = False
) -> Tuple[List[Tuple[int, int, str]], List[Tuple[int, int, str]]]:
    arc_tuples, incorrect_tuples = [], []
    for arc in arc_dicts:
        if arc.get("answer") == "accept":
            arc_tuples.append((arc["head"], arc["child"], arc["label"]))
        elif arc.get("answer") == "reject":
            incorrect_tuples.append((arc["head"], arc["child"], arc["label"]))
        elif not answered:
            arc_tuples.append((arc["head"], arc["child"], arc["label"]))
    return arc_tuples, incorrect_tuples


def _arc_dicts_to_arrays(
    arc_dicts: Sequence[Dict[str, Any]], nr_token: int, answered: bool = False
) -> Tuple[List[int], List[str]]:
    # TODO v3: is this the best way to represent missing information?
    heads = [i for i in range(nr_token)]
    deps = [MISSING_VALUE for _ in range(nr_token)]
    for arc in arc_dicts:
        answer = arc.get("answer")
        if answer == "accept" or not answered:
            heads[arc["child"]] = arc["head"]
            deps[arc["child"]] = arc["label"]
    assert len(heads) == nr_token
    assert len(deps) == nr_token
    return heads, deps


def _score_deps(
    guesses: List[Tuple[int, int, str]],
    gold_annots: List[Tuple[int, int, str]],
    incorrect_annots: List[Tuple[int, int, str]],
) -> Tuple[float, float, float]:
    right = 0.0
    wrong = 0.0
    unk = 0.0
    for head, child, dep in guesses:
        if (head, child, dep) in gold_annots:
            right += 1
        elif (head, child, dep) in incorrect_annots:
            wrong += 1
        else:
            unk += 1
    for arc in gold_annots:
        if arc not in guesses:
            wrong += 1
    return right, wrong, unk
