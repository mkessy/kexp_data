import copy
import random
from collections import Counter, defaultdict
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    List,
    Optional,
    Sequence,
    Tuple,
    Union,
    cast,
)

from spacy.pipeline import EntityRecognizer
from spacy.tokens import Span

# This is missing from spaCy's pyi file
from spacy.tokens.doc import SetEntsDefault  # pyright: ignore
from spacy.training import Example
from spacy.util import filter_spans
from toolz.itertoolz import partition_all, take

from ..types import ScoredStreamType, StreamType, TaskType
from ..util import (
    BINARY_ATTR,
    INPUT_HASH_ATTR,
    NER_DEFAULT_BEAM_DENSITY,
    NER_DEFAULT_INCORRECT_KEY,
    copy_nlp,
    log,
    set_hashes,
)

if TYPE_CHECKING:
    from spacy.language import Language
    from spacy.tokens import Doc, Token


NUMERICS = set(["QUANTITY", "DATE", "CARDINAL", "TIME", "MONEY", "ORDINAL", "PERCENT"])


def guess_batch_size(n_examples: int) -> int:
    """Heuristic to guess batch size: min(n_examples / 20, 16)"""
    return min(max(4, n_examples // 20), 16)


def merge_spans(examples: Iterable[TaskType]) -> List[TaskType]:
    log(f"MODEL: Merging entity spans of {len(list(examples))} examples")
    examples_lst = [
        copy.deepcopy(eg) for eg in examples if eg.get("answer") != "ignore"
    ]
    log(f"MODEL: Using {len(examples_lst)} examples (without 'ignore')")
    by_input: Dict[str, List[TaskType]] = defaultdict(list)
    for eg in examples_lst:
        eg.setdefault("spans", [])
        if "answer" in eg:
            for span in eg["spans"]:
                span.setdefault("answer", eg["answer"])
    keys = {}
    for eg in examples_lst:
        by_input[eg["text"]].append(eg)
        keys[eg["text"]] = True
    output = []
    for key in keys:
        group = by_input[key]
        spans = []
        for eg in group[1:]:
            spans.extend(eg["spans"])
        eg = dict(group[0])
        eg.setdefault("spans", [])
        eg["spans"].extend(spans)
        eg = set_hashes(eg, overwrite=True)
        output.append(eg)
    return output


class _BatchBeam:
    """Manage a set of analyses for a batch of texts."""

    def __init__(
        self,
        nlp: "Language",
        texts: Sequence[str],
        w: int = 4,
        b: float = NER_DEFAULT_BEAM_DENSITY,
    ) -> None:
        docs = list(nlp.pipe(texts))
        ner = cast(EntityRecognizer, nlp.get_pipe("ner"))
        beams = ner.beam_parse(docs, beam_width=w, beam_density=b)
        parses = []
        scores = []
        ent_scores = []
        for doc, beam in zip(docs, beams):
            ent_scores.append(Counter())
            parses.append([])
            scores.append([])
            for score, ents in ner.moves.get_beam_parses(beam):  # type: ignore
                scores[-1].append(score)
                ents = [(s, e, L) for (s, e, L) in ents if e != -1]
                ents = [(s, e, doc.vocab.strings[L]) for s, e, L in ents]
                parses[-1].append([Span(doc, s, e, L) for s, e, L in ents])
                for seL in ents:
                    ent_scores[-1][seL] += score
        self.docs = docs
        self.parses = parses
        self.scores = scores
        self.ent_scores = ent_scores
        self.w = w
        self.b = b

    def __len__(self) -> int:
        return len(self.docs)

    def predict_best(
        self,
        gold_ents: Sequence[Sequence[Dict[str, Any]]] = tuple(),
        max_wrong: Optional[int] = 0,
        min_right: Optional[int] = 1,
        no_missing: Optional[Sequence[bool]] = None,
    ) -> List[Optional[Sequence[Dict[str, Any]]]]:
        output: List[Optional[Sequence[Dict[str, Any]]]] = []
        for i in range(len(self.docs)):
            if no_missing is not None and no_missing[i]:
                # this code is probably never run?
                # the main output is supposed to a list of lists of dicts, but this is a list of dicts
                output.append(gold_ents[i])
                continue
            assert i < len(gold_ents)
            golds, incorrect_golds = _span_dicts_to_tuples(gold_ents[i])
            stats_parses = self.evaluate_parses(i, golds, incorrect_golds)
            for stats, parse in stats_parses:
                if (max_wrong is None or stats["wrong"] <= max_wrong) and (
                    min_right is None or stats["right"] >= min_right
                ):
                    output.append(parse)
                    break
            else:
                output.append(None)
        return output

    def evaluate_parses(
        self,
        i: int,
        gold_tuples: List[Tuple[int, int, str]],
        incorrect_tuples: List[Tuple[int, int, str]],
    ) -> List[Tuple[Dict[str, Union[float, int]], List[Dict[str, Any]]]]:
        doc = self.docs[i]
        sortable = []
        for j, parse in enumerate(self.parses[i]):
            guess_ents = [(s.start_char, s.end_char, s.label_) for s in parse]
            right, wrong, unk = _score_ents(
                doc, guess_ents, gold_tuples, incorrect_tuples
            )
            prob = self.scores[i][j]
            sortable.append(((-wrong, right, prob, unk), j))
        sortable.sort(reverse=True)
        output = []
        for (neg_wrong, right, prob, unk), j in sortable:
            stats = {
                "acc": right / (right - neg_wrong + 1e-8),
                "right": right,
                "wrong": -neg_wrong,
                "unk": unk,
                "prob": prob,
                "rank": j,
            }
            output.append((stats, self.format_parse(i, j)))
        return output

    def get_entities(self, i: int) -> List[Tuple[int, Span]]:
        ents = []
        seen_ents = set()
        for rank, parse in enumerate(self.parses[i]):
            for span in parse:
                key = (span.text, span.start_char, span.label_)
                if key not in seen_ents:
                    ents.append((rank, span))
                    seen_ents.add(key)
        return ents

    def get_prob(
        self,
        text: Optional[str] = None,
        label: Optional[str] = None,
        i: Optional[int] = None,
        w: Optional[int] = None,
    ) -> float:
        if i is not None:
            batch_parses = [self.parses[i]]
            batch_scores = [self.scores[i]]
        else:
            batch_parses = list(self.parses)
            batch_scores = list(self.scores)
        w = w or self.w
        not_prob = 1.0
        text_hash: Optional[int] = None
        label_hash: Optional[int] = None
        if text is not None:
            text_hash = self.docs[0].vocab.strings[text]
        if label is not None:
            label_hash = self.docs[0].vocab.strings[label]
        for doc_scores, doc_parses in zip(batch_scores, batch_parses):
            for score, parse in zip(doc_scores[:w], doc_parses[:w]):
                for span in parse:
                    span_hash = self.docs[0].vocab.strings[span.text]
                    if text is None or span_hash == text_hash:
                        if label is None or span.label == label_hash:
                            not_prob *= 1.0 - score
        return 1.0 - not_prob

    def get_prob_by_index(self, i: int, j: int, k: int) -> float:
        span = self.parses[i][j][k]
        ent_score = self.ent_scores[i][(span.start, span.end, span.label)]
        total = sum(self.scores[i])
        return ent_score / total

    def format_parse(self, i: int, j: int) -> List[Dict[str, Any]]:
        output = []
        for k, span in enumerate(self.parses[i][j]):
            output.append(
                {
                    "start": span.start_char,
                    "end": span.end_char,
                    "text": span.text,
                    "rank": j,
                    "label": span.label_,
                    "score": self.get_prob_by_index(i=i, j=j, k=k),
                }
            )
        return output


def predict(
    stream: StreamType,
    nlp: "Language",
    labels: Optional[Sequence[str]],
    batch_size: int,
    beam_width: int,
    min_score: float,
) -> ScoredStreamType:
    # These are nested within this scope just for code organization, to
    # make clear that these are the only places the helpers are used.
    # We're not using these as closures.
    def predict_spans(
        nlp: "Language", stream: StreamType, batch_size: int, beam_width: int
    ) -> StreamType:
        if "lang" in nlp.meta and "name" in nlp.meta:
            model_name = nlp.meta["lang"] + "_" + nlp.meta["name"]
        else:
            model_name = "?"
        for batch in partition_all(batch_size, stream):
            log(f"MODEL: Predicting spans for batch (batch size {batch_size})")
            batch = list(batch)
            texts = [eg["text"] for eg in batch]
            beam = _BatchBeam(nlp, texts, w=beam_width, b=NER_DEFAULT_BEAM_DENSITY)
            for i, eg in enumerate(batch):
                task = dict(eg)
                spans = task.setdefault("spans", [])
                # set predefined spans in the stream to score 1.0
                for span in spans:
                    if "score" not in span:
                        span["score"] = 1.0
                for rank, span in beam.get_entities(i):
                    spans.append(
                        {
                            "start": span.start_char,
                            "end": span.end_char,
                            "text": span.text,
                            "rank": rank,
                            "label": span.label_,
                            "score": beam.get_prob(
                                i=i, text=span.text, label=span.label_
                            ),
                            "source": model_name,
                            "input_hash": task[INPUT_HASH_ATTR],
                        }
                    )
                yield task

    def get_tasks(
        stream: StreamType,
        batch_size: int = 32,
        return_scores: bool = False,
        include_empty: bool = False,
    ) -> Union[StreamType, ScoredStreamType]:
        def sort_by_entity(batch: List[TaskType]) -> List[TaskType]:
            log(f"MODEL: Sorting batch by entity type (batch size {batch_size})")
            ent_tasks = {}
            ent_scores = Counter()
            empty_output = []
            for eg in batch:
                if eg.get("spans"):
                    ent = eg["spans"][0]
                    if "text" not in ent:
                        ent["text"] = eg["text"][ent["start"] : ent["end"]]
                    ent_tasks.setdefault(ent["text"], []).append(eg)
                    ent_scores[ent["text"]] += ent["score"]
                elif include_empty:
                    empty_output.append(eg)
            output = []
            emptiness_perc = len(empty_output) / (len(batch) + len(empty_output))
            empty = 0
            for ent, _ in ent_scores.most_common():
                output.extend(ent_tasks[ent])
                while (
                    empty < len(empty_output) and empty / len(output) < emptiness_perc
                ):
                    output.append(empty_output[empty])
                    empty += 1
            while empty < len(empty_output):
                output.append(empty_output[empty])
                empty += 1
            return output

        for batch in partition_all(batch_size, stream):
            batch = list(batch)
            output = []
            for eg in batch:
                spans = eg.get("spans", [])
                if len(spans) == 0 and include_empty:
                    eg.setdefault("meta", {}).setdefault("score", 1.0)
                    eg[BINARY_ATTR] = False
                    output.append(eg)
                elif len(spans) == 1:
                    score = spans[0].get("score", 1.0)
                    eg.setdefault("meta", {}).setdefault("score", score)
                    eg[BINARY_ATTR] = True
                    output.append(eg)
                else:
                    meta = eg.get("meta", {})
                    for span in spans:
                        task = copy.deepcopy(eg)
                        task["text"] = eg["text"]
                        task["spans"] = [span]
                        task["meta"] = dict(meta)
                        task["meta"]["score"] = span.get("score", 1.0)
                        task = set_hashes(task, overwrite=True)
                        task[BINARY_ATTR] = True
                        output.append(task)
            output = sort_by_entity(output)
            for eg in output:
                if return_scores:
                    yield eg["meta"]["score"], eg
                else:
                    yield eg

    # Now the body of the method.
    # These two helper functions are defined above.
    stream = predict_spans(nlp, stream, batch_size=batch_size, beam_width=beam_width)
    scored_stream = cast(
        ScoredStreamType, get_tasks(stream, return_scores=True, include_empty=True)
    )
    for score, eg in scored_stream:
        if score <= min_score:
            continue
        if not labels or not eg["spans"] or eg["spans"][0]["label"] in labels:
            yield score, eg


def ensure_sentencizer(nlp: "Language") -> None:
    # TODO: shouldn't this check for "parser" in nlp.pipe_names as well?
    if "sentencizer" not in nlp.pipe_names:
        nlp.add_pipe("sentencizer", first=True)
        log("MODEL: Added sentence boundary detector to model pipeline", nlp.pipe_names)


class EntityRecognizerModel:
    def __init__(self, nlp: "Language", label: Optional[Sequence[str]] = None) -> None:
        self.nlp = nlp
        self.orig_nlp = copy_nlp(nlp)
        self.labels = label
        self.history: List[TaskType] = []

    def __call__(
        self,
        stream: StreamType,
        batch_size: int = 64,
        beam_width: int = 16,
        min_score: float = 0.001,
    ) -> ScoredStreamType:
        return predict(stream, self.nlp, self.labels, batch_size, beam_width, min_score)

    def make_best(self, examples: Iterable[TaskType]) -> Iterable[TaskType]:
        """Add spans to a dataset for the best predictions, using the model and
        previous annotation decisions.
        """
        log("MODEL: Get best predictions for examples")
        golds = merge_spans(examples)
        for batch in partition_all(32, golds):
            batch = list(batch)
            batch_texts = [eg["text"] for eg in batch]
            batch_annots = [eg["spans"] for eg in batch]
            beam = _BatchBeam(self.nlp, batch_texts, w=16, b=NER_DEFAULT_BEAM_DENSITY)
            for i, parse in enumerate(
                beam.predict_best(batch_annots, max_wrong=None, min_right=None)
            ):
                eg = {"text": batch_texts[i], "spans": parse}
                eg[BINARY_ATTR] = False
                eg = set_hashes(eg)
                yield eg

    def update(
        self, examples: List[TaskType], drop: float = 0.0, batch_size: int = 8
    ) -> float:
        examples_lst = merge_spans(examples)
        if not examples_lst:
            return 0.0
        self.history.extend(examples_lst)
        random.shuffle(self.history)
        # TODO: Find better streaming SGD algorithm
        nr_update = 1 + len(self.history) // (batch_size * 10)
        losses = {"ner": 1e-8, "skipped": 0.0}
        n = 0.0
        for batch in take(nr_update, partition_all(batch_size, self.history)):
            batch = list(batch)
            texts = [eg["text"] for eg in batch]
            spans = [eg["spans"] for eg in batch]
            self._update(texts, spans, losses, drop=drop)
            n += len(batch)
        if n:
            losses["ner"] /= n
        return losses["ner"]

    def _update(
        self,
        texts: List[str],
        annots: Sequence[Sequence[Dict[str, Any]]],
        losses: Dict[str, float],
        drop: float = 0.0,
        beam_width: int = 16,
        beam_density: float = NER_DEFAULT_BEAM_DENSITY,
        no_missing: Optional[Sequence[bool]] = None,
        max_examples_with_missing_ner: float = 0.8,
    ) -> None:
        correct_spans = []
        examples = []
        examples_with_missing_ner = 0
        losses.setdefault("skipped", 0.0)
        beam = _BatchBeam(self.orig_nlp, texts, w=beam_width, b=beam_density)
        # require 1 accept annotation to train on the full predicted parse, if there were no rejects
        best_parses = beam.predict_best(
            annots, max_wrong=0, min_right=1, no_missing=no_missing
        )
        ner_pipe = None
        ner_pipe_name = "ner"
        if "ner" in self.nlp.pipe_names:
            ner_pipe = cast(EntityRecognizer, self.nlp.get_pipe("ner"))
        elif "beam_ner" in self.nlp.pipe_names:
            ner_pipe = cast(EntityRecognizer, self.nlp.get_pipe("beam_ner"))
        assert ner_pipe, "Could not identify an NER component in the pipeline"
        incorrect_key = (
            ner_pipe.cfg.get("incorrect_spans_key") or NER_DEFAULT_INCORRECT_KEY  # type: ignore
        )
        for text, annot, best_parse in zip(texts, annots, best_parses):
            example = Example(self.nlp.make_doc(text), self.nlp.make_doc(text))
            if best_parse is not None:
                correct_spans, incorrect_spans = _span_dicts_to_spans(
                    example.reference, best_parse
                )
                assert len(incorrect_spans) == 0
            else:
                correct_spans, incorrect_spans = _span_dicts_to_spans(
                    example.reference, annot, answered=True
                )
            reference = example.reference
            correct_spans = filter_spans(correct_spans)
            perc_with_missing_ner = examples_with_missing_ner / (len(examples) + 0.0001)
            example.reference.spans[incorrect_key] = incorrect_spans
            if (
                len(incorrect_spans) > 0
                and perc_with_missing_ner < max_examples_with_missing_ner
            ):
                reference.set_ents(correct_spans, default=SetEntsDefault.missing)
                examples_with_missing_ner += 1
            else:
                reference.set_ents(correct_spans, default=SetEntsDefault.outside)
            examples.append(example)
        try:
            with self.nlp.select_pipes(
                enable=["transformer", "tok2vec", ner_pipe_name]
            ):
                self.nlp.update(examples, losses=losses, drop=drop)
        except Exception as e:
            spans = [(span.start, span.end, span.label_) for span in correct_spans]
            log(f"MODEL: {spans}")
            raise e from None


def _span_dicts_to_spans(
    doc: "Doc", span_dicts: Sequence[Dict[str, Any]], answered: bool = False
) -> Tuple[List[Span], List[Span]]:
    correct_spans = []
    incorrect_spans = []
    for span in span_dicts:
        char_span = doc.char_span(span["start"], span["end"], span["label"])
        if span.get("answer") == "accept":
            correct_spans.append(char_span)
        elif span.get("answer") == "reject":
            incorrect_spans.append(char_span)
        elif not answered:
            correct_spans.append(char_span)
    return correct_spans, incorrect_spans


def _span_dicts_to_tuples(
    span_dicts: Sequence[Dict[str, Any]], answered: bool = False
) -> Tuple[List[Tuple[int, int, str]], List[Tuple[int, int, str]]]:
    correct_tuples = []
    incorrect_tuples = []
    for span in span_dicts:
        span_tuple = (span["start"], span["end"], span["label"])
        if span.get("answer") == "accept":
            correct_tuples.append(span_tuple)
        elif span.get("answer") == "reject":
            incorrect_tuples.append(span_tuple)
        elif not answered:
            correct_tuples.append(span_tuple)
    return correct_tuples, incorrect_tuples


def _score_ents(
    doc: "Doc",
    guess_ents: List[Tuple[int, int, str]],
    gold_annots: List[Tuple[int, int, str]],
    incorrect_annots: List[Tuple[int, int, str]],
    labels: Optional[Sequence[str]] = None,
    no_missing: bool = False,
) -> Tuple[float, float, float]:
    if labels:
        gold_annots = [(s, e, L) for s, e, L in gold_annots if L in labels]
        guess_ents = [(s, e, L) for s, e, L in guess_ents if L in labels]

    true_ents = {(s, e, L) for s, e, L in gold_annots if L != "O"}
    false_ents = {(s, e, L) for s, e, L in incorrect_annots if L != "O"}
    true_Os = {s for s, e, L in gold_annots if L == "O"}
    false_Os = {s for s, e, L in incorrect_annots if L == "O"}

    right = 0.0
    wrong = 0.0
    unk = 0.0
    starts = {w.idx: w.i for w in doc}
    ends = {w.idx + len(w): w.i + 1 for w in doc}

    def get_words(s: int, e: int) -> List["Token"]:
        span = doc[starts[s] : ends[e]]
        return [w for w in span]

    for start_char, end_char, label in guess_ents:
        if (start_char, end_char, label) in true_ents:
            right += 1
        elif (start_char, end_char, label) in false_ents:
            wrong += 1
        elif label not in NUMERICS and any(
            word.idx in true_Os for word in get_words(start_char, end_char)
        ):
            wrong += 1
        elif no_missing:
            wrong += 1
        else:
            unk += 1
    for ent in true_ents:
        if ent not in guess_ents:
            wrong += 1
    ent_words = set()
    for start, end, label in guess_ents:
        for word in get_words(start, end):
            ent_words.add(word.idx)
    for start in false_Os:
        if start not in ent_words:
            wrong += 1
    return right, wrong, unk
