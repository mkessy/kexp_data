from .dep import DependencyParserModel, merge_arcs  # noqa: F401
from .ner import EntityRecognizerModel, merge_spans  # noqa: F401
