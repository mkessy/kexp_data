import copy
from collections import Counter, defaultdict
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    List,
    Optional,
    Sequence,
    Set,
    Tuple,
    Union,
    cast,
)
from typing_extensions import TypedDict

import srsly
from spacy.matcher import Matcher, PhraseMatcher
from spacy.tokens import Span
from spacy.util import filter_spans

from ..types import ScoredStreamType, StreamType, TaskType
from ..util import get_hash, log, set_hashes

if TYPE_CHECKING:
    from spacy.language import Language
    from spacy.pipeline import EntityRecognizer


PATTERN_ID_DELIMITER = "||"
TokenPatternType = List[Dict[str, Any]]
PhrasePatternType = str
TokenPatternsType = Dict[str, List[Tuple[int, TokenPatternType]]]
PhrasePatternsType = Dict[str, List[Tuple[int, PhrasePatternType]]]


class PatternType(TypedDict):
    label: str
    pattern: Union[TokenPatternType, PhrasePatternType]
    id: Optional[int]


def parse_patterns(
    patterns: Iterable[PatternType],
) -> Tuple[TokenPatternsType, PhrasePatternsType, Dict[int, int]]:
    """Pre-process and validate match patterns, and sort them into token
    patterns and phrase patterns. Raises ValueError for invalid pattern. The
    returned lists of patterns consist of `(id, pattern)` tuples. Existing
    "id" values on the pattern are respected. If no ID is present, a hash
    based on the pattern and label is used.

    patterns (list): A list of match patterns, usually via JSONL file.
    RETURNS (tuple): A `(token_patterns, phrase_patterns)` tuple of two lists
        consisting of `(id, pattern)` tuples.
    """
    token_patterns = defaultdict(list)
    phrase_patterns = defaultdict(list)
    line_numbers = {}
    for i, entry in enumerate(patterns):
        if not is_valid_pattern(entry):
            raise ValueError("Invalid pattern: %s" % repr(entry))
        label = entry["label"]
        pattern = entry["pattern"]
        # Only re-use existing ID if it's an int: https://support.prodi.gy/t/4220
        pattern_id = entry.get("id")
        if not pattern_id or not isinstance(pattern_id, int):
            pattern_id = get_pattern_id(entry)
        if isinstance(pattern, list):
            token_patterns[label].append((pattern_id, pattern))
        elif isinstance(pattern, str):
            phrase_patterns[label].append((pattern_id, pattern))
        line_numbers[pattern_id] = i
    return token_patterns, phrase_patterns, line_numbers


def is_valid_pattern(entry: PatternType) -> bool:
    """Check if a match pattern (usually an entry in a patterns JSONL file) is
    valid and can be used by spaCy's matcher.

    entry (dict): The entry in the list of patterns.
    RETURNS (bool): Whether the pattern is valid.
    """
    return (
        "pattern" in entry
        and "label" in entry
        and (
            isinstance(entry["pattern"], list)
            or isinstance(entry["pattern"], str)
            and isinstance(entry["label"], str)
        )
    )


def get_pattern_id(entry: PatternType) -> int:
    pattern_id = get_hash(cast(dict, entry), ["label", "pattern"], ignore=[])
    return pattern_id


def _get_pattern_name(label: str, pattern_id: int) -> str:
    """Generate a pattern name from an ID and a label."""
    return f"{label}{PATTERN_ID_DELIMITER}{pattern_id}"


def parse_pattern_name(pattern_name: str) -> Tuple[str, int]:
    """Convert a pattern name to an ID and label."""
    label, pattern_id = pattern_name.split(PATTERN_ID_DELIMITER)
    return label, int(pattern_id)


def create_matcher(nlp: "Language", token_patterns: TokenPatternsType) -> Matcher:
    matcher = Matcher(nlp.vocab)
    for label, patterns in token_patterns.items():
        for pattern_id, pattern in patterns:
            name = _get_pattern_name(label, pattern_id)
            nlp.vocab.strings.add(name)
            matcher.add(name, [pattern])
    return matcher


def create_phrase_matcher(
    nlp: "Language", phrase_patterns: PhrasePatternsType
) -> PhraseMatcher:
    phrase_matcher = PhraseMatcher(nlp.vocab)  # pyright: ignore
    for label, patterns in phrase_patterns.items():
        for pattern_id, pattern in patterns:
            name = _get_pattern_name(label, pattern_id)
            nlp.vocab.strings.add(name)
            phrase_matcher.add(name, [nlp(pattern)])
    return phrase_matcher


class PatternMatcher:
    nlp: "Language"
    prior_correct: float
    prior_incorrect: float
    filter_labels: List[str]
    matchers: List[Union[Matcher, PhraseMatcher]]
    correct_scores: Counter
    incorrect_scores: Counter
    labels: Set[str]

    def __init__(
        self,
        nlp: "Language",
        prior_correct: float = 2.0,
        prior_incorrect: float = 2.0,
        label_span: bool = True,
        label_task: bool = False,
        filter_labels: Optional[Sequence[str]] = None,
        combine_matches: bool = False,
        all_examples: bool = False,
        allow_overlap: bool = False,
        task_hash_keys: Iterable[str] = ("spans", "label", "options"),
    ) -> None:
        self.nlp = nlp
        self.matchers = []
        self.correct_scores = Counter()
        self.incorrect_scores = Counter()
        self.labels = set()
        self.filter_labels = list(filter_labels) if filter_labels is not None else []
        self.prior_correct = prior_correct
        self.prior_incorrect = prior_incorrect
        self.label_span = label_span
        self.label_task = label_task
        self.combine_matches = combine_matches
        self.allow_overlap = allow_overlap
        self.all_examples = all_examples
        self.task_hash_keys = task_hash_keys
        self.line_numbers = {}
        if all_examples and label_task:
            raise ValueError(
                "The PatternMatcher cannot return all examples and attach a "
                "label only if a match is found. Either set `label_task` to "
                "False or set `all_examples` to False."
            )

    def add_patterns(self, patterns: Sequence[PatternType]) -> None:
        if self.filter_labels:
            # Only add patterns for given labels, if filter labels are set
            patterns = [
                p for p in patterns if "label" in p and p["label"] in self.filter_labels
            ]
        log(f"MODEL: Adding {len(patterns)} patterns")
        token_patterns, phrase_patterns, line_nums = parse_patterns(patterns)
        if token_patterns:
            matcher = create_matcher(self.nlp, token_patterns)
            self.add_matcher(matcher)
        if phrase_patterns:
            phrase_matcher = create_phrase_matcher(self.nlp, phrase_patterns)
            self.add_matcher(phrase_matcher)
        self.line_numbers.update(line_nums)

        if self.matchers:
            for entry in patterns:
                pattern_id = entry.get("id", get_pattern_id(entry))
                # TODO: Do we want a Counter here? If we want to deal with floats, I guess we should use
                # a defaultdict?
                if not self.correct_scores[str(pattern_id)]:
                    self.correct_scores[str(pattern_id)] = cast(int, self.prior_correct)
                if not self.incorrect_scores[str(pattern_id)]:
                    self.incorrect_scores[str(pattern_id)] = cast(
                        int, self.prior_incorrect
                    )
            self.labels = set([entry["label"] for entry in patterns])
            if "ner" in self.nlp.pipe_names:
                ner = cast("EntityRecognizer", self.nlp.get_pipe("ner"))
                log("MODEL: Ensure pattern labels are added to EntityRecognizer")
                for label in self.labels:
                    ner.add_label(label)  # type: ignore
        else:
            # Make sure we at least log it when there are no patterns passed in
            log("MODEL: No patterns found to initialize the matcher.")

    def add_matcher(self, matcher: Union[Matcher, PhraseMatcher]) -> None:
        self.matchers.append(matcher)

    def __call__(self, stream: StreamType, batch_size: int = 32) -> ScoredStreamType:
        texts_examples = ((eg["text"], eg) for eg in stream)
        for doc, eg in self.nlp.pipe(
            texts_examples, as_tuples=True, batch_size=batch_size
        ):
            eg = copy.deepcopy(eg)
            matched_spans = []
            for matcher in self.matchers:
                for match_id, start_token, end_token in matcher(doc):
                    span = Span(doc, start_token, end_token, label=match_id)
                    matched_spans.append(span)
            if self.combine_matches:  # show all matches in a single task
                if matched_spans or self.all_examples:
                    all_labels = Counter()
                    if not self.allow_overlap:
                        combined_spans = filter_spans(matched_spans)
                    else:
                        combined_spans = matched_spans
                    task_spans = []
                    for span_obj in combined_spans:
                        label, pattern_id = parse_pattern_name(span_obj.label_)
                        all_labels[label] += 1
                        span = {
                            "text": span_obj.text,
                            "start": span_obj.start_char,
                            "end": span_obj.end_char,
                            "label": label,
                            "pattern": pattern_id,
                        }
                        task_spans.append(span)
                    eg["spans"] = task_spans
                    if self.label_task:
                        # Pick the label with the most matches to label the span
                        best_label, _ = all_labels.most_common(1)[0]
                        eg["label"] = best_label
                        if not self.label_span:
                            # If the user doesn't want to also see labels on the
                            # spans, we only show the matches that correspond to
                            # the top-level label displayed at the top
                            eg["spans"] = [
                                s for s in eg["spans"] if s["label"] == best_label
                            ]
                    if not self.label_span:
                        for span in eg["spans"]:
                            del span["label"]
                    all_ids = [self.line_numbers[s["pattern"]] for s in eg["spans"]]
                    eg.setdefault("meta", {})
                    eg["meta"]["pattern"] = ", ".join([f"{p}" for p in all_ids])
                    # Only hash based on certain task keys to prevent duplicates
                    # (e.g. textcat.teach treating with/without spans as different)
                    eg = set_hashes(eg, overwrite=True, task_keys=self.task_hash_keys)
                    yield (0.5, eg)
            else:
                for span_obj in matched_spans:
                    task = copy.deepcopy(eg)
                    label, pattern_id = parse_pattern_name(span_obj.label_)
                    correct = self.correct_scores[str(pattern_id)]
                    incorrect = self.incorrect_scores[str(pattern_id)]
                    if correct != 0 and incorrect != 0:
                        score = float(correct / (correct + incorrect))
                    else:
                        score = 0.0
                    span = {
                        "text": span_obj.text,
                        "start": span_obj.start_char,
                        "end": span_obj.end_char,
                        "priority": score,
                        "score": score,
                        "pattern": pattern_id,
                    }
                    if self.label_span:
                        span["label"] = label
                    if self.label_task:
                        task["label"] = label
                    task["spans"] = [span]
                    task.setdefault("meta", {})
                    if not isinstance(task["meta"], dict):  # strings etc.
                        task["meta"] = {"meta": task["meta"]}
                    task["meta"]["score"] = score
                    task["meta"]["pattern"] = self.line_numbers[pattern_id]
                    task = set_hashes(
                        task, overwrite=True, task_keys=self.task_hash_keys
                    )
                    yield score, task

    # kwargs for compatibility with other Model.update methods
    def update(self, examples: List[TaskType], **kwargs) -> float:
        for eg in examples:
            answer = eg["answer"]
            for span in eg["spans"]:
                if "pattern" in span:
                    pattern_id = span["pattern"]
                    if answer == "accept":
                        self.correct_scores[str(pattern_id)] += 1
                    elif answer == "reject":
                        self.incorrect_scores[str(pattern_id)] += 1
        return 0.0

    def from_disk(self, path: Union[str, Path]) -> "PatternMatcher":
        log("MODEL: Loading match patterns from disk", path)
        patterns_path = Path(path)
        if not patterns_path.exists():
            raise ValueError(f"Can't find patterns file: {path}")
        patterns = list(srsly.read_jsonl(patterns_path))
        self.add_patterns(cast(List[PatternType], patterns))
        return self
