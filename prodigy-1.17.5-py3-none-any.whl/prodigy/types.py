from __future__ import annotations

from datetime import datetime
from io import TextIOWrapper
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Iterator,
    List,
    Optional,
    TextIO,
    Tuple,
    Union,
)
from typing_extensions import Literal, NewType, NotRequired, TypedDict

from cloudpathlib import AnyPath, CloudPath
from fastapi.security.http import HTTPAuthorizationCredentials
from pydantic import (
    BaseModel,
    Field,
    StrictBool,
    StrictFloat,
    StrictInt,
    StrictStr,
    model_validator,
    validator,
)
from radicli import ExistingFilePath  # noqa: F401

if TYPE_CHECKING:
    from .components.db import Database
    from .core import Controller
    from .prodigy.components.stream import Stream


# Shared type hints
TaskType = Dict[str, Any]
StreamType = Iterator[TaskType]
ScoredStreamType = Iterator[Tuple[float, TaskType]]
SourceType = Union[str, Path, CloudPath, AnyPath, StreamType, TextIOWrapper, TextIO]
LabelsType = NewType("LabelsType", List[str])
PathInputType = Union[str, Path, CloudPath]
PathType = Union[Path, CloudPath]


class RecipeSettingsType(TypedDict):
    """Settings dictionary returned by a recipe function."""

    dataset: Union[str, Literal[False]]
    stream: Union[Stream, StreamType]
    view_id: str
    update: NotRequired[Optional[Callable[[List[TaskType]], Any]]]
    db: NotRequired[Optional[Union[str, "Database"]]]
    progress: NotRequired[Optional[Callable[["Controller", Any], float]]]
    on_load: NotRequired[Optional[Callable[["Controller"], None]]]
    on_exit: NotRequired[Optional[Callable[["Controller"], None]]]
    before_db: NotRequired[Optional[Callable[[List[TaskType]], List[TaskType]]]]
    validate_answer: NotRequired[Optional[Callable[[TaskType], None]]]
    get_session_id: NotRequired[Optional[Callable[[], str]]]
    exclude: NotRequired[Optional[List[str]]]
    config: NotRequired[Optional[Dict[str, Any]]]


ConfigTheme = Literal["basic", "eighties", "spacy", "brutalist", "dark"]
ConfigDiffStyle = Literal["words", "chars", "sentences"]
ConfigWritingDir = Literal["ltr", "rtl"]
ConfigLabelStyle = Literal["list", "dropdown"]
ConfigChoiceStyle = Literal["single", "multiple"]
ConfigExcludeBy = Literal["task", "input"]
ConfigButton = Literal["accept", "reject", "ignore", "undo"]


# Prodigy config submodels


class ConfigDbSettings(BaseModel):
    sqlite: Dict[str, str] = {}
    mysql: Dict[str, Any] = {}
    postgresql: Dict[str, Any] = {}


class ConfigBlock(BaseModel):
    view_id: str = "text"


# Prodigy config


class Config(BaseModel):
    # fmt: off
    # There's kind of no way to win with enums here: the code expects strings,
    # so if we use an enum value it potentially doesn't work. I've left the
    # ConfigButton enum above, but we should just use literals.
    buttons: List[ConfigButton] = ["accept", "reject", "ignore", "undo"]
    theme: ConfigTheme = "basic"
    custom_theme: Dict[str, Any] = {}
    batch_size: Optional[int] = 10
    history_size: Optional[int] = None
    total_examples_target: Optional[int] = None
    port: StrictInt = 8080
    host: StrictStr = "localhost"
    cors: StrictBool = True
    db: StrictStr = "sqlite"
    db_settings: ConfigDbSettings = ConfigDbSettings()
    api_keys: Dict[str, Any] = {}
    validate_data: StrictBool = Field(True, alias="validate")  # shadows BaseModel attribute
    auto_create: StrictBool = True
    auto_exclude_current: StrictBool = True
    auto_count_stream: StrictBool = False
    instant_submit: StrictBool = False
    feed_overlap: bool = True
    annotations_per_task: Optional[float] = None
    allow_work_stealing: bool = True
    feed_history_maxsize: Optional[int] = None
    show_stats: StrictBool = False
    hide_meta: StrictBool = False
    show_flag: StrictBool = False
    instructions: Union[StrictStr, StrictBool, None] = None
    swipe: StrictBool = False
    split_sents_threshold: Union[int, StrictBool, None] = None
    diff_style: ConfigDiffStyle = "words"
    html_template: Union[StrictStr, StrictBool, None] = None
    javascript: Optional[StrictStr] = None
    javascript_urls: Optional[List[str]] = None
    javascript_dir: Optional[Path] = None
    global_css: Optional[StrictStr] = None
    global_css_urls: Optional[List[str]] = None
    global_css_dir: Optional[Path] = None
    card_css: Optional[Union[Dict[str, Any], StrictBool]] = None
    writing_dir: ConfigWritingDir = "ltr"
    hide_true_newline_tokens: StrictBool = False
    honor_token_whitespace: StrictBool = True
    ner_manual_require_click: StrictBool = False
    ner_manual_label_style: ConfigLabelStyle = "list"
    label_style: ConfigLabelStyle = "list"
    choice_style: ConfigChoiceStyle = "single"
    choice_auto_accept: StrictBool = False
    darken_image: Union[StrictFloat, StrictInt] = 0
    show_bounding_box_center: StrictBool = False
    preview_bounding_boxes: StrictBool = False
    shade_bounding_boxes: StrictBool = False
    user_config: Dict[str, Any] = {}
    label: Optional[StrictStr] = None
    labels: List[StrictStr] = []
    blocks: List[ConfigBlock] = []
    exclude_by: ConfigExcludeBy = "task"
    keymap: Optional[Dict[str, List[str]]] = {}
    keymap_by_label: Optional[Dict[str, str]] = {}
    show_audio_cursor: Optional[StrictBool] = True
    show_audio_cursor_time: Optional[StrictBool] = True
    show_audio_timeline: Optional[StrictBool] = False
    show_audio_minimap: Optional[StrictBool] = True
    audio_bar_width: Optional[StrictInt] = 3
    audio_bar_height: Optional[StrictInt] = 2
    audio_bar_gap: Optional[StrictInt] = 2
    audio_bar_radius: Optional[StrictInt] = 2
    audio_max_zoom: Optional[StrictInt] = 5000
    audio_autoplay: Optional[StrictBool] = False
    audio_loop: Optional[StrictBool] = False
    audio_rate: Optional[Union[StrictInt, StrictFloat]] = 1.0
    wrap_relations: Optional[StrictBool] = False
    show_relations_labels: Optional[StrictBool] = True
    hide_relations_arrow: Optional[StrictBool] = False
    relations_span_labels: Optional[List[StrictStr]] = []
    image_manual_legacy: Optional[StrictBool] = False
    image_manual_modes: Optional[List[ImageManualType]] = ["rect", "polygon", "freehand"]
    image_manual_stroke_width: Optional[StrictInt] = 4
    image_manual_font_size: Optional[StrictInt] = 16
    image_manual_from_center: Optional[StrictBool] = False
    image_manual_show_labels: Optional[StrictBool] = True
    pages_show_thumbnails: Optional[StrictBool] = True
    pages_scroll_into_view: Optional[StrictBool] = True
    # fmt: on

    @validator(
        "instructions",
        "html_template",
        "split_sents_threshold",
        "card_css",
        pre=True,
        always=True,
    )
    def ensure_false(cls, v):
        # Backwards-compatible hack to support False-only boolean values
        if isinstance(v, bool) and v is not False:
            raise ValueError("expected value or false, not true")
        return v


# Task submodels

ViewId = Literal[
    "audio_manual",
    "audio",
    "blocks",
    "choice",
    "classification",
    "compare",
    "dep",
    "diff",
    "html",
    "image_manual",
    "image",
    "ner_manual",
    "ner",
    "pages",
    "pos_manual",
    "pos",
    "relations",
    "review",
    "sent_manual",
    "sent",
    "spans_manual",
    "spans",
    "tag_manual",
    "tag",
    "text_input",
    "text",
    "llm_io",
]
Answer = Literal["accept", "reject", "ignore"]
ImageManualType = Literal["rect", "polygon", "freehand"]


class Token(BaseModel):
    start: StrictInt
    end: StrictInt
    id: StrictInt
    disabled: StrictBool = False


class TextSpan(BaseModel):
    start: StrictInt
    end: StrictInt
    label: Optional[StrictStr] = None


class TextSpanLabel(BaseModel):
    start: StrictInt
    end: StrictInt
    label: StrictStr


class TextManualSpan(TextSpan):
    token_start: StrictInt
    token_end: StrictInt


class ImageSpan(BaseModel):
    id: Optional[Union[int, str]] = None
    type: Optional[ImageManualType] = None
    label: Optional[StrictStr] = None
    points: Optional[List[List[Union[float, int]]]] = None
    width: Optional[Union[float, int]] = None
    height: Optional[Union[float, int]] = None
    x: Optional[Union[float, int]] = None
    y: Optional[Union[float, int]] = None
    center: Optional[List[Union[float, int]]] = None
    color: Optional[str] = None


class AudioSpan(BaseModel):
    start: Union[StrictInt, StrictFloat]
    end: Union[StrictInt, StrictFloat]
    label: StrictStr
    color: Optional[StrictStr] = None
    id: Optional[StrictStr] = None


AnySpan = Union[TextSpan, TextManualSpan, ImageSpan]


class Relation(BaseModel):
    head: StrictInt
    child: StrictInt
    label: str
    color: Optional[str] = None


class ChoiceOption(BaseModel):
    id: Union[str, int]
    text: Optional[str] = None
    image: Optional[str] = None
    html: Optional[str] = None
    # TODO: Can this be empty list?
    spans: Optional[List[AnySpan]] = None
    # TODO: Can this be empty dict?
    style: Optional[Dict[str, Any]] = None


class ReviewVersion(BaseModel):
    sessions: List[Union[str, None]]
    default_version: bool = Field(False, alias="default")
    text: Optional[StrictStr] = None
    image: Optional[StrictStr] = None
    html: Optional[StrictStr] = None
    spans: Optional[List[AnySpan]] = None
    options: Optional[List[ChoiceOption]] = None
    accept: Optional[List[Union[str, int]]] = None
    answer: Answer


# Task models


class TaskModel(BaseModel):
    # These are properties that our task-specific models inherit from
    # Field aliases so underscore attributes aren't excluded from JSON schema
    input_hash: StrictInt = Field(..., alias="_input_hash")
    task_hash: StrictInt = Field(..., alias="_task_hash")
    view_id: Optional[ViewId] = Field(None, alias="_view_id")
    session_id: Optional[StrictStr] = Field(None, alias="_session_id")
    meta: Dict[str, Any] = {}


class TextTask(TaskModel):
    text: StrictStr


class HtmlTask(TaskModel):
    html: Optional[StrictStr] = None
    text: Optional[StrictStr] = None


class ClassificationTask(TaskModel):
    text: Optional[StrictStr] = None
    image: Optional[StrictStr] = None
    html: Optional[StrictStr] = None
    label: Optional[StrictStr] = None
    spans: Optional[List[AnySpan]] = None
    audio_spans: Optional[List[AudioSpan]] = None


class SpansTask(TaskModel):
    text: StrictStr
    spans: List[TextSpan]


class SpansManualTask(TaskModel):
    text: StrictStr
    spans: List[TextManualSpan] = []
    tokens: List[Token]


class RelationsTask(TaskModel):
    text: StrictStr
    spans: Optional[List[TextManualSpan]] = []
    tokens: List[Token]
    relations: Optional[List[Relation]] = []


class ImageTask(TaskModel):
    image: StrictStr
    width: Optional[Union[int, float]] = None
    height: Optional[Union[int, float]] = None
    spans: Optional[List[ImageSpan]] = None


class DepTask(TaskModel):
    text: StrictStr
    arcs: List[Relation]
    relations: Optional[List[Relation]] = None
    tokens: List[Token]


class ChoiceTask(TaskModel):
    text: Optional[StrictStr] = None
    image: Optional[StrictStr] = None
    html: Optional[StrictStr] = None
    options: Optional[List[ChoiceOption]] = None
    accept: List[Union[str, int]] = []

    @validator("options")
    def ids_must_be_unique(cls, v):
        all_ids = [option.id for option in v]
        if len(set(all_ids)) != len(v):
            raise ValueError(
                f"Option ids must be unique in a `choice` task. Received: {all_ids}."
            )
        return v


class CompareTask(TaskModel):
    id: Union[str, int]
    input: Optional[Dict[str, Any]] = None
    accept: Dict[str, Any]
    reject: Dict[str, Any]
    mapping: Dict[str, str]


class DiffTask(TaskModel):
    text: Optional[StrictStr] = None
    added: Optional[StrictStr] = None
    removed: Optional[StrictStr] = None
    input: Optional[Dict[str, Any]] = None
    # This would clash with choice:
    # accept: Dict[str, Any]
    reject: Dict[str, Any]


class ReviewTask(TaskModel):
    versions: List[ReviewVersion]
    view_id: ViewId


class TextInputTask(TaskModel):
    field_id: Optional[str] = None
    field_label: Optional[StrictStr] = None
    field_placeholder: Optional[StrictStr] = None
    field_rows: Optional[int] = None
    field_autofocus: Optional[bool] = False


class BlocksTask(TaskModel):
    pass


class AudioTask(TaskModel):
    # TODO: custom validation
    audio: Optional[StrictStr] = None
    video: Optional[StrictStr] = None
    audio_spans: Optional[List[AudioSpan]] = None


class PagesTask(TaskModel):
    pages: List[Dict[str, Any]]
    page_titles: Optional[List[Union[str, int]]] = None

    @validator("pages", pre=True, always=True)
    def has_view_id(cls, v):
        for page in v:
            if "view_id" not in page:
                raise ValueError("Each page needs to include a view_id")
        return v

    @model_validator(mode="after")
    @classmethod
    def pages_titles_equal(cls, data):
        if not data.page_titles:
            return data
        if len(data.pages) != len(data.page_titles):
            raise ValueError("Length of pages and page_titles needs to match")
        return data


# Training examples models


class NerExample(TaskModel):
    text: StrictStr
    spans: Optional[List[TextSpanLabel]] = []
    answer: Answer


class SpansExample(TaskModel):
    text: StrictStr
    spans: Optional[List[TextSpanLabel]] = []
    answer: Answer


class TextcatExample(TaskModel):
    text: StrictStr
    options: Optional[List[ChoiceOption]] = None
    accept: List[Union[str, int]] = []
    label: Optional[StrictStr] = None
    answer: Answer

    # See: https://github.com/samuelcolvin/pydantic/issues/506
    @validator("label", pre=True, always=True)
    def validate_label(cls, v, values):
        if not v and "options" not in values or "accept" not in values:
            raise ValueError(
                f"Expected 'label' OR 'options' and 'accept'. Got: {values}"
            )
        return v


class PosExample(TaskModel):
    text: StrictStr
    spans: List[TextSpanLabel]
    answer: Answer


class DepExample(DepTask):
    text: StrictStr
    arcs: Optional[List[Relation]] = None
    relations: Optional[List[Relation]] = None
    answer: Answer


# Recipe components


class RecipeComponents(BaseModel, extra="forbid"):
    dataset: Union[str, bool]
    view_id: ViewId
    stream: Any  # TODO: how to type Iterable in pydantic?
    update: Optional[Callable] = None
    db: Optional[Any] = True
    progress: Optional[Callable] = None
    on_load: Optional[Callable] = None
    on_exit: Optional[Callable] = None
    before_db: Optional[Callable] = None
    event_hooks: Optional[Dict[str, Callable]] = None
    validate_answer: Optional[Callable] = None
    get_session_id: Optional[Callable] = None
    task_router: Optional[Callable] = None
    session_factory: Optional[Callable] = None
    metrics: Optional[Callable] = None
    exclude: Optional[List[str]] = None
    config: Optional[Config] = None

    @validator("stream", pre=True, always=True)
    def validate_stream(cls, v):
        if not hasattr(v, "__iter__"):
            raise ValueError(f"expected iterable, not {type(v)}")

    @validator(
        "dataset",
        "update",
        "progress",
        "on_load",
        "on_exit",
        "exclude",
        pre=True,
        always=True,
    )
    def ensure_false(cls, v):
        # Support False-only boolean values, just in case
        if isinstance(v, bool) and v is not False:
            raise ValueError("expected value or false, not true")
        return v


# REST API


class SessionID(BaseModel):
    session_id: str
    aliases: List[str] = []


class JWTPayload(BaseModel):
    """JSON Web Token payload"""

    exp: int = Field(..., description="Token expiration date in UTC milliseconds")
    aud: str = Field(..., description="The audience that the token is intended for")
    iss: str = Field(..., description="The issuer of the auth token.")


class APIVersionResponse(BaseModel):
    name: str
    description: str
    author: str
    author_email: str
    url: str
    version: str
    license: str


class APISessionQuestionsRequest(BaseModel):
    session_id: Optional[str] = None
    excludes: Optional[List[int]] = None


class APIQuestionsResponse(BaseModel):
    tasks: List
    total: int
    progress: Optional[float] = None
    progress_kind: Optional[str] = None
    session_id: str


class APIAnswersRequest(BaseModel):
    answers: List
    session_id: Optional[str] = None
    annotator_id: Optional[str] = None


class APIAnswersResponse(BaseModel):
    progress: Optional[float] = None


class APIAnswerValidateRequest(BaseModel):
    answer: Dict


class APIAnswerValidateResponse(BaseModel):
    ok: bool
    message: Optional[str] = None


class APISessionAliasesRequest(BaseModel):
    session_id: str
    aliases: List


class APILogRequest(BaseModel):
    message: str
    data: Dict[str, Any] = {}
    session_id: Optional[str] = None
    timestamp: datetime


class Pattern(BaseModel):
    label: str
    pattern: List[Dict]


class JWTAuthorizationCredentials(HTTPAuthorizationCredentials):
    credentials: str = Field(..., description="The source JWT token string")
    scheme: str = Field("bearer", description="the HTTP authorization scheme")
    payload: JWTPayload = Field(..., description="JSON payload extracted from token")


# Forward updates
Config.update_forward_refs()
RecipeComponents.update_forward_refs()
