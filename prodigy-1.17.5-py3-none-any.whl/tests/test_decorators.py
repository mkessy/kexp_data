from pathlib import Path
from typing import Iterable, Iterator, List, cast
from typing_extensions import TypeVar

import pytest
import srsly

from prodigy.components.decorators import (
    support_both_streams,
    support_structured,
    support_unstructured,
)
from prodigy.components.source import ListSource, load_noop
from prodigy.components.stream import Stream
from prodigy.structured_types import Example, ensure_structured_stream
from prodigy.types import TaskType
from prodigy.util import set_hashes

_StructExampleT = TypeVar("_StructExampleT", bound=Example)


def test_support_both_streams_decorator():
    """Test base usage of decorator across different places."""
    examples = [
        set_hashes({"text": f"example {i}", "number": 1}) for i in range(10)
    ] * 2
    stream = Stream(source=ListSource(examples), loader=load_noop, wrappers=[])
    stream.create_queue("vincent", n_history=-1)

    @support_both_streams(stream_arg="stream")
    def func_to_apply(stream):
        for ex in stream:
            ex["number"] = 2
            yield ex

    orig_results = list(func_to_apply(examples))
    stream = func_to_apply(stream)
    assert isinstance(stream, Stream)
    stream_results = [
        q.data
        for q in stream.iter_queue(router=lambda d: ["vincent"], queue_id="vincent")
    ]

    stream_wrapper = Stream(
        source=ListSource(examples), loader=load_noop, wrappers=[func_to_apply]
    )
    stream_wrapper.create_queue("vincent", n_history=-1)
    queue = stream_wrapper.iter_queue(router=lambda d: ["vincent"], queue_id="vincent")
    wrapper_results = [q.data for q in queue]

    assert orig_results == stream_results
    assert stream_results == wrapper_results
    for ex in orig_results:
        assert ex["number"] == 2


def test_decorator_arg_placement():
    """The argument of the stream can be arg #1 or anywhere else. This test ensures that we can pick."""
    examples = [
        set_hashes({"text": f"example {i}", "number": 1}) for i in range(10)
    ] * 2
    stream = Stream(source=ListSource(examples), loader=load_noop, wrappers=[])
    stream.create_queue("vincent", n_history=-1)

    @support_both_streams(stream_arg="stream")
    def func_to_apply(a, b, stream, *, keyword_arg=10):
        for ex in stream:
            ex["number"] = keyword_arg
            yield ex

    orig_results = list(func_to_apply(1, 2, examples, keyword_arg=20))
    stream = func_to_apply(1, 2, stream, keyword_arg=20)
    assert isinstance(stream, Stream)

    stream_results = [
        q.data
        for q in stream.iter_queue(router=lambda d: ["vincent"], queue_id="vincent")
    ]

    stream_wrapper = Stream(
        source=ListSource(examples),
        loader=load_noop,
        wrappers=[lambda d: func_to_apply(1, 2, d, keyword_arg=20)],
    )
    stream_wrapper.create_queue("vincent", n_history=-1)
    queue = stream_wrapper.iter_queue(router=lambda d: ["vincent"], queue_id="vincent")
    wrapper_results = [q.data for q in queue]

    assert orig_results == stream_results
    assert stream_results == wrapper_results
    for ex in orig_results:
        assert ex["number"] == 20


## Test compat decorators


@pytest.fixture()
def input_unst(datasets_path: Path) -> List[TaskType]:
    data = srsly.read_jsonl(datasets_path / "input_2000.jsonl")
    output = []
    for eg in data:
        output.append(set_hashes(cast(dict, eg)))
    return output


@pytest.fixture()
def input_st(input_unst: List[TaskType]) -> Iterator[Example]:
    stream = ensure_structured_stream(
        input_unst, input_keys=["text"], server_ann_keys=["label"]
    )
    return stream


def test_support_structured_decorator(
    input_unst: List[TaskType], input_st: List[Example]
):
    @support_structured("stream", input_keys=["text"], server_ann_keys=["label"])
    def _set_label_unst(stream: Iterable[TaskType], label: str) -> Iterator[TaskType]:
        """Example unstructured operation"""
        for task in stream:
            task["label"] = label
            yield task

    unst_stream = cast(Iterator[TaskType], _set_label_unst(input_unst, "GREETING"))
    for task in unst_stream:
        assert task["label"] == "GREETING"

    st_stream = cast(Iterator[Example], _set_label_unst(input_st, "GREETING"))
    for task in st_stream:
        assert task.server_anns is not None
        assert task.server_anns["label"] == "GREETING"


def test_support_unstructured_decorator(
    input_unst: List[TaskType], input_st: List[Example]
):
    @support_unstructured("stream", input_keys=["text"], server_ann_keys=["label"])
    def _set_label_st(
        stream: Iterable[_StructExampleT], label: str
    ) -> Iterator[_StructExampleT]:
        """Example structured operation"""
        for task in stream:
            task.server_anns = {"label": label}
            yield task

    st_stream = cast(Iterator[Example], _set_label_st(input_st, "GREETING"))
    for task in st_stream:
        assert task.server_anns is not None
        assert task.server_anns["label"] == "GREETING"

    unst_stream = cast(Iterator[TaskType], _set_label_st(input_unst, "GREETING"))
    for task in unst_stream:
        assert task["label"] == "GREETING"
