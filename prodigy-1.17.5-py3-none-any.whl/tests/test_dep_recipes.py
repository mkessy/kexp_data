from pathlib import Path
from typing import List

import pytest

from prodigy.components.db import Database
from prodigy.components.loaders import JSONL
from prodigy.core import Controller
from prodigy.errors import RecipeError
from prodigy.recipes.dep import correct, teach
from prodigy.types import TaskType
from prodigy.util import set_hashes


@pytest.fixture
def dataset():
    return "tmp-test-dataset"


@pytest.fixture
def examples():
    return [{"text": "Example 1"}, {"text": "Example 2"}, {"text": "Example 3"}]


@pytest.fixture
def text_stream():
    data_path = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    tasks = JSONL(data_path)
    return [set_hashes(task) for task in tasks]


@pytest.fixture
def db(database: Database, dataset: str, examples: List[TaskType]):
    database.add_dataset(dataset, meta={"desc": "TMP dataset"})
    examples = [set_hashes(eg) for eg in examples]
    database.add_examples(examples, datasets=(dataset,))
    return database


# dep.teach #


def test_dep_teach_returns_components(dataset, spacy_model, nlp, examples):
    """Ensure that the dep.teach recipe properly returns components"""
    C = teach(dataset, nlp, source=examples)
    assert C["view_id"] == "dep"
    assert C["dataset"] == dataset
    assert hasattr(C["stream"], "__iter__")
    assert hasattr(C["update"], "__call__")
    assert C["config"]["lang"] == spacy_model.split("_")[0]
    assert "update" not in C["config"]


def test_dep_teach_empty_stream(dataset, nlp):
    """Ensure that the dep.teach recipe shows no results when there is less than one word."""
    examples = [{"text": str(i)} for i in range(200)]
    C = teach(dataset, nlp, source=examples)
    batch = []
    for eg in C["stream"]:
        batch.append(eg)
    assert len(batch) == 0


def test_dep_teach_can_stream(dataset, nlp):
    """Ensure that the dep.teach recipe can stream examples"""
    examples = [{"text": f"Running {i} kilometers."} for i in range(200)]
    C = teach(dataset, nlp, source=examples)
    batch = []
    cutoff = 20
    for eg in C["stream"]:
        batch.append(eg)
        if len(batch) == cutoff:
            break
    assert len(batch) == cutoff


def test_dep_teach_exits_without_parser(dataset, text_stream, nlp_blank):
    """Ensure that the dep.teach recipe exits when a model is given without parser component"""
    with pytest.raises(RecipeError):
        components = teach(dataset, nlp_blank, text_stream)
        Controller.from_components("dep.teach", components)


def test_dep_teach_exits_wrong_label(dataset, text_stream, nlp):
    """Ensure that the dep.teach recipe exits when a label is provided that is not part of the model"""
    with pytest.raises(RecipeError):
        components = teach(dataset, nlp, text_stream, label=["RANDOM"])
        Controller.from_components("dep.teach", components)


def test_dep_teach_predicts_label(dataset, text_stream, nlp):
    """Ensure that the dep.teach recipe provides examples with the correct label only"""
    LABEL = "prep"
    components = teach(dataset, nlp, text_stream, label=[LABEL])
    ctrl = Controller.from_components("dep.teach", components)
    queue = list(ctrl.stream)
    read = False
    for eg in queue:
        read = True
        assert "arcs" in eg
        assert len(eg["arcs"]) == 1
        assert eg["arcs"][0]["label"] == LABEL
        score = eg["arcs"][0]["score"]
        assert 0.0 <= score <= 1.0
    assert read
    ctrl.db.drop_dataset(dataset)


@pytest.mark.xfail(reason="never predicts wrong tag anymore")
def test_dep_teach_updates(dataset, nlp):
    """Ensure that the dep.teach recipe is able to overfit through active learning"""

    def yield_tasks():
        for i in range(700):
            yield {"text": f"taking {i}"}

    labels = ["ROOT", "dobj", "prep"]
    components = teach(dataset, nlp, yield_tasks(), label=labels)
    stream = components["stream"]

    batch = []
    accept_score = 0
    prev_accept_score = None
    for eg in stream:
        arc = eg["arcs"][0]
        if arc["head"] == 0 and arc["child"] == 1:
            if arc["label"] == "prep":
                eg["answer"] = "accept"
                accept_score += arc["score"]
            else:
                eg["answer"] = "reject"
        batch.append(eg)

        if len(batch) == 16:
            _ = components["update"](batch)
            accept_score = accept_score / (
                len([eg for eg in batch if eg["answer"] == "accept"]) + 0.00005
            )

            # initially, it's highly unlikely that 0->1 is predicted as "prep"
            if prev_accept_score is None:
                assert accept_score < 0.2

            batch = []
            prev_accept_score = accept_score
            accept_score = 0

    # By the end of the overfitting loop, the prediction of "prep" should be much higher
    assert prev_accept_score is not None
    assert prev_accept_score > 0.9


def test_dep_teach_unsegmented(dataset, text_stream, nlp):
    """Ensure that the dep.teach recipe 'unsegmented' option works properly"""
    components = teach(dataset, nlp, text_stream, unsegmented=True)
    ctrl = Controller.from_components("dep.teach", components)
    queue = list(ctrl.stream)
    found = False
    for eg in queue:
        text = eg["text"]
        # not split into sentences
        if "illegally touting horses" in text:
            found = True
            assert "several successful hustles" in text
    assert found
    ctrl.db.drop_dataset(dataset)


# dep.correct
def test_dep_correct_returns_components(db, dataset, spacy_model, nlp):
    """Ensure that the dep.correct recipe properly returns components"""
    C = correct(dataset, nlp, source=db.get_dataset_examples(dataset))
    assert C["view_id"] == "relations"
    assert C["dataset"] == dataset
    assert hasattr(C["stream"], "__iter__")
    assert C["config"]["lang"] == spacy_model.split("_")[0]


def test_dep_correct_exits_without_labels(dataset, text_stream, nlp_blank):
    """Ensure that the dep.correct recipe exits when a model is given with no labels"""
    with pytest.raises(RecipeError):
        components = correct(dataset, nlp_blank, text_stream)
        Controller.from_components("dep.correct", components)


def test_dep_correct_exits_without_sentencizer(dataset, text_stream, nlp_blank):
    """Ensure that the dep.correct recipe exits when a blank model is given with sentence segmentation"""
    LABEL = "prep"
    with pytest.raises(RecipeError):
        components = correct(dataset, nlp_blank, text_stream, label=[LABEL])
        Controller.from_components("dep.correct", components)


def test_dep_correct_blank_model(dataset, text_stream, nlp_blank):
    """Ensure that the dep.correct recipe works well with a blank model, custom labels and no segmentation"""
    LABEL = "prep"
    components = correct(
        dataset, nlp_blank, text_stream, unsegmented=True, label=[LABEL]
    )
    ctrl = Controller.from_components("dep.correct", components)
    queue = list(ctrl.stream)
    for eg in queue:
        assert "hidden_relations" in eg
        for rel in eg["hidden_relations"]:
            assert rel["child"] == rel["head"]
            assert rel["label"] == ""
    ctrl.db.drop_dataset(dataset)


def test_dep_correct_pretrained_model_labels(dataset, text_stream, nlp):
    """Ensure that the dep.correct recipe works well with a pretrained model and filtered labels"""
    LABEL = "prep"
    components = correct(dataset, nlp, text_stream, label=[LABEL])
    ctrl = Controller.from_components("dep.correct", components)
    queue = list(ctrl.stream)
    labels = ctrl.config["labels"]
    assert labels == [LABEL]
    found_count = 0
    hidden_count = 0
    for eg in queue:
        if "relations" in eg:
            for rel in eg["relations"]:
                assert rel["label"] == LABEL
                found_count += 1
        if "hidden_relations" in eg:
            for rel in eg["hidden_relations"]:
                assert rel["label"] != LABEL
                hidden_count += 1
    assert found_count > 0
    assert hidden_count > 0
    ctrl.db.drop_dataset(dataset)


def test_dep_correct_unsegmented(dataset, text_stream, nlp):
    """Ensure that the dep.correct recipe 'unsegmented' option works properly"""
    components = correct(dataset, nlp, text_stream, unsegmented=True)
    ctrl = Controller.from_components("dep.correct", components)
    queue = list(ctrl.stream)
    found = False
    for eg in queue:
        # not split into sentences
        text = eg["text"]
        if "illegally touting horse" in text:
            found = True
            assert "illegally touting horse" in text
    assert found
    ctrl.db.drop_dataset(dataset)


def test_dep_correct_updates(dataset, nlp):
    """Ensure that the dep.correct recipe is able to overfit through active learning"""

    def yield_tasks():
        for i in range(96):
            yield {"text": f"I unsure {i} here"}

    components = correct(dataset, nlp, yield_tasks(), update=True)
    stream = components["stream"]

    # We'll try to make the first token the ROOT
    gold_eg_2 = [
        {"child": 0, "head": 0, "label": "ROOT"},
        {"child": 1, "head": 0, "label": "nsubj"},
    ]
    gold_eg_4 = [
        {"child": 0, "head": 0, "label": "ROOT"},
        {"child": 1, "head": 0, "label": "punct"},
        {"child": 2, "head": 1, "label": "nummod"},
        {"child": 3, "head": 1, "label": "advmod"},
    ]

    batch = []
    root = 0
    not_root = 0
    prev_root = 0
    for eg in stream:
        rels = eg["relations"]
        if len(rels) == 2:
            assert rels[0]["child"] == 0
            if rels[0]["label"] == "ROOT":
                root += 1
            else:
                not_root += 1
            eg["relations"] = gold_eg_2
        if len(rels) == 4:
            assert rels[0]["child"] == 0
            if rels[0]["label"] == "ROOT":
                root += 1
            else:
                not_root += 1
            eg["relations"] = gold_eg_4
        eg["answer"] = "accept"
        batch.append(eg)
        if len(batch) == 16:
            # If this fails, we haven't learned anything...
            # Note: details seem to be unpredictable (random seed?)
            assert root >= prev_root
            components["update"](batch)
            batch = []
            root = 0
            not_root = 0
            prev_root = root
