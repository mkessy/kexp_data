import pytest

from prodigy.recipes.openai.terms import _parse_terms

# We cannot assume that `risk` is a complete game because
# OpenAI may have exhausted the tokens
base_completion = """monopoly\n- Scrabble\n- risk"""
# Added some trailing spaces in this one
base_completion_with_trailing_spaces = """monopoly \n- scrabble \n- risk """

# An example where the tokens may have been exhausted
# note the capitalisation
trailing_token_completion = """monopoly\n- scrabble\n- Risk\n- carcas"""

# This can also happen
single_line_completion = "monopoly"


@pytest.mark.parametrize(
    "comment,completion,expectation",
    [
        (
            "Base OpenAI completion with capitalisation",
            base_completion,
            ["monopoly", "Scrabble"],
        ),
        (
            "Check trailing spaces",
            base_completion_with_trailing_spaces,
            ["monopoly", "scrabble"],
        ),
        (
            "Completion with bad final item",
            trailing_token_completion,
            ["monopoly", "scrabble", "Risk"],
        ),
        (
            "Example of a single-line OpenAI completion",
            single_line_completion,
            ["monopoly"],
        ),
    ],
)
def test_parse_terms(comment, completion, expectation):
    assert _parse_terms(completion=completion) == expectation
