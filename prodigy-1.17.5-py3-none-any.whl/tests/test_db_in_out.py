from pathlib import Path
from typing import Any, List, Optional, cast
from typing_extensions import Literal

import pytest
import srsly

from prodigy.components.db import Database
from prodigy.recipes import commands
from prodigy.structured_types import Example
from prodigy.types import TaskType
from prodigy.util import set_hashes


@pytest.fixture()
def unst_source(datasets_path: Path) -> List[TaskType]:
    path = datasets_path / "fashion_brands_sample_unst.jsonl"
    return [set_hashes(cast(TaskType, e)) for e in srsly.read_jsonl(path)]


@pytest.fixture()
def st_source(datasets_path: Path) -> List[Example]:
    path = datasets_path / "fashion_brands_sample_st.jsonl"
    st_examples = []
    for eg in srsly.read_jsonl(path):
        eg = cast(TaskType, eg)
        _ = eg.pop("__class__")
        st_examples.append(Example.from_dict(eg))
    return st_examples


DB_IN_TEST_CASES = {
    "invalid_st_unknown_example_name_no_keys": (
        "fashion_brands_sample_unst.jsonl",
        True,
        "structured",
        "structured",
        "unknown_example_name",
        None,
        None,
        None,
    ),
    "invalid_st_no_example_name_no_keys": (
        "fashion_brands_sample_unst.jsonl",
        True,
        "structured",
        "structured",
        None,
        None,
        None,
        None,
    ),
    "invalid_st_input_file_unst_import_format": (
        "fashion_brands_sample_st.jsonl",
        True,
        "unstructured",
        "structured",
        None,
        None,
        None,
        None,
    ),
    "valid_unst_to_unst": (
        "fashion_brands_sample_unst.jsonl",
        False,
        "unstructured",
        "unstructured",
        None,
        None,
        None,
        None,
    ),
}


@pytest.mark.parametrize(
    "input_file, has_error, import_format, save_format, structured_example_type, input_keys, server_ann_keys, user_ann_keys",
    DB_IN_TEST_CASES.values(),
    ids=DB_IN_TEST_CASES.keys(),
)
def test_db_in(
    database: Database,
    datasets_path: Path,
    dataset: str,
    input_file: str,
    has_error: Any,
    import_format: Literal["structured", "unstructured"],
    save_format: Literal["structured", "unstructured"],
    structured_example_type: str,
    input_keys: Optional[List[str]],
    server_ann_keys: Optional[List[str]],
    user_ann_keys: Optional[List[str]],
):
    assert dataset not in database
    input_path = datasets_path / input_file

    try:
        commands.db_in(
            dataset,
            input_path,
            import_format=import_format,
            save_format=save_format,
            structured_example_type=structured_example_type,
            input_keys=input_keys,
            server_ann_keys=server_ann_keys,
            user_ann_keys=user_ann_keys,
        )
    except SystemExit as e:
        assert has_error is True, e
    else:
        assert dataset in database

        examples = database.get_dataset_examples(dataset)
        assert len(examples) == 10


DB_OUT_TEST_CASES = {
    "valid_unst_to_unst": (
        False,
        "unstructured",
        "unstructured",
        None,
        None,
        None,
        None,
    ),
}


@pytest.mark.parametrize(
    "has_error, dataset, export_format, structured_example_type, input_keys, server_ann_keys, user_ann_keys",
    DB_OUT_TEST_CASES.values(),
    ids=DB_OUT_TEST_CASES.keys(),
)
def test_db_out(
    database: Database,
    unst_source: List[TaskType],
    st_source: List[Example],
    tmpdir: Path,
    has_error: bool,
    dataset: Literal["structured", "unstructured"],
    export_format: Literal["structured", "unstructured"],
    structured_example_type: str,
    input_keys: Optional[List[str]],
    server_ann_keys: Optional[List[str]],
    user_ann_keys: Optional[List[str]],
):
    database.add_examples(unst_source, [dataset])

    try:
        commands.db_out(
            dataset,
            tmpdir,
            export_format=export_format,
            structured_example_type=structured_example_type,
            input_keys=input_keys,
            server_ann_keys=server_ann_keys,
            user_ann_keys=user_ann_keys,
        )
    except SystemExit as e:
        assert has_error is True, e
    else:
        data = list(srsly.read_jsonl(tmpdir / f"{dataset}.jsonl"))
        assert len(data) == 10


def test_structured_db_out_err_unstructured(movies_path, capsys, dataset):
    """We can give different answers and this is reflected in stats."""
    commands.db_in(dataset, movies_path, answer="accept")

    # Ignore stdout so far.
    _ = capsys.readouterr()

    # Passing structured example type without setting export_format to structured needs to exit
    with pytest.raises(SystemExit):
        commands.db_out(
            dataset, answer="accept", structured_example_type="DINOSAUR-NONSENSE"
        )

    # Capture relevant output.
    captured = capsys.readouterr()

    assert "Can't set `--structured-example-type`" in captured.out


def test_structured_db_out_bad_example_type(movies_path, capsys, dataset):
    """We can give different answers and this is reflected in stats."""
    commands.db_in(dataset, movies_path, answer="accept")

    # Ignore stdout so far.
    _ = capsys.readouterr()

    # Passing structured example type without setting export_format to structured needs to exit
    with pytest.raises(SystemExit):
        commands.db_out(
            dataset,
            answer="accept",
            export_format="structured",
            structured_example_type="DINOSAUR-NONSENSE",
        )

    # Capture relevant output.
    captured = capsys.readouterr()

    assert "Can't find DINOSAUR-NONSENSE in registry." in captured.out
