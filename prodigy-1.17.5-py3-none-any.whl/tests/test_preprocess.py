from typing import List, Union, cast

import pytest
import spacy
from pytest_lazyfixture import lazy_fixture
from spacy.language import Language

from prodigy.components.preprocess import (
    add_label_options,
    add_tokens,
    convert_options_to_cats,
    make_ner_suggestions,
    make_spancat_suggestions,
    make_textcat_suggestions,
    merge_pages,
    resolve_labels,
    split_pages,
    split_sentences,
    split_spans,
)
from prodigy.components.source import ListSource, load_noop
from prodigy.components.stream import Stream
from prodigy.structured_types import Example
from prodigy.types import TaskType
from prodigy.util import PAGE_NUM_ATTR, PAGE_TITLE_ATTR, set_hashes

from .util import FixtureRequest


@pytest.fixture
def unst_stream():
    return [
        {
            "text": "Hello world. This is.",
            "tokens": [
                {"text": "Hello", "start": 0, "end": 5, "id": 0},
                {"text": "world", "start": 6, "end": 11, "id": 1},
                {"text": ".", "start": 11, "end": 12, "id": 2},
                {"text": "This", "start": 13, "end": 17, "id": 3},
                {"text": "is", "start": 18, "end": 20, "id": 4},
                {"text": ".", "start": 20, "end": 21, "id": 5},
            ],
            "spans": [
                {
                    "start": 13,
                    "end": 17,
                    "label": "TEST",
                    "token_start": 3,
                    "token_end": 3,
                }
            ],
        }
    ]


@pytest.fixture
def st_stream():
    return [
        Example(
            input_hash=1,
            task_hash=2,
            input={"text": "Hello world. This is."},
            server_anns={
                "tokens": [
                    {"text": "Hello", "start": 0, "end": 5, "id": 0},
                    {"text": "world", "start": 6, "end": 11, "id": 1},
                    {"text": ".", "start": 11, "end": 12, "id": 2},
                    {"text": "This", "start": 13, "end": 17, "id": 3},
                    {"text": "is", "start": 18, "end": 20, "id": 4},
                    {"text": ".", "start": 20, "end": 21, "id": 5},
                ],
                "spans": [
                    {
                        "start": 13,
                        "end": 17,
                        "label": "TEST",
                        "token_start": 3,
                        "token_end": 3,
                    }
                ],
            },
            user_anns={},
            meta={},
            extras={},
            answer=None,
        )
    ]


@pytest.fixture
def nlp():
    obj = spacy.blank("en")
    obj.add_pipe("sentencizer")
    return obj


@pytest.fixture(params=[True, False])
def test_new_stream(request: FixtureRequest[bool]) -> bool:
    return request.param


@pytest.fixture(params=[lazy_fixture("unst_stream"), lazy_fixture("st_stream")])
def stream(test_new_stream: bool, request: FixtureRequest[list]):
    stream = request.param
    if test_new_stream:
        stream = Stream(source=ListSource(stream), loader=load_noop, wrappers=[])
    return stream


def _ensure_list(stream):
    if isinstance(stream, Stream):
        stream.create_queue("vincent", -1)
        return [eg.data for eg in stream.iter_queue(lambda d: ["vincent"], "vincent")]
    return list(stream)


def _to_unst(eg: Union[Example, TaskType]) -> TaskType:
    return eg.to_unst() if isinstance(eg, Example) else eg


def test_add_tokens(nlp: Language, stream: Union[List, Stream]):
    new_stream = _ensure_list(add_tokens(nlp, stream))
    eg = new_stream[0]
    eg = _to_unst(eg)
    span = eg["spans"][0]
    assert "tokens" in eg
    assert len(eg["tokens"]) == 6
    assert "token_start" in span
    assert "token_end" in span
    assert span["token_start"] == 3
    assert span["token_end"] == 3


def test_add_tokens_skip(nlp: Language, stream: Union[List, Stream]):
    # Test that spans are actually excluded and that not only the token setting
    # is skipped.
    stream_orig = list(stream)
    stream = list(stream_orig)
    if isinstance(stream[0], Example):
        assert stream[0].server_anns is not None
        stream[0].server_anns["spans"] = [
            {"start": 13, "end": 17, "label": "TEST"},
            {"start": 1, "end": 3, "label": "INVALID"},
        ]
    else:
        stream[0]["spans"] = [
            {"start": 13, "end": 17, "label": "TEST"},
            {"start": 1, "end": 3, "label": "INVALID"},
        ]
    with pytest.raises(ValueError):
        _ensure_list(add_tokens(nlp, stream))

    # Recreate stream because it was exhausted before
    new_stream = add_tokens(nlp, stream_orig, skip=True)
    new_stream = _ensure_list(new_stream)
    spans = _to_unst(new_stream[0])["spans"]

    assert len(spans) == 1
    assert spans[0]["label"] == "TEST"


def test_add_tokens_overwrite(nlp: Language):
    stream = [{"text": "Hello world.", "tokens": [{"start": 0, "end": 12, "id": 0}]}]
    new_stream = list(add_tokens(nlp, stream))
    assert len(_to_unst(new_stream[0])["tokens"]) == 1
    new_stream = list(add_tokens(nlp, stream, overwrite=True))
    assert len(_to_unst(new_stream[0])["tokens"]) == 3


def test_split_sentences(nlp: Language, stream: Union[List, Stream]):
    new_stream = list(split_sentences(nlp, stream))
    assert len(new_stream) == 2
    sent1 = new_stream[0]
    if isinstance(sent1, Example):
        sent1 = sent1.to_unst()
    assert len(sent1["tokens"]) == 3
    assert [t["text"] for t in sent1["tokens"]] == ["Hello", "world", "."]
    assert len(sent1["spans"]) == 0

    sent2 = new_stream[1]
    if isinstance(sent2, Example):
        sent2 = sent2.to_unst()
    assert len(sent2["tokens"]) == 3
    assert [t["text"] for t in sent2["tokens"]] == ["This", "is", "."]
    assert len(sent2["spans"]) == 1
    span = sent2["spans"][0]
    assert span["start"] == 0
    assert span["end"] == 4
    assert span["token_start"] == 0
    assert span["token_end"] == 0


def test_split_sentences_simple(nlp: Language):
    stream = [
        {
            "text": "Hello world. This is.",
            "spans": [{"start": 13, "end": 17, "label": "TEST"}],
        }
    ]
    new_stream = list(split_sentences(nlp, stream))
    assert len(new_stream) == 2
    sent1 = new_stream[0]
    if isinstance(sent1, Example):
        sent1 = sent1.to_unst()
    assert len(sent1["spans"]) == 0

    sent2 = new_stream[1]
    if isinstance(sent2, Example):
        sent2 = sent2.to_unst()
    assert len(sent2["spans"]) == 1
    span = sent2["spans"][0]
    assert span["start"] == 0
    assert span["end"] == 4


def test_split_sentences_min_length(nlp: Language):
    stream = [{"text": "Hello world. This is a test."}]

    # without min_length
    new_stream = list(split_sentences(nlp, stream, min_length=False))
    assert len(new_stream) == 2
    assert new_stream[0]["text"] == "Hello world."
    assert new_stream[1]["text"] == "This is a test."

    # with matching min_length
    new_stream = list(split_sentences(nlp, stream, min_length=20))
    assert len(new_stream) == 2
    assert new_stream[0]["text"] == "Hello world."
    assert new_stream[1]["text"] == "This is a test."

    # with longer min_length
    new_stream = list(split_sentences(nlp, stream, min_length=50))
    assert len(new_stream) == 1
    assert new_stream[0]["text"] == "Hello world. This is a test."


def test_split_spans():
    span1 = {"start": 6, "end": 11, "label": "TEST"}
    span2 = {"start": 13, "end": 17, "label": "TEST1"}
    stream = [{"text": "Hello world. This is.", "spans": [span1, span2]}]
    st_stream = [
        Example.from_unst_server(
            set_hashes(eg), input_keys=["text"], server_ann_keys=["spans"]
        )
        for eg in stream
    ]

    new_stream = cast(List[TaskType], list(split_spans(stream)))
    new_st_stream = cast(List[Example], list(split_spans(st_stream)))
    assert len(new_stream) == len(new_st_stream) == 2
    assert new_stream[0]["text"] == new_st_stream[1].input["text"]
    for prop in ("start", "end", "label"):
        assert new_stream[0]["spans"][0][prop] == span1[prop]
        assert new_stream[1]["spans"][0][prop] == span2[prop]

        assert new_st_stream[0].server_anns is not None
        assert new_st_stream[1].server_anns is not None
        assert new_st_stream[0].server_anns["spans"][0][prop] == span1[prop]
        assert new_st_stream[1].server_anns["spans"][0][prop] == span2[prop]

    new_stream = cast(List[TaskType], list(split_spans(stream, labels=["TEST1"])))
    assert len(new_stream) == 1
    for prop in ("start", "end", "label"):
        assert new_stream[0]["spans"][0][prop] == span2[prop]


@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_add_label_options(structured: bool):
    stream = [{"text": "Hello world"}, {"text": "A test."}, {"text": "Yo"}]
    if structured:
        stream = [
            Example.from_unst_server(
                set_hashes(eg), input_keys=["text"], server_ann_keys=["label"]
            )
            for eg in stream
        ]
    labels = ["POSITIVE", "NEGATIVE", "NEUTRAL"]
    new_stream = list(add_label_options(stream, labels))

    assert len(new_stream) == 3
    eg = _to_unst(new_stream[0])
    assert "options" in eg
    assert len(eg["options"]) == 3
    assert eg["options"][0]["id"] == labels[0]
    assert eg["options"][0]["text"] == labels[0]
    assert eg["options"][1]["id"] == labels[1]
    assert eg["options"][1]["text"] == labels[1]
    assert eg["options"][2]["id"] == labels[2]
    assert eg["options"][2]["text"] == labels[2]


def test_convert_options_to_labels_non_exclusive():
    stream = [
        {"text": "Hello world", "answer": "accept", "accept": ["A", "B"]},
        {"text": "This is a test.", "answer": "accept", "accept": []},
        {"text": "Yo", "answer": "accept", "accept": ["C"]},
        {"text": "And another text", "answer": "accept", "accept": ["B", "C"]},
        {"text": "And another text", "answer": "reject", "accept": ["B", "C"]},
    ]
    for eg in stream:
        eg["options"] = [{"id": name, "text": name} for name in ["A", "B", "C", "D"]]
    new_stream = convert_options_to_cats(stream, exclusive=False)
    assert len(new_stream) == 5
    assert all("cats" in eg for eg in new_stream)
    assert new_stream[0]["cats"] == {"A": 1.0, "B": 1.0}
    assert new_stream[1]["cats"] == {}
    assert new_stream[2]["cats"] == {"C": 1.0}
    assert new_stream[3]["cats"] == {"B": 1.0, "C": 1.0}
    assert new_stream[4]["cats"] == {"B": 0.0, "C": 0.0}


def test_convert_options_to_labels_exclusive():
    stream = [
        {"text": "Hello world", "answer": "accept", "accept": ["A", "B"]},
        {"text": "This is a test.", "answer": "accept", "accept": []},
        {"text": "Yo", "answer": "accept", "accept": ["C"]},
        {"text": "And another text", "answer": "accept", "accept": ["B", "C"]},
        {"text": "And another text", "answer": "reject", "accept": ["B", "C"]},
    ]
    for eg in stream:
        eg["options"] = [{"id": name, "text": name} for name in ["A", "B", "C", "D"]]
    new_stream = convert_options_to_cats(stream, exclusive=True)
    assert len(new_stream) == 5
    assert all("cats" in eg for eg in new_stream)
    assert new_stream[0]["cats"] == {"A": 1.0, "B": 1.0, "C": 0.0, "D": 0.0}
    assert new_stream[1]["cats"] == {"A": 0.0, "B": 0.0, "C": 0.0, "D": 0.0}
    assert new_stream[2]["cats"] == {"C": 1.0, "A": 0.0, "B": 0.0, "D": 0.0}
    assert new_stream[3]["cats"] == {"B": 1.0, "C": 1.0, "A": 0.0, "D": 0.0}
    assert new_stream[4]["cats"] == {"B": 0.0, "C": 0.0}


def test_make_tasks_textcat():
    stream_in = [{"text": "this is a text example"}]

    @Language.component("textcat_mocker")
    def mocker(doc):
        # This component mocks spancat
        doc.cats = {"foo": 0.9, "bar": 0.8}
        return doc

    nlp = spacy.blank("en")
    nlp.add_pipe("textcat_mocker")

    ## Using a relatively low threshold
    stream = make_textcat_suggestions(
        stream_in,
        nlp=nlp,
        component="textcat_mocker",
        labels=["foo", "bar"],
        threshold=0.8,
    )
    example = next(stream)
    assert len(example["options"]) == 2
    assert example["accept"] == ["foo", "bar"]

    ## Using a relatively high threshold
    stream = make_textcat_suggestions(
        stream_in,
        nlp=nlp,
        component="textcat_mocker",
        labels=["foo", "bar"],
        threshold=0.85,
    )
    example = next(stream)
    assert len(example["options"]) == 2
    assert example["accept"] == ["foo"]

    ## Using a single label, threshold no longer matters
    stream = make_textcat_suggestions(
        stream_in,
        nlp=nlp,
        component="textcat_mocker",
        labels=["foo"],
        threshold=0.99,
    )
    example = next(stream)
    assert example["label"] == "foo"


def test_make_tasks_spancat(capsys):
    stream_in = [{"text": "this is a text example"}]

    nlp = spacy.blank("en")
    ruler = nlp.add_pipe("span_ruler")
    patterns = [
        {"label": "FOO", "pattern": "this"},
        {"label": "BAR", "pattern": "text"},
        {"label": "BUZ", "pattern": "text example"},
    ]
    ruler.add_patterns(patterns)

    ## Using all three tasks
    stream = make_spancat_suggestions(
        stream_in,
        nlp=nlp,
        component="span_ruler",
        labels=["FOO", "BAR", "BUZ"],
    )
    example = next(stream)
    assert set([s["label"] for s in example["spans"]]) == {"FOO", "BAR", "BUZ"}

    ## Using a subset
    stream = make_spancat_suggestions(
        stream_in,
        nlp=nlp,
        component="span_ruler",
        labels=["FOO", "BUZ"],
    )
    example = next(stream)
    assert set([s["label"] for s in example["spans"]]) == {"FOO", "BUZ"}


def test_make_tasks_ner(capsys, nlp_md):
    stream_in = [{"text": "My name is Vincent and I live in Amsterdam."}]

    ## Using all three tasks
    stream = make_ner_suggestions(
        stream_in,
        nlp=nlp_md,
        component="ner",
        labels=["PERSON", "GPE"],
    )
    example = next(stream)
    assert set([s["label"] for s in example["spans"]]) == {"PERSON", "GPE"}

    ## Using a subset
    stream = make_ner_suggestions(
        stream_in,
        nlp=nlp_md,
        component="ner",
        labels=["PERSON"],
    )
    example = next(stream)
    assert set([s["label"] for s in example["spans"]]) == {"PERSON"}


def test_resolve_labels(nlp_md, capsys):
    # It should be able to fetch a subset
    assert resolve_labels(nlp_md, "ner", ["PERSON", "ORG"]) == ["PERSON", "ORG"]

    # It should be able to fetch the full label list if presented with empty recipe labels
    assert resolve_labels(nlp_md, "ner", recipe_labels=[]) == nlp_md.pipe_labels["ner"]

    # But the param is optional, so it can also be left empty
    assert resolve_labels(nlp_md, "ner") == nlp_md.pipe_labels["ner"]

    # It should sysexit when a label does not exist
    with pytest.raises(SystemExit):
        resolve_labels(nlp_md, "ner", ["PERSON", "ORG", "FOOBAR"])

    # It should sysexit when a component does not exist
    with pytest.raises(SystemExit):
        resolve_labels(nlp_md, "dinosaurhead", ["PERSON", "ORG"])


def test_split_pages():
    stream = [
        {
            "pages": [
                {"text": "a", "view_id": "text"},
                {"text": "b", "view_id": "text"},
            ]
        },
        {
            "pages": [
                {"text": "c", "view_id": "text"},
                {"text": "d", "view_id": "text"},
                {"text": "e", "view_id": "text"},
            ]
        },
    ]
    result = list(split_pages(stream))
    assert len(result) == 5
    assert [eg["text"] for eg in result] == ["a", "b", "c", "d", "e"]

    result = list(split_pages([{"pages": [{"text": "a", "view_id": "text"}]}]))
    assert len(result) == 1

    stream = [
        {
            "page_titles": ["foo", "bar"],
            "pages": [
                {"text": "a", "view_id": "text"},
                {"text": "b", "view_id": "text"},
            ],
        }
    ]
    result = list(split_pages(stream))
    assert result[0][PAGE_TITLE_ATTR] == "foo"
    assert result[1][PAGE_TITLE_ATTR] == "bar"


def test_merge_pages():
    stream = [
        {"text": "a", "view_id": "text", PAGE_NUM_ATTR: 0},
        {"text": "b", "view_id": "text", PAGE_NUM_ATTR: 1},
        {"text": "c", "view_id": "text", PAGE_NUM_ATTR: 0},
        {"text": "d", "view_id": "text", PAGE_NUM_ATTR: 1},
        {"text": "e", "view_id": "text", PAGE_NUM_ATTR: 2},
    ]
    stream = [set_hashes(eg) for eg in stream]
    result = list(merge_pages(stream))
    assert len(result) == 2
    assert [eg["text"] for eg in result[0]["pages"]] == ["a", "b"]
    assert [eg["text"] for eg in result[1]["pages"]] == ["c", "d", "e"]

    result = list(
        merge_pages([set_hashes({"text": "a", "view_id": "text", PAGE_NUM_ATTR: 0})])
    )
    assert len(result) == 1
    assert [eg["text"] for eg in result[0]["pages"]] == ["a"]

    stream = [
        set_hashes(
            {"text": "a", "view_id": "text", PAGE_NUM_ATTR: 0, PAGE_TITLE_ATTR: "foo"}
        ),
        set_hashes(
            {"text": "b", "view_id": "text", PAGE_NUM_ATTR: 1, PAGE_TITLE_ATTR: "bar"}
        ),
    ]
    result = list(merge_pages(stream))
    assert result[0]["page_titles"] == ["foo", "bar"]


def test_split_merge_pages_roundtrip():
    stream = [
        {
            "pages": [
                {"text": "a", "view_id": "text"},
                {"text": "b", "view_id": "text"},
            ]
        },
        {
            "pages": [
                {"text": "c", "view_id": "text"},
                {"text": "d", "view_id": "text"},
                {"text": "e", "view_id": "text"},
            ]
        },
    ]
    stream = [set_hashes(eg) for eg in stream]
    result_split = list(split_pages(stream))
    result = list(merge_pages(result_split))
    assert len(result) == 2
    assert [eg["text"] for eg in result[0]["pages"]] == [
        eg["text"] for eg in stream[0]["pages"]
    ]
    assert [eg["text"] for eg in result[1]["pages"]] == [
        eg["text"] for eg in stream[1]["pages"]
    ]

    stream = [
        {
            "page_titles": ["foo", "bar"],
            "pages": [
                {"text": "a", "view_id": "text"},
                {"text": "b", "view_id": "text"},
            ],
            "meta": {"title": "Hello world"},
        }
    ]
    stream = [set_hashes(eg) for eg in stream]
    result_split = list(split_pages(stream))
    result = list(merge_pages(result_split))
    assert len(result) == 1
    assert result[0]["page_titles"] == stream[0]["page_titles"]
    assert result[0]["meta"]["title"] == stream[0]["meta"]["title"]
