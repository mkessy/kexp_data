from pathlib import Path
from typing import List

import pytest

from prodigy.components.db import Database
from prodigy.components.loaders import JSONL
from prodigy.components.preprocess import split_sentences
from prodigy.core import Controller
from prodigy.errors import RecipeError
from prodigy.recipes.ner import ab_evaluate, correct, manual, silver_to_gold, teach
from prodigy.types import TaskType
from prodigy.util import set_hashes


@pytest.fixture(scope="session")
def dataset():
    return "tmp-test-dataset"


@pytest.fixture(scope="session")
def examples():
    return [{"text": "Example 1"}, {"text": "Example 2"}, {"text": "Example 3"}]


@pytest.fixture
def text_stream():
    data_path = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    tasks = JSONL(data_path)
    return [set_hashes(task) for task in tasks]


@pytest.fixture(scope="session")
def patterns_path():
    data_path = Path(__file__).parent / "sample_datasets" / "ner_patterns.txt"
    return data_path


@pytest.fixture
def db(database: Database, dataset: str, examples: List[TaskType]) -> Database:
    database.add_dataset(dataset, meta={"desc": "TMP dataset"})
    examples = [set_hashes(eg) for eg in examples]
    database.add_examples(examples, datasets=(dataset,))
    return database


def test_empty_spans(nlp):
    text1 = "Yeah right. Granted, she went overboard by piling on the punishments."
    text2 = "I've put a lot of videos on YouTube. I'm a female."
    orig_stream = [{"text": text1, "spans": []}, {"text": text2, "spans": []}]
    stream = list(split_sentences(nlp, orig_stream))
    assert id(stream[0]["spans"]) != id(stream[1]["spans"])


# ner.teach #


def test_ner_teach_returns_components(dataset, nlp, spacy_model, examples):
    """Ensure that the ner.teach recipe properly returns components"""
    C = teach(dataset, nlp, source=examples)
    assert C["view_id"] == "ner"
    assert C["dataset"] == dataset
    assert hasattr(C["update"], "__call__")
    assert C["config"]["lang"] == spacy_model.split("_")[0]
    assert C["config"]["label"] == "all"


def test_ner_teach_can_stream(dataset, nlp):
    """Ensure that the ner.teach recipe can stream examples"""
    # Important: make texts diverse enough to give model the chance to predict something
    examples = [{"text": f"Test aaa bbbb c d e {i} {i + 1}.123"} for i in range(100)]
    C = teach(dataset, nlp, source=examples)
    batch = []
    cutoff = 20
    C["stream"].create_queue("vincent", n_history=-1)
    for eg in C["stream"].iter_queue(router=lambda d: ["vincent"], queue_id="vincent"):
        batch.append(eg)
        if len(batch) == cutoff:
            break
    assert len(batch) == cutoff


def test_ner_teach_exits_without_NER(dataset, text_stream, nlp_blank):
    """Ensure that the ner.teach recipe exits when a model is given without NER component"""
    components = teach(dataset, nlp_blank, text_stream)
    with pytest.raises(KeyError):
        ctrl = Controller.from_components("ner.teach", components)
        ctrl.get_questions("vincent")


def test_ner_teach_exits_wrong_label(dataset, text_stream, nlp):
    """Ensure that the ner.teach recipe exits when a label is provided that is not part of the model"""
    with pytest.raises(RecipeError):
        teach(dataset, nlp, text_stream, label=["RANDOM_LABEL"])


def test_ner_teach_predicts_label(dataset, text_stream, nlp):
    """Ensure that the ner.teach recipe provides examples with the correct label only"""
    LABEL = "PERSON"
    components = teach(dataset, nlp, text_stream, label=[LABEL])
    ctrl = Controller.from_components("ner.teach", components)
    queue = ctrl.get_questions("vincent")
    eg = queue[0]
    assert "spans" in eg
    assert eg["spans"][0]["label"] == LABEL
    score = eg["spans"][0]["score"]
    assert 0.0 <= score <= 1.0
    ctrl.db.drop_dataset(dataset)


def test_ner_teach_updates(dataset, nlp):
    """Ensure that the ner.teach recipe is able to overfit through active learning"""

    def yield_tasks():
        for i in range(700):
            yield {"text": f"How's my stock in Skynet doing on day {i}?"}

    # We'll try and force "DATE" as label for the "Skynet" span
    labels = ["DATE", "PERSON", "ORG", "GPE"]

    components = teach(dataset, nlp, yield_tasks(), label=labels)

    batch = []
    accept_score, reject_score = 0, 0
    accepted, rejected = 0, 0
    prev_accept_score = None
    # prev_reject_score = None

    # For now, we focus on learning from positive examples (accept)
    # TODO: learn from negative reject examples (not working fully yet)
    components["stream"].create_queue("vincent", n_history=-1)
    queue = components["stream"].iter_queue(
        router=lambda d: ["vincent"], queue_id="vincent"
    )
    for item in queue:
        eg = item.data
        if eg["spans"] and eg["spans"][0]["text"] == "Skynet":
            if eg["spans"][0]["label"] == "DATE":
                accepted += 1
                accept_score += eg["spans"][0]["score"]
            else:
                rejected += 1
                reject_score += eg["spans"][0]["score"]
            eg["spans"][0]["label"] = "DATE"
            eg["answer"] = "accept"
            batch.append(eg)
        if len(batch) == 16:
            components["update"](batch)
            accept_score = accept_score / (accepted + 0.00005)
            reject_score = reject_score / (rejected + 0.00005)

            # in the first iteration, we're unlikely to have Skynet "correct" as DATE
            if prev_accept_score is None:
                assert accept_score < 0.8

            batch = []
            prev_accept_score = accept_score
            # prev_reject_score = reject_score
            accept_score, reject_score = 0, 0
            accepted, rejected = 0, 0

    # By the end of the overfitting loop, the prediction of Skynet=DATE should be near 1
    # If this fails, we haven't learned anything...
    assert prev_accept_score
    assert prev_accept_score > 0.9


def test_ner_teach_patterns(dataset, text_stream, nlp_fresh, patterns_path):
    """Ensure that the ner.teach recipe also finds the pattern matches"""
    components = teach(dataset, nlp_fresh, text_stream, patterns=patterns_path)
    ctrl = Controller.from_components("ner.teach", components)
    queue = ctrl.get_questions("vincent")
    found = False
    for item in queue:
        eg = item
        if "illegally touting horses" in eg["text"]:
            assert len(eg["spans"]) == 1
            assert eg["spans"][0]["text"] == "swindler"
            assert eg["spans"][0]["label"] == "GANGSTER"
            assert len(eg["tokens"]) == 20
            found = True
    assert found
    ctrl.db.drop_dataset(dataset)


def test_ner_teach_patterns_filtered(dataset, text_stream, nlp_fresh, patterns_path):
    """Ensure that the ner.teach recipe doesn't find the pattern match if it's the wrong label"""
    components = teach(
        dataset, nlp_fresh, text_stream, patterns=patterns_path, label=["PERSON"]
    )
    ctrl = Controller.from_components("ner.teach", components)
    queue = ctrl.get_questions("vincent")
    for item in queue:
        eg = item
        assert not eg["spans"] or eg["spans"][0]["label"] == "PERSON"
    ctrl.db.drop_dataset(dataset)


def test_ner_teach_unsegmented(dataset, text_stream, nlp_fresh):
    """Ensure that the ner.teach recipe 'unsegmented' option works properly"""
    components = teach(dataset, nlp_fresh, text_stream, unsegmented=True)
    ctrl = Controller.from_components("ner.teach", components)
    queue = ctrl.get_questions("vincent")
    found = False
    for item in queue:
        eg = item
        text = eg["text"]
        # not split into sentences
        if "illegally touting horses" in text:
            found = True
            assert "several successful hustles" in text
    assert found
    ctrl.db.drop_dataset(dataset)


# ner.manual #


def test_ner_manual_exits_with_missing_label(dataset, text_stream, nlp_blank):
    """Ensure that the ner.manual recipe exits when given a blank model and no labels"""
    with pytest.raises(RecipeError):
        manual(dataset, nlp_blank, text_stream)


def test_ner_manual_blank_model(dataset, text_stream, nlp_blank):
    """Ensure that the ner.manual recipe works well with a blank model and custom labels"""
    custom_labels = ["MY_LABEL", "ANOTHER_LABEL"]
    components = manual(dataset, nlp_blank, text_stream, label=custom_labels)
    ctrl = Controller.from_components("ner.manual", components)
    queue = ctrl.get_questions("vincent")
    labels = ctrl.config["labels"]
    assert labels == custom_labels
    eg = queue[0]
    assert "spans" not in eg
    ctrl.db.drop_dataset(dataset)


def test_ner_manual_pretrained_model_labels(dataset, text_stream, nlp):
    """Ensure that the ner.manual recipe works well with a pretrained model and custom labels"""
    custom_labels = ["MY_LABEL", "ANOTHER_LABEL"]
    components = manual(dataset, nlp, text_stream, label=custom_labels)
    ctrl = Controller.from_components("ner.manual", components)
    queue = ctrl.get_questions("vincent")
    labels = ctrl.config["labels"]
    assert labels == custom_labels
    eg = queue[0]
    assert "spans" not in eg
    ctrl.db.drop_dataset(dataset)


def test_ner_manual_pretrained_model_implicit_labels(dataset, text_stream, nlp):
    """Ensure that the ner.manual recipe works well with a pretrained model"""
    components = manual(dataset, nlp, text_stream)
    ctrl = Controller.from_components("ner.manual", components)
    queue = ctrl.get_questions("vincent")
    labels = ctrl.config["labels"]
    assert len(labels) > 2
    assert "PERSON" in labels
    eg = queue[0]
    assert "spans" not in eg
    ctrl.db.drop_dataset(dataset)


def test_ner_manual_patterns(dataset, text_stream, nlp, patterns_path):
    """Ensure that the ner.manual recipe pre-annotates entities from the provided patterns"""
    components = manual(dataset, nlp, text_stream, patterns=patterns_path)
    ctrl = Controller.from_components("ner.manual", components)
    queue = ctrl.get_questions("vincent")
    eg = queue[0]
    assert "illegally touting horses" in eg["text"]
    assert len(eg["spans"]) == 1
    assert eg["spans"][0]["text"] == "swindler"
    assert eg["spans"][0]["label"] == "GANGSTER"
    assert len(eg["tokens"]) == 79
    ctrl.db.drop_dataset(dataset)


def test_ner_manual_chars(dataset, text_stream, nlp):
    """Ensure that the ner.manual recipe's highlight_chars option works well"""
    components = manual(dataset, nlp, text_stream, highlight_chars=True)
    ctrl = Controller.from_components("ner.manual", components)
    queue = ctrl.get_questions("vincent")
    eg = queue[0]
    assert "illegally touting horses" in eg["text"]
    assert len(eg["text"].replace(" ", "")) == 327
    assert len(eg["tokens"]) == 79
    ctrl.db.drop_dataset(dataset)


# ner.correct


def test_ner_correct_returns_components(db, dataset, spacy_model, nlp):
    """Ensure that the ner.correct recipe properly returns components"""
    C = correct(dataset, nlp, source=db.get_dataset_examples(dataset))
    assert C["view_id"] == "ner_manual"
    assert C["dataset"] == dataset
    assert C["config"]["lang"] == spacy_model.split("_")[0]


def test_ner_correct_exits_with_missing_label(dataset, text_stream, nlp_blank):
    """Ensure that the ner.correct recipe exits when given a blank model and no labels"""
    with pytest.raises(RecipeError):
        correct(dataset, nlp_blank, text_stream)


def test_ner_correct_pretrained_model_labels(dataset, text_stream, nlp):
    """Ensure that the ner.correct recipe works well with a pretrained model and filtered labels"""
    LABEL = "PERSON"
    components = correct(dataset, nlp, text_stream, label=[LABEL])
    ctrl = Controller.from_components("ner.correct", components)
    queue = ctrl.get_questions("vincent")
    labels = ctrl.config["labels"]
    assert labels == [LABEL]
    found_count = 0
    empty_count = 0
    for item in queue:
        eg = item
        assert "spans" in eg
        if len(eg["spans"]) > 0:
            found_count += 1
            assert eg["spans"][0]["label"] == LABEL
        else:
            empty_count += 1
    # some examples contain a label, some don't
    assert found_count > 0
    assert empty_count > 0
    ctrl.db.drop_dataset(dataset)


def test_ner_correct_unsegmented(dataset, text_stream, nlp):
    """Ensure that the ner.correct recipe 'unsegmented' option works properly"""
    components = correct(dataset, nlp, text_stream, unsegmented=True)
    ctrl = Controller.from_components("ner.correct", components)
    queue = ctrl.get_questions("vincent")
    found = False
    for item in queue:
        eg = item
        # not split into sentences
        text = eg["text"]
        if "illegally touting horse" in text:
            found = True
            assert "illegally touting horse" in text
    assert found
    ctrl.db.drop_dataset(dataset)


# ner.silver-to-gold #


def test_ner_silver_to_gold_exits_with_missing_label(dataset, nlp):
    """Ensure that the ner.silver-to-gold recipe exits when given an unknown dataset"""
    with pytest.raises(RecipeError):
        silver_to_gold(dataset, ["a-random-not-existing-dataset"], nlp)


def _set_up_teach_dataset(dataset_teach, nlp):
    examples = [
        {"text": "Philip Becker decided to take flight 342 to Tokyo."},
        {"text": "Maria also flew to Japan."},
    ]
    components_teach = teach(dataset_teach, nlp, source=examples)
    ctrl_teach = Controller.from_components("ner.teach", components_teach)
    queue = ctrl_teach.get_questions("vincent")
    batch = []
    for item in queue:
        eg = item
        eg["answer"] = "accept"
        batch.append(eg)
    # We assume the pretrained model predicts the 5 entities
    assert len(batch) == 5
    ctrl_teach.receive_answers(batch)

    def clean_up():
        ctrl_teach.db.drop_dataset(dataset_teach)

    return clean_up


def test_ner_silver_to_gold_exits_no_labels(dataset, nlp_fresh, nlp_blank):
    """Ensure that the ner.silver-to-gold recipe exits when it doesn't get any labels"""
    dataset_teach = dataset + "_teach"
    clean_up = _set_up_teach_dataset(dataset_teach, nlp_fresh)
    with pytest.raises(RecipeError):
        silver_to_gold(dataset, [dataset_teach], nlp_blank)
    clean_up()


def test_ner_silver_to_gold_exits_blank_model(dataset, nlp_fresh, nlp_blank):
    """Ensure that the ner.silver-to-gold recipe exits when there is no NER component"""
    dataset_teach = dataset + "_teach"
    clean_up = _set_up_teach_dataset(dataset_teach, nlp_fresh)
    LABEL = "CARDINAL"
    with pytest.raises(KeyError):
        components = silver_to_gold(dataset, [dataset_teach], nlp_blank, label=[LABEL])
        list(components["stream"])
    clean_up()


def test_ner_silver_to_gold_filter_labels(dataset, nlp_fresh):
    """Ensure that the ner.silver-to-gold recipe filters by label"""
    dataset_teach = dataset + "_teach"
    clean_up = _set_up_teach_dataset(dataset_teach, nlp_fresh)
    LABEL = "CARDINAL"

    components = silver_to_gold(dataset, [dataset_teach], nlp_fresh, label=[LABEL])
    queue = list(components["stream"])
    found = False
    for eg in queue:
        for span in eg["spans"]:
            assert span["label"] == LABEL
            found = True
    assert found
    clean_up()


def test_ner_silver_to_gold_works(dataset, nlp_fresh):
    """Ensure that the ner.silver-to-gold recipe works properly"""
    dataset_teach = dataset + "_teach"
    # the pretrained model predicts 5 entities
    clean_up = _set_up_teach_dataset(dataset_teach, nlp_fresh)
    components = silver_to_gold(dataset, [dataset_teach], nlp_fresh)
    queue = list(components["stream"])
    found = 0
    assert len(queue) == 2
    for eg in queue:
        if eg["text"] == "Philip Becker decided to take flight 342 to Tokyo.":
            found += len(eg["spans"])
            assert len(eg["spans"]) == 3
        if eg["text"] == "Maria also flew to Japan.":
            found += len(eg["spans"])
            assert len(eg["spans"]) == 2
    assert found == 5
    clean_up()


# ner.eval-ab #


def test_ner_ab_eval_works(dataset, text_stream, nlp, nlp_blank):
    """Ensure that the ner.ab_evaluate recipe works properly"""
    components = ab_evaluate(dataset, nlp, nlp_blank, text_stream)
    queue = list(components["stream"])
    for eg in queue:
        text = eg["input"]["text"]
        A = eg["A"]
        B = eg["B"]
        assert text == A["text"] == B["text"]
        spansA = A["spans"]
        spansB = B["spans"]
        for option in eg["options"]:
            assert option["text"] == text
            if option["id"] == "A":
                assert option["spans"] == spansA
            else:
                assert option["spans"] == spansB


def test_ner_ab_eval_labels(dataset, text_stream, nlp, nlp_blank):
    """Ensure that the ner.ab_evaluate filters labels correctly"""
    LABEL = "PERSON"
    components = ab_evaluate(dataset, nlp, nlp_blank, text_stream, label=[LABEL])
    queue = list(components["stream"])
    for eg in queue:
        text = eg["input"]["text"]
        A = eg["A"]
        B = eg["B"]
        assert text == A["text"] == B["text"]
        spansA = A["spans"]
        for span in spansA:
            assert span["label"] == LABEL
        spansB = B["spans"]
        for span in spansB:
            assert span["label"] == LABEL
