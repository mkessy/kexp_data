from functools import partial
from typing import Any, Dict, List

import numpy as np
import pytest

from prodigy.components.metrics._util import (
    _build_reliability_table,
    _get_answer,
    _get_attributes,
    _get_choice,
    _get_contains,
    _is_matrix_valid,
    _validate_annotators,
    _validate_labels,
)
from prodigy.components.metrics.base import (
    Metric,
    resolve_config,
)
from prodigy.components.metrics.errors import (
    AnnotationTypeError,
    IntraAnnotatorTaskDuplicates,
    MetricRegistryError,
    MismatchedAnnotatorsError,
    MismatchedLabelsError,
    MissingAnnotatorId,
    MissingViewId,
    MultipleBinaryLabelsError,
    NoLabelsError,
    SingleAnnotatorError,
)

# from confection import registry as confection_registry
from prodigy.components.metrics.iaa_doc import (
    IaaDoc,
    make_iaa_doc_metric,
)
from prodigy.components.stream import get_stream


@pytest.fixture
def binary_annotations() -> List[Dict[str, Any]]:
    return [
        {
            "text": "This is a test 1",
            "_input_hash": 1,
            "_task_hash": 1,
            "answer": "accept",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 2",
            "_input_hash": 2,
            "_task_hash": 2,
            "answer": "reject",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 3",
            "_input_hash": 3,
            "_task_hash": 3,
            "answer": "accept",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 1",
            "_input_hash": 1,
            "_task_hash": 1,
            "answer": "accept",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 2",
            "_input_hash": 2,
            "_task_hash": 2,
            "answer": "reject",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 3",
            "_input_hash": 3,
            "_task_hash": 3,
            "answer": "reject",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_alex",
        },
    ]


@pytest.fixture
def new_binary_annotations() -> List[Dict[str, Any]]:
    return [
        {
            "text": "This is a test 4",
            "_input_hash": 4,
            "_task_hash": 4,
            "answer": "accept",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 5",
            "_input_hash": 5,
            "_task_hash": 5,
            "answer": "reject",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 4",
            "_input_hash": 4,
            "_task_hash": 4,
            "answer": "accept",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 5",
            "_input_hash": 5,
            "_task_hash": 5,
            "answer": "accept",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 6",
            "_input_hash": 6,
            "_task_hash": 6,
            "answer": "reject",
            "label": "NEWS",
            "_view_id": "classification",
            "_annotator_id": "ann_alex",
        },
    ]


@pytest.fixture
def binary_reliability_matrix() -> np.ndarray:
    return np.array([[1, 1], [0, 0], [0, 1]], dtype=int)


@pytest.fixture
def binary_reliability_matrix_non_symmetric() -> np.ndarray:
    return np.array([[1, 1], [0, 0], [0, 1]], dtype=int)


@pytest.fixture
def binary_agreement_matrix() -> np.ndarray:
    return np.array(
        [
            [[1, 2], [0, 0]],
            [[0, 2], [1, 0]],
            [[0, 1], [1, 1]],
        ],
        dtype=int,
    )


@pytest.fixture
def binary_agreement_matrix_non_symetric() -> np.ndarray:
    return np.array(
        [
            [[1, 2], [0, 0]],
            [[0, 2], [1, 0]],
            [[0, 1], [1, 1]],
        ],
        dtype=int,
    )


@pytest.fixture
def multiclass_annotations() -> List[Dict[str, Any]]:
    return [
        {
            "text": "This is a test 1",
            "_input_hash": 1,
            "_task_hash": 1,
            "answer": "accept",
            "accept": ["BROCCOLI"],
            "_view_id": "choice",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 2",
            "_input_hash": 2,
            "_task_hash": 2,
            "answer": "accept",
            "accept": ["BANANA"],
            "_view_id": "choice",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 3",
            "_input_hash": 3,
            "_task_hash": 3,
            "answer": "accept",
            "accept": ["APPLE"],
            "_view_id": "choice",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 1",
            "_input_hash": 1,
            "_task_hash": 1,
            "answer": "accept",
            "accept": ["BROCCOLI"],
            "_view_id": "choice",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 2",
            "_input_hash": 2,
            "_task_hash": 2,
            "answer": "accept",
            "accept": ["BROCCOLI"],
            "_view_id": "choice",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 3",
            "_input_hash": 3,
            "_task_hash": 3,
            "answer": "reject",
            "_view_id": "choice",
            "_annotator_id": "ann_alex",
        },
    ]


@pytest.fixture
def multiclass_reliability_matrix() -> np.ndarray:
    return np.array(
        [[0, 0], [0, 1], [-1, 2]],
        dtype=int,
    )


@pytest.fixture
def multiclass_agreement_matrix() -> np.ndarray:
    return np.array(
        [
            [[0, 2], [1, 0], [2, 0]],
            [[0, 1], [1, 1], [2, 0]],
            [[0, 0], [1, 0], [2, 1]],
        ],
        dtype=int,
    )


@pytest.fixture
def multilabel_annotations() -> List[Dict[str, Any]]:
    return [
        {
            "text": "This is a test 1",
            "_input_hash": 1,
            "_task_hash": 1,
            "answer": "accept",
            "accept": ["BROCCOLI"],
            "_view_id": "choice",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 2",
            "_input_hash": 2,
            "_task_hash": 2,
            "answer": "accept",
            "accept": ["BROCCOLI", "BANANA"],
            "_view_id": "choice",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 3",
            "_input_hash": 3,
            "_task_hash": 3,
            "answer": "accept",
            "accept": ["APPLE", "BANANA"],
            "_view_id": "choice",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 1",
            "_input_hash": 1,
            "_task_hash": 1,
            "answer": "accept",
            "accept": ["BROCCOLI", "BANANA"],
            "_view_id": "choice",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 2",
            "_input_hash": 2,
            "_task_hash": 2,
            "answer": "accept",
            "accept": ["BROCCOLI"],
            "_view_id": "choice",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 3",
            "_input_hash": 3,
            "_task_hash": 3,
            "answer": "reject",
            "accept": [],
            "_view_id": "choice",
            "_annotator_id": "ann_alex",
        },
    ]


@pytest.fixture
def new_multilabel_annotations() -> List[Dict[str, Any]]:
    return [
        {
            "text": "This is a test 4",
            "_input_hash": 4,
            "_task_hash": 4,
            "answer": "accept",
            "accept": ["BROCCOLI", "APPLE"],
            "_view_id": "choice",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 5",
            "_input_hash": 5,
            "_task_hash": 5,
            "answer": "accept",
            "accept": ["BROCCOLI", "BANANA"],
            "_view_id": "choice",
            "_annotator_id": "ann_bob",
        },
        {
            "text": "This is a test 4",
            "_input_hash": 4,
            "_task_hash": 4,
            "answer": "accept",
            "accept": ["APPLE", "BANANA"],
            "_view_id": "choice",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 5",
            "_input_hash": 5,
            "_task_hash": 5,
            "answer": "accept",
            "accept": ["BROCCOLI", "BANANA"],
            "_view_id": "choice",
            "_annotator_id": "ann_alex",
        },
        {
            "text": "This is a test 6",
            "_input_hash": 6,
            "_task_hash": 6,
            "answer": "accept",
            "accept": ["BROCCOLI"],
            "_view_id": "choice",
            "_annotator_id": "ann_alex",
        },
    ]


@pytest.fixture
def multilabel_reliability_matrix() -> Dict[str, np.ndarray]:
    return {
        "BROCCOLI": np.array([[1, 1], [1, 1], [0, -1]], dtype=int),
        "BANANA": np.array([[0, 1], [1, 0], [1, -1]], dtype=int),
        "APPLE": np.array([[0, 0], [0, 0], [1, -1]], dtype=int),
    }


@pytest.fixture
def multilabel_agreement_matrix() -> Dict[str, np.ndarray]:
    return {
        "BROCCOLI": np.array(
            [[[1, 2], [0, 0]], [[1, 2], [0, 0]], [[1, 0], [0, 1]]], dtype=int
        ),
        "BANANA": np.array(
            [[[0, 1], [1, 1]], [[0, 1], [1, 1]], [[0, 0], [1, 1]]], dtype=int
        ),
        "APPLE": np.array(
            [[[0, 2], [1, 0]], [[0, 2], [1, 0]], [[0, 0], [1, 1]]], dtype=int
        ),
    }


@pytest.fixture()
def binary_iaa_doc(binary_annotations) -> IaaDoc:
    m = make_iaa_doc_metric(
        annotation_type="binary",
        annotators=["ann_bob", "ann_alex"],
    )
    stream = get_stream(binary_annotations, loader=None)
    m.measure(stream)
    return m


@pytest.fixture
def multiclass_iaa_doc(multiclass_annotations) -> IaaDoc:
    m = make_iaa_doc_metric(
        annotation_type="multiclass",
        annotators=["ann_bob", "ann_alex"],
        labels=["BROCCOLI", "BANANA", "APPLE"],
    )
    stream = get_stream(multiclass_annotations, loader=None)
    m.measure(stream)
    return m


@pytest.fixture
def multilabel_iaa_doc(multilabel_annotations) -> IaaDoc:
    m = make_iaa_doc_metric(
        annotation_type="multilabel",
        annotators=["ann_bob", "ann_alex"],
        labels=["BROCCOLI", "BANANA", "APPLE"],
    )
    stream = get_stream(multilabel_annotations, loader=None)
    m.measure(stream)
    return m


@pytest.fixture
def make_temp_file(tmp_path):
    def _temp_file(filename: str, content: str):
        file = tmp_path / filename
        file.write_text(content)
        return file

    yield _temp_file

    # teardown - delete the temporary file
    for item in tmp_path.glob("*"):
        item.unlink()


@pytest.fixture
def cfg_str() -> str:
    return """[metric]\n@metrics = "test_metric.v1"\na = 1\nb = 3\n[other_settings]"""


@pytest.fixture
def iaa_doc_cfg_str() -> str:
    return """[metric]\n@metrics = "prodigy.metrics.IaaDoc.v1"\nannotation_type = 1\nb = 3"""


@pytest.fixture
def cfg_file(make_temp_file, cfg_str):
    return make_temp_file("test.cfg", cfg_str)


@pytest.fixture
def iaa_doc_cfg_file(make_temp_file, iaa_doc_cfg_str):
    return make_temp_file("test.cfg", iaa_doc_cfg_str)


@pytest.fixture
def unstructured_input_str() -> str:
    return """{"text": "This is a test example.","_input_hash": 639213366,"_task_hash": -298818960,"label": "TEST","_view_id": "classification","answer": "accept","_timestamp": 1679249719,"_annotator_id": "bob","_session_id": "bob"}\n{"text": "This is another test example.","_input_hash": -497909832,"_task_hash": 1338997692,"label": "TEST","_view_id": "classification","answer": "accept","_timestamp": 1679249719,"_annotator_id": "bob","_session_id": "bob"}"""


@pytest.fixture
def unstructured_input_str2() -> str:
    return """{"text": "This is a test example.","_input_hash": 639213366,"_task_hash": -298818960,"label": "TEST","_view_id": "classification","answer": "accept","_timestamp": 1679249719,"_annotator_id": "alex","_session_id": "alex"}\n{"text": "This is another test example.","_input_hash": -497909832,"_task_hash": 1338997692,"label": "TEST","_view_id": "classification","answer": "accept","_timestamp": 1679249719,"_annotator_id": "alex","_session_id": "alex"}"""


def test_config_metric_registry_error():
    default_config = Metric._get_default_metric_config("test_metric.v2")
    with pytest.raises(MetricRegistryError):
        _ = resolve_config(metric_name="test_metric.v2", config=default_config)


@pytest.mark.parametrize("annotation_type", ["binary", "multiclass"])
def test_iaa_doc_reliability_matrix(
    annotation_type,
    binary_iaa_doc,
    binary_reliability_matrix,
    multiclass_iaa_doc,
    multiclass_reliability_matrix,
):
    """Test building IAA reliability table."""
    m = None
    value_getter = None
    expected_matrix = None
    if annotation_type == "binary":
        m = binary_iaa_doc
        expected_matrix = binary_reliability_matrix
        value_getter = _get_answer
    elif annotation_type == "multiclass":
        m = multiclass_iaa_doc
        expected_matrix = multiclass_reliability_matrix
        value_getter = _get_choice
    assert m is not None
    assert value_getter is not None
    assert expected_matrix is not None
    matrix = _build_reliability_table(
        m._examples,
        m._labels,
        m._annotators,
        m._annotation_type,
        value_getter=value_getter,
    )
    sorted_matrix = np.sort(matrix, axis=1)  # type: ignore
    sorted_expected = np.sort(expected_matrix, axis=1)  # type: ignore
    assert np.array_equal(sorted_matrix, sorted_expected)


def test_iaa_doc_reliability_matrix_multilabel(
    multilabel_iaa_doc, multilabel_reliability_matrix
):
    """Test building IAA reliability matrix for multilabel annotations."""
    labels = ["BROCCOLI", "BANANA", "APPLE"]
    for label in labels:
        label_value_getter = partial(_get_contains, value=label)
        matrix = _build_reliability_table(
            multilabel_iaa_doc._examples,
            multilabel_iaa_doc._labels,
            multilabel_iaa_doc._annotators,
            multilabel_iaa_doc._annotation_type,
            value_getter=label_value_getter,
        )
        sorted_matrix = np.sort(matrix, axis=1)  # type: ignore
        sorted_expected = np.sort(multilabel_reliability_matrix[label], axis=1)  # type: ignore
        assert np.array_equal(sorted_matrix, sorted_expected)


@pytest.mark.parametrize("annotation_type", ["binary", "multiclass"])
def test_iaa_doc_agreement_table(
    annotation_type,
    binary_iaa_doc,
    binary_reliability_matrix,
    binary_agreement_matrix,
    multiclass_iaa_doc,
    multiclass_reliability_matrix,
    multiclass_agreement_matrix,
):
    """Test building IAA agreement table for binary and multiclass annotations."""
    matrix = None
    expected = None
    if annotation_type == "binary":
        matrix = binary_iaa_doc._build_agreement_table(binary_reliability_matrix)
        expected = binary_agreement_matrix
    elif annotation_type == "multiclass":
        matrix = multiclass_iaa_doc._build_agreement_table(
            multiclass_reliability_matrix
        )
        expected = multiclass_agreement_matrix
    sorted_matrix = np.sort(matrix, axis=1)  # type: ignore
    sorted_expected = np.sort(expected, axis=1)  # type: ignore
    assert np.array_equal(sorted_matrix, sorted_expected)  # type: ignore


def test_iaa_doc_multilabel_agreement_table(
    multilabel_iaa_doc, multilabel_reliability_matrix, multilabel_agreement_matrix
):
    """Test building IAA agreement table for mutilabel annotations."""
    for label, m in multilabel_reliability_matrix.items():
        matrix = multilabel_iaa_doc._build_agreement_table(m)
        sorted_matrix = np.sort(matrix, axis=1)  # type: ignore
        sorted_expected = np.sort(multilabel_agreement_matrix[label], axis=1)  # type: ignore
        assert np.array_equal(sorted_matrix, sorted_expected)  # type: ignore


def test_iaa_doc_binary_update(binary_iaa_doc, new_binary_annotations):
    """Test updating IAA doc with new binary annotations."""
    # if there is no annotation for a given example, it counts as 0
    expected = {
        "_all": np.array(
            [
                [[1, 2], [0, 0]],
                [[0, 2], [1, 0]],
                [[1, 1], [0, 1]],
                [[1, 2], [0, 0]],
                [[1, 1], [0, 1]],
                [[0, 1], [1, 0]],
            ],
            dtype=int,
        )
    }
    stream = get_stream(new_binary_annotations, loader=None)
    binary_iaa_doc.measure(stream)
    assert len([eg for eg in binary_iaa_doc._examples]) == 11

    sorted_matrix = np.sort(binary_iaa_doc._agreement_table_per_label["_all"], axis=1)  # type: ignore
    sorted_expected = np.sort(expected["_all"], axis=1)  # type: ignore
    assert np.array_equal(sorted_matrix, sorted_expected)  # type: ignore


def test_iaa_doc_multilabel_update(multilabel_iaa_doc, new_multilabel_annotations):
    """Test updating IAA doc with new binary annotations."""
    # if there is no annotation for a given example, it counts as 0
    expected = {
        "BROCCOLI": np.array(
            [
                [[0, 0], [1, 2]],
                [[0, 0], [1, 2]],
                [[0, 1], [1, 0]],
                [[0, 1], [1, 1]],
                [[0, 0], [1, 2]],
                [[0, 0], [1, 1]],
            ],
            dtype=int,
        ),
        "BANANA": np.array(
            [
                [[0, 1], [1, 1]],
                [[0, 1], [1, 1]],
                [[0, 0], [1, 1]],
                [[0, 1], [1, 1]],
                [[0, 0], [1, 2]],
                [[0, 1], [1, 0]],
            ],
            dtype=int,
        ),
        "APPLE": np.array(
            [
                [[0, 2], [1, 0]],
                [[0, 2], [1, 0]],
                [[0, 0], [1, 1]],
                [[0, 0], [1, 2]],
                [[0, 2], [1, 0]],
                [[0, 1], [1, 0]],
            ],
            dtype=int,
        ),
    }
    stream = get_stream(new_multilabel_annotations, loader=None)
    multilabel_iaa_doc.measure(stream)
    # assert len(multilabel_iaa_doc.examples) == 11
    assert len(multilabel_iaa_doc._agreement_table_per_label) == 3
    for k, v in multilabel_iaa_doc._agreement_table_per_label.items():
        sorted_matrix = np.sort(v, axis=1)
        sorted_expected = np.sort(expected[k], axis=1)
        assert np.array_equal(sorted_matrix, sorted_expected)


def test_get_result_binary(
    binary_iaa_doc, binary_agreement_matrix, binary_reliability_matrix
):
    """Test getting the IAA result for binary annotations."""
    binary_iaa_doc.agreement_table_per_label = {"_all": binary_agreement_matrix}
    binary_iaa_doc.reliability_table_per_label = {"_all": binary_reliability_matrix}
    result_per_label = binary_iaa_doc.get_result()
    result = result_per_label["_all"]
    assert result.n_examples == 6
    assert result.n_categories == 2
    assert result.n_coincident_examples == 3
    assert result.n_single_annotation == 0
    assert result.n_annotators == 2
    assert result.avg_raters_per_example == 2.0
    assert result.percent_agreement == 0.6666666666666666
    assert result.kripp_alpha == 0.4444444444444444
    assert result.gwet_ac2 == 0.33333333333333326


def test_get_result_multilabel(
    multilabel_iaa_doc, multilabel_agreement_matrix, multilabel_reliability_matrix
):
    """Test getting the IAA result for multilabel annotations."""
    multilabel_iaa_doc.agreement_table_per_label = multilabel_agreement_matrix
    multilabel_iaa_doc.reliability_table_per_label = multilabel_reliability_matrix
    result = multilabel_iaa_doc.get_result()
    broccoli_results = result.get("BROCCOLI")
    banana_results = result.get("BANANA")
    apple_results = result.get("APPLE")
    assert (
        broccoli_results.n_examples
        == banana_results.n_examples
        == apple_results.n_examples
        == 5
    )
    assert (
        broccoli_results.n_categories
        == banana_results.n_categories
        == apple_results.n_categories
        == 3
    )
    assert (
        broccoli_results.n_coincident_examples
        == banana_results.n_coincident_examples
        == apple_results.n_coincident_examples
        == 2
    )
    assert (
        broccoli_results.n_single_annotation
        == banana_results.n_single_annotation
        == apple_results.n_single_annotation
        == 1
    )
    assert (
        broccoli_results.n_annotators
        == banana_results.n_annotators
        == apple_results.n_annotators
        == 2
    )
    assert (
        broccoli_results.avg_raters_per_example
        == banana_results.avg_raters_per_example
        == apple_results.avg_raters_per_example
        == 1.6666666666666667
    )
    assert broccoli_results.percent_agreement == 1.0
    assert broccoli_results.kripp_alpha == 0
    assert broccoli_results.gwet_ac2 == 1.0

    assert banana_results.percent_agreement == 0.0
    assert banana_results.kripp_alpha == -0.5
    assert banana_results.gwet_ac2 == -0.8

    assert apple_results.percent_agreement == 1.0
    assert apple_results.kripp_alpha == 0
    assert apple_results.gwet_ac2 == 1.0


"""Tests from examples in:
K. L. Gwet, “On Krippendorff’s Alpha Coefficient,” p. 16, 2015.
https://agreestat.com/papers/onkrippendorffalpha_rev10052015.pdf
"""


@pytest.fixture
def reliability_data1():
    # from 'K. L. Gwet, “On Krippendorff’s Alpha Coefficient,” p. 16, 2015.'
    return np.array(
        [
            [1.0, 1.0, -1, 1.0],
            [2.0, 2.0, 3.0, 2.0],
            [3.0, 3.0, 3.0, 3.0],
            [3.0, 3.0, 3.0, 3.0],
            [2.0, 2.0, 2.0, 2.0],
            [1.0, 2.0, 3.0, 4.0],
            [4.0, 4.0, 4.0, 4.0],
            [1.0, 1.0, 2.0, 1.0],
            [2.0, 2.0, 2.0, 2.0],
            [-1, 5.0, 5.0, 5.0],
            [-1, -1, 1.0, 1.0],
            [-1, -1, 3.0, -1],
        ],
        dtype=int,
    )


@pytest.fixture
def reliability_data2():
    # From
    # Hayes, A. F., & Krippendorff, K. (2007).
    #  Answering the Call for a Standard Reliability Measure for Coding Data.
    #  Communication Methods and Measures, 1(1), 77–89.
    #  doi:10.1080/19312450709336664
    return np.array(
        [
            [1.0, 1.0, 2.0, -1, 2.0],
            [1.0, 1.0, 0.0, 1.0, -1],
            [2.0, 3.0, 3.0, 3.0, -1],
            [-1, 0.0, 0.0, -1, 0.0],
            [0.0, 0.0, 0.0, -1, 0.0],
            [0.0, 0.0, 0.0, -1, 0.0],
            [1.0, 0.0, 2.0, -1, 1.0],
            [1.0, -1, 2.0, 0.0, -1],
            [2.0, 2.0, 2.0, -1, 2.0],
            [2.0, 1.0, 1.0, 1.0, -1],
            [-1, 1.0, 0.0, 0.0, -1],
            [0.0, 0.0, 0.0, 0.0, -1],
            [1.0, 2.0, 2.0, 2.0, -1],
            [3.0, 3.0, 2.0, 2.0, 3.0],
            [1.0, 1.0, 1.0, -1, 1.0],
            [1.0, 1.0, 1.0, -1, 1.0],
            [2.0, 1.0, 2.0, -1, 2.0],
            [1.0, 2.0, 3.0, 3.0, -1],
            [1.0, 1.0, 0.0, 1.0, -1],
            [0.0, 0.0, 0.0, -1, 0.0],
            [0.0, 0.0, 1.0, 1.0, -1],
            [0.0, 0.0, -1, 0.0, 0.0],
            [2.0, 3.0, 3.0, 3.0, -1],
            [0.0, 0.0, 0.0, 0.0, -1],
            [1.0, 2.0, -1, 2.0, 2.0],
            [0.0, 1.0, 1.0, 1.0, -1],
            [0.0, 0.0, 0.0, 1.0, 0.0],
            [1.0, 2.0, 1.0, 2.0, -1],
            [1.0, 1.0, 2.0, 2.0, -1],
            [1.0, 1.0, 2.0, -1, 2.0],
            [1.0, 1.0, 0.0, -1, 0.0],
            [2.0, 1.0, 2.0, 1.0, -1],
            [2.0, 2.0, -1, 2.0, 2.0],
            [3.0, 2.0, 2.0, 2.0, -1],
            [2.0, 2.0, 2.0, -1, 2.0],
            [2.0, 2.0, 3.0, -1, 2.0],
            [2.0, 2.0, 2.0, -1, 2.0],
            [2.0, 2.0, -1, 1.0, 2.0],
            [2.0, 2.0, 2.0, 2.0, -1],
            [1.0, 1.0, 1.0, -1, 1.0],
        ],
        dtype=int,
    )


@pytest.fixture
def reliability_data3():
    # From https://en.wikipedia.org/wiki/Krippendorff's_Alpha")
    #  reliability_data_str = (
    #   "*    *    *    *    *    3    4    1    2    1    1    3    3    *    3",  # coder A
    #   "1    *    2    1    3    3    4    3    *    *    *    *    *    *    *",  # coder B
    #   "*    *    2    1    3    4    4    *    2    1    1    3    3    *    4",  # coder C
    # )
    # here transposed to n by m, where n is examples and m is annotators
    return np.array(
        [
            [-1, 1, -1],
            [-1, -1, -1],
            [-1, 2, 2],
            [-1, 1, 1],
            [-1, 3, 3],
            [3, 3, 4],
            [4, 4, 4],
            [1, 3, -1],
            [2, -1, 2],
            [1, -1, 1],
            [1, -1, 1],
            [3, -1, 3],
            [3, -1, 3],
            [-1, -1, -1],
            [3, -1, 4],
        ],
        dtype=int,
    )


@pytest.fixture
def reliability_data4():
    return np.array(
        [
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
        ],
        dtype=int,
    )


def test_benchmark_data1(reliability_data1, binary_iaa_doc):
    agreement_data = binary_iaa_doc._build_agreement_table(reliability_data1)
    stats = binary_iaa_doc._compute_agreement(agreement_data, reliability_data1, "_all")
    assert stats.percent_agreement == pytest.approx(0.8182, 0.0001)
    assert stats.kripp_alpha == pytest.approx(0.7434, 0.0001)
    assert stats.gwet_ac2 == pytest.approx(0.7754, 0.0001)


def test_benchmark_data2(reliability_data2, binary_iaa_doc):
    agreement_data = binary_iaa_doc._build_agreement_table(reliability_data2)
    stats = binary_iaa_doc._compute_agreement(agreement_data, reliability_data2, "_all")
    assert stats.percent_agreement == pytest.approx(0.6250, 0.0001)
    assert stats.kripp_alpha == pytest.approx(0.4765, 0.0001)
    assert stats.gwet_ac2 == pytest.approx(0.5093, 0.0001)


def test_benchmark_data3(reliability_data3, binary_iaa_doc):
    agreement_data = binary_iaa_doc._build_agreement_table(reliability_data3)
    stats = binary_iaa_doc._compute_agreement(agreement_data, reliability_data3, "_all")
    assert stats.kripp_alpha == pytest.approx(0.691358024691358, 0.0001)


def test_kripp_warning(reliability_data4, binary_iaa_doc, capsys):
    agreement_data = binary_iaa_doc._build_agreement_table(reliability_data4)
    stats = binary_iaa_doc._compute_agreement(agreement_data, reliability_data4, "_all")
    out = capsys.readouterr().out
    assert "⚠ The agreement expected by chance" in out
    assert stats.kripp_alpha == 0.0


# Helpers

# Value getters

test_cases_multiclass = [
    # Test case 1: 1 Single value in annotations
    ({"answer": "accept", "accept": ["POLITICS"]}, "POLITICS", 1),
    # Test case 2: 2 Multiple values in annotations
    ({"answer": "accept", "accept": ["POLITICS", "TECH"]}, "POLITICS", 1),
    # Test case 3: No annotations
    ({"answer": "accept", "accept": []}, "POLITICS", 0),
    # Test case 4: reject answer, should return _NO_ANNOTATION
    ({"answer": "reject", "accept": ["POLITCS", "TECH"]}, "POLITICS", -1),
]


@pytest.mark.parametrize("example, value, expected", test_cases_multiclass)
def test_get_contains(example, value, expected):
    result = _get_contains(example, value)
    assert result == expected


test_cases_multilabel = [
    # Test case 1: Single value in annotations
    ({"answer": "accept", "accept": ["POLITICS"]}, "POLITICS"),
    # Test case 2: Multiple values in annotations
    ({"answer": "accept", "accept": ["POLITICS", "TECH"]}, AnnotationTypeError),
    # Test case 3: No annotations
    ({"answer": "accept", "accept": []}, -1),
    # Test case 4: reject answer, should return _NO_ANNOTATION
    ({"answer": "reject", "accept": ["POLITCS"]}, -1),
]


@pytest.mark.parametrize("example, expected", test_cases_multilabel)
def test_get_choice(example, expected):
    if expected == AnnotationTypeError:
        with pytest.raises(AnnotationTypeError):
            _get_choice(example)
    else:
        result = _get_choice(example)
        assert result == expected


test_cases_binary = [
    # Test case 1: Accept answer, should return 1
    ({"answer": "accept"}, 1),
    # Test case 2: Reject answer, should return 0
    ({"answer": "reject"}, 0),
    # Test case 3: Ignore answer, should return _NO_ANNOTATION
    ({"answer": "ignore"}, -1),
]


@pytest.mark.parametrize("example, expected", test_cases_binary)
def test_get_answer(example, expected):
    result = _get_answer(example)
    assert result == expected


test_cases_matrix_validation = [
    # Test case 1: Matrix filled with -1 should return True
    (np.full((3, 3), -1), False),
    # Test case 2: Matrix filled with 0 should return True
    (np.zeros((4, 4)), False),
    # Test case 3: Matrix with only 0 and -1 values should return True
    (np.array([[0, -1], [0, 0]]), False),
    # Test case 4: Matrix with non-integer values should return False
    (np.array([[0.5, -1], [0, 0]]), True),
]


@pytest.mark.parametrize("matrix, expected", test_cases_matrix_validation)
def test_is_matrix_valid(matrix, expected):
    result = _is_matrix_valid(matrix)
    assert result == expected


# Input data validation

test_cases_labels_validation = [
    # Test case 1: Valid labels match dataset, non-binary
    (
        "multilabel",
        ["label1", "label2", "label3"],
        set(["label1", "label2", "label3"]),
        None,
    ),
    # Test case 2: Valid subset, non-binary
    ("multilabel", ["label1", "label2"], set(["label1", "label2", "label3"]), None),
    # Test case 3: Mismatched labels dataset, non-binary
    ("multilabel", ["label1", "label2"], set(["label1"]), MismatchedLabelsError),
    # Test case 4: Mismatched labels, empty dataset, non-binary
    ("multilabel", ["label1", "label2"], set(), MismatchedLabelsError),
    # Test case 5: No labels, non-binary
    ("multilabel", None, set(), NoLabelsError),
    # Test case 6: Valid labels, binary annotation
    ("binary", ["label1"], set(["label1"]), None),
    # Test case 7: Invalid multiple labels, binary annotation
    (
        "binary",
        ["label1", "label2"],
        set(["label1", "label2"]),
        MultipleBinaryLabelsError,
    ),
]


@pytest.mark.parametrize(
    "annotation_type, cli_labels, dataset_labels, expected_exception",
    test_cases_labels_validation,
)
def test_validate_labels_binary(
    annotation_type, cli_labels, dataset_labels, expected_exception
):
    IaaDoc(annotation_type, labels=cli_labels, annotators=None)
    if expected_exception:
        with pytest.raises(expected_exception):
            _validate_labels(cli_labels, dataset_labels, annotation_type)
    else:
        _validate_labels(cli_labels, dataset_labels, annotation_type)


test_cases_validate_annotators = [
    # Test case 1: Valid annotators match dataset, at least 2 annotators
    (
        ["annotator1", "annotator2", "annotator3"],
        set(["annotator1", "annotator2", "annotator3"]),
        None,
    ),
    # Test case 2: Valid subset, at least 2 annotators
    (
        ["annotator1", "annotator2"],
        set(["annotator1", "annotator2", "annotator3"]),
        None,
    ),
    # Test case 3: Mismatched annotators, should raise MismatchedAnnotatorsError
    (
        ["annotator1", "annotator2"],
        set(["annotator1", "annotator3"]),
        MismatchedAnnotatorsError,
    ),
    # Test case 4: Single annotator, should raise SingleAnnotatorError
    (None, set(["annotator1"]), SingleAnnotatorError),
]


@pytest.mark.parametrize(
    "cli_annotators, dataset_annotators, expected_exception",
    test_cases_validate_annotators,
)
def test_validate_annotators(cli_annotators, dataset_annotators, expected_exception):
    IaaDoc("binary", labels=None, annotators=cli_annotators)
    if expected_exception:
        with pytest.raises(expected_exception):
            _validate_annotators(cli_annotators, dataset_annotators)
    else:
        _validate_annotators(cli_annotators, dataset_annotators)


def test_duplicates_raise_error():
    # Sample data with duplicates for the same task and annotator
    examples = [
        {"_input_hash": "task1", "_annotator_id": "ann1"},
        {"_input_hash": "task1", "_annotator_id": "ann1"},
    ]
    labels = ["label1", "label2"]
    annotators = ["ann1"]
    annotation_type = "binary"

    def value_getter(x):
        return x["_input_hash"]  # Dummy value getter

    # Ensure that the function raises IntraAnnotatorTaskDuplicates errormatch="
    with pytest.raises(IntraAnnotatorTaskDuplicates) as e:
        _build_reliability_table(
            examples, labels, annotators, annotation_type, value_getter
        )
        assert e.match(
            "Cannot build reliability matrix: multiple annotations of a single task `task1` from annotator `ann1`."
        )


def test_get_attributes():
    examples = [
        {
            "_task_hash": 1,
            "_annotator_id": "ann1",
            "label": "positive",
            "_view_id": "view1",
        },
        {
            "_task_hash": 2,
            "_annotator_id": "ann2",
            "label": "negative",
            "_view_id": "view1",
        },
        {
            "_task_hash": 3,
            "_annotator_id": "ann2",
            "label": "positive",
            "_view_id": "view1",
        },
    ]
    annotation_type = "binary"

    # Ensure that the function returns the expected values
    annotators, labels, view_ids = _get_attributes(examples, annotation_type)

    # Check if the sets contain the expected values
    assert annotators == {"ann1", "ann2"}
    assert labels == {"positive", "negative"}
    assert view_ids == {"view1"}


def test_get_attributes_missing_view_id():
    # Sample data with missing view_id
    examples = [{"task_hash": 1, "annotator_id": "ann1", "label": "positive"}]
    annotation_type = "binary"

    # Ensure that the function raises MissingViewId error
    with pytest.raises(MissingViewId) as e:
        _get_attributes(examples, annotation_type)
        e.match(
            "View ID is missing in example with task_hash: 1. It is expected under _view_id key."
        )


def test_get_attributes_missing_annotator_id():
    # Sample data with missing annotator_id
    examples = [{"task_hash": 1, "label": "positive", "_view_id": "view1"}]
    annotation_type = "binary"

    # Ensure that the function raises MissingAnnotatorId error
    with pytest.raises(MissingAnnotatorId) as e:
        _get_attributes(examples, annotation_type)
        e.match(
            "Annotator ID is missing in example with task_hash: 1. It is expected under _annotator_id key."
        )
