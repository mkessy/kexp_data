import random
import string
from pathlib import Path
from typing import List

import pytest

from prodigy.components.db import Database
from prodigy.components.loaders import JSONL
from prodigy.core import Controller
from prodigy.errors import RecipeError
from prodigy.recipes.pos import correct, teach
from prodigy.types import TaskType
from prodigy.util import set_hashes


@pytest.fixture
def dataset():
    return "tmp-test-dataset"


@pytest.fixture
def examples():
    return [{"text": "Example 1"}, {"text": "Example 2"}, {"text": "Example 3"}]


@pytest.fixture
def text_stream():
    data_path = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    tasks = JSONL(data_path)
    return [set_hashes(task) for task in tasks]


@pytest.fixture
def db(database: Database, dataset: str, examples: List[TaskType]) -> Database:
    database.add_dataset(dataset, meta={"desc": "TMP dataset"})
    examples = [set_hashes(eg) for eg in examples]
    database.add_examples(examples, datasets=(dataset,))
    return database


# pos.teach #


def test_tag_teach_returns_components(dataset, spacy_model, nlp, examples):
    """Ensure that the pos.teach recipe properly returns components"""
    C = teach(dataset, nlp, source=examples)
    assert C["view_id"] == "pos"
    assert C["dataset"] == dataset
    assert hasattr(C["stream"], "__iter__")
    assert hasattr(C["update"], "__call__")
    assert C["config"]["lang"] == spacy_model.split("_")[0]
    assert C["config"]["label"] == "all"


def test_tag_teach_can_stream(dataset, nlp):
    """Ensure that the pos.teach recipe can stream examples"""
    examples = [
        {
            "text": "".join(
                random.choice(string.ascii_letters + " " * 10) for x in range(i)
            )
        }
        for i in range(100)
    ]
    C = teach(dataset, nlp, source=examples)
    batch = []
    cutoff = 20
    for eg in C["stream"]:
        batch.append(eg)
        if len(batch) == cutoff:
            break
    assert len(batch) == cutoff


def test_tag_teach_exits_without_tagger(dataset, text_stream, nlp_blank):
    """Ensure that the pos.teach recipe exits when a model is given without tagger component"""
    with pytest.raises(RecipeError):
        teach(dataset, nlp_blank, text_stream, label=["RANDOM"])


def test_tag_teach_exits_wrong_label(dataset, text_stream, nlp):
    """Ensure that the pos.teach recipe exits when a label is provided that is not part of the model"""
    with pytest.raises(RecipeError):
        components = teach(dataset, nlp, text_stream, label=["RANDOM"])
        Controller.from_components("pos.teach", components)


def test_tag_teach_predicts_label(dataset, text_stream, nlp):
    """Ensure that the pos.teach recipe provides examples with the correct label only"""
    LABEL = "DT"
    components = teach(dataset, nlp, text_stream, label=[LABEL])
    ctrl = Controller.from_components("pos.teach", components)
    queue = list(ctrl.stream)
    for eg in queue:
        assert "spans" in eg
        assert len(eg["spans"]) == 1
        assert eg["spans"][0]["label"] == LABEL
        score = eg["spans"][0]["score"]
        assert score >= 0
    ctrl.db.drop_dataset(dataset)


def test_tag_teach_updates(dataset, nlp):
    """Ensure that the pos.teach recipe is able to overfit through active learning"""

    def yield_tasks():
        for i in range(500):
            # we need some tokens ("sn") that the model will be unsure about
            yield {"text": f"{i} sn"}

    labels = ["NN", "VB", "CD"]
    # We want to measure the model's degree of (un)certainty without filtering the stream
    components = teach(dataset, nlp, yield_tasks(), label=labels, no_filter=True)
    stream = components["stream"]

    batch = []
    accept_score = 0
    prev_accept_score = None
    for eg in stream:
        if eg["spans"][0]["text"].startswith("sn"):
            if eg["spans"][0]["label"] == "CD":
                eg["answer"] = "accept"
                accept_score += eg["spans"][0]["score"]
            else:
                eg["answer"] = "reject"
            batch.append(eg)

        if len(batch) == 16:
            components["update"](batch)
            accept_score = accept_score / (
                len([eg for eg in batch if eg["answer"] == "accept"]) + 0.00005
            )
            batch = []
            # the model will not be predicting NN with high confidence at the beginning
            if prev_accept_score is None:
                assert accept_score < 0.8
            prev_accept_score = accept_score
            accept_score = 0

    # By the end of the overfitting loop, the prediction of sn=NN should be much higher
    assert prev_accept_score > 0.9


def test_tag_teach_unsegmented(dataset, text_stream, nlp):
    """Ensure that the pos.teach recipe 'unsegmented' option works properly"""
    components = teach(dataset, nlp, text_stream, unsegmented=True)
    ctrl = Controller.from_components("pos.teach", components)
    queue = list(ctrl.stream)
    found = False
    for eg in queue:
        text = eg["text"]
        # not split into sentences
        if "illegally touting horses" in text:
            found = True
            assert "several successful hustles" in text
    assert found
    ctrl.db.drop_dataset(dataset)


# pos.correct


def test_tag_correct_returns_components(db, dataset, spacy_model, nlp):
    """Ensure that the pos.correct recipe properly returns components"""
    C = correct(dataset, nlp, source=db.get_dataset_examples(dataset))
    assert C["view_id"] == "pos_manual"
    assert C["dataset"] == dataset
    assert hasattr(C["stream"], "__iter__")
    assert C["config"]["lang"] == spacy_model.split("_")[0]


def test_tag_correct_blank_model(dataset, text_stream, nlp_blank):
    """Ensure that the tag.correct recipe works well with a blank model and custom labels"""
    custom_labels = ["MY_LABEL", "ANOTHER_LABEL"]
    components = correct(dataset, nlp_blank, text_stream, label=custom_labels)
    ctrl = Controller.from_components("tag.correct", components)
    queue = list(ctrl.stream)
    labels = ctrl.config["labels"]
    assert labels == custom_labels
    eg = queue[0]
    assert "spans" in eg
    ctrl.db.drop_dataset(dataset)


def test_tag_correct_pretrained_model_labels(dataset, text_stream, nlp):
    """Ensure that the tag.correct recipe works well with a pretrained model and filtered labels"""
    LABEL = "JJ"
    components = correct(dataset, nlp, text_stream, label=[LABEL])
    ctrl = Controller.from_components("tag.correct", components)
    queue = list(ctrl.stream)
    labels = ctrl.config["labels"]
    assert labels == [LABEL]
    found_count = 0
    empty_count = 0
    for eg in queue:
        assert "spans" in eg
        if len(eg["spans"]) > 0:
            found_count += 1
            assert eg["spans"][0]["label"] == LABEL
        else:
            empty_count += 1
    # some examples contain a label, some don't
    assert found_count > 0
    assert empty_count > 0
    ctrl.db.drop_dataset(dataset)


def test_tag_correct_unsegmented(dataset, text_stream, nlp):
    """Ensure that the tag.correct recipe 'unsegmented' option works properly"""
    components = correct(dataset, nlp, text_stream, unsegmented=True)
    ctrl = Controller.from_components("tag.correct", components)
    queue = list(ctrl.stream)
    found = False
    for eg in queue:
        # not split into sentences
        text = eg["text"]
        if "illegally touting horse" in text:
            found = True
            assert "illegally touting horse" in text
    assert found
    ctrl.db.drop_dataset(dataset)
