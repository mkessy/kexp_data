from prodigy.recipes.data_utils import load_examples


def test_load_util_that_should_raise_hashing_warning(database, capsys):
    database.add_dataset("testtest")
    # Poor mans mock right here
    database.get_dataset_examples = lambda d: [{"text": "no hash!"}]
    load_examples(database, ["testtest"])
    captured = capsys.readouterr()
    assert "⚠" in captured.out
