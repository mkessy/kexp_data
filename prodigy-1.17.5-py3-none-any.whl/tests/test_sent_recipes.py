from pathlib import Path
from typing import List

import pytest
from spacy.language import Language

from prodigy.components.db import Database
from prodigy.components.loaders import JSONL
from prodigy.core import Controller
from prodigy.errors import RecipeError
from prodigy.recipes.sent import correct, teach
from prodigy.types import TaskType
from prodigy.util import set_hashes


@pytest.fixture
def dataset():
    return "tmp-test-dataset"


@pytest.fixture(scope="session")
def spacy_model() -> str:
    return "xx_sent_ud_sm"


@pytest.fixture(scope="session")
def nlp(spacy_model: str) -> Language:
    model = pytest.importorskip(spacy_model)
    return model.load()


@pytest.fixture
def examples():
    return [{"text": "Example 1"}, {"text": "Example 2"}, {"text": "Example 3"}]


@pytest.fixture
def text_stream():
    data_path = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    tasks = JSONL(data_path)
    return [set_hashes(task) for task in tasks]


@pytest.fixture
def db(database: Database, dataset: str, examples: List[TaskType]) -> Database:
    database.add_dataset(dataset, meta={"desc": "TMP dataset"})
    examples = [set_hashes(eg) for eg in examples]
    database.add_examples(examples, datasets=(dataset,))
    return database


# sent.teach #


def test_sent_teach_returns_components(dataset, spacy_model, nlp, examples):
    """Ensure that the sent.teach recipe properly returns components"""
    C = teach(dataset, nlp, source=examples)
    assert C["view_id"] == "pos"
    assert C["dataset"] == dataset
    assert hasattr(C["stream"], "__iter__")
    assert hasattr(C["update"], "__call__")
    assert C["config"]["lang"] == spacy_model.split("_")[0]


def test_sent_teach_can_stream(dataset, nlp):
    """Ensure that the sent.teach recipe can stream examples.
    The teach recipe only selects uncertain cases so there needs to be
    some ambiguity in the example sentences."""
    examples = [{"text": f"{str(i)} Unclear sentences {str(i)}."} for i in range(500)]
    C = teach(dataset, nlp, source=examples)
    batch = []
    cutoff = 2
    for eg in C["stream"]:
        batch.append(eg)
        if len(batch) == cutoff:
            break
    assert len(batch) == cutoff


def test_sent_teach_exits_without_senter(dataset, text_stream, nlp_blank):
    """Ensure that the sent.teach recipe exits when a model is given without senter component"""
    with pytest.raises(RecipeError):
        teach(dataset, nlp_blank, text_stream)


# sent.correct


def test_sent_correct_returns_components(db, dataset, spacy_model, nlp):
    """Ensure that the sent.correct recipe properly returns components"""
    C = correct(dataset, nlp, source=db.get_dataset_examples(dataset))
    assert C["view_id"] == "pos_manual"
    assert C["dataset"] == dataset
    assert hasattr(C["stream"], "__iter__")
    assert C["config"]["lang"] == spacy_model.split("_")[0]


def test_sent_correct_blank_model(dataset, text_stream, nlp_blank):
    """Ensure that the sent.correct recipe works well with a blank model"""
    components = correct(dataset, nlp_blank, text_stream)
    ctrl = Controller.from_components("sent.correct", components)
    queue = list(ctrl.stream)
    eg = queue[0]
    assert "spans" in eg
    ctrl.db.drop_dataset(dataset)
