from pathlib import Path

import pytest

from prodigy.components.loaders import JSONL
from prodigy.core import Controller
from prodigy.errors import RecipeError
from prodigy.recipes.coref import DEFAULT_LABELS, NP_LABEL, manual
from prodigy.util import set_hashes


@pytest.fixture
def dataset():
    return "tmp-test-dataset"


@pytest.fixture
def text_stream():
    data_path = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    tasks = JSONL(data_path)
    return [set_hashes(task) for task in tasks]


# coref.manual #


def test_coref_manual_exits_with_missing_tagger(dataset, text_stream, nlp_blank):
    """Ensure that the coref.manual recipe exits when given a model without tagger"""
    with pytest.raises(RecipeError):
        manual(dataset, nlp_blank, text_stream)


def test_coref_manual_default(dataset, text_stream, nlp):
    """Ensure that the coref.manual recipe uses default NP and NER labels"""
    components = manual(
        dataset,
        nlp,
        text_stream,
    )
    ctrl = Controller.from_components("coref.manual", components)
    labels = ctrl.config["labels"]
    assert labels == DEFAULT_LABELS
    queue = list(ctrl.stream)
    found_ner = 0
    found_np = 0
    enabled = 0
    disabled = 0
    for eg in queue:
        assert "spans" in eg
        for span in eg["spans"]:
            label = span["label"]
            if label == NP_LABEL:
                found_np += 1
            else:
                found_ner += 1
        assert "tokens" in eg
        for token in eg["tokens"]:
            if token["disabled"]:
                disabled += 1
            else:
                enabled += 1
    assert found_ner > 0
    assert found_np > 0
    assert enabled > 0
    assert disabled > 0


def test_coref_manual_custom_labels(dataset, text_stream, nlp):
    """Ensure that the coref.manual recipe registers custom labels"""
    custom_labels = ["COREF_1", "COREF_2"]
    components = manual(dataset, nlp, text_stream, label=custom_labels)
    ctrl = Controller.from_components("coref.manual", components)
    labels = ctrl.config["labels"]
    assert labels == custom_labels
