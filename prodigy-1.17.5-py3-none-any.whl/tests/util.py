import contextlib
import json
import os
import shutil
import tempfile
import warnings
from pathlib import Path
from typing import Any, Dict, Generator, Generic, TypeVar

import srsly
from pytest import FixtureRequest as _FixtureRequest

from prodigy.util import ENV_VARS

T = TypeVar("T")


class FixtureRequest(_FixtureRequest, Generic[T]):
    param: T


@contextlib.contextmanager
def make_tempfile(mode="r"):
    f = tempfile.TemporaryFile(mode=mode)
    yield f
    f.close()


@contextlib.contextmanager
def make_tempdir() -> Generator[Path, None, None]:
    """Execute a block in a temporary directory and remove the directory and
    its contents at the end of the with block.

    YIELDS (Path): The path of the temp directory.
    """
    d = Path(tempfile.mkdtemp())
    yield d
    try:
        shutil.rmtree(str(d))
    except PermissionError:
        warnings.warn(f"Could not remove temp directory {d}")


@contextlib.contextmanager
def env_var_override(env_var_name: str, value: Any) -> Generator:
    os.environ[env_var_name] = value
    yield
    if env_var_name in os.environ:
        del os.environ[env_var_name]


def verbose_logging():
    return env_var_override(ENV_VARS.LOGGING, "verbose")


def config_overrides(overrides: Dict[str, Any]):
    return env_var_override(ENV_VARS.CONFIG_OVERRIDES, json.dumps(overrides))


@contextlib.contextmanager
def replace_config(new_settings: Dict[str, Any]) -> Generator:
    """Like `config_overrides`, but do it by replacing the `prodigy.json` file"""
    with make_tempdir() as dir:
        path = dir / "prodigy.json"
        srsly.write_json(path, new_settings)
        with env_var_override("PRODIGY_CONFIG", str(path)):
            yield new_settings
