import pytest

from prodigy.components.filters import (
    filter_duplicates,
    filter_empty,
    filter_inputs,
    filter_seen_before,
    filter_tasks,
)
from prodigy.components.source import ListSource, load_noop
from prodigy.components.stream import Stream
from prodigy.util import INPUT_HASH_ATTR, TASK_HASH_ATTR, set_hashes


@pytest.fixture
def stream():
    tasks = [
        {"text": ""},
        {"text": False},
        {"meta": {"foo": "bar"}},
        {"text": "foo", "spans": []},
        {"text": "foo", "spans": []},
        {"text": "bar", "spans": []},
    ]
    for i, task in enumerate(tasks):
        task[INPUT_HASH_ATTR] = i
        task[TASK_HASH_ATTR] = i
    return tasks


@pytest.fixture
def filter_stream():
    tasks = [
        {"text": "example 1", "_input_hash": 1, "_task_hash": 1},
        {"text": "example 2", "_input_hash": 2, "_task_hash": 2},
        {"text": "example 3", "_input_hash": 3, "_task_hash": 3},
    ]
    return tasks


def make_new_stream(examples):
    return Stream(source=ListSource(examples), loader=load_noop, wrappers=[])


def ensure_list(stream):
    if isinstance(stream, Stream):
        stream.create_queue("vincent", -1)
        return [eg.data for eg in stream.iter_queue(lambda d: ["vincent"], "vincent")]
    return list(stream)


def test_filter_empty(stream):
    filtered_stream = list(filter_empty(stream, "text"))
    assert len(filtered_stream) == 3
    with pytest.raises(ValueError):
        filtered_stream = list(filter_empty(stream, "text", skip=False))


def test_filter_empty_new_stream(stream):
    filtered_stream = ensure_list(filter_empty(make_new_stream(stream), "text"))
    assert len(filtered_stream) == 3
    with pytest.raises(ValueError):
        ensure_list(filter_empty(make_new_stream(stream), "text", skip=False))


def test_filter_duplicates(stream):
    filtered_stream = list(filter_duplicates(stream + stream, by_input=False))
    assert len(filtered_stream) == len(stream)
    filtered_stream = list(filter_duplicates(stream + stream, by_input=True))
    assert len(filtered_stream) == len(stream)


def test_filter_duplicates_new_stream(stream):
    filtered = filter_duplicates(make_new_stream(stream + stream), by_input=False)
    filtered_stream = ensure_list(filtered)
    assert len(filtered_stream) == len(stream)

    filtered = filter_duplicates(make_new_stream(stream + stream), by_input=True)
    filtered_stream = ensure_list(filtered)
    assert len(filtered_stream) == len(stream)


def test_filter_duplicates_warns_about_many_duplicates():
    stream_dupes = [set_hashes({"text": "same"}) for i in range(5)]
    stream_uniques = [set_hashes({"text": str(i)}) for i in range(1)]
    stream = stream_dupes + stream_uniques
    called = False

    def fake_prints(*texts, **kwargs):
        nonlocal called
        called = True

    filtered_stream = list(
        filter_duplicates(stream, warn_threshold=0.4, warn_fn=fake_prints)
    )
    assert len(filtered_stream) == 2
    assert called is True


def test_filter_funcs_generator_stream(filter_stream):
    out = list(filter_inputs(filter_stream, [1, 2]))
    assert len(out) == 1

    out = list(filter_tasks(filter_stream, [1, 2]))
    assert len(out) == 1


def test_filter_funcs_new_stream(filter_stream):
    out = ensure_list(filter_inputs(make_new_stream(filter_stream), [1, 2]))
    assert len(out) == 1

    out = ensure_list(filter_tasks(make_new_stream(filter_stream), [1, 2]))
    assert len(out) == 1


def test_filter_seen_before():
    stream_a = [
        {"text": "example 1", "_input_hash": 1, "_task_hash": 1},
        {"text": "example 2", "_input_hash": 2, "_task_hash": 2},
        {"text": "example 3", "_input_hash": 3, "_task_hash": 3},
    ]
    stream_b = [
        {"text": "example 2", "_input_hash": 4, "_task_hash": 2},
        {"text": "example 3", "_input_hash": 3, "_task_hash": 4},
    ]
    input_result = filter_seen_before(stream_a, stream_b, exclude_by="input")
    task_result = filter_seen_before(stream_a, stream_b, exclude_by="task")

    input_res_hashes = set([_["_input_hash"] for _ in input_result])
    task_res_hashes = set([_["_task_hash"] for _ in task_result])

    assert input_res_hashes == set([1, 2])
    assert task_res_hashes == set([1, 3])
