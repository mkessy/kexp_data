import concurrent.futures
import datetime
import json
import os
import subprocess
import time
from collections import defaultdict
from pathlib import Path
from typing import Callable, Dict, List, Optional

import httpx
import jwt
import psutil
import pytest
import typer
from httpx import BasicAuth, Client

from prodigy.components.db import Database
from prodigy.components.stream import get_stream
from prodigy.types import TaskType
from prodigy.util import ENV_VARS, INPUT_HASH_ATTR, TASK_HASH_ATTR, msg

from ..util import FixtureRequest

auth = BasicAuth(username="test-user", password="lame-test-password")

TEST_SECRET = "testing-secret-secure-like-an-open-door"
TEST_AUDIENCE = "http://test-audience.localhost"
TEST_BASIC_AUTH_USER = "test-user"
TEST_BASIC_AUTH_PASS = "lame-test-password"

HASH_ONE = 13
HASH_TWO = 67

MAX_THREADS = 4
CONCURRENT_THREADS = 3


def encode_token(expire_seconds: int = 600, secret: str = TEST_SECRET):
    payload = {
        "exp": datetime.datetime.utcnow() + datetime.timedelta(seconds=expire_seconds),
        "aud": TEST_AUDIENCE,
        "iss": TEST_AUDIENCE,
    }
    return jwt.encode(payload, secret)


def make_headers(token: str):
    return {"Authorization": "Bearer {}".format(token)}


def token_headers():
    return make_headers(encode_token())


@pytest.fixture()
def dataset_name() -> str:
    return "concurrency_dataset"


@pytest.fixture()
def source_path(datasets_path: Path) -> Path:
    # make sure this file does not have duplicates
    path = datasets_path / "input_2000.jsonl"
    return path


@pytest.fixture()
def source_examples(source_path: Path) -> List[TaskType]:
    return _get_source_examples(source_path)


def _get_source_examples(source_path: Path) -> List[TaskType]:
    source = list(get_stream(source_path, rehash=True, dedup=True, input_key="text"))
    return source


@pytest.fixture(params=[1, 10, 30])
def batch_size(request: FixtureRequest[int]) -> int:
    return request.param


@pytest.fixture()
def num_allowed_duplicates(batch_size: int) -> int:
    # maps batch size (key) to expected number of duplicates in DB due to work stealing (value)
    return batch_size * 3
    # return {1: 10, 5: 30, 10: 50, 30: 100}


@pytest.fixture(params=[True, False], ids=["overlap", "no_overlap"])
def feed_overlap(request: FixtureRequest[bool]) -> bool:
    return request.param


@pytest.fixture
def config(database: Database, batch_size: int, feed_overlap: bool):
    config_overrides = json.loads(os.getenv(ENV_VARS.CONFIG_OVERRIDES, "{}"))
    config_overrides["db"] = database.db_id
    config_overrides["batch_size"] = batch_size
    config_overrides["feed_overlap"] = feed_overlap
    return config_overrides


@pytest.fixture(scope="session")
def find_free_port():
    """
    Source: https://gist.github.com/bertjwregeer/0be94ced48383a42e70c3d9fff1f4ad0

    Returns a factory that finds the next free port that is available on the OS
    This is a bit of a hack, it does this by creating a new socket, and calling
    bind with the 0 port. The operating system will assign a brand new port,
    which we can find out using getsockname(). Once we have the new port
    information we close the socket thereby returning it to the free pool.
    This means it is technically possible for this function to return the same
    port twice (for example if run in very quick succession), however operating
    systems return a random port number in the default range (1024 - 65535),
    and it is highly unlikely for two processes to get the same port number.
    In other words, it is possible to flake, but incredibly unlikely.
    """

    def _find_free_port():
        import socket

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", 0))
        portnum = s.getsockname()[1]
        s.close()

        return portnum

    return _find_free_port


@pytest.fixture(scope="function")
def prodigy_port(find_free_port: Callable[[], int]) -> int:
    return find_free_port()


def healthcheck(base_url: str, max_attempts: int = 10, interval_s: int = 0.5):
    with Client(auth=auth, base_url=base_url) as client:
        for _ in range(max_attempts):
            time.sleep(interval_s)
            try:
                response = client.post("/health")
            except httpx.ConnectError:
                continue
            if response.status_code == 200:
                return True
    return False


def kill(proc_pid: int) -> None:
    """Kill a process and all its children by its pid"""
    process = psutil.Process(proc_pid)
    for proc in process.children(recursive=True):
        proc.kill()
    process.kill()


@pytest.fixture(scope="function")
def prodigy_server(
    config: dict, dataset_name: str, source_path: Path, prodigy_port: int
):
    prodigy_proc = subprocess.Popen(
        [
            "PRODIGY_PORT={} PRODIGY_CONFIG_OVERRIDES='{}' python -m prodigy ner.manual {} blank:en {} -l PERSON".format(
                prodigy_port, json.dumps(config), dataset_name, source_path
            )
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        shell=True,
    )
    # Give the server time to start
    healthcheck(f"http://localhost:{prodigy_port}")

    assert not prodigy_proc.poll(), prodigy_proc.stdout.read()
    yield prodigy_proc
    kill(prodigy_proc.pid)


def hashes(tasks, by=TASK_HASH_ATTR):
    return [eg[by] for eg in tasks]


headers = dict(token_headers(), **{"Content-Type": "application/json"})


def get_questions(
    base_url: str, session_id: Optional[str] = None, excludes: List[str] = None
):
    body = dict(session_id=session_id, excludes=excludes)
    with Client(auth=auth, base_url=base_url, timeout=httpx.Timeout(15)) as client:
        response = client.post("/get_session_questions", json=body, headers=headers)
    assert response.status_code == 200, response.text
    return response.json()["tasks"]


def give_answers(
    base_url: str, answers: List[TaskType], session_id: Optional[str] = None
):
    body = dict(answers=answers, session_id=session_id)
    with Client(auth=auth, base_url=base_url, timeout=httpx.Timeout(15)) as client:
        response = client.post("/give_answers", json=body, headers=headers)

    assert response.status_code == 200, response.text
    return response.json()["progress"]


def save_and_refresh(
    base_url: str, answers: List[TaskType], session_id: Optional[str] = None
):
    give_answers(base_url, answers, session_id)
    return get_questions(base_url, session_id)


def execute_simple_session(base_url: str, session_id: Optional[str], batch_size: int):
    queue = get_questions(base_url, session_id)
    outbox = []
    answers = []
    history = []
    history_map = {}
    i = 0
    while queue:
        i += 1
        if i == 50:
            answers = outbox
            outbox = []
            give_answers(base_url, answers, session_id)
        # simulate session three doing less work that other sessions (slows down the test)
        if i == 2000 and session_id == "three":
            time.sleep(3)
        if len(queue) > 0:
            q = queue.pop(0)
            history.append(q)
            if q[INPUT_HASH_ATTR] in history_map:
                print("Duplicate Task Found:", q)  # noqa: T201
                print("Index of Duplicate:", i)  # noqa: T201
                print("Session ID of Duplicate:", session_id)  # noqa: T201
            history_map[q[INPUT_HASH_ATTR]] = q

            answer = {**q, "answer": "accept", "label": "TEST_LABEL"}
            outbox.append(answer)
            if len(outbox) >= batch_size:
                answers = outbox
                outbox = []
                give_answers(base_url, answers, session_id)
            if len(queue) < 2 or len(queue) < (batch_size / 2):
                # if queue runs short, get new tasks
                excludes = hashes(outbox) + hashes(answers) + hashes(queue)
                queue += get_questions(base_url, session_id, excludes=excludes)
    answers = outbox
    outbox = []
    give_answers(base_url, answers, session_id)
    # Assert there are no duplicates within the session
    task_hashes = hashes(history, INPUT_HASH_ATTR)
    assert len(task_hashes) == len(set(task_hashes))
    return history, session_id


def execute_save_refresh_session(
    base_url: str, session_id: Optional[str], batch_size: int
):
    queue = get_questions(base_url, session_id)
    outbox = []
    answers = []
    history = []
    history_map = {}
    i = 0
    while queue:
        i += 1
        if i == 50:
            answers = outbox
            outbox = []
            give_answers(base_url, answers, session_id)
        if i > 500 and i % 3 == 0:
            answers = outbox
            outbox = []
            queue = save_and_refresh(base_url, answers, session_id)
        # simulate session three doing less work that other sessions (slows down the test)
        if i == 2000 and session_id == "three":
            time.sleep(3)
        if len(queue) > 0:
            q = queue.pop(0)
            history.append(q)
            if q[INPUT_HASH_ATTR] in history_map:
                print("Duplicate Task Found:", q)  # noqa: T201
                print("Index of Duplicate:", i)  # noqa: T201
                print("Session ID of Duplicate:", session_id)  # noqa: T201
            history_map[q[INPUT_HASH_ATTR]] = q

            answer = {**q, "answer": "accept", "label": "TEST_LABEL"}
            outbox.append(answer)
            if len(outbox) >= batch_size:
                answers = outbox
                outbox = []
                give_answers(base_url, answers, session_id)
            if len(queue) < 2 or len(queue) < (batch_size / 2):
                # if queue runs short, get new tasks
                excludes = hashes(outbox) + hashes(answers) + hashes(queue)
                queue += get_questions(base_url, session_id, excludes=excludes)

    # Send the final answers back to simulate a save when the queue is gone
    # and no more tasks are available.
    answers = outbox
    outbox = []
    give_answers(base_url, answers, session_id)
    # Assert there are no duplicates within the session.
    history_hashes = hashes(history, INPUT_HASH_ATTR)
    assert len(history_hashes) == len(set(history_hashes))
    return history, session_id


# TODO session with refresh and without saving?


@pytest.mark.slow()
@pytest.mark.parametrize(
    "flow",
    [execute_simple_session, execute_save_refresh_session],
    ids=["simple", "save_refresh"],
)
def test_concurrent_annotation_flow(
    prodigy_server,
    flow: Callable,
    config: Dict,
    dataset_name: str,
    database: Database,
    source_examples: List,
    num_allowed_duplicates: int,
    prodigy_port: int,
):
    """
    Simulate a multiple annotator workflow annotating a full source continuously.
    Tests that each example is annotated by each annotator in the case overlap and
    that each example is annotated only once in case of no overlap.
    """
    base_url = f"http://localhost:{prodigy_port}"
    batch_size = config["batch_size"]
    feed_overlap = config["feed_overlap"]
    session_ids = ["one", "two", "three", "four"]
    _run_parallel_test(
        flow=flow,
        base_url=base_url,
        source_examples=source_examples,
        database=database,
        dataset=dataset_name,
        batch_size=batch_size,
        num_allowed_duplicates=num_allowed_duplicates,
        feed_overlap=feed_overlap,
        session_ids=session_ids,
    )


def _run_parallel_test(
    flow: Callable,
    base_url: str,
    dataset: str,
    source_examples: List[TaskType],
    batch_size: int,
    num_allowed_duplicates: int,
    feed_overlap: bool,
    database: Optional[Database] = None,
    session_ids: List[str] = ["one", "two", "three", "four"],
    n_processes: int = MAX_THREADS,
):
    """Run the body of the parallel test against a URL. Can be used to run against
    a remote server or the local prodigy_server test fixture"""

    # Prefix session_ids with the dataset name to mirror the UI's behavior
    for i in range(len(session_ids)):
        session_id = session_ids[i]
        if not session_id.startswith(dataset):
            session_ids[i] = f"{dataset}-{session_id}"

    full_history = []
    with concurrent.futures.ProcessPoolExecutor(n_processes) as executor:
        futures = [
            executor.submit(flow, base_url, session_id, batch_size)
            for session_id in session_ids
        ]
        for future in concurrent.futures.as_completed(futures):
            history, session_id = future.result()
            full_history.extend(history)

    if database is not None:
        saved_examples = database.get_dataset_examples(dataset)
        saved_examples_hashes = hashes(saved_examples)
        if feed_overlap:
            # Assert each example was annotatated at least once by each annotator
            history_by_session = defaultdict(list)
            for eg in saved_examples:
                history_by_session[eg.get("_session_id")].append(eg.get("_task_hash"))
            all_sessions = [
                set(history_by_session.get(session_id)) for session_id in session_ids
            ]
            # compare all sessions to each other and to input stream
            all_sessions.append(set(hashes(source_examples)))
            assert len(set.difference(*all_sessions)) == 0

        else:
            # Currently, due to work stealing there might be some duplicates towards the end of the stream.
            # Assert all examples were annotated at least once.

            saved_nums = set(sorted([int(e["text"]) for e in saved_examples]))
            source_nums = set(sorted([int(e["text"]) for e in source_examples]))
            nums_diff = source_nums.difference(saved_nums)
            if nums_diff:
                print("Nums in source but not saved to DB: ", nums_diff)  # noqa: T201

            assert set(saved_examples_hashes).issuperset(set(hashes(source_examples)))
            seen = set()
            duplicates = [
                int(eg.get("text"))
                for eg in saved_examples
                if eg.get("_task_hash") in seen or seen.add(eg.get("_task_hash"))
            ]
            # Assert that the number of duplicates is not greater than expected.
            assert len(duplicates) <= num_allowed_duplicates, f"{sorted(duplicates)}"
            if duplicates:
                # Assert that the number of duplicates appear only in the last 30% of the stream
                assert all(dup > len(source_examples) * 0.3 for dup in duplicates)


def run_parallel_test(
    base_url: str = typer.Option(..., help="Base URL for server"),
    dataset: str = typer.Option(
        ...,
        help="Name of dataset the server was started with to prefix session IDs with",
    ),
    source_path: Path = typer.Option(..., help="Path to file with source examples"),
    batch_size: int = typer.Option(
        default=10, help="Prodigy Server Batch Size setting"
    ),
    feed_overlap: bool = typer.Option(
        default=False, help="Prodigy Server Feed Overlap setting"
    ),
    refresh_flow: bool = typer.Option(
        default=True, help="Run simple flow, or refresh flow"
    ),
    n_processes: int = typer.Option(
        MAX_THREADS, "-n", help="Number of parallel sessions to run test with"
    ),
):
    msg.info(f"Starting Parallel Multi-annotator Test against Server: {base_url}")
    basic_auth_user = os.getenv("PRODIGY_BASIC_AUTH_USER")
    basic_auth_pass = os.getenv("PRODIGY_BASIC_AUTH_PASS")

    if basic_auth_user and basic_auth_pass:
        global auth
        auth = BasicAuth(username=basic_auth_user, password=basic_auth_pass)
        msg.good("Configured Global BasicAuth creds from ENV VARS")

    flow = execute_save_refresh_session if refresh_flow else execute_simple_session
    source = _get_source_examples(source_path)
    n_allowed_duplicates = num_allowed_duplicates(batch_size)

    with msg.loading("Starting test..."):
        _run_parallel_test(
            flow=flow,
            dataset=dataset,
            base_url=base_url,
            source_examples=source,
            batch_size=batch_size,
            num_allowed_duplicates=n_allowed_duplicates,
            feed_overlap=feed_overlap,
            database=None,
            n_processes=n_processes,
        )
        msg.good("Done.")


if __name__ == "__main__":
    typer.run(run_parallel_test)
