"""Integration test to check if the weights from the tok2vec base model carries over"""
import numpy
import pytest
import spacy
import srsly
from spacy.training.initialize import init_nlp
from spacy.util import load_model_from_config

from prodigy.recipes.train import prodigy_config

DATASETS = [
    ("spancat", "spancat-examples", "annotated-spans.jsonl"),
    ("ner", "spancat-examples", "annotated-spans.jsonl"),  # use same data
    ("textcat", "textcat-excl-examples", "annotated-textcat-excl.jsonl"),
    ("textcat_multilabel", "textcat-examples", "annotated-textcat.jsonl"),
]


@pytest.mark.parametrize("nlp", [None, "spacy_model", "spacy_model_md"])  # use fixtures
@pytest.mark.parametrize("component,dataset,filepath", DATASETS)
def test_generate_config_returns_valid(
    nlp, component, dataset, filepath, request, sqlite, datasets_path
):
    """Test to ensure that config parsing produces a valid config."""
    # get fixture value (cf. conftest.py)
    base_model = request.getfixturevalue(nlp) if nlp else None

    sqlite.add_dataset(name=dataset)
    examples = list(srsly.read_jsonl(datasets_path / filepath))
    sqlite.add_examples(examples=examples, datasets=[dataset])

    config = prodigy_config(None, base_model=base_model, **{component: dataset})
    load_model_from_config(config, validate=True, auto_fill=False)


@pytest.mark.parametrize("base_nlp", ["spacy_model", "spacy_model_md"])  # use fixtures
@pytest.mark.parametrize("text", ["There is a there there", "Some random text"])
@pytest.mark.parametrize("component,dataset,filepath", DATASETS)
def test_tok2vec_weights_is_same(
    request, base_nlp, text, component, dataset, filepath, sqlite, datasets_path
):
    """Ensure that the tok2vec weights from the base model are carried over"""
    # Get fixture value (cf. conftest.py) and obtain its tok2vec component
    # and run it on a random input to see its output vectors
    base_model = request.getfixturevalue(base_nlp)
    nlp_orig = spacy.load(base_model)
    vector_orig = nlp_orig.make_doc(text).vector

    # Create a new config file new_config by calling this generate_config
    # function and mimicking its usage as if we're calling train with
    # --base-model, with let's say --spancat
    sqlite.add_dataset(name=dataset)
    examples = list(srsly.read_jsonl(datasets_path / filepath))
    sqlite.add_examples(examples=examples, datasets=[dataset])

    train_config = prodigy_config(
        None,
        config=None,
        verbose=True,
        silent=False,
        base_model=base_model,
        **{component: dataset},
    )

    # Now obtain the tok2vec model from the new nlp object. Run this
    # tok2vec model on the same input as the second step.
    nlp_new = init_nlp(train_config)
    vector_new = nlp_new.make_doc(text).vector

    # The vectors should be the same (only then can we be certain that sourcing
    # has worked correctly). They should exactly be the same but we want
    # to add some tolerance
    assert numpy.allclose(vector_orig, vector_new, rtol=0.001)
