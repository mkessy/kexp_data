import pytest

from prodigy.components.session import Session
from prodigy.components.source import ListSource, load_noop
from prodigy.components.stream import Stream
from prodigy.util import INPUT_HASH_ATTR, TASK_HASH_ATTR, set_hashes


@pytest.fixture
def non_unique_examples():
    examples = [{"text": str(i), "label": "a"} for i in range(10)]
    examples = list(sorted(examples * 2, key=lambda d: d["text"]))
    return examples


@pytest.fixture
def base_stream():
    examples = [{"text": str(i).zfill(3), "label": "a"} for i in range(100)]

    return Stream(
        source=ListSource(examples),
        loader=load_noop,
        wrappers=[lambda d: (set_hashes(ex) for ex in d)],
    )


def test_receive_deduplicated_examples(non_unique_examples):
    """Make sure hash keys are set."""
    # Generate a stream with hashes on the examples
    stream = Stream(
        source=ListSource(non_unique_examples),
        loader=load_noop,
        wrappers=[lambda d: (set_hashes(ex) for ex in d)],
    )
    stream.create_queue("vincent", n_history=10)

    # Start the session
    session = Session(
        session_id="vincent",
        stream=stream,
        batch_size=10,
    )

    # Each item in results should have unique data
    results = session.get_questions(
        10,
        task_router=lambda d: ["vincent"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
    )
    assert len({r.data[TASK_HASH_ATTR] for r in results}) == 10
    assert len({r.data[INPUT_HASH_ATTR] for r in results}) == 10


def test_exclude_mechanic(non_unique_examples):
    """Confirm that `exclude` actually excludes."""
    stream = Stream(
        source=ListSource(non_unique_examples),
        loader=load_noop,
        wrappers=[lambda d: (set_hashes(ex) for ex in d)],
    )
    stream.create_queue("vincent", n_history=10)

    excl_hashes = [set_hashes(ex)[TASK_HASH_ATTR] for ex in non_unique_examples[:10]]

    session = Session(
        session_id="vincent",
        stream=stream,
        batch_size=10,
    )
    results = session.get_questions(
        10,
        task_router=lambda d: ["vincent"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(excl_hashes),
    )

    for res in results:
        assert res.key not in excl_hashes


@pytest.mark.parametrize("i", [1, 2, 3, 4])
def test_skip_received_answers(non_unique_examples, i):
    """You should not see answers that have been received."""
    stream = Stream(
        source=ListSource(non_unique_examples),
        loader=load_noop,
        wrappers=[lambda d: (set_hashes(ex) for ex in d)],
    )
    stream.create_queue("vincent", n_history=10)

    # Start the session
    session = Session(
        session_id="vincent",
        stream=stream,
        batch_size=10,
    )

    # We will prepare some answers to send back.
    received_answers = [set_hashes(ex) for ex in non_unique_examples[:i]]
    received_keys = [ex[TASK_HASH_ATTR] for ex in received_answers]
    session.receive_answers(received_answers, keys=received_keys, progress=0.1)

    # We should not see these received answers when we get questions
    results = session.get_questions(
        10,
        task_router=lambda d: ["vincent"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
    )
    for result in results:
        assert result.data[TASK_HASH_ATTR] not in received_keys


def test_basic_work_stealing(base_stream: Stream):
    """Demonstrate that basic work stealing works."""
    base_stream.create_queue("vincent", n_history=10)
    base_stream.create_queue("sok", n_history=10)

    # Start the sessions
    session_vin = Session(
        session_id="vincent",
        stream=base_stream,
        batch_size=10,
    )

    session_sok = Session(
        session_id="sok",
        stream=base_stream,
        batch_size=10,
    )

    # Vincent is able to fetch data
    results_vin = session_vin.get_questions(
        10,
        task_router=lambda d: ["vincent"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
    )
    # Even though the router does not supply data, it can be stolen from other sessions
    results_sok = session_sok.get_questions(
        10,
        task_router=lambda d: ["vincent"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
        other_sessions=[session_vin],
    )

    assert len(results_vin) == 10
    assert len(results_sok) == 1  # only able to steal 1 task at a time
    assert results_vin[0] == results_sok[0]


def test_basic_work_stealing_with_answering(non_unique_examples):
    """Same as previous test but now the user answers before work can be stolen."""
    stream = Stream(
        source=ListSource(non_unique_examples),
        loader=load_noop,
        wrappers=[lambda d: (set_hashes(ex) for ex in d)],
    )
    stream.create_queue("vincent", n_history=10)
    stream.create_queue("sok", n_history=10)

    # Start the sessions
    session_vin = Session(
        session_id="vincent",
        stream=stream,
        batch_size=10,
    )

    session_sok = Session(
        session_id="sok",
        stream=stream,
        batch_size=10,
    )

    # Vincent is able to fetch data
    results_vin = session_vin.get_questions(
        4,
        task_router=lambda d: ["vincent"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
    )
    session_vin.receive_answers(
        results_vin, keys=[e.key for e in results_vin], progress=0.1
    )

    # Because the answers have been given, Sok cannot steal these
    results_sok = session_sok.get_questions(
        4,
        task_router=lambda d: ["vincent"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
        other_sessions=[session_vin],
    )

    assert len(results_sok) == 0

    # But when Vincent gets more questions without answering
    results_vin = session_vin.get_questions(
        4,
        task_router=lambda d: ["vincent"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
    )

    # Then Sok is able to steal work.
    results_sok = session_sok.get_questions(
        4,
        task_router=lambda d: ["vincent"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
        other_sessions=[session_vin],
    )

    assert len(results_vin) == 4
    assert len(results_sok) == 1  # only able to steal 1 task at a time


def test_basic_work_stealing_causes_no_duplicates(base_stream):
    """This test was added after spotting a scenario where duplicates would appear."""
    base_stream.create_queue("vincent", n_history=10)
    base_stream.create_queue("noa", n_history=10)
    base_stream.create_queue("sok", n_history=10)

    # Start the sessions
    session_vin = Session(
        session_id="vincent",
        stream=base_stream,
        batch_size=10,
    )

    session_noa = Session(
        session_id="noa",
        stream=base_stream,
        batch_size=10,
    )

    session_sok = Session(
        session_id="sok",
        stream=base_stream,
        batch_size=10,
    )

    # The item that Vincent receives
    session_vin.get_questions(
        1,
        task_router=lambda d: ["vincent", "noa"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
    )
    # Is the same item that Noa receives
    session_noa.get_questions(
        1,
        task_router=lambda d: ["vincent", "noa"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
    )
    # That means that Sok can only steal one item
    results_sok = session_sok.get_questions(
        2,
        task_router=lambda d: ["vincent", "noa"],
        exclude_input_hashes=set(),
        exclude_task_hashes=set(),
        other_sessions=[session_vin, session_noa],
    )

    assert len(results_sok) == 1
