import pytest
import spacy
from confection import Config

from prodigy.recipes.train import generate_config


@pytest.mark.parametrize(
    "active_components, base_name, expected_cfg, spacy_default_cfg",
    [
        (
            ["ner"],
            "blank:en",
            "ner_blank.cfg",
            "ner_tok2vec_default.cfg",
        ),  # training from scratch
        (
            ["textcat_multilabel"],
            "blank:en",
            "textcat_blank.cfg",
            "textcat_default.cfg",
        ),  # training textcat from scratch
        (
            ["parser", "ner"],
            "en_core_web_sm",
            "parser_ner_en_core_web_sm.cfg",
            "parser_ner_tok2vec_default.cfg",
        ),  # updating trained pipeline
        (
            ["tagger", "ner"],
            "en_core_web_trf",
            "tagger_ner_en_core_web_trf.cfg",
            "tagger_ner_trf_default.cfg",
        ),  # training from pre-trained trf pipeline, parser frozen and with replaced listener
    ],
)
def test_generate_config(
    active_components,
    base_name,
    expected_cfg,
    spacy_default_cfg,
    config_path,
    nlp_blank,
    nlp_fresh,
    nlp_trf,
):
    if base_name == "blank:en":
        base_model = spacy.blank("en")
    elif base_name == "en_core_web_sm":
        base_model = nlp_fresh
    elif base_name == "en_core_web_trf":
        base_model = nlp_trf
    else:
        raise ValueError(f"base_name {base_name} not supported")
    default_config = Config().from_disk(path=config_path / spacy_default_cfg)
    expected_config = Config().from_disk(path=config_path / expected_cfg)
    cfg = generate_config(
        config=default_config,
        base_nlp=base_model,
        base_name=base_name,
        pipes=active_components,
    )
    assert cfg["nlp"] == expected_config["nlp"]
    assert cfg["components"] == expected_config["components"]
    assert (
        cfg["training"]["frozen_components"]
        == expected_config["training"]["frozen_components"]
    )
    assert cfg["initialize"] == expected_config["initialize"]
