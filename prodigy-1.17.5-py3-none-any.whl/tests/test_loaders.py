import shutil

import pytest

from prodigy.components.loaders import CSV, get_stream
from prodigy.errors import RecipeError

from .util import make_tempdir


def test_get_stream_from_filepath_jsonl(datasets_path):
    dataset_input = datasets_path / "nyt_text_14.jsonl"
    stream = get_stream(dataset_input)
    assert len(list(stream)) == 14


def test_get_stream_from_dirpath(datasets_path):
    files = ["nyt_text_14.jsonl", "movies_sample.jsonl"]  # 14 + 3
    with make_tempdir() as dest:
        for file_name in files:
            shutil.copyfile(str(datasets_path / file_name), str(dest / file_name))
        stream = list(get_stream(dest, loader="jsonl"))
    assert len(list(stream)) == 17


def test_get_stream_from_filepath_no_loader_found():
    dataset_input = "non_existent.jsonll"
    with pytest.raises(RecipeError) as error:
        _ = get_stream(dataset_input)
        assert error == "No loader found for 'jsonll'"


def test_get_stream_from_filepath_loader(tmp_path):
    filepath = tmp_path / "temp_file"
    filepath.write_text("Example One\nExample Two\nExample Three")
    stream = get_stream(filepath, loader="txt")
    assert len(list(stream)) == 3
    filepath.unlink()


@pytest.mark.parametrize("delimiter", [None, ";"])
def test_get_stream_from_filepath_loader_manual(tmp_path, delimiter):
    filepath = tmp_path / "temp_file"
    if delimiter is not None:
        filepath.write_text(
            "Text;Label;Meta\nThis is a sentence.;POSITIVE;0\nThis is another sentence.;NEGATIVE;0.1"
        )
        csv_stream = CSV(filepath, delimiter=delimiter)
    else:
        filepath.write_text(
            "Text,Label,Meta\nThis is a sentence.,POSITIVE,0\nThis is another sentence.,NEGATIVE,0.1"
        )
        csv_stream = CSV(filepath)
    assert len(list(csv_stream)) == 2


def test_get_stream_from_iterator():
    eg_iter = (f"Example {n}" for n in range(3))
    stream = get_stream(eg_iter)
    assert len(list(stream)) == 3


def test_get_stream_from_db_dataset(database, stream):
    database.add_dataset("test_dataset")
    database.add_examples(stream, ["test_dataset"])
    stream = get_stream("dataset:test_dataset")
    assert len(list(stream)) == 1
