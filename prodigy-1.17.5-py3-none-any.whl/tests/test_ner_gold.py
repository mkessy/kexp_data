import pytest
from spacy.tokens import Doc
from spacy.vocab import Vocab

from prodigy.models.ner import _score_ents
from prodigy.util import is_neg_label, neg_to_pos_label


@pytest.fixture
def nlp():
    en_core_web_sm = pytest.importorskip("en_core_web_sm")
    return en_core_web_sm.load()


@pytest.fixture
def vocab():
    return Vocab()


@pytest.fixture
def words():
    return ["Australia", "lost", "the", "Ashes", "."]


@pytest.fixture
def doc(vocab, words):
    return Doc(vocab, words=words)


@pytest.fixture
def guess_ents(doc):
    aus = doc[:1]
    ashes = doc[3:4]
    return [
        (aus.start_char, aus.end_char, "GPE"),
        (ashes.start_char, ashes.end_char, "PERSON"),
    ]


@pytest.fixture
def true_ents(doc):
    aus = doc[:1]
    ashes = doc[3:4]
    return [
        (aus.start_char, aus.end_char, "GPE"),
        (ashes.start_char, ashes.end_char, "!PERSON"),
    ]


# def test_answers_to_gold(nlp, true_ents):
#    text = u'Australia lost the Ashes.'
#    doc, gold = list(_ner_answers2golds(nlp, [text], [true_ents]))[0]
#    assert gold.ner[0] == 'U-GPE'
#    assert gold.ner[-1] == 'O'
#    assert gold.ner[-2] != 'U-PERSON'
#


@pytest.mark.parametrize(
    "guess_labels,true_labels,right,wrong,unk",
    [
        (("GPE", "PERSON"), ("GPE", "!PERSON"), 1, 1, 0),
        (("GPE",), ("GPE", "!PERSON"), 1, 0, 0),
        (("GPE",), ("GPE", "EVENT"), 1, 1, 0),
        (("GPE", "EVENT"), ("GPE", "!PERSON"), 1, 0, 1),
        (("GPE", "EVENT"), ("GPE", "EVENT"), 2, 0, 0),
    ],
)
def test_score_with_isnt(doc, guess_labels, true_labels, right, wrong, unk):
    spans = [doc[0:1], doc[3:4]]
    if len(true_labels) >= len(spans):
        spans.append(doc[3:4])
    guess_ents = [
        (s.start_char, s.end_char, label) for s, label in zip(spans, guess_labels)
    ]
    true_ents = [
        (s.start_char, s.end_char, label)
        for s, label in zip(spans, true_labels)
        if not is_neg_label(label)
    ]
    false_ents = [
        (s.start_char, s.end_char, neg_to_pos_label(label))
        for s, label in zip(spans, true_labels)
        if is_neg_label(label)
    ]

    assert _score_ents(doc, guess_ents, true_ents, false_ents) == (right, wrong, unk)


#
# @pytest.mark.parametrize('text', ['Australia lost the Ashes.'])
# def test_get_beam_entities(nlp, text):
#    doc, cands = get_beam_entities(nlp, text)
#    for score, ents in cands:
#        for start_char, end_char, label in ents:
#            assert isinstance(start_char, int)
#            assert isinstance(end_char, int)
#            assert isinstance(label, str)
#
# TODO: Format these tests
# Guess
# Gold
# Right, wrong, unk
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', 'U-O', '-', '-', '-']
# 1.0 0.0 4.0
# ['B-PERSON', 'I-PERSON', 'L-PERSON', 'U-O', 'B-PERSON', 'L-PERSON', 'U-O', 'B-PERSON', 'L-PERSON']
# ['-', 'U-!O', '-', '-', '-', '-', '-', '-', '-']
# 0.0 0.0 9.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-ORG', 'U-O', 'U-PERSON', 'U-O', 'U-O', 'U-O']
# ['-', '-', 'U-O', '-', '-', '-', '-', '-', '-', '-', '-', '-']
# 1.0 0.0 11.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', '-', '-', '-', '-', '-', '-', '-', '-', '-']
# 0.0 0.0 10.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', '-', '-', '-', '-', '-', '-', '-', 'U-O', '-', '-', '-']
# 1.0 0.0 11.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', '-', '-', '-', '-', '-', '-']
# 0.0 0.0 7.0
# ['U-O', 'U-O', 'U-PERSON', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-']
# 0.0 0.0 11.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-ORG', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', '-', '-', '-', '-', '-', '-', '-', '-', 'U-!O', '-', '-', '-', '-', '-', '-', '-', '-']
# 0.0 0.0 18.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', 'U-O', '-', '-', '-', '-']
# 1.0 0.0 5.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', '-', '-', '-', '-', '-', '-', '-', 'U-!CARDINAL', '-', '-', '-', '-', '-', '-', '-', '-']
# 0.0 0.0 17.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'B-PERSON', 'I-PERSON', 'L-PERSON', 'U-O', 'U-O', 'B-ORG', 'I-ORG', 'L-ORG', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'U-O', '-', '-', '-', '-', '-', '-', '-', '-', '-']
# 0.0 1.0 19.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'B-ORG', 'L-ORG', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-']
# 0.0 0.0 18.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-ORG', 'U-O']
# ['-', '-', '-', '-', '-', '-', '-']
# 0.0 0.0 7.0
# ['U-O', 'U-O', 'U-O', 'U-O', 'U-CARDINAL', 'U-O', 'U-O', 'U-PERSON', 'U-O', 'B-DATE', 'I-DATE', 'L-DATE', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O', 'U-O']
# ['-', '-', '-',
