import copy
from typing import (
    Any,
    Dict,
    Iterator,
    List,
    NamedTuple,
    Optional,
    Set,
    Type,
    Union,
)
from typing_extensions import Literal, TypeVar

import pydantic
import pytest
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel

from prodigy.components.db import Database
from prodigy.components.validate import ValidationErrorMsg
from prodigy.structured_types import (
    AudiocatExample,
    AudioInput,
    AudioSpansAnns,
    AudioSpansExample,
    AudioTranscribeExample,
    AudioTranscribeServerAnns,
    AudioTranscribeUserAnns,
    BoundingBoxAnns,
    ChoiceUserAnns,
    ClassificationAnns,
    ConflictingKeysError,
    DepAnns,
    DepExample,
    Example,
    HTMLcatExample,
    HTMLInput,
    ImagecatExample,
    ImageExample,
    ImageInput,
    MissingAnswerError,
    RelationsAnns,
    RelationsExample,
    SpansAnns,
    SpansExample,
    SpansManualAnns,
    SpansManualExample,
    StructuredExampleError,
    TextcatChoiceExample,
    TextcatChoiceServerAnns,
    TextcatExample,
    TextcatServerAnns,
    TextInput,
    ValidationError,
    _is_mapping,
    prodigy_example_type,
)
from prodigy.types import (
    AudioSpan,
    ChoiceOption,
    ImageSpan,
    Relation,
    TextManualSpan,
    TextSpan,
    Token,
)
from prodigy.util import INPUT_HASH_ATTR, TASK_HASH_ATTR

_ExampleT = TypeVar("_ExampleT", bound=Example)


class TextInputTest(BaseModel):
    text: str


class SpansAnnotationsTest(BaseModel):
    spans: List[TextSpan]


@prodigy_example_type("tests.prodigy.SpansExample.v1")
class SpansExampleTest(Example):
    input: TextInputTest
    user_anns: Optional[SpansAnnotationsTest]
    server_anns: Optional[SpansAnnotationsTest]


@pytest.mark.parametrize(
    "value, type_, has_error",
    [
        ("foo", str, False),
        ("foo", int, True),
        ("", str, False),
        ("", int, True),
        ("0", str, False),
        ("0", int, True),
        ("", type(None), True),
        ("None", type(None), True),
        (None, type(None), False),
    ],
)
def test_validate_type_simple(value: Any, type_: Type, has_error: bool) -> None:
    maybe_error = ValidationError.check_type(value, type_, key="simple")
    if has_error:
        assert maybe_error is not None
    else:
        assert maybe_error is None


@pytest.mark.parametrize(
    "value, type_, has_error",
    [
        ("foo", Union[str, int], False),
        ("foo", Union[int, str], False),
        ("foo", Union[int, float], True),
        (0, Union[str, Union[int, type(None)]], False),
        (0, Union[str, Union[type(None), List]], True),
    ],
)
def test_validate_type_unions(value: Any, type_: Type, has_error: bool) -> None:
    maybe_error = ValidationError.check_type(value, type_, key="simple")
    if has_error:
        assert maybe_error is not None
    else:
        assert maybe_error is None


@pytest.mark.parametrize(
    "value, type_, has_error",
    [
        ("foo", Optional[str], False),
        (None, Optional[str], False),
        (0, Optional[str], True),
        ("foo", Optional[int], True),
    ],
)
def test_validate_type_optionals(value: Any, type_: Type, has_error: bool) -> None:
    maybe_error = ValidationError.check_type(value, type_, key="simple")
    if has_error:
        assert maybe_error is not None
    else:
        assert maybe_error is None


@pytest.mark.parametrize(
    "value, type_, has_error",
    [
        (
            {"foo": "hi"},
            pydantic.create_model("TestModel1", foo=(str, ...)),
            False,
        ),
        (
            {"foo": "hi"},
            pydantic.create_model("TestModel1", foo=(int, ...), bar=(int, ...)),
            True,
        ),
        (
            {},
            pydantic.create_model("TestModel1", foo=(int, ...), bar=(int, ...)),
            True,
        ),
    ],
)
def test_validate_type_pydantic(value: Any, type_: Type, has_error: bool) -> None:
    maybe_error = ValidationError.check_type(value, type_, key="simple")
    if has_error:
        assert maybe_error is not None
    else:
        assert maybe_error is None


@pytest.mark.parametrize(
    "value, expected",
    [
        (
            {"foo": "hi"},
            True,
        ),
        (
            {},
            True,
        ),
        (
            (1,),
            False,
        ),
        (
            [1, 2, 3],
            False,
        ),
        ([], False),
        (
            list,
            False,
        ),
        (
            dict,
            False,
        ),
    ],
)
def test_is_mapping(value: Any, expected: bool) -> None:
    assert _is_mapping(value) == expected


@pytest.mark.parametrize(
    "ExampleType, include, exclude, expected",
    [
        (
            Example,
            None,
            None,
            (
                "input_hash",
                "task_hash",
                "input",
                "meta",
                "extras",
                "answer",
                "server_anns",
                "user_anns",
            ),
        ),
        (Example, {"input_hash"}, None, ("input_hash",)),
        (
            Example,
            None,
            {"input"},
            (
                "input_hash",
                "task_hash",
                "meta",
                "extras",
                "answer",
                "server_anns",
                "user_anns",
            ),
        ),
    ],
)
def test_get_fields_include_exclude(
    ExampleType: Type[Example],
    include: Optional[Set[str]],
    exclude: Optional[Set[str]],
    expected: List[str],
):
    fields = ExampleType.get_fields(include=include, exclude=exclude)
    assert tuple(f.name for f in fields) == expected


BASE_TASK_TO_FROM_DICT_CASES = {
    "invalid_empty_data_dict": (
        {},
        ValidationError(
            errors=[
                ValidationErrorMsg(loc=("meta",), msg="missing, field required"),
                ValidationErrorMsg(loc=("extras",), msg="missing, field required"),
                ValidationErrorMsg(loc=("answer",), msg="missing, field required"),
                ValidationErrorMsg(loc=("server_anns",), msg="missing, field required"),
                ValidationErrorMsg(loc=("user_anns",), msg="missing, field required"),
            ]
        ),
    ),
    "invalid_task_hash_type_error": (
        {
            "input_hash": 0,
            "task_hash": "asdf",
            "input": {"text": "test"},
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": None,
        },
        ValidationError(
            errors=[
                ValidationErrorMsg(
                    loc=("task_hash",), msg="str is not an instance of int"
                )
            ]
        ),
    ),
    "invalid_input_is_none_error": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": None,
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": None,
        },
        ValidationError(
            errors=[ValidationErrorMsg(loc=("input",), msg="NoneType is not a dict")]
        ),
    ),
    "invalid_answer_str": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": {"text": "test"},
            "server_anns": None,
            "user_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
            "answer": "INVALID_ANSWER",
            "meta": {},
            "extras": {},
        },
        ValidationError(
            errors=[
                ValidationErrorMsg(
                    loc=("answer",),
                    msg=(
                        "str did not match any element in the union:"
                        "\n  Literal['accept', 'reject', 'ignore']: is not any of ('accept', 'reject', 'ignore')"
                        "\n  NoneType: is not an instance of NoneType"
                    ),
                )
            ]
        ),
    ),
    "valid_task_input_only": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": {"text": "test"},
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": None,
        },
        Example(
            input_hash=0,
            task_hash=1,
            meta={},
            extras={},
            input={"text": "test"},
            server_anns=None,
            user_anns=None,
            answer=None,
        ),
    ),
    "valid_task_server_anns": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": {"text": "test"},
            "server_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
            "user_anns": None,
            "answer": None,
            "meta": {},
            "extras": {},
        },
        Example(
            input_hash=0,
            task_hash=1,
            meta={},
            extras={},
            input={"text": "test"},
            server_anns={"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
            user_anns=None,
            answer=None,
        ),
    ),
    "valid_task_user_anns": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": {"text": "test"},
            "server_anns": None,
            "user_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
            "answer": "accept",
            "meta": {},
            "extras": {},
        },
        Example(
            input_hash=0,
            task_hash=1,
            meta={},
            extras={},
            input={"text": "test"},
            server_anns=None,
            user_anns={"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
            answer="accept",
        ),
    ),
    "valid_sets_hashes": (
        {
            "input": {"text": "test"},
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": None,
        },
        Example(
            input_hash=-508435184,
            task_hash=1096249858,
            meta={},
            extras={},
            input={"text": "test"},
            server_anns=None,
            user_anns=None,
            answer=None,
        ),
    ),
}


@pytest.mark.parametrize(
    "data, expected",
    BASE_TASK_TO_FROM_DICT_CASES.values(),
    ids=BASE_TASK_TO_FROM_DICT_CASES.keys(),
)
def test_base_task_to_from_dict(data: Dict, expected: Union[Example, ValidationError]):
    try:
        task = Example.from_dict(data)
    except ValidationError as e:
        assert isinstance(expected, ValidationError)
        assert len(e.errors) == len(expected.errors)
        for err, expected_err in zip(e.errors, expected.errors):
            assert err.loc == expected_err.loc
            assert err.msg == expected_err.msg
    else:
        assert isinstance(expected, Example)
        assert task.input_hash == expected.input_hash
        assert task.task_hash == expected.task_hash
        assert task.answer == expected.answer
        assert task.input == expected.input
        assert task.server_anns == expected.server_anns
        assert task.user_anns == expected.user_anns
        assert task.meta == expected.meta

        task_dict = task.to_dict()
        assert task_dict["__class__"] == "@prodigy.example_types.BaseExample.v1"
        if "input_hash" in data:
            assert task_dict["input_hash"] == data["input_hash"]
        if "task_hash" in data:
            assert task_dict["task_hash"] == data["task_hash"]
        assert task_dict["answer"] == data["answer"]
        assert task_dict["input"] == data["input"]
        assert task_dict["meta"] == data["meta"]
        assert task_dict["server_anns"] == data["server_anns"]
        assert task_dict["user_anns"] == data["user_anns"]


CUSTOM_TASK_TO_FROM_DICT_CASES = {
    "invalid_empty_data_dict": (
        {},
        ValidationError(
            errors=[
                ValidationErrorMsg(loc=("meta",), msg="missing, field required"),
                ValidationErrorMsg(loc=("extras",), msg="missing, field required"),
                ValidationErrorMsg(loc=("answer",), msg="missing, field required"),
                ValidationErrorMsg(loc=("server_anns",), msg="missing, field required"),
                ValidationErrorMsg(loc=("user_anns",), msg="missing, field required"),
            ]
        ),
    ),
    "invalid_task_hash_type_error": (
        {
            "input_hash": 0,
            "task_hash": "asdf",
            "input": {"text": "test"},
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": None,
        },
        ValidationError(
            errors=[
                ValidationErrorMsg(
                    loc=("task_hash",), msg="str is not an instance of int"
                )
            ]
        ),
    ),
    "invalid_input_is_none_error": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": None,
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": None,
        },
        ValidationError(
            errors=[
                ValidationErrorMsg(
                    loc=("input",),
                    msg="NoneType is invalid for this field. Field is required.",
                )
            ]
        ),
    ),
    "invalid_answer_str": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": {"text": "test"},
            "server_anns": None,
            "user_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
            "answer": "INVALID_ANSWER",
            "meta": {},
            "extras": {},
        },
        ValidationError(
            errors=[
                ValidationErrorMsg(
                    loc=("answer",),
                    msg=(
                        "str did not match any element in the union:"
                        "\n  Literal['accept', 'reject', 'ignore']: is not any of ('accept', 'reject', 'ignore')"
                        "\n  NoneType: is not an instance of NoneType"
                    ),
                )
            ]
        ),
    ),
    "invalid_input_pydantic_error": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": {"text_is_wrong": "test"},
            "server_anns": None,
            "user_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
            "answer": "accept",
            "meta": {},
            "extras": {},
        },
        ValidationError(
            errors=[
                ValidationErrorMsg(
                    loc=("input",),
                    msg=(
                        "dict is invalid because of a Pydantic Validation Error."
                        "\n1 validation error for TextInputTest"
                        "\ntext"
                        "\n  field required (type=value_error.missing)"
                    ),
                )
            ]
        ),
    ),
    "valid_task_input_only": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": {"text": "test"},
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": None,
        },
        SpansExampleTest(
            input_hash=0,
            task_hash=1,
            meta={},
            extras={},
            input=TextInputTest(text="test"),
            server_anns=None,
            user_anns=None,
            answer=None,
        ),
    ),
    "valid_task_server_anns": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": {"text": "test"},
            "server_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
            "user_anns": None,
            "answer": None,
            "meta": {},
            "extras": {},
        },
        SpansExampleTest(
            input_hash=0,
            task_hash=1,
            meta={},
            extras={},
            input=TextInputTest(text="test"),
            server_anns=SpansAnnotationsTest(
                spans=[TextSpan(start=0, end=4, label="TEST")]
            ),
            user_anns=None,
            answer=None,
        ),
    ),
    "valid_task_user_anns": (
        {
            "input_hash": 0,
            "task_hash": 1,
            "input": {"text": "test"},
            "server_anns": None,
            "user_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
            "answer": "accept",
            "meta": {},
            "extras": {},
        },
        SpansExampleTest(
            input_hash=0,
            task_hash=1,
            meta={},
            extras={},
            input=TextInputTest(text="test"),
            server_anns=None,
            user_anns=SpansAnnotationsTest(
                spans=[TextSpan(start=0, end=4, label="TEST")]
            ),
            answer="accept",
        ),
    ),
}


@pytest.mark.parametrize(
    "data, expected",
    CUSTOM_TASK_TO_FROM_DICT_CASES.values(),
    ids=CUSTOM_TASK_TO_FROM_DICT_CASES.keys(),
)
def test_custom_task_to_from_dict(
    data: Dict[str, Any],
    expected: SpansExampleTest,
):
    try:
        task = SpansExampleTest.from_dict(data)
    except ValidationError as e:
        assert isinstance(expected, ValidationError)
        assert len(e.errors) == len(expected.errors)
        for err, expected_err in zip(e.errors, expected.errors):
            assert err.loc == expected_err.loc
    else:
        assert isinstance(expected, SpansExampleTest)
        assert task.input_hash == expected.input_hash
        assert task.task_hash == expected.task_hash
        assert task.answer == expected.answer
        assert task.input == expected.input
        if data["server_anns"] is not None:
            assert task.server_anns is not None
            assert expected.server_anns is not None
            assert isinstance(task.server_anns, SpansAnnotationsTest)
            assert task.server_anns.spans == expected.server_anns.spans
        if data["user_anns"] is not None:
            assert task.user_anns is not None
            assert expected.user_anns is not None
            assert isinstance(task.user_anns, SpansAnnotationsTest)
            assert task.user_anns.spans == expected.user_anns.spans
        assert task.user_anns == expected.user_anns
        assert task.meta == expected.meta

        task_dict = task.to_dict()
        assert task_dict["__class__"] == "@tests.prodigy.SpansExample.v1"
        assert task_dict["input_hash"] == data["input_hash"]
        assert task_dict["task_hash"] == data["task_hash"]
        assert task_dict["answer"] == data["answer"]
        assert task_dict["input"] == data["input"]
        assert task_dict["meta"] == data["meta"]
        assert task_dict["extras"] == data["extras"]
        assert task_dict["server_anns"] == data["server_anns"]
        assert task_dict["user_anns"] == data["user_anns"]


def test_get_validation_errors():
    invalid_data = {
        "input_hash": 0,
        "task_hash": 1,
        "input": {"text": "test"},
        "server_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
        "user_anns": {"spans": [{"start": True, "WRONG_KEY": 4, "labesl": True}]},
        "meta": {},
        "extras": {},
        "answer": "accept",
    }

    with pytest.raises(ValidationError):
        SpansExampleTest.from_dict(invalid_data)

    try:
        SpansExampleTest.from_dict(invalid_data)
    except ValidationError as e:
        assert "✘ Prodigy Structured Type ValidationError" in e.msg
        assert "spans.0.start" in e.msg or "spans -> 0 -> start" in e.msg
        assert "spans.0.end" in e.msg or "spans -> 0 -> end" in e.msg
        assert "field required" in e.msg.lower()

    invalid_data["user_anns"] = {"spans": [{"start": 0, "end": 4, "label": "TEST"}]}
    task = SpansExampleTest.from_dict(invalid_data)
    assert isinstance(task.input, TextInputTest)
    assert task.input.text == "test"
    assert task.server_anns is not None
    assert isinstance(task.server_anns.spans[0], TextSpan)
    assert task.server_anns.spans[0].start == 0
    assert task.server_anns.spans[0].end == 4
    assert task.server_anns.spans[0].label == "TEST"
    assert isinstance(task.user_anns, SpansAnnotationsTest)


def test_custom_get_validation_errors():
    @prodigy_example_type("tests.prodigy.CustomValidationSpansExample.v1")
    class CustomValidationSpansExample(Example):
        input: TextInputTest
        user_anns: Optional[SpansAnnotationsTest]
        server_anns: Optional[SpansAnnotationsTest]

        @classmethod
        def get_validation_errors(
            cls,
            data: Dict[str, Any],
            include: Optional[Set[str]] = None,
            exclude: Optional[Set[str]] = None,
        ) -> Iterator[ValidationError]:
            error = ValidationError.from_msg("ISSUE WITH INPUT", key="input")
            yield error

    valid_example_data = {
        "input_hash": 0,
        "task_hash": 1,
        "input": {"text": "test"},
        "server_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
        "user_anns": {"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
        "meta": {},
        "extras": {},
        "answer": "accept",
    }

    with pytest.raises(ValidationError):
        CustomValidationSpansExample.from_dict(valid_example_data)

    try:
        CustomValidationSpansExample.from_dict(valid_example_data)
    except ValidationError as e:
        assert "✘ Prodigy Structured Type ValidationError" in e.msg
        assert "input" in e.msg
        assert "ISSUE WITH INPUT" in e.msg


def test_from_dict_subtype_union():
    """Validates that type resolution works for `user_anns` and
    `server_anns` denoted with a `Union`.
    """

    class SpansManualAnnotations(BaseModel):
        spans: List[TextManualSpan]
        tokens: List[Token]

    class DepAnnotations(BaseModel):
        relations: List[Relation]
        tokens: List[Token]

    @prodigy_example_type("tests.prodigy.CustomValidationSpansExample.v1")
    class SpansUnionSubExample(Example):
        input: TextInputTest
        user_anns: Optional[
            Union[DepAnnotations, SpansManualAnnotations, SpansAnnotationsTest]
        ]
        server_anns: Optional[
            Union[DepAnnotations, SpansManualAnnotations, SpansAnnotationsTest]
        ]

    valid_spans_manual_task = {
        "input_hash": 0,
        "task_hash": 1,
        "input": {"text": "test"},
        "server_anns": {
            "spans": [
                {
                    "start": 22,
                    "end": 33,
                    "label": "PRODUCT",
                    "token_start": 5,
                    "token_end": 6,
                }
            ],
            "tokens": [
                {"text": "First", "start": 0, "end": 5, "id": 0},
                {"text": "look", "start": 6, "end": 10, "id": 1},
                {"text": "at", "start": 11, "end": 13, "id": 2},
                {"text": "the", "start": 14, "end": 17, "id": 3},
                {"text": "new", "start": 18, "end": 21, "id": 4},
                {"text": "MacBook", "start": 22, "end": 29, "id": 5},
                {"text": "Pro", "start": 30, "end": 33, "id": 6},
            ],
        },
        "user_anns": None,
        "meta": {},
        "extras": {},
        "answer": "accept",
    }

    # When resolving the subtype for user/server_anns, `SpansUnionSubExample.resolve_subtype`
    # should loop through each model in the Union. It should fail and continue trying to resolve
    # these annotations as `DepAnnotations`, then succeed on `SpansManualAnnotations` since it's
    # the first type in the Union the data can be parsed into
    task = SpansUnionSubExample.from_dict(valid_spans_manual_task)
    assert isinstance(task.server_anns, SpansManualAnnotations)

    valid_spans_task_no_tokens = {
        "input_hash": 0,
        "task_hash": 1,
        "input": {"text": "test"},
        "server_anns": {"spans": [{"start": 22, "end": 33, "label": "PRODUCT"}]},
        "user_anns": None,
        "meta": {},
        "extras": {},
        "answer": "accept",
    }

    # When removing the tokens data from the annotations above, the same Example model
    # should fail to resolve the annotations to `SpansManualAnnotations` due to
    # pydantic validation, and it should resolve to `SpansAnnotationsTest` successfully
    task = SpansUnionSubExample.from_dict(valid_spans_task_no_tokens)
    assert isinstance(task.server_anns, SpansAnnotationsTest)


BASE_TASK_FROM_UNST_SERVER_TEST_CASES = {
    "invalid_no_input_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
        },
        ValueError("msg"),
        None,
        ["spans"],
    ),
    "invalid_no_server_ann_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
        },
        ValueError("msg"),
        ["text"],
        None,
    ),
    "valid_spans_task": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
        },
        Example(
            input_hash=1,
            task_hash=1,
            input={"text": "Apple updates its analytics service with new metrics"},
            meta={},
            extras={},
            answer=None,
            server_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
            user_anns=None,
        ),
        ["text"],
        ["spans"],
    ),
}


@pytest.mark.parametrize(
    "data, expected, input_keys, server_ann_keys",
    BASE_TASK_FROM_UNST_SERVER_TEST_CASES.values(),
    ids=BASE_TASK_FROM_UNST_SERVER_TEST_CASES.keys(),
)
def test_base_task_from_unst_server(
    data: Dict[str, Any],
    expected: Union[Example, StructuredExampleError, ValueError],
    input_keys: List[str],
    server_ann_keys: List[str],
):
    try:
        task = Example.from_unst_server(
            data,
            input_keys=input_keys,
            server_ann_keys=server_ann_keys,
        )
    except (StructuredExampleError, ValueError) as e:
        assert isinstance(expected, e.__class__)
    else:
        for in_key in input_keys:
            assert in_key in task.input
            assert data[in_key] == task.input[in_key]
        for ann_key in server_ann_keys:
            assert task.server_anns is not None
            assert ann_key in task.server_anns
            assert data[ann_key] == task.server_anns[ann_key]


BASE_TASK_FROM_UNST_USER_TEST_CASES = {
    "invalid_no_input_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        ValueError("msg"),
        None,
        None,
        ["spans"],
    ),
    "invalid_no_user_ann_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        ValueError("msg"),
        ["text"],
        None,
        None,
    ),
    "invalid_missing_answer": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
        },
        MissingAnswerError(
            {
                "text": "Apple updates its analytics service with new metrics",
                "spans": [{"start": 0, "end": 5, "label": "ORG"}],
                INPUT_HASH_ATTR: 1,
                TASK_HASH_ATTR: 1,
            },
            Example,
        ),
        ["text"],
        None,
        ["spans"],
    ),
    "valid_spans_task": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        Example(
            input_hash=1,
            task_hash=1,
            input={"text": "Apple updates its analytics service with new metrics"},
            meta={},
            extras={},
            answer="accept",
            server_anns=None,
            user_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
        ),
        ["text"],
        None,
        ["spans"],
    ),
}


@pytest.mark.parametrize(
    "data, expected, input_keys, server_ann_keys, user_ann_keys",
    BASE_TASK_FROM_UNST_USER_TEST_CASES.values(),
    ids=BASE_TASK_FROM_UNST_USER_TEST_CASES.keys(),
)
def test_base_task_from_unst_user(
    data: Dict[str, Any],
    expected: Union[Example, StructuredExampleError, ValueError],
    input_keys: List[str],
    server_ann_keys: Optional[List[str]],
    user_ann_keys: List[str],
):
    try:
        task = Example.from_unst_user(
            data,
            input_keys=input_keys,
            server_ann_keys=server_ann_keys,
            user_ann_keys=user_ann_keys,
        )
    except (StructuredExampleError, ValueError) as e:
        assert isinstance(expected, e.__class__)
    else:
        for in_key in input_keys:
            assert in_key in task.input
            assert data[in_key] == task.input[in_key]
        for ann_key in user_ann_keys:
            assert task.user_anns is not None
            assert ann_key in task.user_anns
            assert data[ann_key] == task.user_anns[ann_key]


CUSTOM_TASK_FROM_UNST_USER_TEST_CASES = {
    "invalid_no_input_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        ValueError("msg"),
        None,
        None,
        ["spans"],
    ),
    "invalid_no_user_ann_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        ValueError("msg"),
        ["text"],
        None,
        None,
    ),
    "invalid_missing_answer": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
        },
        MissingAnswerError(
            {
                "text": "Apple updates its analytics service with new metrics",
                "spans": [{"start": 0, "end": 5, "label": "ORG"}],
                INPUT_HASH_ATTR: 1,
                TASK_HASH_ATTR: 1,
            },
            Example,
        ),
        ["text"],
        None,
        ["spans"],
    ),
    "invalid_spans_pydantic_error": (
        {
            "_input_hash": 0,
            "_task_hash": 1,
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": True, "end": False, "label": "ORG"}],
            "answer": "accept",
            "meta": {},
            "extras": {},
        },
        ValidationError(
            errors=[
                ValidationErrorMsg(
                    loc=("user_annotations",),
                    msg=(
                        "did not match any element in the union:\n"
                        "  tests.test_structured_task.SpansAnnotationsTest:\n"
                        "  spans -> 0 -> start   value is not a valid integer\n"
                        "  spans -> 0 -> end     value is not a valid integer\n"
                        "  NoneType: is not an instance of NoneType"
                    ),
                )
            ]
        ),
        ["text"],
        None,
        ["spans"],
    ),
    "valid_spans_task": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        SpansExampleTest(
            input_hash=1,
            task_hash=1,
            input=TextInputTest(
                text="Apple updates its analytics service with new metrics"
            ),
            meta={},
            extras={},
            answer="accept",
            server_anns=None,
            user_anns=SpansAnnotationsTest(
                spans=[TextSpan(start=0, end=5, label="ORG")]
            ),
        ),
        ["text"],
        None,
        ["spans"],
    ),
}


@pytest.mark.parametrize(
    "data, expected, input_keys, server_ann_keys, user_ann_keys",
    CUSTOM_TASK_FROM_UNST_USER_TEST_CASES.values(),
    ids=CUSTOM_TASK_FROM_UNST_USER_TEST_CASES.keys(),
)
def test_custom_task_from_unst_user(
    data: Dict[str, Any],
    expected: Union[SpansExampleTest, StructuredExampleError, ValueError],
    input_keys: List[str],
    server_ann_keys: Optional[List[str]],
    user_ann_keys: List[str],
):
    try:
        task = SpansExampleTest.from_unst_user(
            data,
            input_keys=input_keys,
            server_ann_keys=server_ann_keys,
            user_ann_keys=user_ann_keys,
        )
    except (StructuredExampleError, ValueError) as e:
        assert isinstance(expected, e.__class__)
    else:
        for in_key in input_keys:
            assert hasattr(task.input, in_key)
            assert data[in_key] == getattr(task.input, in_key)
        for ann_key in user_ann_keys:
            assert hasattr(task.user_anns, ann_key)
            assert data[ann_key] == jsonable_encoder(getattr(task.user_anns, ann_key))


CONFLICTING_KEYS_TEST_CASES = {
    "conflict_server_ann_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        ConflictingKeysError(Example, {"text"}, {"text"}),
        "server",
        ["text"],
        ["text"],
        None,
    ),
    "conflict_user_ann_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        ConflictingKeysError(Example, {"text"}, {"text"}),
        "user",
        ["text"],
        [],
        ["text"],
    ),
    "no_conflict_server_ann_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        Example(
            input_hash=1,
            task_hash=1,
            input={"text": "Apple updates its analytics service with new metrics"},
            meta={},
            extras={},
            answer="accept",
            server_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
            user_anns=None,
        ),
        "server",
        ["text"],
        ["spans"],
        None,
    ),
    "no_conflict_user_ann_keys": (
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        Example(
            input_hash=1,
            task_hash=1,
            input={"text": "Apple updates its analytics service with new metrics"},
            meta={},
            extras={},
            answer="accept",
            server_anns=None,
            user_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
        ),
        "user",
        ["text"],
        [],
        ["spans"],
    ),
}


@pytest.mark.parametrize(
    "data, expected, anns_source, input_keys, server_ann_keys, user_ann_keys",
    CONFLICTING_KEYS_TEST_CASES.values(),
    ids=CONFLICTING_KEYS_TEST_CASES.keys(),
)
def test_conflicting_keys(
    data: Dict[str, Any],
    expected: Union[Example, ConflictingKeysError],
    anns_source: Literal["server", "user"],
    input_keys: List[str],
    server_ann_keys: List[str],
    user_ann_keys: List[str],
):
    try:
        if anns_source == "server":
            task = Example.from_unst_server(
                data, input_keys=input_keys, server_ann_keys=server_ann_keys
            )
        elif anns_source == "user":
            task = Example.from_unst_user(
                data,
                input_keys=input_keys,
                server_ann_keys=server_ann_keys,
                user_ann_keys=user_ann_keys,
            )

    except (ConflictingKeysError) as e:
        assert isinstance(expected, ConflictingKeysError)
        assert e.msg == expected.msg
    else:
        assert task == expected


INPUT_RESOLUTION_TEST_CASES = {
    "invalid_input_not_overridden": (
        {
            "input_hash": 1,
            "task_hash": 1,
            "input": {"text": "something else"},
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": "accept",
        },
        Example(
            input_hash=1,
            task_hash=1,
            meta={},
            extras={},
            input={"text": "test"},
            server_anns=None,
            user_anns=None,
            answer="accept",
        ),
    ),
    "valid_base_task": (
        {
            "input_hash": 1,
            "task_hash": 1,
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": "accept",
        },
        Example(
            input_hash=1,
            task_hash=1,
            meta={},
            extras={},
            input={"text": "test"},
            server_anns=None,
            user_anns=None,
            answer="accept",
        ),
    ),
    "valid_custom_task": (
        {
            "input_hash": 1,
            "task_hash": 1,
            "meta": {},
            "extras": {},
            "server_anns": None,
            "user_anns": None,
            "answer": "accept",
        },
        SpansExampleTest(
            input_hash=1,
            task_hash=1,
            meta={},
            extras={},
            input=TextInputTest(text="test"),
            server_anns=None,
            user_anns=None,
            answer="accept",
        ),
    ),
}


@pytest.mark.parametrize(
    "data, expected",
    INPUT_RESOLUTION_TEST_CASES.values(),
    ids=INPUT_RESOLUTION_TEST_CASES.keys(),
)
def test_resolve_st_task_input(
    database: Database, dataset: str, data: Dict[str, Any], expected: Example
):
    StExampleType = expected.__class__
    database.add_dataset(dataset, structured=True)
    database.add_st_examples([expected], dataset, "test-session")
    if "input" not in data:
        with pytest.raises(ValueError):
            # Assert raises ValueError if no database and no input provided
            StExampleType.from_dict(data)

    task = StExampleType.from_dict(data, db=database)
    if "input" not in data:
        # If input not provided, we fetch from the database so these should be equal
        assert task.input == expected.input
    else:
        # If input is provided, we don't fetch from the database, so these aren't necessarily equal
        assert task.input != expected.input


TO_UNST_TEST_CASES = {
    "base_task_input_only": (
        Example(
            input_hash=1,
            task_hash=1,
            meta={"some_key": ["a", "b", "c"]},
            extras={"extra_key": 1},
            input={"text": "test"},
            server_anns=None,
            user_anns=None,
            answer=None,
        ),
        {
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "meta": {"some_key": ["a", "b", "c"]},
            "text": "test",
            "extra_key": 1,
        },
    ),
    "base_task_server_anns": (
        Example(
            input_hash=1,
            task_hash=1,
            meta={"some_key": ["a", "b", "c"]},
            extras={"extra_key": 1},
            input={"text": "Apple updates its analytics service with new metrics"},
            server_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
            user_anns=None,
            answer="accept",
        ),
        {
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "meta": {"some_key": ["a", "b", "c"]},
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            "answer": "accept",
            "extra_key": 1,
        },
    ),
    "user_and_server_anns_uses_user_anns": (
        Example(
            input_hash=1,
            task_hash=1,
            meta={"some_key": ["a", "b", "c"]},
            extras={"extra_key": 1},
            input={"text": "Apple updates its analytics service with new metrics"},
            server_anns={"spans": [{"start": 0, "end": 10, "label": "UNKNOWN"}]},
            user_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
            answer="accept",
        ),
        {
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "meta": {"some_key": ["a", "b", "c"]},
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            "answer": "accept",
            "extra_key": 1,
        },
    ),
    "custom_task_user_and_server_anns": (
        SpansExampleTest(
            input_hash=1,
            task_hash=1,
            meta={"some_key": ["a", "b", "c"]},
            extras={"extra_key": 1},
            input=TextInputTest(
                text="Apple updates its analytics service with new metrics"
            ),
            server_anns=SpansAnnotationsTest(
                spans=[TextSpan(start=0, end=10, label="UNKNOWN")]
            ),
            user_anns=SpansAnnotationsTest(
                spans=[TextSpan(start=0, end=5, label="ORG")]
            ),
            answer="accept",
        ),
        {
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "meta": {"some_key": ["a", "b", "c"]},
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            "answer": "accept",
            "extra_key": 1,
        },
    ),
}


@pytest.mark.parametrize(
    "task, expected",
    TO_UNST_TEST_CASES.values(),
    ids=TO_UNST_TEST_CASES.keys(),
)
def test_task_to_unst(
    task: Example,
    expected: Dict[str, Any],
):
    data = task.to_unst()
    assert isinstance(data, dict)
    assert data == expected


###
# The below test checks the `from_unst_server`` and `from_unst_user` factories for
# all built-in Prodigy task types.
# It is also here to document the usage of the built-in task types
# Each test case has
# 1. The initial dict of data from the server (e.g. from a JSONL file)
# 2. A correction to the server data simulating a user changing the presented annotations
# 3. The custom task expected to be created on the server with the initial data
# 4. The custom task expected to be created after updating the data with the user annotations
###


class CustomSubtypesFromUnstTestCase(NamedTuple):
    server_data: Dict[str, Any]
    user_anns: Dict[str, Any]
    expected_from_server: Example
    expected_from_user: Example


CUSTOM_SUBTYPES_FROM_UNST_SERVER_TEST_CASES = {
    "spans_task": CustomSubtypesFromUnstTestCase(
        server_data={
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "PRODUCT"}],
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
        },
        user_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
        expected_from_server=SpansExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(
                text="Apple updates its analytics service with new metrics"
            ),
            meta={},
            extras={},
            answer=None,
            server_anns=SpansAnns(spans=[TextSpan(start=0, end=5, label="PRODUCT")]),
            user_anns=None,
        ),
        expected_from_user=SpansExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(
                text="Apple updates its analytics service with new metrics"
            ),
            meta={},
            extras={},
            answer="accept",
            server_anns=SpansAnns(spans=[TextSpan(start=0, end=5, label="PRODUCT")]),
            user_anns=SpansAnns(spans=[TextSpan(start=0, end=5, label="ORG")]),
        ),
    ),
    "spans_manual_task": CustomSubtypesFromUnstTestCase(
        server_data={
            "text": "First look at the new MacBook Pro",
            "spans": [
                {
                    "start": 22,
                    "end": 33,
                    "label": "ORG",
                    "token_start": 5,
                    "token_end": 6,
                }
            ],
            "tokens": [
                {"text": "First", "start": 0, "end": 5, "id": 0},
                {"text": "look", "start": 6, "end": 10, "id": 1},
                {"text": "at", "start": 11, "end": 13, "id": 2},
                {"text": "the", "start": 14, "end": 17, "id": 3},
                {"text": "new", "start": 18, "end": 21, "id": 4},
                {"text": "MacBook", "start": 22, "end": 29, "id": 5},
                {"text": "Pro", "start": 30, "end": 33, "id": 6},
            ],
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
        },
        user_anns={
            "spans": [
                {
                    "start": 22,
                    "end": 33,
                    "label": "PRODUCT",
                    "token_start": 5,
                    "token_end": 6,
                }
            ],
        },
        expected_from_server=SpansManualExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(text="First look at the new MacBook Pro"),
            meta={},
            extras={},
            answer=None,
            server_anns=SpansManualAnns(
                spans=[
                    TextManualSpan(
                        start=22, end=33, label="ORG", token_start=5, token_end=6
                    )
                ],
                tokens=[
                    Token(start=0, end=5, id=0, disabled=False),
                    Token(start=6, end=10, id=1, disabled=False),
                    Token(start=11, end=13, id=2, disabled=False),
                    Token(start=14, end=17, id=3, disabled=False),
                    Token(start=18, end=21, id=4, disabled=False),
                    Token(start=22, end=29, id=5, disabled=False),
                    Token(start=30, end=33, id=6, disabled=False),
                ],
            ),
            user_anns=None,
        ),
        expected_from_user=SpansManualExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(text="First look at the new MacBook Pro"),
            meta={},
            extras={},
            answer="accept",
            server_anns=SpansManualAnns(
                spans=[
                    TextManualSpan(
                        start=22, end=33, label="ORG", token_start=5, token_end=6
                    )
                ],
                tokens=[
                    Token(start=0, end=5, id=0, disabled=False),
                    Token(start=6, end=10, id=1, disabled=False),
                    Token(start=11, end=13, id=2, disabled=False),
                    Token(start=14, end=17, id=3, disabled=False),
                    Token(start=18, end=21, id=4, disabled=False),
                    Token(start=22, end=29, id=5, disabled=False),
                    Token(start=30, end=33, id=6, disabled=False),
                ],
            ),
            user_anns=SpansManualAnns(
                spans=[
                    TextManualSpan(
                        start=22, end=33, label="PRODUCT", token_start=5, token_end=6
                    )
                ],
                tokens=[
                    Token(start=0, end=5, id=0, disabled=False),
                    Token(start=6, end=10, id=1, disabled=False),
                    Token(start=11, end=13, id=2, disabled=False),
                    Token(start=14, end=17, id=3, disabled=False),
                    Token(start=18, end=21, id=4, disabled=False),
                    Token(start=22, end=29, id=5, disabled=False),
                    Token(start=30, end=33, id=6, disabled=False),
                ],
            ),
        ),
    ),
    "relations_task": CustomSubtypesFromUnstTestCase(
        server_data={
            "text": "My mother’s name is Sasha Smith. She likes dogs and pedigree cats.",
            "tokens": [
                {"text": "My", "start": 0, "end": 2, "id": 0, "ws": True},
                {"text": "mother", "start": 3, "end": 9, "id": 1, "ws": False},
                {"text": "’s", "start": 9, "end": 11, "id": 2, "ws": True},
                {"text": "name", "start": 12, "end": 16, "id": 3, "ws": True},
                {"text": "is", "start": 17, "end": 19, "id": 4, "ws": True},
                {"text": "Sasha", "start": 20, "end": 25, "id": 5, "ws": True},
                {"text": "Smith", "start": 26, "end": 31, "id": 6, "ws": True},
                {
                    "text": ".",
                    "start": 31,
                    "end": 32,
                    "id": 7,
                    "ws": True,
                    "disabled": True,
                },
                {"text": "She", "start": 33, "end": 36, "id": 8, "ws": True},
                {"text": "likes", "start": 37, "end": 42, "id": 9, "ws": True},
                {"text": "dogs", "start": 43, "end": 47, "id": 10, "ws": True},
                {
                    "text": "and",
                    "start": 48,
                    "end": 51,
                    "id": 11,
                    "ws": True,
                    "disabled": True,
                },
                {"text": "pedigree", "start": 52, "end": 60, "id": 12, "ws": True},
                {"text": "cats", "start": 61, "end": 65, "id": 13, "ws": True},
                {
                    "text": ".",
                    "start": 65,
                    "end": 66,
                    "id": 14,
                    "ws": False,
                    "disabled": True,
                },
            ],
            "spans": [
                {
                    "start": 20,
                    "end": 31,
                    "token_start": 5,
                    "token_end": 6,
                    "label": "PERSON",
                },
                {
                    "start": 43,
                    "end": 47,
                    "token_start": 10,
                    "token_end": 10,
                    "label": "NP",
                },
                {
                    "start": 52,
                    "end": 65,
                    "token_start": 12,
                    "token_end": 13,
                    "label": "NP",
                },
            ],
            "relations": [
                {
                    "head": 0,
                    "child": 1,
                    "label": "POSS",
                    "head_span": {
                        "start": 0,
                        "end": 2,
                        "token_start": 0,
                        "token_end": 0,
                        "label": None,
                    },
                    "child_span": {
                        "start": 3,
                        "end": 9,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                }
            ],
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
        },
        user_anns={
            "relations": [
                {
                    "head": 0,
                    "child": 1,
                    "label": "POSS",
                    "head_span": {
                        "start": 0,
                        "end": 2,
                        "token_start": 0,
                        "token_end": 0,
                        "label": None,
                    },
                    "child_span": {
                        "start": 3,
                        "end": 9,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                },
                {
                    "head": 1,
                    "child": 8,
                    "label": "COREF",
                    "head_span": {
                        "start": 3,
                        "end": 9,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 33,
                        "end": 36,
                        "token_start": 8,
                        "token_end": 8,
                        "label": None,
                    },
                },
                {
                    "head": 9,
                    "child": 13,
                    "label": "OBJECT",
                    "head_span": {
                        "start": 37,
                        "end": 42,
                        "token_start": 9,
                        "token_end": 9,
                        "label": None,
                    },
                    "child_span": {
                        "start": 52,
                        "end": 65,
                        "token_start": 12,
                        "token_end": 13,
                        "label": "NP",
                    },
                },
            ],
        },
        expected_from_server=RelationsExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(
                text="My mother’s name is Sasha Smith. She likes dogs and pedigree cats."
            ),
            meta={},
            extras={},
            answer=None,
            server_anns=RelationsAnns(
                spans=[
                    TextManualSpan(
                        start=20, end=31, label="PERSON", token_start=5, token_end=6
                    ),
                    TextManualSpan(
                        start=43, end=47, label="NP", token_start=10, token_end=10
                    ),
                    TextManualSpan(
                        start=52, end=65, label="NP", token_start=12, token_end=13
                    ),
                ],
                relations=[
                    Relation(head=0, child=1, label="POSS", color=None),
                ],
                tokens=[
                    Token(start=0, end=2, id=0, disabled=False),
                    Token(start=3, end=9, id=1, disabled=False),
                    Token(start=9, end=11, id=2, disabled=False),
                    Token(start=12, end=16, id=3, disabled=False),
                    Token(start=17, end=19, id=4, disabled=False),
                    Token(start=20, end=25, id=5, disabled=False),
                    Token(start=26, end=31, id=6, disabled=False),
                    Token(start=31, end=32, id=7, disabled=True),
                    Token(start=33, end=36, id=8, disabled=False),
                    Token(start=37, end=42, id=9, disabled=False),
                    Token(start=43, end=47, id=10, disabled=False),
                    Token(start=48, end=51, id=11, disabled=True),
                    Token(start=52, end=60, id=12, disabled=False),
                    Token(start=61, end=65, id=13, disabled=False),
                    Token(start=65, end=66, id=14, disabled=True),
                ],
            ),
            user_anns=None,
        ),
        expected_from_user=RelationsExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(
                text="My mother’s name is Sasha Smith. She likes dogs and pedigree cats."
            ),
            meta={},
            extras={},
            answer="accept",
            server_anns=RelationsAnns(
                spans=[
                    TextManualSpan(
                        start=20, end=31, label="PERSON", token_start=5, token_end=6
                    ),
                    TextManualSpan(
                        start=43, end=47, label="NP", token_start=10, token_end=10
                    ),
                    TextManualSpan(
                        start=52, end=65, label="NP", token_start=12, token_end=13
                    ),
                ],
                relations=[Relation(head=0, child=1, label="POSS", color=None)],
                tokens=[
                    Token(start=0, end=2, id=0, disabled=False),
                    Token(start=3, end=9, id=1, disabled=False),
                    Token(start=9, end=11, id=2, disabled=False),
                    Token(start=12, end=16, id=3, disabled=False),
                    Token(start=17, end=19, id=4, disabled=False),
                    Token(start=20, end=25, id=5, disabled=False),
                    Token(start=26, end=31, id=6, disabled=False),
                    Token(start=31, end=32, id=7, disabled=True),
                    Token(start=33, end=36, id=8, disabled=False),
                    Token(start=37, end=42, id=9, disabled=False),
                    Token(start=43, end=47, id=10, disabled=False),
                    Token(start=48, end=51, id=11, disabled=True),
                    Token(start=52, end=60, id=12, disabled=False),
                    Token(start=61, end=65, id=13, disabled=False),
                    Token(start=65, end=66, id=14, disabled=True),
                ],
            ),
            user_anns=RelationsAnns(
                spans=[
                    TextManualSpan(
                        start=20, end=31, label="PERSON", token_start=5, token_end=6
                    ),
                    TextManualSpan(
                        start=43, end=47, label="NP", token_start=10, token_end=10
                    ),
                    TextManualSpan(
                        start=52, end=65, label="NP", token_start=12, token_end=13
                    ),
                ],
                relations=[
                    Relation(head=0, child=1, label="POSS", color=None),
                    Relation(head=1, child=8, label="COREF", color=None),
                    Relation(head=9, child=13, label="OBJECT", color=None),
                ],
                tokens=[
                    Token(start=0, end=2, id=0, disabled=False),
                    Token(start=3, end=9, id=1, disabled=False),
                    Token(start=9, end=11, id=2, disabled=False),
                    Token(start=12, end=16, id=3, disabled=False),
                    Token(start=17, end=19, id=4, disabled=False),
                    Token(start=20, end=25, id=5, disabled=False),
                    Token(start=26, end=31, id=6, disabled=False),
                    Token(start=31, end=32, id=7, disabled=True),
                    Token(start=33, end=36, id=8, disabled=False),
                    Token(start=37, end=42, id=9, disabled=False),
                    Token(start=43, end=47, id=10, disabled=False),
                    Token(start=48, end=51, id=11, disabled=True),
                    Token(start=52, end=60, id=12, disabled=False),
                    Token(start=61, end=65, id=13, disabled=False),
                    Token(start=65, end=66, id=14, disabled=True),
                ],
            ),
        ),
    ),
    "dep_task": CustomSubtypesFromUnstTestCase(
        server_data={
            "text": "First look at the new MacBook Pro",
            "arcs": [],
            "tokens": [
                {"text": "First", "start": 0, "end": 5, "id": 0},
                {"text": "look", "start": 6, "end": 10, "id": 1},
                {"text": "at", "start": 11, "end": 13, "id": 2},
                {"text": "the", "start": 14, "end": 17, "id": 3},
                {"text": "new", "start": 18, "end": 21, "id": 4},
                {"text": "MacBook", "start": 22, "end": 29, "id": 5},
            ],
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
        },
        user_anns={"arcs": [{"head": 2, "child": 5, "label": "pobj"}]},
        expected_from_server=DepExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(text="First look at the new MacBook Pro"),
            meta={},
            extras={},
            answer=None,
            server_anns=DepAnns(
                relations=[],
                tokens=[
                    Token(start=0, end=5, id=0, disabled=False),
                    Token(start=6, end=10, id=1, disabled=False),
                    Token(start=11, end=13, id=2, disabled=False),
                    Token(start=14, end=17, id=3, disabled=False),
                    Token(start=18, end=21, id=4, disabled=False),
                    Token(start=22, end=29, id=5, disabled=False),
                ],
            ),
            user_anns=None,
        ),
        expected_from_user=DepExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(text="First look at the new MacBook Pro"),
            meta={},
            extras={},
            answer="accept",
            server_anns=DepAnns(
                relations=[],
                tokens=[
                    Token(start=0, end=5, id=0, disabled=False),
                    Token(start=6, end=10, id=1, disabled=False),
                    Token(start=11, end=13, id=2, disabled=False),
                    Token(start=14, end=17, id=3, disabled=False),
                    Token(start=18, end=21, id=4, disabled=False),
                    Token(start=22, end=29, id=5, disabled=False),
                ],
            ),
            user_anns=DepAnns(
                relations=[Relation(head=2, child=5, label="pobj", color=None)],
                tokens=[
                    Token(start=0, end=5, id=0, disabled=False),
                    Token(start=6, end=10, id=1, disabled=False),
                    Token(start=11, end=13, id=2, disabled=False),
                    Token(start=14, end=17, id=3, disabled=False),
                    Token(start=18, end=21, id=4, disabled=False),
                    Token(start=22, end=29, id=5, disabled=False),
                ],
            ),
        ),
    ),
    "image_task": CustomSubtypesFromUnstTestCase(
        server_data={
            "image": "https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?w=400",
            "spans": [
                {
                    "points": [[155, 35], [305, 35], [305, 160], [155, 160]],
                    "label": "FISH",
                }
            ],
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
        },
        user_anns={
            "spans": [
                {
                    "points": [[155, 15], [305, 15], [305, 160], [155, 160]],
                    "label": "LAPTOP",
                }
            ]
        },
        expected_from_server=ImageExample(
            input_hash=0,
            task_hash=1,
            input=ImageInput(
                image="https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?w=400",
                width=None,
                height=None,
            ),
            meta={},
            extras={},
            answer=None,
            server_anns=BoundingBoxAnns(
                spans=[
                    ImageSpan(
                        id=None,
                        type=None,
                        label="FISH",
                        points=[
                            [155.0, 35.0],
                            [305.0, 35.0],
                            [305.0, 160.0],
                            [155.0, 160.0],
                        ],
                        width=None,
                        height=None,
                        x=None,
                        y=None,
                        center=None,
                        color=None,
                    )
                ]
            ),
            user_anns=None,
        ),
        expected_from_user=ImageExample(
            input_hash=0,
            task_hash=1,
            input=ImageInput(
                image="https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?w=400",
                width=None,
                height=None,
            ),
            meta={},
            extras={},
            answer="accept",
            server_anns=BoundingBoxAnns(
                spans=[
                    ImageSpan(
                        id=None,
                        type=None,
                        label="FISH",
                        points=[
                            [155.0, 35.0],
                            [305.0, 35.0],
                            [305.0, 160.0],
                            [155.0, 160.0],
                        ],
                        width=None,
                        height=None,
                        x=None,
                        y=None,
                        center=None,
                        color=None,
                    )
                ]
            ),
            user_anns=BoundingBoxAnns(
                spans=[
                    ImageSpan(
                        id=None,
                        type=None,
                        label="LAPTOP",
                        points=[
                            [155.0, 15.0],
                            [305.0, 15.0],
                            [305.0, 160.0],
                            [155.0, 160.0],
                        ],
                        width=None,
                        height=None,
                        x=None,
                        y=None,
                        center=None,
                        color=None,
                    )
                ]
            ),
        ),
    ),
    "audio_spans_task": CustomSubtypesFromUnstTestCase(
        server_data={
            "audio": "https://example.com/audio.mp3",
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
        },
        user_anns={
            "audio_spans": [
                {"start": 1.89, "end": 2.83, "label": "SPEAKER_1"},
                {"start": 9.45, "end": 9.94, "label": "SPEAKER_1"},
                {"start": 13.48, "end": 16.19, "label": "SPEAKER_2"},
                {"start": 16.68, "end": 20.62, "label": "SPEAKER_1"},
                {"start": 20.81, "end": 23.78, "label": "SPEAKER_2"},
            ]
        },
        expected_from_server=AudioSpansExample(
            input_hash=0,
            task_hash=1,
            input=AudioInput(audio="https://example.com/audio.mp3"),
            meta={},
            extras={},
            answer=None,
            server_anns=None,
            user_anns=None,
        ),
        expected_from_user=AudioSpansExample(
            input_hash=0,
            task_hash=1,
            input=AudioInput(audio="https://example.com/audio.mp3"),
            meta={},
            extras={},
            answer="accept",
            server_anns=None,
            user_anns=AudioSpansAnns(
                audio_spans=[
                    AudioSpan(start=1.89, end=2.83, label="SPEAKER_1"),
                    AudioSpan(start=9.45, end=9.94, label="SPEAKER_1"),
                    AudioSpan(start=13.48, end=16.19, label="SPEAKER_2"),
                    AudioSpan(start=16.68, end=20.62, label="SPEAKER_1"),
                    AudioSpan(start=20.81, end=23.78, label="SPEAKER_2"),
                ]
            ),
        ),
    ),
    "audio_transcribe_task": CustomSubtypesFromUnstTestCase(
        server_data={
            "audio": "https://example.com/audio.mp3",
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
            "field_rows": 2,
            "field_label": "Transcript",
            "field_id": "#transcript",
            "field_autofocus": True,
            "field_placeholder": "Write transcript here...",
        },
        user_anns={
            "user_input": "This is the transcription I wrote.",
        },
        expected_from_server=AudioTranscribeExample(
            input_hash=0,
            task_hash=1,
            input=AudioInput(audio="https://example.com/audio.mp3"),
            meta={},
            extras={},
            answer=None,
            server_anns=AudioTranscribeServerAnns(
                field_id="#transcript",
                field_placeholder="Write transcript here...",
                field_label="Transcript",
                field_rows=2,
                field_autofocus=True,
                user_input=None,
            ),
            user_anns=None,
        ),
        expected_from_user=AudioTranscribeExample(
            input_hash=0,
            task_hash=1,
            input=AudioInput(audio="https://example.com/audio.mp3"),
            meta={},
            extras={},
            answer="accept",
            server_anns=AudioTranscribeServerAnns(
                field_id="#transcript",
                field_placeholder="Write transcript here...",
                field_label="Transcript",
                field_rows=2,
                field_autofocus=True,
                user_input=None,
            ),
            user_anns=AudioTranscribeUserAnns(
                user_input="This is the transcription I wrote."
            ),
        ),
    ),
    "text_classification_task": CustomSubtypesFromUnstTestCase(
        server_data={
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
        },
        user_anns={"label": "TECHNOLOGY"},
        expected_from_server=TextcatExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(
                text="Apple updates its analytics service with new metrics"
            ),
            meta={},
            extras={},
            answer=None,
            server_anns=TextcatServerAnns(
                label=None, spans=[TextSpan(start=0, end=5, label="ORG")]
            ),
            user_anns=None,
        ),
        expected_from_user=TextcatExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(
                text="Apple updates its analytics service with new metrics"
            ),
            meta={},
            extras={},
            answer="accept",
            server_anns=TextcatServerAnns(
                label=None, spans=[TextSpan(start=0, end=5, label="ORG")]
            ),
            user_anns=ClassificationAnns(label="TECHNOLOGY"),
        ),
    ),
    "image_classification_task": CustomSubtypesFromUnstTestCase(
        server_data={
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
            "image": "https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?w=400",
        },
        user_anns={"label": "TECHNOLOGY"},
        expected_from_server=ImagecatExample(
            input_hash=0,
            task_hash=1,
            input=ImageInput(
                image="https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?w=400"
            ),
            meta={},
            extras={},
            answer=None,
            server_anns=None,
            user_anns=None,
        ),
        expected_from_user=ImagecatExample(
            input_hash=0,
            task_hash=1,
            input=ImageInput(
                image="https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?w=400"
            ),
            meta={},
            extras={},
            answer="accept",
            server_anns=None,
            user_anns=ClassificationAnns(label="TECHNOLOGY"),
        ),
    ),
    "audio_classification_task": CustomSubtypesFromUnstTestCase(
        server_data={
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
            "audio": "https://example.com/audio.mp3",
            "label": "POSITIVE",
        },
        user_anns={"label": "NEGATIVE"},
        expected_from_server=AudiocatExample(
            input_hash=0,
            task_hash=1,
            input=AudioInput(audio="https://example.com/audio.mp3"),
            meta={},
            extras={},
            answer=None,
            server_anns=ClassificationAnns(label="POSITIVE"),
            user_anns=None,
        ),
        expected_from_user=AudiocatExample(
            input_hash=0,
            task_hash=1,
            input=AudioInput(audio="https://example.com/audio.mp3"),
            meta={},
            extras={},
            answer="accept",
            server_anns=ClassificationAnns(label="POSITIVE"),
            user_anns=ClassificationAnns(label="NEGATIVE"),
        ),
    ),
    "html_classification_task": CustomSubtypesFromUnstTestCase(
        server_data={
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
            "html": "<p>This business is not good</p>",
            "label": "POSITIVE",
        },
        user_anns={"label": "NEGATIVE"},
        expected_from_server=HTMLcatExample(
            input_hash=0,
            task_hash=1,
            input=HTMLInput(html="<p>This business is not good</p>"),
            meta={},
            extras={},
            answer=None,
            server_anns=ClassificationAnns(label="POSITIVE"),
            user_anns=None,
        ),
        expected_from_user=HTMLcatExample(
            input_hash=0,
            task_hash=1,
            input=HTMLInput(html="<p>This business is not good</p>"),
            meta={},
            extras={},
            answer="accept",
            server_anns=ClassificationAnns(label="POSITIVE"),
            user_anns=ClassificationAnns(label="NEGATIVE"),
        ),
    ),
    "textcat_choice_task": CustomSubtypesFromUnstTestCase(
        server_data={
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
            "text": "Pick the odd one out.",
            "spans": [{"start": 13, "end": 16, "label": "NUMBER"}],
            "options": [
                {"id": "BANANA", "text": "🍌 banana"},
                {"id": "BROCCOLI", "text": "🥦 broccoli"},
                {"id": "TOMATO", "text": "🍅 tomato"},
            ],
        },
        user_anns={"accept": ["BANANA"]},
        expected_from_server=TextcatChoiceExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(text="Pick the odd one out."),
            meta={},
            extras={},
            answer=None,
            server_anns=TextcatChoiceServerAnns(
                options=[
                    ChoiceOption(id="BANANA", text="🍌 banana"),
                    ChoiceOption(id="BROCCOLI", text="🥦 broccoli"),
                    ChoiceOption(id="TOMATO", text="🍅 tomato"),
                ],
                spans=[TextSpan(start=13, end=16, label="NUMBER")],
            ),
            user_anns=None,
        ),
        expected_from_user=TextcatChoiceExample(
            input_hash=0,
            task_hash=1,
            input=TextInput(text="Pick the odd one out."),
            meta={},
            extras={},
            answer="accept",
            server_anns=TextcatChoiceServerAnns(
                options=[
                    ChoiceOption(id="BANANA", text="🍌 banana"),
                    ChoiceOption(id="BROCCOLI", text="🥦 broccoli"),
                    ChoiceOption(id="TOMATO", text="🍅 tomato"),
                ],
                spans=[TextSpan(start=13, end=16, label="NUMBER")],
            ),
            user_anns=ChoiceUserAnns(accept=["BANANA"]),
        ),
    ),
}


_ExampleT = TypeVar("_ExampleT", bound=Example)


@pytest.mark.parametrize(
    "server_data, user_anns, expected_from_server, expected_from_user",
    CUSTOM_SUBTYPES_FROM_UNST_SERVER_TEST_CASES.values(),
    ids=CUSTOM_SUBTYPES_FROM_UNST_SERVER_TEST_CASES.keys(),
)
def test_custom_subtypes_from_unst_annotate(
    server_data: Dict[str, Any],
    user_anns: Dict[str, Any],
    expected_from_server: _ExampleT,
    expected_from_user: _ExampleT,
):
    # Check loading from server
    server_task = expected_from_server.__class__.from_unst_server(server_data)
    assert server_task == expected_from_server

    # Update annotations and check loading from user annotations
    data = dict(server_data)
    for key, val in user_anns.items():
        data[key] = val
    data["answer"] = "accept"
    user_anns_task = expected_from_user.__class__.from_unst_user(data)
    user_anns_task.server_anns = copy.deepcopy(server_task.server_anns)
    assert user_anns_task == expected_from_user


def test_extract_extras():

    server_data = {
        "text": "Apple updates its analytics service with new metrics",
        "spans": [{"start": 0, "end": 5, "label": "PRODUCT"}],
        INPUT_HASH_ATTR: 0,
        TASK_HASH_ATTR: 1,
        "extra1": "extra1",
        "extra2": True,
        "extra3": [1, 2, 3],
        "answer": "accept",
    }

    task = Example.from_unst_server(
        server_data,
        input_keys=["text"],
        server_ann_keys=["spans"],
    )
    for key in ["extra1", "extra2", "extra3"]:
        assert key in task.extras


def test_rehash():

    data = dict(
        input_hash=0,
        task_hash=1,
        meta={},
        extras={},
        input={"text": "test"},
        server_anns=None,
        user_anns={"spans": [{"start": 0, "end": 4, "label": "TEST"}]},
        answer="accept",
    )

    base_example = Example.from_dict(data)
    spans_example = SpansExample.from_dict(data)

    for example in (base_example, spans_example):
        assert example.input_hash == 0
        assert example.task_hash == 1

        example.rehash()
        assert example.input_hash == -508435184
        assert example.task_hash == 1096249858
