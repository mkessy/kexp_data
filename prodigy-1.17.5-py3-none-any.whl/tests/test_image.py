from pathlib import Path

import pytest

from prodigy.components.db import Database
from prodigy.core import Controller
from prodigy.recipes.image import image_manual

from .util import replace_config


@pytest.mark.skip(
    "Fails in v1.14+ because this arg is just required now, will raise TypeError, not SystemExit"
)
def test_label_not_passed_sysexit(dataset: str, images_path: Path):
    with pytest.raises(SystemExit):
        image_manual(dataset, str(images_path))


def test_label_not_passed_type_error(dataset: str, images_path: Path):
    with pytest.raises(TypeError):
        image_manual(dataset, str(images_path))


@pytest.mark.parametrize("remove_base64", [True, False])
def test_image_manual_base_settings(
    database: Database, dataset: str, images_path: Path, remove_base64: bool
):
    components = image_manual(
        dataset, str(images_path), label=["cat", "dog"], remove_base64=remove_base64
    )
    components["db"] = database
    ctrl = Controller.from_components("image.manual", components)
    questions = ctrl.get_questions("vincent")

    if database.db_id == "mysql" and not remove_base64:
        # This fails because of the MySQL string length limit. We're
        # dealing with a large image here, so that could fail.
        with pytest.raises(ValueError):
            ctrl.receive_answers(questions, "vincent")

        examples = database.get_dataset_examples(dataset)
        assert len(examples) == 0
    else:
        ctrl.receive_answers(questions, "vincent")
        examples = database.get_dataset_examples(dataset)
        assert len(examples) == 1
        for ex in examples:
            does_it_appear = "base64" not in ex["image"]
            assert does_it_appear == remove_base64


@pytest.mark.parametrize(
    "overrides",
    [
        {"image_manual_modes": ["rect"]},
        {"darken_image": 0.5},
        {"image_manual_font_size": 15.5},
    ],
)
def test_prodigy_settings_image_manual_dont_break(overrides, dataset, images_path):
    # This test was added to ensure that this does not happen again:
    # https://support.prodi.gy/t/bug-report-specifiying-image-manual-modes-crashes-with-pydantic-configerror/6742/3
    with replace_config(overrides) as _:
        image_manual(dataset, str(images_path), label=["cat", "dog"])
