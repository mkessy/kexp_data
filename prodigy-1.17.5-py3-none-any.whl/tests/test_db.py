import contextlib
import shutil
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

import pytest
from pydantic import BaseModel

from prodigy.components.db import (
    BulkCreateNotInTransaction,
    Database,
    Dataset,
    DatasetIsStructured,
    DatasetNotFound,
    DatasetNotStructured,
    _do_bulk_create,
)
from prodigy.structured_types import (
    Example,
    MissingAnswerError,
    StructuredExampleError,
    prodigy_example_type,
)
from prodigy.types import TaskType, TextSpan
from prodigy.util import INPUT_HASH_ATTR, TASK_HASH_ATTR, set_hashes


@contextlib.contextmanager
def make_tempdir():
    d = Path(tempfile.mkdtemp())
    yield d
    shutil.rmtree(str(d))


@pytest.fixture
def session_id():
    return "1337"


@pytest.fixture
def session_examples():
    return [
        {INPUT_HASH_ATTR: 1, TASK_HASH_ATTR: 37, "text": "first"},
        {INPUT_HASH_ATTR: 2, TASK_HASH_ATTR: 34, "text": "second"},
    ]


@pytest.fixture(scope="module")
def unst_task() -> TaskType:
    return {
        INPUT_HASH_ATTR: 1,
        TASK_HASH_ATTR: 1,
        "text": "Apple updates its analytics service with new metrics",
        "spans": [{"start": 0, "end": 5, "label": "ORG"}],
        "answer": "accept",
    }


@pytest.fixture(scope="session")
def st_task() -> Example:
    return Example(
        input_hash=1,
        task_hash=1,
        input={"text": "Apple updates its analytics service with new metrics"},
        meta={},
        extras={},
        answer="accept",
        server_anns=None,
        user_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
    )


@pytest.fixture(scope="session")
def many_examples() -> List[TaskType]:
    examples = []
    for i in range(999):
        examples.append(
            {INPUT_HASH_ATTR: i, TASK_HASH_ATTR: -i, "text": {str(i): True}}
        )
    return examples


@pytest.fixture(scope="session")
def many_st_tasks() -> List[Example]:
    examples = []
    for i in range(999):
        examples.append(
            Example(
                input_hash=i,
                task_hash=-i,
                input={"text": str(i)},
                server_anns=None,
                user_anns=None,
                answer="accept",
                meta={},
                extras={},
            )
        )
    return examples


class TextInput(BaseModel):
    text: str


class SpansAnnotations(BaseModel):
    spans: List[TextSpan]


@prodigy_example_type("tests.prodigy.db.SpansTask.v1")
class SpansTaskTest(Example):
    input: TextInput
    user_anns: Optional[SpansAnnotations]
    server_anns: Optional[SpansAnnotations]


def test_database_tables_exist(database: Database):
    table_names = database.db.get_tables()
    assert sorted(table_names) == [
        "dataset",
        "example",
        "link",
        "structured_example",
        "structured_input",
        "structured_link",
    ]


@pytest.mark.parametrize("structured", [True, False])
def test_add_dataset(database: Database, dataset: str, structured: bool):
    database.add_dataset(dataset, structured=structured)
    dataset_names = database.st_datasets if structured else database.datasets
    assert len(dataset_names) == 1
    assert dataset_names[0] == dataset


ADD_EXAMPES_TEST_CASES = {
    "base_spans_task": (
        Example(
            input_hash=1,
            task_hash=1,
            input={"text": "Apple updates its analytics service with new metrics"},
            meta={},
            extras={},
            answer="accept",
            server_anns=None,
            user_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
        ),
        {
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
        },
    ),
    "custom_spans_task": (
        SpansTaskTest(
            input_hash=1,
            task_hash=1,
            input=TextInput(
                text="Apple updates its analytics service with new metrics"
            ),
            meta={},
            extras={},
            answer="accept",
            server_anns=None,
            user_anns=SpansAnnotations(spans=[TextSpan(start=0, end=5, label="ORG")]),
        ),
        {
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
        },
    ),
}


@pytest.mark.parametrize(
    "st_task,unst_data",
    ADD_EXAMPES_TEST_CASES.values(),
    ids=ADD_EXAMPES_TEST_CASES.keys(),
)
@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_add_examples(
    database: Database,
    dataset: str,
    structured: bool,
    st_task: Example,
    unst_data: TaskType,
):
    with pytest.raises(DatasetNotFound):
        database.add_st_examples([st_task], dataset, "session")

    database.add_dataset(dataset, structured=structured)
    if structured:
        database.add_st_examples([st_task], dataset, "session")
        st_examples = database.get_st_dataset_examples(dataset)
        assert len(st_examples) == 1
        assert st_examples[0].__class__ == st_task.__class__
        assert st_examples[0] == st_task
        assert database.count_st_dataset(dataset) == len(st_examples)
        assert len(database.st_sessions) == 1
    else:
        with pytest.raises(DatasetNotStructured):
            database.add_st_examples([st_task], dataset, "session")
        database.add_examples([unst_data], datasets=[dataset])
        examples = database.get_dataset_examples(dataset)
        assert len(examples) == 1
        assert database.count_dataset(dataset) == len(examples)


GET_ST_EXAMPLES_FROM_UNST_TEST_CASES = {
    "invalid_missing_answer": (
        {
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
        },
        MissingAnswerError(
            {
                INPUT_HASH_ATTR: 1,
                TASK_HASH_ATTR: 1,
                "text": "Apple updates its analytics service with new metrics",
                "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            },
            Example,
        ),
        ["text"],
        None,
        ["spans"],
    ),
    "valid_spans_task": (
        {
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
            "answer": "accept",
        },
        Example(
            input_hash=1,
            task_hash=1,
            input={"text": "Apple updates its analytics service with new metrics"},
            meta={},
            extras={},
            answer="accept",
            server_anns=None,
            user_anns={"spans": [{"start": 0, "end": 5, "label": "ORG"}]},
        ),
        ["text"],
        None,
        ["spans"],
    ),
}


@pytest.mark.parametrize(
    "data, expected, input_keys, server_ann_keys, user_ann_keys",
    GET_ST_EXAMPLES_FROM_UNST_TEST_CASES.values(),
    ids=GET_ST_EXAMPLES_FROM_UNST_TEST_CASES.keys(),
)
def test_get_st_dataset_examples_from_unst(
    database: Database,
    dataset: str,
    data: Dict[str, Any],
    expected: Any,
    input_keys: Optional[List[str]],
    server_ann_keys: Optional[List[str]],
    user_ann_keys: Optional[List[str]],
):
    database.add_dataset(dataset)
    database.add_examples([data], [dataset])

    try:
        st_examples_from_unst = database.get_st_dataset_examples_from_unst(
            dataset,
            input_keys=input_keys,
            server_ann_keys=server_ann_keys,
            user_ann_keys=user_ann_keys,
        )
    except (StructuredExampleError) as e:
        assert isinstance(e, type(expected))
    else:
        assert len(st_examples_from_unst) == 1
        assert isinstance(st_examples_from_unst[0], type(expected))


@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_drop_dataset(
    database: Database, structured: bool, st_task: Example, unst_task: TaskType
):
    database.add_dataset("train", structured=structured)
    if structured:
        database.add_st_examples([st_task], "train", "session")
        assert "train" in database.st_datasets
        assert "train" not in database.datasets
    else:
        database.add_examples([unst_task], ["train"])
        assert "train" in database.datasets
        assert "train" not in database.st_datasets

    database.drop_dataset("train")
    assert "train" not in database.st_datasets
    assert "train" not in database.datasets


@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_get_dataset_names(database: Database, structured: bool):
    database.add_dataset("train", structured=structured)
    names = database.st_datasets if structured else database.datasets
    assert "train" in names


@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_get_hashes(database: Database, structured: bool):
    n_hashes = 100
    dataset_id = "hash_dev"
    hash_examples = [
        {TASK_HASH_ATTR: i * 10, INPUT_HASH_ATTR: i * 10, "text": str(i + 1)}
        for i in range(n_hashes)
    ]
    database.add_dataset(dataset_id, structured=structured)
    if structured:
        st_tasks = [
            Example.from_unst_user(
                {**data, "answer": "accept"},
                input_keys=["text"],
                server_ann_keys=[],
                user_ann_keys=[],
            )
            for data in hash_examples
        ]
        database.add_st_examples(st_tasks, dataset_id, "session")
        examples = database.get_st_dataset_examples(dataset_id)
        task_hashes = database.get_st_task_hashes(dataset_id)
        input_hashes = database.get_st_input_hashes(dataset_id)
    else:
        database.add_examples(hash_examples, datasets=[dataset_id])
        examples = database.get_dataset_examples(dataset_id)
        task_hashes = database.get_task_hashes(dataset_id)
        input_hashes = database.get_input_hashes(dataset_id)
    assert len(examples) == n_hashes
    assert len(task_hashes) == n_hashes
    assert len(input_hashes) == n_hashes


@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_orm_delete_many_examples_no_batching(
    database: Database,
    many_examples: List[TaskType],
    many_st_tasks: List[Example],
    dataset: str,
    session_id: str,
    structured: bool,
):
    database.add_dataset(dataset, structured=structured)
    if structured:
        database.add_st_examples(many_st_tasks, dataset, session_id)
        assert dataset in database.st_datasets
        session_examples = database.get_st_dataset_examples(
            dataset, session_ids=[session_id]
        )
    else:
        database.add_dataset(session_id, session=True)
        database.add_examples(many_examples, (dataset, session_id))
        assert dataset in database
        session_examples = database.get_sessions_examples([session_id])

    assert len(session_examples) == len(many_examples) == len(many_st_tasks)
    database.drop_dataset(dataset)
    assert dataset not in database
    assert dataset not in database.st_datasets


@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_orm_get_sessions_examples(
    database: Database,
    session_examples: List[TaskType],
    dataset: str,
    session_id: str,
    structured: bool,
):
    with pytest.raises(ValueError):
        database.get_sessions_examples(None)
    with pytest.raises(ValueError):
        database.get_sessions_examples([])

    other_session = "session_id_2"
    session_ids = [session_id, other_session]
    database.add_dataset(dataset, structured=structured)

    if structured:
        st_tasks = [
            Example.from_unst_user(
                {**data, "answer": "accept"},
                input_keys=["text"],
                server_ann_keys=[],
                user_ann_keys=[],
            )
            for data in session_examples
        ]
        database.add_st_examples(st_tasks, dataset, session_id)
        database.add_st_examples(st_tasks, dataset, session_id)
        found = database.get_st_dataset_examples(dataset, session_ids=session_ids)
        assert len(found) == len(session_examples) * len(session_ids)
    else:
        database.add_dataset(session_id, session=True)
        database.add_dataset(other_session, session=True)
        database.add_examples(session_examples, [dataset] + session_ids)
        found = database.get_sessions_examples(session_ids)
        # should find (sessions * examples) results
        assert len(found) == len(session_examples) * len(session_ids)

        # verify session_id is added to the examples
        for example in found:
            assert example["session_id"] in session_ids


def test_example_st_db_flow(
    database: Database, dataset: str, many_st_tasks: List[Example]
):
    """This test documents the flow of Structured Examples in the Database"""

    # Add a Structured Dataset
    database.add_dataset(dataset, structured=True)
    assert dataset in database.st_datasets

    # Validate the Dataset exists and is marked as structured
    db_dataset = database.get_st_dataset(dataset)
    assert isinstance(db_dataset, Dataset)
    assert db_dataset.name == dataset
    assert db_dataset.structured is True

    # Error is raised if tried to access as an unstructured dataset
    with pytest.raises(DatasetIsStructured):
        database.get_unst_dataset(dataset)

    session_ids = ["one", "two", "three", "four"]
    n_examples = len(many_st_tasks)
    chunk_size = int(n_examples / len(session_ids))

    # Add Structured Examples for 4 different sessions to the Structured Dataset
    for i, session_id in enumerate(session_ids):
        st_tasks = many_st_tasks[i * chunk_size : (i + 1) * chunk_size]
        assert len(st_tasks) == chunk_size
        database.add_st_examples(st_tasks, dataset, session_id=session_id)

    assert set(database.st_sessions) == set(session_ids)

    # Fetch examples from Structured Dataset
    dataset_st_tasks = database.get_st_dataset_examples(dataset)
    assert len(dataset_st_tasks) == chunk_size * len(session_ids)

    # Fetch examples by session_id and ensure the total number
    # of examples is the same as fetching all examples for the same dataset
    session_st_tasks = []
    for session_id in session_ids:
        st_tasks = database.get_st_dataset_examples(dataset, session_ids=[session_id])
        assert len(st_tasks) == chunk_size
        session_st_tasks += st_tasks
    assert len(session_st_tasks) == len(dataset_st_tasks)

    # Fetch count of datasets by session_id, should be the same as the lens above
    dataset_count = database.count_st_dataset(dataset)
    assert dataset_count == len(session_st_tasks)
    for session_id in session_ids:
        session_count = database.count_st_dataset(dataset, session_id=session_id)
        assert session_count == chunk_size


def test_do_bulk_create_fails_without_transaction(database: Database):
    datasets = [
        Dataset(name="test", meta=b"{}", session=False),
        Dataset(name="test2", meta=b"{}", session=False),
    ]
    with pytest.raises(BulkCreateNotInTransaction):
        _do_bulk_create(database, Dataset, datasets)
    with database.db.atomic():
        created = _do_bulk_create(database, Dataset, datasets)
    assert created[0].id == 1
    assert created[1].id == 2


def test_get_dataset_named_sessions(
    database: Database, dataset: str, session_examples: List[TaskType]
):
    database.add_dataset(dataset)
    database.add_dataset("session_one", session=True)
    database.add_dataset("session_two", session=True)

    database.add_examples(session_examples[:1], [dataset, "session_one"])
    database.add_examples(session_examples[1:], [dataset, "session_two"])
    assert database.get_dataset_sessions(dataset) == ["session_one", "session_two"]


def test_get_hashes_min_cadinality(database: Database, dataset: str):
    database.add_dataset(dataset)
    for sess in ["a", "b"]:
        examples = [
            set_hashes({"text": f"{i}", "_session_id": sess}) for i in range(100)
        ]
        database.add_examples(examples=examples, datasets=[dataset])
    assert len(database.get_hashes_min_cardinality(dataset, n=2)) == 100

    examples = [set_hashes({"text": f"{i}", "_session_id": "c"}) for i in range(50)]
    database.add_examples(examples=examples, datasets=[dataset])
    assert len(database.get_hashes_min_cardinality(dataset, n=2)) == 100
    assert len(database.get_hashes_min_cardinality(dataset, n=3)) == 50


def test_get_hash_count(database: Database, dataset: str):
    database.add_dataset(dataset)
    for i, sess in enumerate(["a", "b", "c"]):
        examples = [
            set_hashes({"text": f"{i}", "_session_id": sess}) for i in range(20)
        ]
        database.add_examples(examples=examples, datasets=[dataset])
        for ex in database.get_dataset_examples(dataset):
            assert database.get_hash_count(
                dataset, hash=ex["_task_hash"], kind="task"
            ) == (i + 1)


def test_iter_dataset_examples(
    database: Database, dataset: str, many_examples: List[TaskType]
):
    database.add_dataset(dataset)
    database.add_examples(many_examples, [dataset])
    examples_iterator = database.iter_dataset_examples(dataset)
    assert database.get_dataset_examples(dataset) == list(examples_iterator)
    with pytest.raises(StopIteration):
        next(examples_iterator)


def test_iter_st_dataset_examples(
    database: Database, dataset: str, many_st_tasks: List[Example]
):
    database.add_dataset(dataset, structured=True)
    database.add_st_examples(many_st_tasks, dataset, session_id="test")
    examples_iterator = database.iter_st_dataset_examples(dataset)
    assert database.get_st_dataset_examples(dataset) == list(examples_iterator)
    with pytest.raises(StopIteration):
        next(examples_iterator)
