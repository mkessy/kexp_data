from pathlib import Path

import pytest
import spacy
import srsly
from spacy.language import Language
from spacy.pipeline.textcat_multilabel import DEFAULT_MULTI_TEXTCAT_MODEL
from spacy.training import Example

from prodigy.recipes.ner import ner_model_annotate
from prodigy.recipes.review import get_review_stream
from prodigy.recipes.spans import spans_model_annotate
from prodigy.recipes.textcat import textcat_model_annotate
from prodigy.util import ANNOTATOR_ID_ATTR, SESSION_ID_ATTR


@pytest.fixture(scope="session")
def all_models_nlp():
    # First the spancat stuff, this is easy
    nlp = spacy.blank("en")

    ent_ruler = nlp.add_pipe("entity_ruler")
    patterns = [{"label": "GANGSTER", "pattern": "swindler"}]
    ent_ruler.add_patterns(patterns)

    span_ruler = nlp.add_pipe("span_ruler")
    patterns = [{"label": "GANGSTER", "pattern": "swindler"}]
    span_ruler.add_patterns(patterns)

    # Now for the verbose textcat route.
    doc = nlp("this is some text")
    doc.cats = {"foo": 1}
    config = {
        "threshold": 0.5,
        "model": DEFAULT_MULTI_TEXTCAT_MODEL,
    }

    textcat = nlp.add_pipe("textcat_multilabel", config=config)

    # This initialisation bit is important because the labels need to be known
    textcat.initialize(lambda: [Example(doc, doc)], nlp=nlp, labels=["foo", "bar"])

    # Now to add the component that actually forces the predictions
    @Language.component("force_preds")
    def force_preds(doc):
        # Do something to the doc here
        doc.cats = {"foo": 0.6, "bar": 0.7}
        return doc

    nlp.add_pipe("force_preds")

    return nlp


@pytest.fixture
def movie_data_path(datasets_path):
    return datasets_path / "movies_sample.jsonl"


@pytest.mark.parametrize("task", ["ner", "textcat", "spans"])
def test_sysexit_bad_component_name(
    all_models_nlp: Language, dataset: str, task: str, movie_data_path: Path
):
    # Bad component names should be caught in there
    with pytest.raises(SystemExit):
        if task == "ner":
            ner_model_annotate(
                dataset,
                all_models_nlp,
                movie_data_path,
                task,
                component="ohno",
            )
        if task == "textcat":
            textcat_model_annotate(
                dataset,
                all_models_nlp,
                movie_data_path,
                task,
                component="ohno",
            )
        if task == "spans":
            spans_model_annotate(
                dataset,
                all_models_nlp,
                movie_data_path,
                task,
                component="ohno",
            )


def run_base_recipes(
    all_models_nlp: Language, movie_data_path, dataset: str, task: str, name: str
):
    if task == "ner":
        ner_model_annotate(
            dataset,
            all_models_nlp,
            movie_data_path,
            model_alias=name,
            component="entity_ruler",
        )
    if task == "spans":
        spans_model_annotate(
            dataset,
            all_models_nlp,
            movie_data_path,
            model_alias=name,
            component="span_ruler",
        )
    if task == "textcat":
        textcat_model_annotate(
            dataset,
            all_models_nlp,
            movie_data_path,
            model_alias=name,
            component="textcat_multilabel",
            threshold=0.65,
        )


@pytest.mark.parametrize("name", ["some_name", "other_name"])
@pytest.mark.parametrize("task", ["ner", "spans", "textcat"])
def test_basic_dataset_addition(
    all_models_nlp: Language,
    database,
    dataset: str,
    task: str,
    name: str,
    movie_data_path: Path,
):
    # First run recipe like normal
    run_base_recipes(all_models_nlp, movie_data_path, dataset, task, name)

    # Check database content
    examples = database.get_dataset_examples(dataset)
    for ex_annot, ex_orig in zip(examples, srsly.read_jsonl(movie_data_path)):
        assert ex_annot["text"] == ex_orig["text"]
        assert ex_annot[SESSION_ID_ATTR] == name
        assert ex_annot[ANNOTATOR_ID_ATTR] == name
        assert ex_annot["answer"] == "accept"
        if task in ["ner", "spancat"]:
            assert "spans" in ex_annot
        if task in ["textcat"]:
            # Note that this holds true due to the threshold
            assert ex_annot["accept"] == ["bar"]

    # Run recipe again
    run_base_recipes(all_models_nlp, movie_data_path, dataset, task, name)

    # Now confirm no new datapoints got added.
    examples_again = database.get_dataset_examples(dataset)
    assert len(examples) == len(examples_again)

    # Run recipe again, but with another name
    run_base_recipes(all_models_nlp, movie_data_path, dataset, task, name="repeater")

    # Now confirm that these can be loaded in a `review` recipe.
    all_examples = {
        set_id: database.get_dataset_examples(set_id) for set_id in [dataset]
    }
    # Assert that examples have view_id set
    for set_id, examples in all_examples.items():
        for example in examples:
            if task == "ner":
                assert example["_view_id"] == "ner_manual"
            elif task == "spans":
                assert example["_view_id"] == "spans_manual"
            elif task == "textcat":
                assert (
                    example["_view_id"] == "choice"
                    or example["view_id"] == "classification"
                )

    review_stream = list(get_review_stream(all_examples))
    for item in review_stream:
        assert set(item["sessions"]) == set(["repeater", name])
