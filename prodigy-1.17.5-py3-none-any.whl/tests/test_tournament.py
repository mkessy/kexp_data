import numpy as np
import pytest

from prodigy.components.tournament import GlickoTournament, RandomTournament


@pytest.mark.parametrize("tournament", [RandomTournament, GlickoTournament])
def test_obvious_usecase(tournament):
    """Checks types and that obvious winner is tracked."""
    tournament = tournament(options="ab")

    # Simulate 10 matches
    for _ in range(10):
        i, j = tournament.top_k(2)
        assert isinstance(i, str)
        assert isinstance(j, str)
        tournament.update(i, j, outcome=i < j)

    # The smallest `i` will always be the winner.
    # So the best player should be player "a".
    assert tournament.top_k(1)[0] == "a"
    assert sum(tournament.player_counts.values()) == 20
    assert len(tournament.match_log)


def test_less_obvious_usecase():
    """Glicko should be able to very quickly pick up the winner"""
    tournament = GlickoTournament(options="abcdefghiklmnopqrstuvwxyz")

    for _ in range(100):
        i, j = tournament.top_k(2)
        tournament.update(i, j, outcome=i < j)

    assert tournament.top_k(1)[0] == "a"


def test_glicko_known_values():
    # The options don't matter in this test
    tournament = GlickoTournament(options="abc")

    # Known values taken from Glicko paper: http://www.glicko.net/glicko/glicko.pdf
    assert np.round(tournament._g(30), 4) == 0.9955
    assert np.round(tournament._g(100), 4) == 0.9531
    assert np.round(tournament._g(300), 4) == 0.7242
    assert np.round(tournament._E(1500, 1400, 30), 3) == 0.639
    assert np.round(tournament._E(1500, 1550, 100), 3) == 0.432
    assert np.round(tournament._E(1500, 1700, 300), 3) == 0.303
    r_j = np.array([1400, 1550, 1700])
    RD_j = np.array([30, 100, 300])
    s_j = np.array([1, 0, 0])
    r_delta, RD_prime = tournament._glicko_update(
        r=1500, RD=200, s_j=s_j, r_j=r_j, RD_j=RD_j
    )
    assert np.round(1500 + r_delta) == 1464
    assert np.round(RD_prime, 1) == 151.4
