import ml_datasets
import pytest

from prodigy.recipes.textcat import (
    add_text_classifier,
    get_predict_binary,
    get_update_binary,
)


def count_loss(examples, is_gold):
    loss = 0.0
    for score, eg in examples:
        if not eg["meta"].get("via_seed"):
            if is_gold(eg):
                loss += 1 - score
            else:
                loss += score
    return loss


@pytest.fixture
def nlp():
    en_core_web_sm = pytest.importorskip("en_core_web_sm")
    return en_core_web_sm.load()


@pytest.fixture
def label():
    return "INSULT"


@pytest.fixture
def stream():
    return [
        {"text": "A", "meta": {"via_seed": True}},
        {"text": "B", "meta": {"via_seed": True}},
        {"text": "A", "meta": {"via_seed": True}},
        {"text": "A", "meta": {"via_seed": True}},
        {"text": "A", "meta": {"via_seed": True}},
        {"text": "A", "meta": {}},
        {"text": "A", "meta": {}},
        {"text": "B", "meta": {}},
        {"text": "C", "meta": {}},
        {"text": "B", "meta": {}},
        {"text": "B", "meta": {}},
        {"text": "A", "meta": {}},
        {"text": "A", "meta": {}},
    ]


@pytest.mark.parametrize("accept_text", ["A", "B"])
def test_example_scores(nlp, label, stream, accept_text):
    component = add_text_classifier(nlp, label)
    predict = get_predict_binary(nlp, label)
    update = get_update_binary(nlp, component=component)
    scored_stream = predict(stream)
    loss_before = count_loss(scored_stream, lambda eg: eg["text"] == accept_text)
    for score, eg in predict(stream):
        answer = dict(eg)
        answer["answer"] = "accept" if eg["text"] == accept_text else "reject"
        update([answer])
    loss_after = count_loss(predict(stream), lambda eg: eg["text"] == accept_text)
    # Add a big margin for error, to make the test less flakey
    assert (loss_before * 1.5) > loss_after


def get_imdb(limit, long_text):
    train, test = ml_datasets.imdb(limit=limit)
    train_egs = []
    for text, label in train:
        if not long_text:
            text = text[:200]
        train_egs.append(
            {
                "text": text,
                "label": "POSITIVE",
                "answer": "accept" if label else "reject",
            }
        )
    test_egs = []
    for text, label in test:
        if not long_text:
            text = text[:200]
        test_egs.append(
            {
                "text": text,
                "label": "POSITIVE",
                "answer": "accept" if label else "reject",
            }
        )
    return train_egs, test_egs
