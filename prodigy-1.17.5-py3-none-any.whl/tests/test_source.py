import json
from io import TextIOWrapper
from pathlib import Path
from typing import IO, Dict, Iterator, List, Optional, Type, Union

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

import pytest
import srsly

from prodigy.components.db import Database
from prodigy.components.source import (
    BinaryFileSource,
    DatasetSource,
    FileSource,
    JSONLFileSource,
    ListSource,
    TextFileSource,
    load_audio_files,
    load_image_files,
    load_json_file,
    load_jsonl_file,
    load_noop,
    load_video_files,
)
from prodigy.util import set_hashes

from .util import make_tempdir


@pytest.fixture
def tmp_dir() -> Iterator[Path]:
    with make_tempdir() as path:
        yield path


def _to_jsonl(data: List[Dict]) -> str:
    return "\n".join([json.dumps(x) for x in data])


CONTENTS = {
    "file1.jsonl": _to_jsonl([{"text": "a"}, {"text": "b"}]),
    "file2.jsonl": _to_jsonl([{"text": "hi"}, {"text": "bye"}]),
    "file3.jsonl": _to_jsonl([{"text": "foo"}, {"text": "bar"}]),
    "subdir": {
        "subfile1.txt": "hello world",
        "subfile2.jsonl": _to_jsonl([{"text": "something"}]),
    },
}


@pytest.fixture
def file_contents() -> Dict:
    return CONTENTS


@pytest.fixture
def many_file_contents() -> Dict:
    out = {}
    for i in range(10000):
        out[f"dir{i}"] = CONTENTS
    return out


@pytest.fixture
def dataset(database: Database) -> str:
    return "hello"


@pytest.mark.parametrize("SourceType", [FileSource, TextFileSource])
@pytest.mark.parametrize("extension", [None, "jsonl", "json"])
def test_file_source_from_path(
    tmp_path: Path,
    SourceType: Type[Union[FileSource, TextFileSource]],
    file_contents: Dict,
    extension: Optional[str],
) -> None:
    _make_contents(tmp_path, file_contents)
    expected_files = _list_by_extension(file_contents, extension)
    source = SourceType.from_path(path=tmp_path, extension=extension)
    source_paths = [p.relative_to(tmp_path) for p in source._paths]
    source_paths.sort()
    expected_files.sort()
    assert source_paths == expected_files


@pytest.mark.parametrize("SourceType", [FileSource, TextFileSource])
def test_file_source_positions(
    tmp_path: Path,
    SourceType: Type[Union[FileSource, TextFileSource]],
    file_contents: Dict,
) -> None:
    _make_contents(tmp_path, file_contents)
    source = SourceType.from_path(path=tmp_path, extension=None)
    assert source.position == 0
    prev_position = 0
    for file_ in source:
        assert not file_.closed
        assert isinstance(file_, TextIOWrapper)
        prev_position = source.position
        _ = file_.read()
        file_.close()
        assert source.position > prev_position
        prev_position = source.position
    assert source.position != 0
    assert source.position == len(source)


@pytest.mark.parametrize("SourceType", [FileSource, TextFileSource])
def test_file_source_iter_without_open(
    tmp_path: Path,
    SourceType: Type[Union[FileSource, TextFileSource]],
    file_contents: Dict,
) -> None:
    # I'm not sure whether these semantics are really a great idea.
    # It's inexplicit but it's kind of nice to be able to just
    # iterate over the source. It also makes the backwards
    # compatibility much simpler.
    _make_contents(tmp_path, file_contents)
    source = SourceType.from_path(path=tmp_path, extension=None)
    files: List[IO] = []
    for i, file_ in enumerate(source):
        files.append(file_)
        # Files should close when new file is opened during iteration
        assert all([f.closed for f in files[:i]])
        assert not file_.closed
    # Files are closed after iteration
    for f in files:
        assert f.closed


@pytest.mark.parametrize("SourceType", [FileSource, TextFileSource])
def test_file_source_iter_with_open(
    tmp_path: Path,
    SourceType: Type[Union[FileSource, TextFileSource]],
    file_contents: Dict,
) -> None:
    _make_contents(tmp_path, file_contents)
    source = SourceType.from_path(path=tmp_path, extension=None)
    with source.open():
        files: List[IO] = []
        for i, file_ in enumerate(source):
            files.append(file_)
            # Files should close when new file is opened during iteration
            assert all([f.closed for f in files[:i]])
            assert not file_.closed
        # Files are closed after iteration, because we
        # opened explicitly
        assert all([f.closed for f in files[:-1]])

    # Just testing this because I had a bug where I wasn't
    # resetting it. Remove if implementation changes.
    assert source._open_files == []
    # Now files should be closed
    for f in files:
        assert f.closed


@pytest.mark.parametrize("SourceType", [FileSource, TextFileSource])
def test_file_source_copy_before_iteration(
    tmp_path: Path,
    SourceType: Type[Union[FileSource, TextFileSource]],
    file_contents: Dict,
) -> None:
    _make_contents(tmp_path, file_contents)
    source = SourceType.from_path(path=tmp_path, extension=None)
    source2 = source.copy()
    with source.open(), source2.open():
        for s1, s2 in zip(source, source2):
            s1_data = s1.read()
            s2_data = s2.read()
            assert s1_data == s2_data


@pytest.mark.parametrize("SourceType", [FileSource, TextFileSource])
def test_file_source_many_files_no_max_file_handles_exceeded(
    tmp_path: Path,
    SourceType: Union[FileSource, TextFileSource],
    many_file_contents: Dict,
) -> None:
    """Regression test for old implementation which kept all files open.
    With a lot of files, this could lead to OSError from too many file
    handles being open. Depends on the user's set `ulimit`. This test ensures
    a super large directory with a bunch of files doesn't just keep all of the files
    open forever."""
    _make_contents(tmp_path, many_file_contents)
    source = SourceType.from_path(path=tmp_path, extension=None)
    with source.open():
        for file_ in source:
            _ = file_.read()


@pytest.mark.parametrize(
    "file_contents",
    [[{"text": "hi"}, {"image": b"436"}, {"text": "foo"}], [], [{"data": "yes"}]],
)
def test_list_source(file_contents: List[Dict]) -> None:
    source = ListSource(file_contents)
    with source.open():
        prev_position = source.position
        assert source.position == 0
        for _ in source:
            assert source.position > prev_position
        assert source.position == len(source)
    assert source.position == len(source)
    with source.open():
        assert list(source) == file_contents
    source2 = source.copy()
    assert list(source2) == list(source)


@pytest.mark.parametrize("answer", ["all", "accept", "reject", "ignore"])
def test_dataset_source(
    database: Database,
    dataset: str,
    answer: Literal["all", "accept", "reject", "ignore"],
) -> None:
    database.add_dataset(dataset)
    database.add_examples(
        list(
            map(
                set_hashes,
                [
                    {"text": "foo", "answer": "reject"},
                    {"text": "bar", "answer": "ignore"},
                    {"text": "hi", "answer": "accept"},
                ],
            )
        ),
        [dataset],
    )
    source = DatasetSource(database, name=dataset, answer=answer)
    assert not source.is_open
    with source.open():
        assert len(source) == 3 if answer == "all" else 1
        prev_position = source.position
        assert source.position == 0
        for _ in source:
            assert source.position > prev_position
        assert source.position == len(source)
        assert source.position != 0
    source2 = source.copy()
    assert list(source2) == list(source)


def test_load_json(tmp_dir: Path) -> None:
    contents = [{"text": "foo"}, {"text": "bar"}]
    path = tmp_dir / "sample.json"
    with path.open("w", encoding="utf8") as file_:
        file_.write(json.dumps(contents))
    source = TextFileSource.from_path(path)
    tasks = list(load_json_file(source))
    assert tasks == contents


def test_load_jsonl(tmp_dir: Path) -> None:
    contents = [{"text": "foo"}, {"text": "bar"}]
    path = tmp_dir / "sample.jsonl"
    srsly.write_jsonl(path, contents)
    source = TextFileSource.from_path(path)
    tasks = list(load_jsonl_file(source))
    assert tasks == contents


def test_load_jsonl_source(tmp_dir: Path) -> None:
    contents = [{"text": "foo"}, {"text": "bar"}]
    path = tmp_dir / "sample.jsonl"
    srsly.write_jsonl(path, contents)
    source = JSONLFileSource.from_path(path)
    tasks = list(source)
    assert tasks == contents


def test_load_noop() -> None:
    contents = [{"text": "foo"}, {"text": "bar"}]
    source = ListSource(contents)
    assert list(load_noop(source)) == contents


@pytest.mark.parametrize("binary", ["Audio", "Image", "Video"])
def test_load_binary_files(
    binary: str, recordings_path: Path, images_path: Path, video_path: Path
) -> None:
    path, loader, expected = None, None, None
    if binary == "Audio":
        path = recordings_path
        loader = load_audio_files
        expected = "test_audio.mp3"
    elif binary == "Image":
        path = images_path
        loader = load_image_files
        expected = "test_image.jpg"
    elif binary == "Video":
        path = video_path
        loader = load_video_files
        expected = "test_video.mp4"
    assert path is not None
    assert loader is not None
    assert expected is not None
    source = BinaryFileSource.from_path(path)
    tasks = list(loader(source))
    assert len(tasks) == 1
    assert tasks[0]["meta"]["file"] == expected


def _list_by_extension(
    file_contents: Dict, extension: Optional[str], *, path: str = ""
) -> List[Path]:
    output: List[str] = []
    for key, value in file_contents.items():
        if isinstance(value, dict):
            output.extend(
                _list_by_extension(
                    value,
                    extension,
                    path=(Path(path) / key if path else Path(key)),
                )
            )
        elif extension is None or key.endswith(extension):
            output.append((Path(path) / key if path else Path(key)))
    return output


def _make_contents(parent: Path, file_contents) -> None:
    for name, file_or_dir_contents in file_contents.items():
        if isinstance(file_or_dir_contents, str):
            if not parent.exists():
                parent.mkdir(parents=True)
            with (parent / name).open("w", encoding="utf8") as file_:
                file_.write(file_or_dir_contents)
        else:
            _make_contents(parent / name, file_or_dir_contents)
