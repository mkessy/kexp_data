from pathlib import Path

import pytest
import srsly
import toolz

from prodigy.models import ner
from prodigy.recipes.data_utils import create_ner_annotations
from prodigy.util import NER_DEFAULT_INCORRECT_KEY, set_hashes


@pytest.fixture
def nlp():
    en_core_web_sm = pytest.importorskip("en_core_web_sm")
    return en_core_web_sm.load()


@pytest.fixture
def stream():
    loc = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    return srsly.read_jsonl(loc)


@pytest.fixture
def batch(stream):
    return list(toolz.take(10, stream))


@pytest.fixture
def texts(batch):
    return [eg["text"] for eg in batch]


@pytest.fixture
def model(nlp):
    return ner.EntityRecognizerModel(nlp=nlp)


def test_merge_spans():
    """Test function that groups entity annotations by input"""
    stream = [
        {
            "answer": "accept",
            "text": "a b c",
            "spans": [{"start": 0, "end": 1, "text": "a"}],
        },
        {
            "answer": "accept",
            "text": "a b c",
            "spans": [{"start": 2, "end": 3, "text": "b"}],
        },
        {"answer": "accept", "text": "d e f", "spans": []},
    ]
    merged = ner.merge_spans(stream)
    assert len(merged) == 2
    assert merged[0]["text"] == "a b c"
    assert merged[1]["text"] == "d e f"
    assert len(merged[0]["spans"]) == 2
    assert len(merged[1]["spans"]) == 0


@pytest.mark.parametrize(
    "a_label,b_label,answer,ignored,ents,incorrect_spans",
    [
        ("PERSON", "ORG", "accept", False, ["PERSON", "ORG"], []),
        ("PERSON", "ORG", "reject", False, [], ["PERSON", "ORG"]),
        ("PERSON", "ORG", "ignore", True, [], []),
        ("PERSON", "!ORG", "accept", False, ["PERSON"], ["ORG"]),
        ("PERSON", "!ORG", "reject", False, ["ORG"], ["PERSON"]),
        ("PERSON", "!ORG", "ignore", True, [], []),
        ("!PERSON", "!ORG", "accept", False, [], ["PERSON", "ORG"]),
        ("!PERSON", "!ORG", "reject", False, ["PERSON", "ORG"], []),
        ("!PERSON", "!ORG", "ignore", True, [], []),
    ],
)
def test_spans_to_spacy(nlp, a_label, b_label, answer, ignored, ents, incorrect_spans):
    """Ensure that the conversion to spaCy format goes well"""
    examples = [
        {
            "answer": answer,
            "text": "a b c",
            "spans": [
                {"start": 0, "end": 1, "text": "a", "label": a_label},
                {"start": 2, "end": 3, "text": "b", "label": b_label},
            ],
            "_input_hash": 123,
        }
    ]
    texts = {}
    ner_by_input, set_annotations = create_ner_annotations(
        examples, texts, validate=False, labels=set()
    )
    if ignored:
        assert len(ner_by_input.keys()) == 0
        assert len(texts.keys()) == 0
    else:
        assert set(ner_by_input.keys()) == {123}
        assert set(texts.keys()) == {123}
        doc = nlp(texts[123])
        set_annotations(ner_by_input[123], doc)
        assert [e.label_ for e in doc.ents] == ents
        assert [
            e.label_ for e in doc.spans[NER_DEFAULT_INCORRECT_KEY]
        ] == incorrect_spans


@pytest.mark.parametrize(
    "answer,ignored",
    [
        ("accept", False),
        ("reject", True),
        ("ignore", True),
    ],
)
def test_empty_spans_to_spacy(nlp, answer, ignored):
    """Ensure that the conversion to spaCy format goes well for empty spans"""
    # TODO: test with different setting of missing/outside default tags
    examples = [
        {
            "answer": answer,
            "text": "a b c",
            "spans": [],
            "_input_hash": 123,
        }
    ]
    texts = {}
    ner_by_input, set_annotations = create_ner_annotations(
        examples, texts, validate=False, labels=set()
    )  # TODO: incorrect_key
    if ignored:
        assert len(ner_by_input.keys()) == 0
        assert len(texts.keys()) == 0
    else:
        assert set(ner_by_input.keys()) == {123}
        assert set(texts.keys()) == {123}
        doc = nlp(texts[123])
        set_annotations(ner_by_input[123], doc)
        assert len(doc.ents) == 0
        assert len(doc.spans[NER_DEFAULT_INCORRECT_KEY]) == 0


def test_init_ner(nlp):
    model = ner.EntityRecognizerModel(nlp)
    for attr in ["labels", "nlp", "orig_nlp"]:
        assert hasattr(model, attr)


def test_ner_update(model, texts):
    stream = [set_hashes({"text": text, "spans": []}) for text in texts[:5]]
    predicted = [eg for score, eg in model(stream)]
    for i, eg in enumerate(predicted):
        eg["answer"] = "accept"
        for span in eg["spans"]:
            span["answer"] = "accept"
    loss1 = model.update(predicted)
    loss2 = model.update(predicted)
    assert loss2 < loss1


def test_call_ner(model, stream):
    stream = [set_hashes(eg) for eg in stream]
    n = 0
    for score, eg in model(stream):
        n += 1
        assert score >= 0.0
    assert n >= 1


def test_duplicate_entities(nlp):
    text = "I live in London and I think London is a great city."
    stream = [{"text": text, "_input_hash": 342}]
    model = ner.EntityRecognizerModel(nlp)
    doc = nlp(text)
    assert (len(doc.ents)) == 2
    assert [e.text for e in doc.ents] == ["London", "London"]
    assert [e.label_ for e in doc.ents] == ["GPE", "GPE"]
    tasks = list(model(stream))
    assert len(tasks) == 2
    for score, task in tasks:
        assert task["spans"][0]["text"] == "London"
