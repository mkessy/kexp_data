from pathlib import Path

import pytest
import srsly
from spacy_llm.util import assemble

from prodigy.components.llm import confirm_correct_task
from prodigy.components.preprocess import validate_component
from prodigy.recipes.llm.ab import PromptConfigPair, llm_tournament, load_template
from prodigy.recipes.llm.ner import llm_fetch_ner
from prodigy.recipes.llm.span import llm_fetch_spans
from prodigy.recipes.llm.terms import terms_llm_fetch
from prodigy.recipes.llm.textcat import llm_fetch_textcat
from prodigy.recipes.terms import to_patterns


@pytest.fixture
def movie_data_path(datasets_path):
    return datasets_path / "movies_sample.jsonl"


@pytest.mark.parametrize("write_to_db", [True, False])
@pytest.mark.parametrize("task", ["textcat", "spans", "ner"])
def test_fetch(
    database,
    dataset,
    task,
    spacy_llm_config_path,
    tmp_path,
    write_to_db,
    movie_data_path,
):
    """Make sure that we can write to a file and a dataset. Uses cached LLM results."""
    if write_to_db:
        out_path = f"dataset:{dataset}"
    else:
        out_path = tmp_path / "out.jsonl"

    if task == "ner":
        llm_fetch_ner(
            spacy_llm_config_path / "spacy-llm-ner.cfg", movie_data_path, out_path
        )
    if task == "spans":
        llm_fetch_spans(
            spacy_llm_config_path / "spacy-llm-textcat.cfg", movie_data_path, out_path
        )
    if task == "textcat":
        llm_fetch_textcat(
            spacy_llm_config_path / "spacy-llm-spancat.cfg", movie_data_path, out_path
        )

    if write_to_db:
        examples = database.get_dataset_examples("xxx")
    else:
        examples = list(srsly.read_jsonl(out_path))

    for i, ex in enumerate(srsly.read_jsonl(movie_data_path)):
        assert examples[i]["text"] == ex["text"]


@pytest.mark.parametrize(
    "config_path", Path("tests/config-files/spacy_llm").glob("*.cfg")
)
@pytest.mark.parametrize("override", [True, False])
def test_llm_validation_save_io_setting(config_path, override):
    """Make sure that we can detect the save_io setting."""
    config_overrides = {}
    config_overrides["components.llm.save_io"] = override
    nlp = assemble(config_path, overrides=config_overrides)

    if not override:
        with pytest.raises(SystemExit):
            validate_component(nlp=nlp, component="llm")
    else:
        validate_component(nlp=nlp, component="llm")


@pytest.mark.parametrize("task", ["textcat", "spans", "ner"])
def test_view_id_is_added_to_fetch(
    task, dataset, database, spacy_llm_config_path, movie_data_path
):
    view_id = []
    out_path = f"dataset:{dataset}"
    if task == "ner":
        llm_fetch_ner(
            spacy_llm_config_path / "spacy-llm-ner.cfg", movie_data_path, out_path
        )
        view_id = ["ner_manual"]
    if task == "spans":
        llm_fetch_spans(
            spacy_llm_config_path / "spacy-llm-textcat.cfg", movie_data_path, out_path
        )
        view_id = ["spans_manual"]
    if task == "textcat":
        llm_fetch_textcat(
            spacy_llm_config_path / "spacy-llm-spancat.cfg", movie_data_path, out_path
        )
        view_id = ["classification", "choice"]
    examples = database.get_dataset_examples("xxx")
    for ex in examples:
        assert ex["_view_id"] in view_id


@pytest.mark.parametrize("accept", [True, False])
def test_generated_terms_have_meta_tags(
    database, dataset, spacy_llm_config_path, tmpdir, accept
):
    """Bit of a smoke test, but the generated examples should contain meta info and should be patternizable."""
    config_path = spacy_llm_config_path / "terms.cfg"
    terms_llm_fetch(dataset, config_path, "skateboard tricks", auto_accept=accept)
    for ex in database.get_dataset_examples(dataset):
        assert ex["meta"]["topic"] == "skateboard tricks"
        if accept:
            assert ex["answer"] == "accept"
    file_out = tmpdir / "patterns.jsonl"
    if accept:
        to_patterns(dataset, "skateboard-tricks", file_out)
        orig_examples = database.get_dataset_examples(dataset)
        pattern_examples = srsly.read_jsonl(file_out)
        for ex_orig, ex_pat in zip(orig_examples, pattern_examples):
            assert ex_pat["label"] == "skateboard-tricks"
            assert ex_orig["text"] == ex_pat["pattern"]


def test_error_thrown_tournament_recipe(
    datasets_path, dataset, spacy_llm_config_path, prompts_path
):
    """Just to make sure we sysexit."""
    config_file = spacy_llm_config_path / "tournament.cfg"
    template_file = prompts_path / "template1.jinja2"
    inputs_path = datasets_path / "topics.jsonl"
    # The recipe demands at least two combinations. Passing two files won't work.
    with pytest.raises(SystemExit):
        llm_tournament(
            dataset,
            inputs_path=inputs_path,
            prompt_path=template_file,
            config_path=config_file,
        )


@pytest.mark.parametrize(
    "config,task",
    [("terms.cfg", "prodigy.TextPrompter.v1"), ("tournament.cfg", "prodigy.Terms.v1")],
)
def test_config_validation_triggers(spacy_llm_config_path, config, task):
    with pytest.raises(SystemExit):
        confirm_correct_task(spacy_llm_config_path / config, task)


def test_textprompter_parse(spacy_llm_config_path, prompts_path):
    config_file = spacy_llm_config_path / "tournament.cfg"
    template_file = prompts_path / "template1.jinja2"
    nlp = assemble(config_file)

    pcp = PromptConfigPair(
        template_path=template_file,
        config_path=config_file,
        template=load_template(template_file),
        nlp=nlp,
    )
    assert pcp.generate(**{"topic": "Python"}) == ""
