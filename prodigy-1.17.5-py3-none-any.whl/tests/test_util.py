import os
from typing import Any, List, Tuple

import pytest
import srsly

from prodigy._util import get_msg
from prodigy.env_vars import ENV_VARS
from prodigy.errors import ConfigError
from prodigy.protocols import ModelProtocol
from prodigy.types import ScoredStreamType, StreamType, TaskType
from prodigy.util import (
    add_global_config,
    b64_to_bytes,
    bytes_to_b64,
    combine_models,
    deep_merge_dicts,
    first_warning,
    get_labels,
    merge_configs,
    parse_env_overrides,
)

from .util import env_var_override, verbose_logging


def test_deep_merge_dicts():
    a = {
        "theme": "basic",
        "db_settings": {"sqlite": {"name": "prodigy.db"}},
        "custom_theme": {"labels": {"FOO": "red"}},
    }
    b = {
        "theme": "eighties",
        "labels": ["FOO", "BAR"],
        "db_settings": {"mysql": {"host": "localhost"}},
    }
    cfg = deep_merge_dicts(a, b)
    assert cfg["theme"] == b["theme"]
    assert cfg["labels"] == b["labels"]
    assert cfg["custom_theme"] == a["custom_theme"]
    assert cfg["db_settings"]["sqlite"] == a["db_settings"]["sqlite"]
    assert cfg["db_settings"]["mysql"] == b["db_settings"]["mysql"]


def test_add_global_config(capsys):
    global_cfg = {"theme": "basic", "db_settings": {"sqlite": {"name": "prodigy.db"}}}
    recipe_cfg = {"labels": ["FOO", "BAR"], "theme": "eighties"}
    cfg = add_global_config(global_cfg, recipe_cfg)
    assert cfg["theme"] == global_cfg["theme"]
    assert cfg["db_settings"] == global_cfg["db_settings"]
    assert cfg["labels"] == recipe_cfg["labels"]
    global_cfg = {"theme": "basic", "html_template": "foo"}
    recipe_cfg = {"labels": ["FOO", "BAR"], "theme": "eighties", "html_template": "bar"}
    cfg = add_global_config(global_cfg, recipe_cfg)
    # This should warn about global config overriding html_template recipe setting
    captured = capsys.readouterr()
    assert "'html_template' defined in recipe is overwritten" in captured.out


def test_merge_configs():
    global_cfg = {
        "theme": "basic",
        "db_settings": {"sqlite": {"name": "prodigy.db"}},
        "batch_size": 10,
    }
    recipe_cfg = {"labels": ["FOO", "BAR"]}
    overrides = {"batch_size": 7}
    cfg = merge_configs(global_cfg, recipe_cfg, overrides)
    assert cfg["theme"] == global_cfg["theme"]
    assert cfg["db_settings"] == global_cfg["db_settings"]
    assert cfg["labels"] == recipe_cfg["labels"]
    assert cfg["batch_size"] == overrides["batch_size"]


def test_merge_configs_does_not_log_sensitive_info(caplog):

    with verbose_logging():
        global_cfg = {
            "theme": "basic",
            "db_settings": {"sqlite": {"name": "prodigy.db"}},
            "batch_size": 10,
        }
        recipe_cfg = {"labels": ["FOO", "BAR"]}
        overrides = {
            "batch_size": 7,
            "db_settings": {"sqlite": {"name": "prodigy_custom_db.db"}},
        }
        cfg = merge_configs(global_cfg, recipe_cfg, overrides)
        assert cfg["theme"] == global_cfg["theme"]
        assert cfg["db_settings"] == global_cfg["db_settings"]
        assert cfg["labels"] == recipe_cfg["labels"]
        assert cfg["batch_size"] == overrides["batch_size"]

        assert "batch_size" in caplog.text
        assert "7" in caplog.text
        assert "db_settings" in caplog.text
        assert "sqlite" in caplog.text
        assert "name" in caplog.text
        assert "prodigy.db" not in caplog.text


@pytest.mark.parametrize("value", ['{"batch_size": 10, "labels": ["FOO", "BAR"]}'])
def test_parse_env_overrides(value):

    os.environ[ENV_VARS.CONFIG_OVERRIDES] = value
    assert parse_env_overrides() == srsly.json_loads(value)
    del os.environ[ENV_VARS.CONFIG_OVERRIDES]


@pytest.mark.parametrize(
    "value", ["{batch_size: 10}", "{'foo': 'bar'}", '["foo", "bar"]']
)
def test_parse_env_overrides_bad(value):
    os.environ[ENV_VARS.CONFIG_OVERRIDES] = value
    with pytest.raises(ConfigError):
        parse_env_overrides()
    del os.environ[ENV_VARS.CONFIG_OVERRIDES]


def test_base64_utils():
    """Test that base64 conversion works cross-platform."""
    data = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/2wCEABwcHBwcHDAcHDBEMDAwRFxEREREXHRcXFxcXHSMdHR0dHR0jIyMjIyMjIyoqKioqKjExMTExNzc3Nzc3Nzc3NwBIiQkODQ4YDQ0YOacgJzm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5v/AABEIABUAFAMBIgACEQEDEQH/xABYAAEBAQEAAAAAAAAAAAAAAAAAAQUGEAACAQUAAwEAAAAAAAAAAAAAAQIDBBESISJBcaEBAQAAAAAAAAAAAAAAAAAAAAARAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AOgnUVOUU0/J44i7rdQ9tZJUkoQc2s6rPDPds6l5C4U5paPmfz4BqAiWOACkwABQAB//2Q=="
    bytes_data = b64_to_bytes(data)
    new_data = bytes_to_b64(bytes_data, "image/jpeg")
    assert data == new_data


def test_first_warning():
    # There is no warning to be raised first
    assert not first_warning("specific_warning_name", lambda: False)
    # This is the first time that the indicator is True
    assert first_warning("specific_warning_name", lambda: True)
    # And that means that this is no longer the first warning
    assert not first_warning("specific_warning_name", lambda: True)
    # This should also never trigger again
    assert not first_warning("specific_warning_name", lambda: False)


def test_capture_traceback(capsys):
    msg = get_msg()

    # No logging set? Then we should not see dividers.
    with pytest.raises(SystemExit):
        msg.fail("oh no!", exits=True)
    captured = capsys.readouterr().out
    assert "Traceback" not in captured
    assert "Locals" not in captured

    # # Just logging set? Then traceback, but no locals.
    with env_var_override(ENV_VARS.LOGGING, "basic"):
        with pytest.raises(SystemExit):
            msg.fail("oh noes!", exits=True)
    captured = capsys.readouterr().out
    assert "Traceback" in captured
    assert "Locals" not in captured

    # Now we should see both
    with env_var_override(ENV_VARS.LOGGING, "basic"):
        with env_var_override(ENV_VARS.LOG_LOCALS, "1"):
            with pytest.raises(SystemExit):
                msg.fail("oh no no noes!", exits=True)
    captured = capsys.readouterr().out

    assert "Traceback" in captured
    assert "Locals" in captured


def test_get_label(tmp_path):
    assert get_labels(None) == []
    assert get_labels("foo,bar") == ["foo", "bar"]
    path = tmp_path / "labels.txt"
    path.write_text("foo\nbar")
    assert get_labels(str(path)) == ["foo", "bar"]


class ModelOne(ModelProtocol):
    def __call__(self, input_data: StreamType) -> ScoredStreamType:
        for eg in input_data:
            yield (eg["num"] + 1.0, eg)

    def predict(self, input_data: StreamType) -> ScoredStreamType:
        for eg in input_data:
            yield (eg["num"] + 1.0, eg)

    def update(self, input_data: List[TaskType]) -> float:
        return 0.2


class ModelTwo(ModelProtocol):
    def __call__(self, input_data: StreamType) -> ScoredStreamType:
        for eg in input_data:
            yield (eg["num"] * 2.0, eg)

    def predict(self, input_data: StreamType) -> ScoredStreamType:
        for eg in input_data:
            yield (eg["num"] * 2.0, eg)

    def update(self, input_data: List[TaskType]) -> float:
        return 0.2


test_cases: List[Tuple[Any, Any]] = [
    (ModelOne(), ModelTwo()),
    ((ModelOne().predict, ModelOne().update), ModelTwo()),
    (ModelOne(), (ModelTwo().predict, ModelTwo().update)),
    ((ModelOne().predict, ModelOne().update), (ModelTwo().predict, ModelTwo().update)),
]


@pytest.mark.parametrize("model1, model2", test_cases)
def test_combine_models(model1, model2):
    input_data = ({"num": num} for num in [1, 2, 3])
    expected_predict = [
        (2.0, {"num": 1}),
        (2.0, {"num": 1}),
        (3.0, {"num": 2}),
        (4.0, {"num": 2}),
        (4.0, {"num": 3}),
        (6.0, {"num": 3}),
    ]
    expected_update = 0.4
    stream = (eg for eg in input_data)
    combined_predict, combined_update = combine_models(model1, model2)
    predictions = list(combined_predict(stream))
    assert predictions == expected_predict
    assert combined_update([]) == expected_update
