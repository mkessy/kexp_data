import pytest

from prodigy.components.routers import no_overlap
from prodigy.components.validate import (
    SCHEMAS,
    Validator,
    validate_config,
    validate_recipe,
)
from prodigy.core import _session_factory

good_tasks = [
    ("text", {"text": "hello world", "custom_property": 1234}),
    (
        "ner",
        {
            "text": "Apple updates its analytics service with new metrics",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
        },
    ),
    (
        "ner_manual",
        {
            "text": "Hello Apple",
            "tokens": [
                {"text": "Hello", "start": 0, "end": 5, "id": 0},
                {"text": "Apple", "start": 6, "end": 11, "id": 1},
            ],
            "spans": [
                {
                    "start": 6,
                    "end": 11,
                    "label": "ORG",
                    "token_start": 1,
                    "token_end": 1,
                }
            ],
        },
    ),
    (
        "dep",
        {
            "text": "Hello Apple",
            "tokens": [
                {"text": "Hello", "start": 0, "end": 5, "id": 0},
                {"text": "Apple", "start": 6, "end": 11, "id": 1},
            ],
            "arcs": [{"head": 1, "child": 0, "label": "compound"}],
        },
    ),
    ("image", {"image": "some_image.jpg"}),
    (
        "image",
        {
            "image": "some_image.jpg",
            "width": 800,
            "height": 600,
            "spans": [
                {
                    "label": "PERSON",
                    "color": "magenta",
                    "points": [
                        [150, 80],
                        [270, 100],
                        [250, 200],
                        [170, 240],
                        [100, 200],
                    ],
                }
            ],
        },
    ),
    ("image_manual", {"image": "some_image.jpg", "width": 800, "height": 600}),
    ("classification", {"text": "Apple updates its service", "label": "TECH"}),
    ("classification", {"image": "hotdog.jpg", "label": "food"}),
    (
        "classification",
        {
            "text": "Apple updates its analytics service with new metrics",
            "label": "CORRECT",
            "spans": [{"start": 0, "end": 5, "label": "ORG"}],
        },
    ),
    (
        "choice",
        {
            "text": "This is a text",
            "label": "LABEL",
            "options": [
                {"id": 1, "text": "Apple", "style": {"background": "#ff6666"}},
                {"id": 2, "text": "Google"},
                {"id": 3, "text": "McDonalds"},
            ],
        },
    ),
    (
        "compare",
        {
            "id": 1,
            "input": {"text": "NLP"},
            "accept": {"text": "Natural Language Processing"},
            "reject": {"text": "Neuro-Linguistic Programming"},
            "mapping": {"A": "accept", "B": "reject"},
        },
    ),
    (
        "html",
        {
            "html": '<iframe width="560" height="315" src="https://www.youtube.com/embed/vKmrxnbjlfY"></iframe>',
            "text": "Baby sloth yawning",
        },
    ),
    (
        "ner",
        {
            "pages": [
                {
                    "text": "Apple updates its analytics service with new metrics",
                    "spans": [{"start": 0, "end": 5, "label": "ORG"}],
                    "view_id": "ner",
                    "_input_hash": 1,
                    "_task_hash": 2,
                },
                {
                    "text": "Hello world",
                    "spans": [],
                    "view_id": "ner",
                    "_input_hash": 3,
                    "_task_hash": 4,
                },
            ]
        },
    ),
    (
        "text",
        {
            "pages": [
                {
                    "text": "Apple updates its analytics",
                    "view_id": "text",
                    "_input_hash": 1,
                    "_task_hash": 2,
                },
                {
                    "text": "Hello world",
                    "view_id": "text",
                    "_input_hash": 3,
                    "_task_hash": 4,
                },
            ],
            "page_titles": ["one", "two"],
        },
    ),
]


bad_tasks = [
    ("text", {"custom_property": 1234}),
    ("text", {"text": 1234}),
    ("ner", {}),
    ("ner", {"text": "Apple", "spans": {"start": 0, "end": 5, "label": "ORG"}}),
    (
        "ner_manual",
        {
            "text": "Hello Apple",
            "spans": [
                {
                    "start": 6,
                    "end": 11,
                    "label": "ORG",
                    "token_start": 1,
                    "token_end": 1,
                }
            ],
        },
    ),
    (
        "ner_manual",
        {
            "text": "Hello Apple",
            "tokens": [
                {"text": "Hello", "start": 0, "end": 5},
                {"text": "Apple", "start": 6, "end": 11},
            ],
        },
    ),
    (
        "ner_manual",
        {
            "text": "Hello Apple",
            "tokens": [
                {"text": "Hello", "start": 0, "end": 5, "id": 0},
                {"text": "Apple", "start": 6, "end": 11, "id": 1},
            ],
            "spans": [{"start": 6, "end": 11, "label": "ORG", "token_start": 1}],
        },
    ),
    (
        "choice",
        {"text": "This is a text", "options": [{"text": "Apple"}, {"text": "Google"}]},
    ),
    (
        "choice",
        {
            "text": "This is text about Google.",
            "label": "LABEL",
            "options": [
                {"id": "non-unique-name", "text": "Apple"},
                {"id": "non-unique-name", "text": "Google"},
            ],
        },
    ),
    (
        "image",
        {
            "image": "some_image.jpg",
            "width": 800,
            "height": 600,
            "spans": [
                {
                    "label": "PERSON",
                    "points": [150, 80, 270, 100, 250, 200, 170, 240, 100, 200],
                }
            ],
        },
    ),
    ("image_manual", {"text": "some_image.jpg"}),
    (
        "text",
        {
            "pages": [
                {
                    "text": "Apple updates its analytics",
                    "_input_hash": 1,
                    "_task_hash": 2,
                },
                {
                    "text": "Hello world",
                    "view_id": "text",
                    "_input_hash": 3,
                    "_task_hash": 4,
                },
            ]
        },
    ),
    (
        "image_manual",
        {
            "pages": [
                {
                    "text": "Apple updates its analytics",
                    "view_id": "image_manual",
                    "_input_hash": 1,
                    "_task_hash": 2,
                },
                {
                    "image": "image.jpg",
                    "view_id": "image_manual",
                    "_input_hash": 3,
                    "_task_hash": 4,
                },
            ]
        },
    ),
    (
        "text",
        {
            "pages": [
                {
                    "text": "Apple updates its analytics",
                    "view_id": "text",
                    "_input_hash": 1,
                    "_task_hash": 2,
                },
                {
                    "text": "Hello world",
                    "view_id": "text",
                    "_input_hash": 3,
                    "_task_hash": 4,
                },
            ],
            "page_titles": ["one", "two", "three"],
        },
    ),
]

default_config = {
    "theme": "basic",
    "custom_theme": {},
    "batch_size": 10,
    "port": 8080,
    "host": "localhost",
    "cors": True,
    "db": "sqlite",
    "db_settings": {},
    "validate": True,
    "auto_create": True,
    "show_stats": False,
    "hide_meta": False,
    "show_flag": False,
    "instructions": None,
    "swipe": False,
    "split_sents_threshold": False,
    "diff_style": "words",
    "html_template": None,
    "card_css": None,
    "writing_dir": "ltr",
    "hide_true_newline_tokens": False,
    "ner_manual_require_click": False,
    "ner_manual_label_style": "list",
    "choice_style": "single",
    "choice_auto_accept": False,
    "darken_image": 0,
    "show_bounding_box_center": False,
    "preview_bounding_boxes": False,
    "shade_bounding_boxes": False,
}


bad_config = [
    {"port": "8080"},
    {"db_settings": [1, 2, 3]},
    {"choice_style": None},
    {"instructions": True},
    {"darken_image": True},
    {"label": ["PERSON", "ORG"]},
    {"labels": "PERSON, ORG"},
]


@pytest.mark.parametrize("view_id", SCHEMAS.keys())
def test_schema_loading_validation(view_id):
    Validator(view_id)


@pytest.mark.parametrize("view_id,task", good_tasks)
def test_validate_good_tasks(view_id, task):
    task["_input_hash"] = 0
    task["_task_hash"] = 1
    validator = Validator(view_id)
    validator.check(task)


@pytest.mark.parametrize("view_id,task", bad_tasks)
def test_validate_bad_tasks(view_id, task):
    task["_input_hash"] = 0
    task["_task_hash"] = 1
    validator = Validator(view_id)
    with pytest.raises(SystemExit):
        validator.check(task)


def test_validate_config():
    validate_config(default_config)


@pytest.mark.parametrize("options", bad_config)
def test_validate_config_fails(options):
    config = dict(default_config)
    config.update(options)
    with pytest.raises(SystemExit):
        validate_config(config)


good_components = [
    # fmt: off
    {"dataset": "foo", "stream": [], "view_id": "text", "update": lambda x: x},
    {"dataset": "foo", "stream": [], "view_id": "text", "task_router": no_overlap},
    {"dataset": "foo", "stream": [], "view_id": "text", "session_factory": _session_factory},
    {"dataset": False, "stream": [], "view_id": "ner", "config": {"labels": ["X"]}},
    # fmt: on
]

bad_components = [
    {"stream": [], "view_id": "text"},  # no dataset
    {"dataset": ["foo"], "stream": [], "view_id": "ner"},  # wrong dataset
    {"dataset": "foo", "strean": [], "view_id": "text"},  # additional properties,
    {"dataset": "foo", "stream": [], "view_id": "xyz"},  # invalid view_id
    {"dataset": "foo", "stream": [], "view_id": "text", "update": {"a": "b"}},
    {"dataset": "foo", "stream": [], "view_id": "ner", "config": bad_config[-1]},
    {"dataset": "foo", "stream": None, "view_id": "text"},
]


@pytest.mark.parametrize("components", good_components)
def test_validate_recipe_components(components):
    validate_recipe("test", components)


@pytest.mark.parametrize("components", bad_components)
def test_validate_recipe_components_fails(components):
    with pytest.raises(SystemExit):
        validate_recipe("test", components)
