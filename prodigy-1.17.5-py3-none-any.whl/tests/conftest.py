import contextlib
import os
import tempfile
from pathlib import Path
from typing import Any, Generic, Iterator, List, Type, TypeVar
from typing_extensions import Protocol

import pytest
import spacy
from pytest import FixtureRequest as _FixtureRequest
from pytest import TempPathFactory
from pytest_lazyfixture import lazy_fixture
from spacy.language import Language

from prodigy.components.db import DB_TABLES, Database, connect
from prodigy.components.openai import (
    OpenAISuggester,
    PromptExample,
    ResponseParserProtocol,
    get_api_credentials,
    load_template,
)
from prodigy.util import ENV_VARS, INPUT_HASH_ATTR, TASK_HASH_ATTR

from .util import config_overrides

_T = TypeVar("_T")
_PromptExampleT = TypeVar("_PromptExampleT", bound=PromptExample)


class FixtureRequest(_FixtureRequest, Generic[_T]):
    param: _T


# Stuff to register the 'slow' mark. Copy-pasted from spaCy.
def pytest_addoption(parser):
    parser.addoption("--slow", action="store_true", help="include slow tests")


def pytest_runtest_setup(item):
    def getopt(opt):
        # To avoid this, we need to pass a default value.
        # We default to False, i.e., we act like all the
        # options weren't given.
        return item.config.getoption(f"--{opt}", False)

    for opt in ["slow", "manual"]:
        if opt in item.keywords and not getopt(opt):
            pytest.skip(f"need --{opt} option to run")


# Make sure that prodigy home state is written into a safe location.
# This controls where prodigy.json is found and where trash backups
# are placed.
os.environ[ENV_VARS.HOME] = tempfile.gettempdir()


def has_postgres_deps() -> bool:  # pyright: ignore
    try:
        import psycopg  # noqa
        import psycopg2  # noqa
        from pytest_postgresql.executor import PostgreSQLExecutor  # noqa

        return True
    except ImportError:
        return False


def has_mysql_deps() -> bool:  # pyright: ignore
    try:
        import MySQLdb  # noqa
        import pymysql  # noqa
        from pytest_mysql import factories  # noqa
        from pytest_mysql.executor import MySQLExecutor  # noqa

        return True
    except ImportError:
        return False


@pytest.fixture(scope="session")
def test_db_name() -> str:
    return "prodigy-test-db"


@pytest.fixture(scope="session", name="sqlite")
def database_sqlite(
    tmp_path_factory: TempPathFactory,
    test_db_name: str,
) -> Iterator[Database]:
    """Session Scoped SQLite test fixture.
    Yields a Prodigy Database instance pointed at a SQLite DB
    in a tempfile that gets cleaned up after the test run finishes."""
    # NOTE: rather than use an in-memory SQLite db, we generate a temporary
    # file for each fixture injection. This is because calling close/reconnect
    # on an in-memory database will drop any existing data.
    #
    # The prodigy app routinely closes or reconnects to the DB to ensure connections
    # don't time out and result in weird errors.
    with _make_sqlite_database(tmp_path_factory, test_db_name) as db:
        yield db


@contextlib.contextmanager
def _make_sqlite_database(
    tmp_path_factory: TempPathFactory, test_db_name: str
) -> Iterator[Database]:
    db_folder = tmp_path_factory.mktemp("sqlite")
    db_filename = f"{test_db_name}.db"
    db_file = db_folder / db_filename
    db_settings = {"sqlite": {"name": db_filename, "path": str(db_folder)}}

    with config_overrides({"db": "sqlite", "db_settings": db_settings}):
        prodigy_db = connect()
        yield prodigy_db
        try:
            if db_file.exists():
                os.remove(db_file)
        except (PermissionError, FileNotFoundError):
            # In our CI, we may get PermissionError on this if the file is still
            # noted as being used, e.g. by multiple tests.
            # Also the file might be already removed. We don't
            # need to fail on either of these conditions so just pass
            pass


def database_mysql_factory():
    _database_mysql = None  # type: ignore

    if has_mysql_deps():

        import pymysql
        from pytest_mysql.executor import MySQLExecutor

        @pytest.fixture(scope="session", name="mysql")
        def _database_mysql(
            mysql_proc: "MySQLExecutor",
        ) -> Iterator[Database]:
            """Session Scoped MySQL test fixture.
            Yields a Prodigy Database instance pointed at an open MySQL database."""
            # Default database name is "test" but that's not available on the MySQLExecutor
            # fixture so we hardcode it here

            Path(mysql_proc.base_directory).mkdir(parents=True, exist_ok=True)

            dbname = "test"
            # Ensure the "test" Database is created in the mysql test server
            _conn = pymysql.connect(
                host=mysql_proc.host,
                port=mysql_proc.port,
                user=mysql_proc.user,
                autocommit=True,
            )
            with _conn.cursor() as _cursor:
                _cursor.execute(f"CREATE DATABASE IF NOT EXISTS {dbname}")
            _conn.close()

            db_settings = {
                "mysql": {
                    "user": mysql_proc.user,
                    "host": mysql_proc.host,
                    "port": mysql_proc.port,
                    "database": dbname,
                }
            }

            with config_overrides({"db": "mysql", "db_settings": db_settings}):
                prodigy_db = connect()
                yield prodigy_db
                if ENV_VARS.CONFIG_OVERRIDES in os.environ:
                    del os.environ[ENV_VARS.CONFIG_OVERRIDES]

    return _database_mysql


def database_postgresql_factory():
    _database_postgresql = None  # type: ignore

    if has_postgres_deps():
        import psycopg2
        from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
        from pytest_postgresql.executor import PostgreSQLExecutor

        @pytest.fixture(scope="session", name="postgresql")
        def _database_postgresql(
            postgresql_proc: "PostgreSQLExecutor",
        ) -> Iterator[Database]:
            """Session Scoped PostgreSQL test fixture.
            Yields a Prodigy Database instance pointed at an open PostgreSQL database.
            """
            Path(postgresql_proc.datadir).mkdir(parents=True, exist_ok=True)

            # Ensure the "tests" Database is created in the test server
            _raw_conn_info = "user={user} host={host} port={port}".format(
                user=postgresql_proc.user,
                host=postgresql_proc.host,
                port=postgresql_proc.port,
            )
            _conn = psycopg2.connect(_raw_conn_info)
            _conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
            with _conn.cursor() as _cursor:
                _cursor.execute(f"CREATE DATABASE {postgresql_proc.dbname}")
            _conn.close()

            db_settings = {
                "postgresql": {
                    "user": postgresql_proc.user,
                    "password": postgresql_proc.password,
                    "host": postgresql_proc.host,
                    "port": postgresql_proc.port,
                    "dbname": postgresql_proc.dbname,
                }
            }

            with config_overrides({"db": "postgresql", "db_settings": db_settings}):
                prodigy_db = connect()
                yield prodigy_db

    return _database_postgresql


database_mysql = database_mysql_factory()
database_postgresql = database_postgresql_factory()

database_lazy_params = [lazy_fixture("sqlite")]
if database_mysql is not None:
    database_lazy_params.append(lazy_fixture("mysql"))
if database_postgresql is not None:
    database_lazy_params.append(lazy_fixture("postgresql"))


@pytest.fixture(params=database_lazy_params)
def database(
    request: FixtureRequest[Database],
) -> Iterator[Database]:
    """Parametrized Function scoped Fixture for setting up a SQLite, MySQL,
    or PostgreSQL database for testing all supported database dialects.
    Cleans tables and resets db_settings for each test."""

    database_proc = request.param
    if not database_proc:
        pytest.skip("dependencies not installed")

    peewee_proxy = database_proc.db
    peewee_proxy.drop_tables(DB_TABLES)
    peewee_proxy.create_tables(DB_TABLES, safe=True)
    yield database_proc


@pytest.fixture(autouse=True)
def autouse_sqlite_db_fixture(
    request: FixtureRequest, tmp_path_factory: TempPathFactory, test_db_name: str
):
    """Creates a temporary SQLite database for each test that doesn't use the
    database fixture. Stops calls to `db = connect()` from using your local SQLite
    database (or whatever else is configured in your prodigy.json)
    """
    with _make_sqlite_database(tmp_path_factory, test_db_name) as _database:
        peewee_proxy = _database.db
        peewee_proxy.drop_tables(DB_TABLES)
        peewee_proxy.create_tables(DB_TABLES, safe=True)
        yield


@pytest.fixture
def dataset():
    return "xxx"


@pytest.fixture
def tests_path():
    return Path(__file__).parent


@pytest.fixture()
def datasets_path():
    return Path(__file__).parent / "sample_datasets"


@pytest.fixture()
def recordings_path():
    return Path(__file__).parent / "recordings"


@pytest.fixture()
def images_path():
    return Path(__file__).parent / "images"


@pytest.fixture()
def video_path():
    return Path(__file__).parent / "videos"


@pytest.fixture()
def config_path():
    return Path(__file__).parent / "config-files"


@pytest.fixture()
def prompts_path():
    return Path(__file__).parent / "prompts"


@pytest.fixture()
def spacy_llm_config_path():
    return Path(__file__).parent / "config-files" / "spacy-llm"


@pytest.fixture()
def movies_path(datasets_path: Path):
    return datasets_path / "movies_sample.jsonl"


@pytest.fixture
def max_sessions():
    return 4


@pytest.fixture
def view_id():
    return "classification"


@pytest.fixture
def stream():
    return [{INPUT_HASH_ATTR: 0, TASK_HASH_ATTR: 1, "text": "Test", "label": "LABEL"}]


@pytest.fixture
def recipe_config(dataset, view_id, stream, database, max_sessions):
    database.add_dataset(dataset)
    return {
        "dataset": dataset,
        "view_id": view_id,
        "stream": stream,
        "update": None,
        "db": database,
        "progress": None,
        "on_load": None,
        "on_exit": None,
        "before_db": None,
        "validate_answer": None,
        "get_session_id": None,
        "exclude": None,
        "config": {"max_sessions": max_sessions},
    }


@pytest.fixture(scope="session")
def spacy_model() -> str:
    return "en_core_web_sm"


@pytest.fixture(scope="session")
def spacy_model_md() -> str:
    return "en_core_web_md"


@pytest.fixture(scope="session")
def spacy_model_trf() -> str:
    return "en_core_web_trf"


@pytest.fixture(scope="session")
def nlp(spacy_model: str) -> Language:
    en_core_web_sm = pytest.importorskip(spacy_model)
    return en_core_web_sm.load()


@pytest.fixture(scope="function")
def nlp_fresh(spacy_model: str) -> Language:
    """Use this for models that are updated"""
    en_core_web_sm = pytest.importorskip(spacy_model)
    return en_core_web_sm.load()


@pytest.fixture(scope="session")
def nlp_md(spacy_model_md: str):
    en_core_web_md = pytest.importorskip(spacy_model_md)
    return en_core_web_md.load()


@pytest.fixture(scope="session")
def nlp_trf(spacy_model_trf: str):
    en_core_web_trf = pytest.importorskip(spacy_model_trf)
    return en_core_web_trf.load()


@pytest.fixture(scope="session")
def nlp_blank():
    return spacy.blank("en")


class OpenAISuggesterTestFactory(Protocol):
    def __call__(
        self,
        response_parser: ResponseParserProtocol,
        labels: List[str],
        prompt_path: Path,
        prompt_example_class: Type[_PromptExampleT],
        model: str = "text-davinci-003",
        **kwargs: Any,
    ) -> OpenAISuggester[_PromptExampleT]:
        ...


@pytest.fixture(scope="session")
def make_openai_suggester() -> OpenAISuggesterTestFactory:
    def _make_suggester(
        response_parser: ResponseParserProtocol,
        labels: List[str],
        prompt_path: Path,
        prompt_example_class: Type[_PromptExampleT],
        model: str = "text-davinci-003",
        **kwargs: Any,
    ) -> OpenAISuggester[_PromptExampleT]:
        if "openai_api_key" not in kwargs or "openai_api_org" not in kwargs:
            api_key, api_org = get_api_credentials(model)
            if "openai_api_key" not in kwargs:
                kwargs["openai_api_key"] = api_key
            if "openai_api_org" not in kwargs:
                kwargs["openai_api_org"] = api_org
        if "max_examples" not in kwargs:
            kwargs["max_examples"] = 0
        if "prompt_template" not in kwargs:
            kwargs["prompt_template"] = load_template(prompt_path)
        if "segment" not in kwargs:
            kwargs["segment"] = False
        if "openai_model" not in kwargs:
            kwargs["openai_model"] = "text-davinci-003"

        openai = OpenAISuggester(
            response_parser=response_parser,
            labels=labels,
            prompt_example_class=prompt_example_class,
            **kwargs,
        )
        return openai

    return _make_suggester
