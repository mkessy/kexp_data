import jinja2
import pytest
import srsly
from requests import HTTPError

from prodigy.components.openai import (
    OpenAISuggester,
    get_api_credentials,
    get_resume_stream,
)
from prodigy.util import set_hashes

# Setup the template and the suggester
environment = jinja2.Environment()
template = environment.from_string("Prompt: {{ text }}")

openai = OpenAISuggester(
    prompt_template=template,
    labels=["label1", "label2"],
    max_examples=1,
    segment=False,
    openai_model="text-davinci-003",
    openai_api_key="Fake api key",
    openai_api_org="Fake api org",
    response_parser=lambda x: {"key": "value"},
    openai_n_retries=1,
    openai_read_timeout_s=1,
    openai_retry_timeout_s=1,
    prompt_example_class=None,
)

OPENAI_MODELS_ENDPOINT = "https://api.openai.com/v1/models"


@pytest.mark.parametrize(
    "prompts,response_text",
    [
        (["A single prompt"], ["A single response"]),
        (["A batch", "of prompts"], ["A batch", "of responses"]),
    ],
)
def test_openai_response_follows_contract(requests_mock, prompts, response_text):
    """Test happy path where OpenAI follows the contract and we can parse it
    https://beta.openai.com/docs/api-reference/completions
    """

    requests_mock.post(
        openai.openai_completions_endpoint,
        json={
            "choices": [
                {
                    "text": text,
                    "index": index,
                    "logprobs": 0.1,
                    "finish_reason": "length",
                }
                for index, text in enumerate(response_text)
            ]
        },
    )

    chatgpt_response = openai._get_openai_response(prompts=prompts)
    assert len(chatgpt_response) == len(prompts)
    assert set(chatgpt_response) == set(response_text)


@pytest.mark.parametrize("error_code", openai.retry_error_codes)
def test_retry_function_when_calls_fail(requests_mock, error_code):
    """Test if status error shows up after all failed retries."""
    requests_mock.post(
        openai.openai_completions_endpoint,
        status_code=error_code,
    )
    with pytest.raises(HTTPError):
        openai._get_openai_response(prompts=["Some prompt"])


@pytest.mark.parametrize(
    "key,org", [("", "fake api org"), ("fake api key", ""), ("", "")]
)
def test_get_api_credentials_error_handling_envvars(monkeypatch, key, org):
    """Ensure that auth fails whenever key or org is none."""
    monkeypatch.setenv("OPENAI_KEY", key)
    monkeypatch.setenv("OPENAI_ORG", org)
    with pytest.raises(SystemExit):
        get_api_credentials(model="text-davinci-003")


@pytest.mark.parametrize("error_code", [422, 500, 501])
def test_get_api_credentials_calls_fail(requests_mock, monkeypatch, error_code):
    """Ensure that auth fails when we encounter an error code."""
    requests_mock.get(
        OPENAI_MODELS_ENDPOINT,
        status_code=error_code,
    )
    monkeypatch.setenv("OPENAI_KEY", "fake api key")
    monkeypatch.setenv("OPENAI_ORG", "fake api org")

    with pytest.raises(SystemExit):
        get_api_credentials(model="text-davinci-003")


def test_get_api_credentials_model_does_not_exist(requests_mock, monkeypatch):
    """Ensure that auth fails when model passed does not exist.
    https://beta.openai.com/docs/api-reference/models/list
    """
    requests_mock.get(
        OPENAI_MODELS_ENDPOINT,
        json={
            "data": [{"id": "model-id-0"}, {"id": "model-id-1"}, {"id": "model-id-2"}]
        },
    )

    monkeypatch.setenv("OPENAI_KEY", "fake api key")
    monkeypatch.setenv("OPENAI_ORG", "fake api org")

    with pytest.raises(SystemExit):
        get_api_credentials(model="a-model-that-does-not-exist")


@pytest.mark.parametrize(
    "texts,expected",
    [
        (
            [
                "i am annotating using prodigy",
                "data annotation is important",
                "some annotation",
                "extra text",
                "text",
            ],
            ["extra text", "text"],
        )
    ],
)
def test_get_resume_stream_returns_non_cached_results(datasets_path, texts, expected):
    cache = srsly.read_jsonl(datasets_path / "sample_cache.jsonl")
    # Prepare stream
    stream = [set_hashes({"text": text}) for text in texts]
    output = get_resume_stream(stream, cache)
    output_texts = [eg.get("text") for eg in output]

    assert len(output_texts) == len(expected)
    assert set(output_texts) == set(expected)
