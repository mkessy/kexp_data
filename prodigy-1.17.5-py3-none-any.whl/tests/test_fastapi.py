import base64
import datetime
import json
import os
from pathlib import Path
from typing import Any, Dict, Tuple

import jwt
import pytest
from starlette.testclient import TestClient

from prodigy import about
from prodigy.app import app, set_controller
from prodigy.components.db import connect
from prodigy.core import Controller
from prodigy.types import APILogRequest
from prodigy.util import ENV_VARS, INPUT_HASH_ATTR, TASK_HASH_ATTR


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c
        c.close()


TEST_SECRET = "testing-secret-secure-like-an-open-door"
TEST_AUDIENCE = "http://test-audience.localhost"
TEST_BASIC_AUTH_USER = "test-user"
TEST_BASIC_AUTH_PASS = "lame-test-password"

HASH_ONE = 13
HASH_TWO = 67


@pytest.fixture
def session_id():
    return "1337"


@pytest.fixture
def examples():
    return [
        {INPUT_HASH_ATTR: HASH_ONE, TASK_HASH_ATTR: 37, "content": {"first": True}},
        {INPUT_HASH_ATTR: HASH_TWO, TASK_HASH_ATTR: 34, "content": {"second": False}},
    ]


@pytest.fixture
def app_controller(database, session_id):
    os.environ[ENV_VARS.JWT] = "1"
    os.environ[ENV_VARS.JWT_SECRET] = TEST_SECRET
    os.environ[ENV_VARS.JWT_AUDIENCE] = TEST_AUDIENCE
    if ENV_VARS.BASIC_AUTH_USER in os.environ:
        del os.environ[ENV_VARS.BASIC_AUTH_USER]
    if ENV_VARS.BASIC_AUTH_PASS in os.environ:
        del os.environ[ENV_VARS.BASIC_AUTH_PASS]
    recipe_config = {
        "dataset": "train",
        "view_id": "classification",
        "stream": [
            {INPUT_HASH_ATTR: 0, TASK_HASH_ATTR: 1, "text": "Test", "label": "LABEL"}
        ],
        "update": None,
        "progress": None,
        "on_load": None,
        "on_exit": None,
        "before_db": None,
        "validate_answer": None,
        "get_session_id": lambda: session_id,
        "exclude": None,
        "config": {"feed_overlap": True, "cors": False},
        "metrics": None,
    }
    ctrl_class = Controller
    controller = ctrl_class(**recipe_config, db=database)
    set_controller(controller, recipe_config)
    yield controller
    if ENV_VARS.BASIC_AUTH_USER in os.environ:
        del os.environ[ENV_VARS.BASIC_AUTH_USER]
    if ENV_VARS.BASIC_AUTH_PASS in os.environ:
        del os.environ[ENV_VARS.BASIC_AUTH_PASS]
    if ENV_VARS.JWT in os.environ:
        del os.environ[ENV_VARS.JWT]
    if ENV_VARS.JWT_SECRET in os.environ:
        del os.environ[ENV_VARS.JWT_SECRET]


def encode_token(expire_seconds: int = 600, secret: str = TEST_SECRET):
    payload = {
        "exp": datetime.datetime.utcnow() + datetime.timedelta(seconds=expire_seconds),
        "aud": TEST_AUDIENCE,
        "iss": TEST_AUDIENCE,
    }
    return jwt.encode(payload, secret)


def make_headers(token):
    return {"Authorization": "Bearer {}".format(token)}


@pytest.fixture
def token_headers():
    return make_headers(encode_token())


@pytest.fixture
def static_headers():
    slug = base64.b64encode(f"{TEST_BASIC_AUTH_USER}:{TEST_BASIC_AUTH_PASS}".encode())
    return {"Authorization": f"Basic {slug.decode('utf8')}"}


def assert_guarded_route(client, route, method="post"):
    # cannot call without token
    action = getattr(client, method)
    response = action(route)
    assert response.status_code == 403

    # cannot call with expired token
    response = action(route, headers=make_headers(encode_token(-1)))
    assert response.status_code == 403


def test_fastapi_static_files_optional_basic_auth(
    client, app_controller, static_headers, route="/index.html"
):
    # Now the user can access the route, because no auth is present
    response = client.get(route, headers=static_headers)
    assert response.status_code == 200

    # Set the basic auth params
    os.environ[ENV_VARS.BASIC_AUTH_USER] = TEST_BASIC_AUTH_USER
    os.environ[ENV_VARS.BASIC_AUTH_PASS] = TEST_BASIC_AUTH_PASS

    # Now the user cannot access the route, because basic auth is present
    response = client.get(route)
    assert response.status_code == 401


def test_fastapi_static_files_optional_basic_auth_errors(
    client, app_controller, route="/index.html"
):
    os.environ[ENV_VARS.BASIC_AUTH_USER] = TEST_BASIC_AUTH_USER
    os.environ[ENV_VARS.BASIC_AUTH_PASS] = TEST_BASIC_AUTH_PASS
    # Setting only one of the two basic auth env vars is an error
    del os.environ[ENV_VARS.BASIC_AUTH_PASS]
    with pytest.raises(ValueError):
        client.get(route)


def test_fastapi_version(client, app_controller, token_headers, route="/version"):
    assert_guarded_route(client, route, method="get")
    response = client.get(route, headers=token_headers)
    assert response.status_code == 200

    # Returns the values in prodigy's about.py file
    data = response.json()
    assert data["name"] == "prodigy"
    assert data["description"] == about.__summary__
    assert data["author"] == about.__author__
    assert data["author_email"] == about.__email__
    assert data["url"] == about.__uri__
    assert data["version"] == about.__version__
    assert data["license"] == about.__license__


def test_fastapi_project(client, app_controller, token_headers, route="/project"):
    assert_guarded_route(client, route, method="get")
    response = client.get(route, headers=token_headers)
    assert response.status_code == 200


def test_fastapi_project_restricted_sessions(
    client, app_controller, token_headers, route="/project/{}"
):
    os.environ[ENV_VARS.ALLOWED_SESSIONS] = "foo,bar"
    # "invalid" is not allowed because it's not in the list
    response = client.get(route.format("invalid"), headers=token_headers)
    assert response.status_code == 403
    # "foo" is allowed
    response = client.get(route.format("foo"), headers=token_headers)
    assert response.status_code == 200
    del os.environ[ENV_VARS.ALLOWED_SESSIONS]


def test_fastapi_project_unrestricted_sessions(
    client, app_controller, token_headers, route="/project/{}"
):
    # Everything is allowed because allowed_sessions is not set
    for var in ["invalid", "12345", "leet_hax0r"]:
        response = client.get(route.format("invalid"), headers=token_headers)
        assert response.status_code == 200


def test_fastapi_get_questions(
    client, app_controller, token_headers, route="/get_questions"
):
    assert_guarded_route(client, route, method="get")

    # When feed_overlap is True, raise an error if no session_id is provided
    response = client.get(route, headers=token_headers)
    assert response.status_code == 400


def test_fastapi_get_questions_by_session(
    client, app_controller, token_headers, route="/get_session_questions"
):
    assert_guarded_route(client, route)
    headers = dict(token_headers, **{"Content-Type": "application/json"})
    # Multiple sessions each with their own copy of the stream
    max_sessions = app_controller._max_sessions

    for i in range(max_sessions):
        body = json.dumps(dict(session_id=f"sess_{i}"))

        # The test stream has one batch in it
        response = client.post(route, data=body, headers=headers)
        assert len(response.json()["tasks"]) == 1

    # If we try to request for more than the max_sessions (default to 100)
    # then an error is raised saying we've exceeded max sessions
    body = json.dumps(dict(session_id=f"sess_{max_sessions}"))

    response = client.post(route, data=body, headers=headers)
    assert response.status_code == 400


def test_fastapi_get_questions_by_session_trailing_slash(
    client, app_controller, token_headers, route="/get_session_questions"
):
    assert_guarded_route(client, route)
    headers = dict(token_headers, **{"Content-Type": "application/json"})
    # Multiple sessions each with their own copy of the stream
    import json

    for i in range(10):
        for slashes in ["", "/", "///"]:
            sess_id = f"sess_{i}{slashes}"
            body = json.dumps(dict(session_id=sess_id))

            # The test stream has one batch in it
            response = client.post(route, data=body, headers=headers)
            assert response.json()["session_id"] == f"sess_{i}"


def test_fastapi_get_questions_by_session_exclude_hashes(
    client, app_controller, token_headers, route="/get_session_questions"
):
    # The test stream has one item in it with task_hash == 1
    body = json.dumps(dict(session_id="sess_one", excludes=[1]))
    headers = dict(token_headers, **{"Content-Type": "application/json"})
    response = client.post(route, data=body, headers=headers)
    assert response.status_code == 200
    assert len(response.json()["tasks"]) == 0


def test_fastapi_get_questions_by_session_no_exclude_hashes(
    client, app_controller, token_headers, route="/get_session_questions"
):
    # Without the exclusion, there is one item
    body = json.dumps(dict(session_id="sess_one"))
    headers = dict(token_headers, **{"Content-Type": "application/json"})
    response = client.post(route, data=body, headers=headers)
    assert response.status_code == 200
    assert len(response.json()["tasks"]) == 1


@pytest.mark.xfail(reason="Examine end_session mechanism")
def test_fastapi_set_session_aliases(
    client,
    app_controller,
    session_id,
    examples,
    token_headers,
    route="/set_session_aliases",
):
    assert_guarded_route(client, route)
    questions = app_controller.get_questions(session_id=session_id)
    app_controller.receive_answers(
        [{INPUT_HASH_ATTR: 0, TASK_HASH_ATTR: 1, "content": {"text": "Test"}}],
        session_id=session_id,
    )
    body = json.dumps(dict(session_id="sess-1", aliases=[session_id]))
    headers = dict(token_headers, **{"Content-Type": "application/json"})
    # Associate session-2 with session_id for exclusion purposes
    response = client.post(route, data=body, headers=headers)
    assert response.status_code == 200

    app_controller.set_db(connect())

    # There are 0 questions in the stream because of the exclusion
    questions = app_controller.get_questions("sess-1")
    assert len(questions) == 0

    body = json.dumps(dict(session_id="sess-1", aliases=[]))

    # Remove the session alias to test inverse
    response = client.post(route, data=body, headers=headers)
    assert response.status_code == 200

    # Reset the stream so we can retrieve the test question again
    app_controller.set_db(connect())
    app_controller.end_session("sess-1")

    # There is now 1 unfiltered question because the alias to sess-1 was removed
    questions = app_controller.get_questions("sess-1")
    assert len(questions) == 1


def test_fastapi_give_answers(
    client, app_controller, examples, token_headers, route="/give_answers"
):
    assert_guarded_route(client, route)
    body = json.dumps(dict(answers=examples))
    headers = dict(
        token_headers, **{"Content-Type": "application/json"}
    )  # When feed_overlap is True, raise an error if no session_id is provided
    response = client.post(route, data=body, headers=headers)
    assert response.status_code == 400


def test_fastapi_give_answers_by_session(
    client, app_controller, examples, token_headers, route="/give_answers"
):
    assert_guarded_route(client, route)
    # can insert into specified session by id
    body = json.dumps(dict(answers=examples, session_id="foo"))
    headers = dict(token_headers, **{"Content-Type": "application/json"})
    response = client.post(route, data=body, headers=headers)
    assert response.status_code == 200
    app_controller.set_db(connect())
    out_examples = app_controller.db.get_dataset_examples("foo")
    assert len(out_examples) == 2


@pytest.mark.parametrize("route", ["/health", "/healthz"])
def test_health_endpoints(client, app_controller, token_headers, route):
    response = client.get(route, headers=token_headers)
    assert response.status_code == 200


def test_log_endpoint(
    client,
    app_controller: Controller,
    token_headers: Dict[str, Any],
    capsys,
    route: str = "/log",
):
    assert_guarded_route(client, route)
    log_msg = "test log endpoint"
    simple_body = APILogRequest(message=log_msg, timestamp=datetime.datetime.utcnow())

    body = simple_body.json()
    headers = dict(token_headers, **{"Content-Type": "application/json"})
    response = client.post(route, data=body, headers=headers)

    assert response.status_code == 200

    stdout = capsys.readouterr().out
    assert "Front End Log -" in stdout
    assert log_msg in stdout


def test_fastapi_event_hooks(client, app_controller, examples, token_headers):
    def hook1(ctrl, arg1: str) -> Tuple[str, str]:
        return ("called hook1", arg1)

    def hook2(ctrl, arg1: str) -> Tuple[str, str]:
        return ("called hook2", arg1)

    assert_guarded_route(client, "/event/h1", method="post")
    headers = dict(token_headers, **{"Content-Type": "application/json"})
    assert app_controller.recipe_event_hooks == {}
    # Check we get 404 if no event hook registered
    response = client.post("/event/h1", json={"arg1": "hi"}, headers=headers)
    assert response.status_code == 404
    # Insert the event hooks
    app_controller.recipe_event_hooks["h1"] = hook1
    app_controller.recipe_event_hooks["h2"] = hook2

    response = client.post("/event/h1", json={"arg1": "hi"}, headers=headers)
    assert response.status_code == 200
    assert response.json() == ["called hook1", "hi"]
    response = client.post("/event/h2", json={"arg1": "hi"}, headers=headers)
    assert response.status_code == 200
    assert response.json() == ["called hook2", "hi"]
    response = client.post("/event/h3", json={"arg1": "hi"}, headers=headers)
    assert response.status_code == 404


def test_javascript_urls_config(client, app_controller, examples, token_headers):
    assert "javascript_urls" not in app_controller.config
    assert "javascript_dir" not in app_controller.config

    app_controller.config["javascript_dir"] = Path(__file__).parent / "static"
    app_controller.config["javascript_urls"] = [
        "https://unpkg.com/htmx.org@1.9.6/dist/htmx.min.js"
    ]
    set_controller(app_controller, app_controller.config)

    res = client.get("/project", headers=token_headers)
    assert res.status_code == 200
    assert res.json()["javascript_urls"] == [
        "https://unpkg.com/htmx.org@1.9.6/dist/htmx.min.js",
        "/user_files/javascript/js/test.js",
        "/user_files/javascript/js/subfolder/test_inner.js",
    ]


def test_global_css_urls_config(client, app_controller, examples, token_headers):

    assert "global_css_urls" not in app_controller.config

    app_controller.config["global_css_dir"] = Path(__file__).parent / "static"
    app_controller.config["global_css_urls"] = [
        "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
    ]
    set_controller(app_controller, app_controller.config)

    res = client.get("/project", headers=token_headers)
    assert res.status_code == 200
    assert res.json()["global_css_urls"] == [
        "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css",
        "/user_files/global_css/css/test.css",
        "/user_files/global_css/css/subfolder/test_inner.css",
    ]
