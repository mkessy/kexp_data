import pytest

from prodigy.util import INPUT_HASH_ATTR, TASK_HASH_ATTR, get_hash, set_hashes


@pytest.mark.parametrize("task", [{"text": "hello"}])
def test_set_hashes(task):
    task_w_hashes = set_hashes(task)
    assert INPUT_HASH_ATTR in task_w_hashes
    assert TASK_HASH_ATTR in task_w_hashes


@pytest.mark.parametrize(
    "task", [{"text": "hello", INPUT_HASH_ATTR: 123, TASK_HASH_ATTR: 456}]
)
def test_set_hashes_overwrite(task):
    task_w_hashes = set_hashes(task, overwrite=True)
    assert task_w_hashes[INPUT_HASH_ATTR] != task[INPUT_HASH_ATTR]
    assert task_w_hashes[TASK_HASH_ATTR] != task[TASK_HASH_ATTR]


@pytest.mark.parametrize(
    "task1,task2", [({"text": "abc", "label": "yes"}, {"image": "abc", "label": "yes"})]
)
def test_get_hash(task1, task2):
    input_keys = ["text", "image"]
    task_keys = ["label"]
    input_hash1 = get_hash(task1, keys=input_keys)
    input_hash2 = get_hash(task2, keys=input_keys)
    task_hash1 = get_hash(task1, keys=task_keys, prefix=input_hash1)
    task_hash2 = get_hash(task2, keys=task_keys, prefix=input_hash2)
    assert task_hash1 != task_hash2


def test_get_hashes_sort_keys():
    task_keys = ("spans", "label")
    task1 = {"text": "x", "spans": [{"a": "b"}, {"c": "d"}], "label": "test"}
    task2 = {"label": "test", "text": "x", "spans": [{"a": "b"}, {"c": "d"}]}
    task_hash1 = get_hash(task1, keys=task_keys)
    task_hash2 = get_hash(task2, keys=task_keys)
    assert task_hash1 == task_hash2


def test_hashes_ignore_given_attributes():
    task_keys = ("spans", "label")
    task1 = {"text": "x", "spans": [{"label": "a", "score": 0.0}]}
    task2 = {"text": "x", "spans": [{"label": "a", "score": 0.1}]}
    assert get_hash(task1, keys=task_keys) == get_hash(task2, keys=task_keys)
