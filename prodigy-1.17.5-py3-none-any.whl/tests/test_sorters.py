import random
import string
from typing import List, Tuple

import pytest

from prodigy.components.sorters import (
    ExpMovingAverage,
    Linear,
    Probability,
    Threshold,
    prefer_uncertain,
)
from prodigy.types import TaskType

from .util import FixtureRequest


@pytest.fixture(scope="session")
def examples() -> List[TaskType]:
    return [{"text": letter} for letter in string.ascii_uppercase]


@pytest.fixture(scope="session", params=[0.0, 1.0])
def uniform_stream(request: FixtureRequest[float], examples: List[TaskType]):
    return [(request.param, eg) for eg in examples]


@pytest.fixture(scope="session")
def uniform_stream_zeros(examples: List[TaskType]):
    return [(0.0, eg) for eg in examples]


@pytest.fixture(scope="session")
def uniform_stream_ones(examples: List[TaskType]):
    return [(1.0, eg) for eg in examples]


@pytest.fixture(scope="session")
def asc_stream(examples: List[TaskType]):
    return [(i / len(examples), eg) for i, eg in enumerate(examples)]


@pytest.fixture(scope="session")
def desc_stream(examples: List[TaskType]):
    return [(1 - (i / len(examples)), eg) for i, eg in enumerate(examples)]


@pytest.fixture(scope="session")
def rand_stream(examples: List[TaskType]):
    random.seed(0)
    return [(random.random(), eg) for eg in examples]


def test_linear_sorter_uniform(uniform_stream: List[Tuple[float, TaskType]]):
    ema = Linear(iter(uniform_stream))
    questions = list(ema)
    assert len(questions) == len(uniform_stream)
    assert questions == [task for _, task in uniform_stream]


def test_linear_sorter_asc(asc_stream: List[Tuple[float, TaskType]]):
    ema = Linear(iter(asc_stream))
    questions = list(ema)
    assert len(questions) == len(asc_stream)
    assert questions == [task for _, task in reversed(asc_stream)]


def test_linear_sorter_desc(desc_stream: List[Tuple[float, TaskType]]):
    ema = Linear(iter(desc_stream))
    questions = list(ema)
    assert len(questions) == len(desc_stream)
    assert questions == [task for _, task in desc_stream]


def test_linear_sorter_rand(rand_stream: List[Tuple[float, TaskType]]):
    ema = Linear(iter(rand_stream))
    questions = list(ema)
    assert len(questions) == len(rand_stream)
    assert questions == [
        task for _, task in sorted(rand_stream, key=lambda x: x[0], reverse=True)
    ]


def test_threshold_sorter_uniform(uniform_stream: List[Tuple[float, TaskType]]):
    ema = Threshold(iter(uniform_stream), minimum=0.0, maximum=1.1)
    questions = list(ema)
    if uniform_stream[0][0] == 1.0:
        assert len(questions) == len(uniform_stream)
        assert questions == [task for _, task in uniform_stream]
    else:
        assert len(questions) == 0


def test_threshold_sorter_asc(asc_stream: List[Tuple[float, TaskType]]):
    ema = Threshold(iter(asc_stream), minimum=0.0, maximum=1.0)
    questions = list(ema)
    # 0.0 gets excluded so should be 25 tasks here
    assert len(questions) == len(asc_stream) - 1
    assert questions == [task for _, task in asc_stream[1:]]


def test_threshold_sorter_cuttoff(asc_stream: List[Tuple[float, TaskType]]):
    ema = Threshold(iter(asc_stream), minimum=0.5, maximum=1.0)
    questions = list(ema)
    # 0.0 gets excluded so should be 25 tasks here
    assert len(questions) == 12
    assert questions == [task for _, task in asc_stream[14:]]


def test_prop_sorter_uniform_zeros(uniform_stream_zeros: List[Tuple[float, TaskType]]):
    ema = Probability(iter(uniform_stream_zeros))
    questions = list(ema)
    assert len(questions) == 1
    assert questions == [uniform_stream_zeros[0][1]]


def test_prop_sorter_uniform_ones(uniform_stream_ones: List[Tuple[float, TaskType]]):
    ema = Probability(iter(uniform_stream_ones))
    questions = list(ema)
    assert len(questions) == len(uniform_stream_ones)
    assert questions == [task for _, task in uniform_stream_ones]


def test_prop_sorter_rand_stream(asc_stream: List[Tuple[float, TaskType]]):
    """Test Probability sorter with a rand stream should
    yield about half the examples in the stream"""
    ema = Probability(iter(asc_stream))
    questions = list(ema)
    assert len(questions) < len(asc_stream)


def test_expma_sorter_uniform(uniform_stream: List[Tuple[float, TaskType]]):
    """If all priorities are the same (e.g. zero), we should ask all questions"""
    ema = ExpMovingAverage(iter(uniform_stream))
    questions = list(ema)
    assert len(questions) == len(uniform_stream)


def test_expma_sorter_skips_in_increasing_stream(
    asc_stream: List[Tuple[float, TaskType]]
):
    """If the priorities are increasing, we should be skipping some"""
    ema = ExpMovingAverage(iter(asc_stream))
    questions = list(ema)
    assert len(questions) < len(asc_stream)


def test_expma_sorter_doesnt_stall_in_desc_stream(
    desc_stream: List[Tuple[float, TaskType]]
):
    """If the priorities are decreasing, we dont want to stall out, hoping
    for the old average"""
    ema = ExpMovingAverage(iter(desc_stream))
    questions = list(ema)
    assert len(questions) < len(desc_stream)


def test_prefer_uncertain_skips_in_random_stream(
    rand_stream: List[Tuple[float, TaskType]]
):
    """For a random stream, ensure prefer_uncertain returns an ExpMovingAverage by default.
    The probabilities associated with each task won't be sorted but the probabilities
    in the first half of the stream should be lower than the probabilities in the second
    half of the stream
    """
    key_to_prob_map = {item[1]["text"]: item[0] for item in rand_stream}
    ema = prefer_uncertain(iter(rand_stream))
    assert isinstance(ema, ExpMovingAverage)

    ema.first_n = 2
    questions = list(ema)
    question_probs = [key_to_prob_map[q["text"]] for q in questions]
    assert len(questions) < len(rand_stream)

    first_half_probs = question_probs[: len(questions) // 2]
    second_half_probs = question_probs[len(questions) // 2 :]
    assert sum(first_half_probs) < sum(second_half_probs)
