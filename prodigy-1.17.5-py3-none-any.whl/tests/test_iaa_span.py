from typing import Dict, List, Tuple, Union

import numpy as np
import pytest

from prodigy.components.metrics._util import _build_reliability_table
from prodigy.components.metrics.iaa_span import IaaSpan
from prodigy.structured_types import SpansAnns, SpansManualAnns
from prodigy.types import TextManualSpan, TextSpan, Token

"""
We'll use 3 annotators for the tests:
ann_1 & ann_2 have a complete overlap (both of them annotated the same 3 examples: 111, 222, 333),
while ann_3 has a partial overlap (annotated 2 examples: 111, 222).
All annotators have perfect agreement on coincident examples.
"""


@pytest.fixture
def annotator_1_TextManualSpan():
    """Annotator with TextManualSpan task"""
    return [
        {
            "_input_hash": 111,
            "_task_hash": 111,
            "text": "Test input one",
            "answer": "accept",
            "_annotator_id": "ann_1",
            "_session_id": "ann_1",
            "_view_id": "ner_manual",
        },
        {
            "_input_hash": 222,
            "_task_hash": 222,
            "text": "Test input two",
            "answer": "accept",
            "_annotator_id": "ann_1",
            "_session_id": "ann_1",
            "spans": [
                {
                    "start": 0,
                    "end": 3,
                    "token_start": 0,
                    "token_end": 0,
                    "label": "PER",
                },
                {
                    "start": 9,
                    "end": 11,
                    "token_start": 2,
                    "token_end": 2,
                    "label": "ORG",
                },
            ],
            "tokens": [
                {"text": "Test", "start": 0, "end": 3, "id": 0, "ws": "true"},
                {"text": "input", "start": 4, "end": 8, "id": 1, "ws": "true"},
                {"text": "two", "start": 9, "end": 11, "id": 2, "ws": "true"},
            ],
            "_view_id": "ner_manual",
        },
        {
            "_input_hash": 333,
            "_task_hash": 333,
            "text": "Test input three",
            "_annotator_id": "ann_1",
            "_session_id": "ann_1",
            "answer": "accept",
            "spans": [
                {
                    "start": 4,
                    "end": 8,
                    "token_start": 1,
                    "token_end": 1,
                    "label": "PER",
                },
                {
                    "start": 9,
                    "end": 13,
                    "token_start": 2,
                    "token_end": 2,
                    "label": "PER",
                },
            ],
            "tokens": [
                {"text": "Test", "start": 0, "end": 3, "id": 0, "ws": "true"},
                {"text": "input", "start": 4, "end": 8, "id": 1, "ws": "true"},
                {"text": "three", "start": 9, "end": 13, "id": 2, "ws": "true"},
            ],
            "_view_id": "ner_manual",
        },
    ]


@pytest.fixture
def annotator_2_TextManualSpan():
    """Annotator with TextManualSpan task"""
    return [
        {
            "_input_hash": 111,
            "_task_hash": 111,
            "text": "Test input one",
            "_annotator_id": "ann_2",
            "_session_id": "ann_2",
            "answer": "accept",
            "_view_id": "ner_manual",
        },
        {
            "_input_hash": 222,
            "_task_hash": 222,
            "text": "Test input two",
            "_annotator_id": "ann_2",
            "_session_id": "ann_2",
            "answer": "accept",
            "spans": [
                {
                    "start": 0,
                    "end": 3,
                    "token_start": 0,
                    "token_end": 0,
                    "label": "PER",
                },
                {
                    "start": 9,
                    "end": 11,
                    "token_start": 2,
                    "token_end": 2,
                    "label": "ORG",
                },
            ],
            "tokens": [
                {"text": "Test", "start": 0, "end": 3, "id": 0, "ws": "true"},
                {"text": "input", "start": 4, "end": 8, "id": 1, "ws": "true"},
                {"text": "two", "start": 9, "end": 11, "id": 2, "ws": "true"},
            ],
            "_view_id": "ner_manual",
        },
        {
            "_input_hash": 333,
            "_task_hash": 333,
            "text": "Test input 3",
            "_annotator_id": "ann_2",
            "_session_id": "ann_2",
            "answer": "accept",
            "spans": [
                {
                    "start": 4,
                    "end": 8,
                    "token_start": 1,
                    "token_end": 1,
                    "label": "PER",
                },
                {
                    "start": 9,
                    "end": 13,
                    "token_start": 2,
                    "token_end": 2,
                    "label": "PER",
                },
            ],
            "tokens": [
                {"text": "Test", "start": 0, "end": 3, "id": 0, "ws": "true"},
                {"text": "input", "start": 4, "end": 8, "id": 1, "ws": "true"},
                {"text": "three", "start": 9, "end": 13, "id": 2, "ws": "true"},
            ],
            "_view_id": "ner_manual",
        },
    ]


@pytest.fixture
def annotator_3_TextManualSpan():
    """Annotator with TextManualSpan task"""
    return [
        {
            "_input_hash": 111,
            "_task_hash": 111,
            "text": "Test input one",
            "_annotator_id": "ann_3",
            "_session_id": "ann_3",
            "answer": "accept",
            "_view_id": "ner_manual",
        },
        {
            "_input_hash": 222,
            "_task_hash": 222,
            "text": "Test input two",
            "_annotator_id": "ann_3",
            "_session_id": "ann_3",
            "answer": "accept",
            "spans": [
                {
                    "start": 0,
                    "end": 3,
                    "token_start": 0,
                    "token_end": 0,
                    "label": "PER",
                },
                {
                    "start": 9,
                    "end": 11,
                    "token_start": 2,
                    "token_end": 2,
                    "label": "ORG",
                },
            ],
            "tokens": [
                {"text": "Test", "start": 0, "end": 3, "id": 0, "ws": "true"},
                {"text": "input", "start": 4, "end": 8, "id": 1, "ws": "true"},
                {"text": "two", "start": 9, "end": 11, "id": 2, "ws": "true"},
            ],
            "_view_id": "ner_manual",
        },
    ]


# Reliability table corresponding to the 3 annotators above.


@pytest.fixture
def reliability_table():
    """Reliability table"""
    # 3 tasks, 3 annotators
    return np.array(
        [
            [None, None, None],
            [
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=0, end=3, token_start=0, token_end=0, label="PER"
                        ),
                        TextManualSpan(
                            start=9, end=11, token_start=2, token_end=2, label="ORG"
                        ),
                    ]
                ),
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=0, end=3, token_start=0, token_end=0, label="PER"
                        ),
                        TextManualSpan(
                            start=9, end=11, token_start=2, token_end=2, label="ORG"
                        ),
                    ]
                ),
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=0, end=3, token_start=0, token_end=0, label="PER"
                        ),
                        TextManualSpan(
                            start=9, end=11, token_start=2, token_end=2, label="ORG"
                        ),
                    ]
                ),
            ],
            [
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=4, end=8, token_start=1, token_end=1, label="PER"
                        ),
                        TextManualSpan(
                            start=9, end=13, token_start=2, token_end=2, label="PER"
                        ),
                    ]
                ),
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=4, end=8, token_start=1, token_end=1, label="PER"
                        ),
                        TextManualSpan(
                            start=9, end=13, token_start=2, token_end=2, label="PER"
                        ),
                    ]
                ),
                -1,
            ],
        ]
    )


@pytest.fixture
def reliability_table_label_errors():
    """Reliability table"""
    # 3 tasks, 3 annotators
    return np.array(
        [
            [None, None, None],
            [
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=0, end=3, token_start=0, token_end=0, label="PER"
                        ),
                        TextManualSpan(
                            start=9, end=11, token_start=2, token_end=2, label="ORG"
                        ),
                    ]
                ),
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=0, end=3, token_start=0, token_end=0, label="PER"
                        ),
                        TextManualSpan(
                            start=9, end=11, token_start=2, token_end=2, label="PER"
                        ),
                    ]
                ),
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=0, end=3, token_start=0, token_end=0, label="ORG"
                        ),
                        TextManualSpan(
                            start=9, end=11, token_start=2, token_end=2, label="ORG"
                        ),
                    ]
                ),
            ],
            [
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=4, end=8, token_start=1, token_end=1, label="PER"
                        ),
                        TextManualSpan(
                            start=9, end=13, token_start=2, token_end=2, label="PER"
                        ),
                    ]
                ),
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=4, end=8, token_start=1, token_end=1, label="PER"
                        ),
                        TextManualSpan(
                            start=9, end=13, token_start=2, token_end=2, label="PER"
                        ),
                    ]
                ),
                -1,
            ],
        ]
    )


@pytest.fixture
def perfect_agreement():
    """Return an list of two annotations of a single example with perfect agreement"""
    # "A Juan le gustan los gatos"
    return [
        # Juan - PER, gatos - ANIMAL
        SpansAnns(
            spans=[
                TextManualSpan(start=2, end=6, token_start=2, token_end=2, label="PER"),
                TextManualSpan(
                    start=21, end=26, token_start=6, token_end=6, label="ANIMAL"
                ),
            ]
        ),
        # Juan - PER, gatos - ANIMAL
        SpansAnns(
            spans=[
                TextManualSpan(start=2, end=6, token_start=2, token_end=2, label="PER"),
                TextManualSpan(
                    start=21, end=26, token_start=6, token_end=6, label="ANIMAL"
                ),
            ]
        ),
    ]


@pytest.fixture
def perfect_agreement_matrix():
    # order: ['ANIMAL', 'PER', '0']
    # ith - true, jth - predicted
    # perfect_agreement = ((Juan: PER, gatos: ANIMAL), (Juan: PER, gatos: ANIMAL))
    return np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 0.0]])


@pytest.fixture
def no_agreement():
    # "A Juan le gustan los gatos"
    return [
        # Juan - PER, gatos - ANIMAL
        SpansAnns(
            spans=[
                TextManualSpan(start=2, end=6, token_start=1, token_end=1, label="PER"),
                TextManualSpan(
                    start=21, end=26, token_start=5, token_end=5, label="ANIMAL"
                ),
            ]
        ),
        # los - ANIMAL
        SpansAnns(
            spans=[
                TextManualSpan(
                    start=17, end=20, token_start=4, token_end=4, label="ANIMAL"
                )
            ]
        ),
    ]


@pytest.fixture
def no_agreement_matrix():
    # order: ['ANIMAL', 'PER', '0']
    # ith - true, jth - predicted
    # no_agreement = ((Juan: PER, gatos: ANIMAL), (los,: ANIMAL))
    return np.array([[0.0, 0.0, 1.0], [0.0, 0.0, 1.0], [1.0, 0.0, 0.0]])


@pytest.fixture
def boundary_errors():
    # "A Juan le gustan los gatos"
    return [
        # Juan - PER, gatos - ANIMAL
        SpansAnns(
            spans=[
                TextManualSpan(start=2, end=6, token_start=2, token_end=2, label="PER"),
                TextManualSpan(
                    start=21, end=26, token_start=6, token_end=6, label="ANIMAL"
                ),
            ]
        ),
        # Juan - PER, los gatos - ANIMAL
        SpansAnns(
            spans=[
                TextManualSpan(start=2, end=6, token_start=2, token_end=2, label="PER"),
                TextManualSpan(
                    start=17, end=26, token_start=5, token_end=6, label="ANIMAL"
                ),
            ]
        ),
    ]


@pytest.fixture
def boundary_errors_matrix():
    # order: ['ANIMAL', 'PER', '0']
    # ith - true, jth - predicted
    # boundary_errors = ((Juan: PER, gatos: ANIMAL), (Juan: PER, los gatos: ANIMAL))
    # strict agrrement, no partial credit for overlapping spans
    return np.array([[0.0, 0.0, 1.0], [0.0, 1.0, 0.0], [1.0, 0.0, 0.0]])


@pytest.fixture
def label_errors(nlp):
    # "A Juan le gustan los gatos"
    return [
        # Juan - PER, gatos - ANIMAL
        SpansAnns(
            spans=[
                TextManualSpan(start=2, end=6, token_start=2, token_end=2, label="PER"),
                TextManualSpan(
                    start=21, end=26, token_start=6, token_end=6, label="ANIMAL"
                ),
            ]
        ),
        # Juan - ANIMAL, gatos - ANIMAL
        SpansAnns(
            spans=[
                TextManualSpan(
                    start=2, end=6, token_start=2, token_end=2, label="ANIMAL"
                ),
                TextManualSpan(
                    start=21, end=26, token_start=6, token_end=6, label="ANIMAL"
                ),
            ]
        ),
    ]


@pytest.fixture
def label_errors_2():
    # "A los gatos les gustan los pajaros")
    return [
        # gatos - ANIMAL, pajaros - ANIMAL
        SpansAnns(
            spans=[
                TextManualSpan(
                    start=6, end=11, token_start=3, token_end=3, label="ANIMAL"
                ),
                TextManualSpan(
                    start=27, end=34, token_start=7, token_end=7, label="ANIMAL"
                ),
            ]
        ),
        # gatos- PER, pajaros - PER
        SpansAnns(
            spans=[
                TextManualSpan(
                    start=6, end=11, token_start=3, token_end=3, label="PER"
                ),
                TextManualSpan(
                    start=27, end=34, token_start=7, token_end=7, label="PER"
                ),
            ]
        ),
    ]


@pytest.fixture
def label_errors_matrix():
    # order: ['ANIMAL', 'PER', '0']
    # ith - true, jth - predicted
    # label_errors = ((Juan: PER, gatos: ANIMAL), (Juan: ANIMAL, gatos: ANIMAL))
    # strict agrrement, no partial credit for overlapping spans
    return np.array([[1.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 0.0]])


def test_build_reliability_table_spans(
    annotator_1_TextManualSpan,
    annotator_2_TextManualSpan,
    annotator_3_TextManualSpan,
):
    """Test that the reliability table is built correctly"""
    m = IaaSpan(
        labels=["PER", "ORG"], annotators=["ann_1", "ann_2", "ann_3"], partial=False
    )
    m._examples = annotator_1_TextManualSpan
    m._examples.extend(annotator_2_TextManualSpan)
    m._examples.extend(annotator_3_TextManualSpan)
    assert m._cli_annotators is not None
    assert m._cli_labels is not None
    reliability_table = _build_reliability_table(
        examples=m._examples,
        labels=m._cli_labels,
        annotators=m._cli_annotators,
        annotation_type=m._annotation_type,
        value_getter=m._value_getter,
    )

    assert reliability_table.shape == (3, 3)
    assert list(reliability_table[0, :]) == [None, None, None]
    assert list(reliability_table[1, :]) == [
        SpansManualAnns(
            spans=[
                TextManualSpan(start=0, end=3, label="PER", token_start=0, token_end=0),
                TextManualSpan(
                    start=9, end=11, label="ORG", token_start=2, token_end=2
                ),
            ],
            tokens=[
                Token(start=0, end=3, id=0, disabled=False),
                Token(start=4, end=8, id=1, disabled=False),
                Token(start=9, end=11, id=2, disabled=False),
            ],
        ),
        SpansManualAnns(
            spans=[
                TextManualSpan(start=0, end=3, label="PER", token_start=0, token_end=0),
                TextManualSpan(
                    start=9, end=11, label="ORG", token_start=2, token_end=2
                ),
            ],
            tokens=[
                Token(start=0, end=3, id=0, disabled=False),
                Token(start=4, end=8, id=1, disabled=False),
                Token(start=9, end=11, id=2, disabled=False),
            ],
        ),
        SpansManualAnns(
            spans=[
                TextManualSpan(start=0, end=3, label="PER", token_start=0, token_end=0),
                TextManualSpan(
                    start=9, end=11, label="ORG", token_start=2, token_end=2
                ),
            ],
            tokens=[
                Token(start=0, end=3, id=0, disabled=False),
                Token(start=4, end=8, id=1, disabled=False),
                Token(start=9, end=11, id=2, disabled=False),
            ],
        ),
    ]
    assert list(reliability_table[2, :]) == [
        SpansManualAnns(
            spans=[
                TextManualSpan(start=4, end=8, label="PER", token_start=1, token_end=1),
                TextManualSpan(
                    start=9, end=13, label="PER", token_start=2, token_end=2
                ),
            ],
            tokens=[
                Token(start=0, end=3, id=0, disabled=False),
                Token(start=4, end=8, id=1, disabled=False),
                Token(start=9, end=13, id=2, disabled=False),
            ],
        ),
        SpansManualAnns(
            spans=[
                TextManualSpan(start=4, end=8, label="PER", token_start=1, token_end=1),
                TextManualSpan(
                    start=9, end=13, label="PER", token_start=2, token_end=2
                ),
            ],
            tokens=[
                Token(start=0, end=3, id=0, disabled=False),
                Token(start=4, end=8, id=1, disabled=False),
                Token(start=9, end=13, id=2, disabled=False),
            ],
        ),
        -1,
    ]


@pytest.mark.parametrize(
    "annotators, expected_shape",
    [
        (  # all annotators in the dataset
            ["ann_1", "ann_2", "ann_3"],
            (3, 3),
        ),
        (  # excluding one annotator on CLI
            ["ann_1", "ann_2"],
            (3, 2),
        ),
    ],
)
def test_filtering_annotators(
    annotator_1_TextManualSpan,
    annotator_2_TextManualSpan,
    annotator_3_TextManualSpan,
    annotators,
    expected_shape,
):
    """Test that the reliability table is built correctly"""
    m = IaaSpan(labels=["PER", "ORG"], annotators=annotators, partial=False)
    m._examples = annotator_1_TextManualSpan
    m._examples.extend(annotator_2_TextManualSpan)
    m._examples.extend(annotator_3_TextManualSpan)

    assert m._cli_annotators is not None
    assert m._cli_labels is not None
    reliability_table = _build_reliability_table(
        examples=m._examples,
        labels=m._cli_labels,
        annotators=m._cli_annotators,
        annotation_type=m._annotation_type,
        value_getter=m._value_getter,
    )

    assert reliability_table.shape == expected_shape


def test_get_coincident_examples_spans(reliability_table):
    """Test that the coincident examples are returned correctly"""
    m = IaaSpan()
    m._reliability_table = reliability_table
    expected = np.array(
        [
            [None, None],
            [
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=0, end=3, label="PER", token_start=0, token_end=0
                        ),
                        TextManualSpan(
                            start=9, end=11, label="ORG", token_start=2, token_end=2
                        ),
                    ]
                ),
                SpansAnns(
                    spans=[
                        TextManualSpan(
                            start=0, end=3, label="PER", token_start=0, token_end=0
                        ),
                        TextManualSpan(
                            start=9, end=11, label="ORG", token_start=2, token_end=2
                        ),
                    ]
                ),
            ],
        ]
    )
    coincident_examples = m._get_coincident_examples(1, 2)
    assert np.array_equal(coincident_examples, expected)


@pytest.mark.parametrize(
    "match_type, spans1, spans2, expected",
    [
        (  # label error, full match
            "full",
            [(0, 1, "a"), (2, 3, "b")],
            [(0, 1, "a"), (2, 3, "c")],
            {("a", "a"): 1, ("b", "c"): 1},
        ),
        (  # label error, partial match
            "partial",
            [(0, 1, "a"), (2, 3, "b")],
            [(0, 1, "a"), (2, 3, "c")],
            {("a", "a"): 1, ("b", "c"): 1},
        ),
        (
            # boundary error full match
            "full",
            [(2, 6, "a"), (21, 26, "b")],
            [(2, 6, "a"), (17, 26, "b")],
            {("a", "a"): 1, ("b", "0"): 1, ("0", "b"): 1},
        ),
        (
            # boundary error partial match
            "partial",
            [(2, 6, "a"), (21, 26, "b")],
            [(2, 6, "a"), (17, 26, "b")],
            {("a", "a"): 1, ("b", "b"): 1},
        ),
        (
            # perfect agreement full match
            "full",
            [(2, 6, "a"), (21, 26, "b")],
            [(2, 6, "a"), (21, 26, "b")],
            {("a", "a"): 1, ("b", "b"): 1},
        ),
        (
            # perfect agreement partial match
            "partial",
            [(2, 6, "a"), (21, 26, "b")],
            [(2, 6, "a"), (21, 26, "b")],
            {("a", "a"): 1, ("b", "b"): 1},
        ),
        (
            # no agreement full match
            "full",
            [(2, 6, "a"), (21, 26, "b")],
            [(7, 8, "a")],
            {("a", "0"): 1, ("b", "0"): 1, ("0", "a"): 1},
        ),
        (
            # no agreement partial match
            "partial",
            [(2, 6, "a"), (21, 26, "b")],
            [(7, 8, "a")],
            {("a", "0"): 1, ("b", "0"): 1, ("0", "a"): 1},
        ),
    ],
)
def test_single_eg_cm_2(
    match_type: str,
    spans1: List[Tuple[int, int, str]],
    spans2: List[Tuple[int, int, str]],
    expected: Dict[Tuple[str, str], int],
) -> None:
    labels = {label for s, e, label in spans1}
    labels.update({label for s, e, label in spans2})
    labels = list(sorted(labels))
    labels.append("0")
    iaa = IaaSpan(labels=labels, annotators=None, partial=match_type == "partial")
    if spans1 is None:
        trues = None
    else:
        trues = SpansAnns(
            spans=[
                TextSpan(start=start, end=end, label=label)
                for start, end, label in spans1
            ],
        )
    if spans2 is None:
        preds = None
    else:
        preds = SpansAnns(
            spans=[
                TextSpan(start=start, end=end, label=label)
                for start, end, label in spans2
            ]
        )
    cm = iaa._build_single_eg_confusion_matrix(trues, preds, labels)
    predicted = {}
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            if cm[i, j]:
                key = (labels[i], labels[j])
                predicted[key] = int(cm[i, j])
    assert expected == predicted


@pytest.mark.parametrize(
    "match_type, spans1, spans2, expected",
    [
        (
            # no spans annotatated
            "full",
            [None],
            [None],
            {("0", "0"): 1},
        ),
        (
            # no spans annotatated
            "partial",
            [None],
            [None],
            {("0", "0"): 1},
        ),
        (
            # ann1 no annoations
            "partial",
            [None],
            [(7, 8, "a")],
            {("0", "a"): 1},
        ),
        (
            # ann2 no annoations
            "partial",
            [(7, 8, "a")],
            [None],
            {("a", "0"): 1},
        ),
    ],
)
def test_single_eg_cm_3(
    match_type: str,
    spans1: List[Union[Tuple[int, int, str], None]],
    spans2: List[Union[Tuple[int, int, str], None]],
    expected: Dict[Tuple[str, str], int],
) -> None:
    labels = set()
    trues = None
    if spans1[0] is None:
        labels.add("0")
        trues = None
    else:
        assert spans1 is not None
        labels = {label for s, e, label in spans1}  # type: ignore
        trues = SpansAnns(
            spans=[
                TextSpan(start=start, end=end, label=label)
                for start, end, label in spans1  # type: ignore
            ]
        )
    if spans2[0] is None:
        labels.add("0")
        preds = None
    else:
        assert spans2 is not None
        labels.update({label for s, e, label in spans2})  # type: ignore
        preds = SpansAnns(
            spans=[
                TextSpan(start=start, end=end, label=label)
                for start, end, label in spans2  # type: ignore
            ]
        )
    if "0" not in labels:
        labels.add("0")
    labels = list(sorted(labels))
    iaa = IaaSpan(labels=labels, annotators=None, partial=match_type == "partial")
    cm = iaa._build_single_eg_confusion_matrix(trues, preds, labels)
    predicted = {}
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            if cm[i, j]:
                key = (labels[i], labels[j])
                predicted[key] = int(cm[i, j])
    assert expected == predicted


# test single example matrix
@pytest.mark.parametrize(
    "agreement, partial",
    [
        ("perfect_agreement", True),
        ("perfect_agreement", False),
        ("no_agreement", True),
        ("no_agreement", False),
        ("label_errors", True),
        ("label_errors", False),
        ("boundary_errors", True),
        ("boundary_errors", False),
    ],
)
def test_single_eg_cm(
    agreement,
    partial,
    perfect_agreement,
    perfect_agreement_matrix,
    no_agreement,
    label_errors,
    label_errors_matrix,
    no_agreement_matrix,
    boundary_errors,
    boundary_errors_matrix,
):
    """Test the single example confusion matrix is built correctly"""
    m = IaaSpan(labels=["ANIMAL", "PER"], partial=partial)
    egs = None
    expected = None
    if agreement == "perfect_agreement":
        egs = perfect_agreement
        expected = perfect_agreement_matrix
    elif agreement == "no_agreement":
        egs = no_agreement
        expected = no_agreement_matrix
    elif agreement == "label_errors":
        egs = label_errors
        expected = label_errors_matrix
        """
        print("Egs", egs)
        print("Expected", expected)
        """
    elif agreement == "boundary_errors":
        egs = boundary_errors
        if partial:
            expected = perfect_agreement_matrix
        else:
            expected = boundary_errors_matrix
    assert egs is not None
    assert expected is not None
    true = egs[0]
    pred = egs[1]
    labels = ["ANIMAL", "PER", "0"]
    cm_eg = m._build_single_eg_confusion_matrix(true, pred, labels)
    # print("RESULT", cm_eg)
    assert np.array_equal(cm_eg, np.array(expected))


def test_update_pair_matrix(
    perfect_agreement, no_agreement, boundary_errors, label_errors
):
    """Test the confusion matrix update for a pair of annotators"""
    m = IaaSpan(labels=["ANIMAL", "PER"])
    coincident_examples = np.stack(
        (perfect_agreement, no_agreement, boundary_errors, label_errors), axis=0
    )
    labels = ["ANIMAL", "PER", "0"]
    cm_pair = m._build_pairwise_confusion_matrix(coincident_examples, labels)
    expected = np.array([[2.0, 0.0, 2.0], [1.0, 2.0, 1.0], [2.0, 0.0, 0.0]])
    cm_pair = [list(x) for x in cm_pair]
    expected = [list(x) for x in expected]
    # print(cm_pair)
    # print(expected)
    assert cm_pair == expected
    # assert np.array_equal(cm_pair, expected)


def test_update_global_matrix(reliability_table):
    """Test the global confusion matrix update"""
    m = IaaSpan(
        labels=["PER", "ORG"],
        annotators=["ann_1", "ann_2", "ann_3"],
    )
    assert m._cli_annotators is not None
    assert m._cli_labels is not None
    m._labels = m._cli_labels
    m._annotators = m._cli_annotators
    m._reliability_table = reliability_table
    m._update_cms()
    expected = np.array([[5.0, 0.0, 0.0], [0.0, 3.0, 0.0], [0.0, 0.0, 3.0]])
    assert np.array_equal(m._confusion_matrix, expected)


def test_compute_avg_scores():
    m = IaaSpan(labels=["label1", "label2", "label3"], annotators=[])
    assert m._cli_annotators is not None
    assert m._cli_labels is not None
    m._labels = m._cli_labels
    m._annotators = m._cli_annotators
    total_support = 10
    m._results.metrics_per_label = {
        "label1": {"p": 0.8, "r": 0.9, "f1": 0.84, "support": 2},
        "label2": {"p": 0.7, "r": 0.8, "f1": 0.74, "support": 3},
        "label3": {"p": 0.6, "r": 0.7, "f1": 0.64, "support": 4},
    }
    m._update_macro_avg(total_support)
    assert m._results.pairwise_precision == 0.7
    assert m._results.pairwise_recall == 0.8
    assert m._results.pairwise_f1 == 0.74


@pytest.mark.parametrize(
    "agreement",
    ["boundary_errors"],
)
def test_get_result_from_cm(
    agreement,
    perfect_agreement_matrix,
    no_agreement_matrix,
    label_errors_matrix,
    boundary_errors_matrix,
):
    cm = None
    f1 = None
    if agreement == "perfect_agreement":
        cm = perfect_agreement_matrix
        f1 = 1.0
    elif agreement == "no_agreement":
        cm = no_agreement_matrix
        f1 = 0.0
    elif agreement == "label_errors":
        cm = label_errors_matrix
        f1 = 0.33
    elif agreement == "boundary_errors":
        cm = boundary_errors_matrix
        f1 = 0.5
    assert cm is not None
    assert f1 is not None
    m = IaaSpan(labels=["ANIMAL", "PER"], annotators=["ann_1", "ann_2"])
    assert m._cli_annotators is not None
    assert m._cli_labels is not None
    m._labels = m._cli_labels
    m._annotators = m._cli_annotators
    m._confusion_matrix = cm
    m._compute_agreement()
    assert m._results.pairwise_f1 == f1


def test_get_result_from_from_f1(reliability_table_label_errors):
    m = IaaSpan(
        labels=["PER", "ORG"],
        annotators=["ann_1", "ann_2", "ann_3"],
    )
    assert m._cli_annotators is not None
    assert m._cli_labels is not None
    m._labels = m._cli_labels
    m._annotators = m._cli_annotators
    m._reliability_table = reliability_table_label_errors
    m._update_cms()
    """
    Pairwise matrices:
    0-1
    [[3. 0. 2.]
    [1. 0. 0.]
    [0. 0. 1.]]
    0-2
    [[0. 1. 0.]
    [0. 1. 0.]
    [0. 0. 1.]]
    1-2
    [[0. 2. 0.]
    [0. 0. 0.]
    [0. 0. 1.]]
    Global confusion_matrix:
    [[3. 1. 3.]
    [3. 1. 0.]
    [1. 3. 0.]]
    """
    m._compute_agreement()
    assert m._results.pairwise_f1 == 0.47
    assert m._results.metrics_per_label["PER"]["f1"] == 0.6
    assert m._results.metrics_per_label["ORG"]["f1"] == 0.3333333333333333


"""
    [[5. 0. 0.]
 [0. 3. 0.]
 [0. 0. 3.]]

 [array([[3., 0., 0.],
       [0., 1., 0.],
       [0., 0., 1.]]),

array([[1., 0., 0.],
       [0., 1., 0.],
       [0., 0., 1.]]),

array([[1., 0., 0.],
       [0., 1., 0.],
       [0., 0., 1.]])]
"""
