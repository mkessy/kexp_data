from pathlib import Path
from typing import Generator

import pytest
import spacy
from spacy.pipeline.textcat import DEFAULT_SINGLE_TEXTCAT_MODEL
from spacy.pipeline.textcat_multilabel import DEFAULT_MULTI_TEXTCAT_MODEL
from spacy.training import Example

from prodigy.components.loaders import JSONL
from prodigy.components.source import GeneratorSource, load_noop
from prodigy.components.stream import Stream
from prodigy.core import Controller
from prodigy.recipes.textcat import (
    correct,
    get_textcat_component,
    infer_exclusive,
    manual,
    teach,
)
from prodigy.util import set_hashes


def examples():
    yield {"text": "test1", "_id": 1}
    yield {"text": "test2", "_id": 2}
    yield {"text": "test3", "_id": 3}


@pytest.fixture
def dataset():
    return "tmp-test-dataset"


@pytest.fixture
def text_stream():
    data_path = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    tasks = JSONL(data_path)
    return [set_hashes(task) for task in tasks]


def generator_to_stream(stream: Generator):
    source = GeneratorSource(items=stream)
    return Stream(source=source, loader=load_noop, wrappers=[])


# textcat.manual #


@pytest.mark.parametrize(
    "accept_empty", [True, False], ids=["accept_empty", "deny_empty"]
)
@pytest.mark.parametrize("labels", [["pos"], ["pos", "neg"]], ids=["binary", "multi"])
@pytest.mark.parametrize("exclusive", [True, False], ids=["exclusive", "not-exclusive"])
def test_validator_manual(dataset, text_stream, exclusive, labels, accept_empty):
    components = manual(
        dataset,
        text_stream,
        label=labels,
        exclusive=exclusive,
        accept_empty=accept_empty,
    )

    # The validator should trigger here
    if len(labels) > 1 and exclusive and (not accept_empty):
        # This should break
        with pytest.raises(AssertionError):
            components["validate_answer"]({"answer": "accept", "accept": labels})
        with pytest.raises(AssertionError):
            components["validate_answer"]({"answer": "accept", "accept": []})
        # This is fine
        components["validate_answer"]({"answer": "accept", "accept": [labels[0]]})
        components["validate_answer"]({"answer": "accept", "accept": [labels[1]]})
        components["validate_answer"]({"answer": "ignore", "accept": labels})
        components["validate_answer"]({"answer": "ignore", "accept": []})
        components["validate_answer"]({"answer": "reject", "accept": []})
    else:
        # In all other cases, no need to automatically validate
        assert components["validate_answer"] is None


def test_textcat_manual_custom_labels(dataset, text_stream):
    """Ensure that the textcat.manual recipe works well with a blank model and custom labels"""
    custom_labels = ["MY_POS", "MY_NEG"]
    components = manual(dataset, text_stream, label=custom_labels)
    ctrl = Controller.from_components("textcat.manual", components)
    assert ctrl.config["choice_style"] == "multiple"
    queue = ctrl.get_questions("vincent")
    labels = ctrl.config["labels"]
    assert labels == custom_labels
    eg = queue[0]
    assert "spans" not in eg
    ctrl.db.drop_dataset(dataset)


def test_textcat_manual_exclusive(dataset, text_stream):
    """Ensure that the textcat.manual recipe can toggle the choice interface with 'exclusive'"""
    custom_labels = ["MY_POS", "MY_NEG"]
    components = manual(dataset, text_stream, label=custom_labels, exclusive=True)
    ctrl = Controller.from_components("textcat.manual", components)
    assert ctrl.config["choice_style"] == "single"
    ctrl.db.drop_dataset(dataset)


# textcat.correct #


@pytest.mark.parametrize(
    "textcat_model",
    ["spacy.TextCatEnsemble.v2", "spacy.TextCatCNN.v2", "spacy.TextCatBOW.v2"],
)
@pytest.mark.parametrize("exclusive", [True, False])
def test_infer_exclusive(exclusive, textcat_model):
    nlp = spacy.blank("en")
    doc = nlp("This is an example")

    # For each architecture, generate a config that the `infer_exclusive` function should handle
    config = {"model": {"@architectures": textcat_model}}
    if textcat_model == "spacy.TextCatEnsemble.v2":
        config["model"] = (
            DEFAULT_SINGLE_TEXTCAT_MODEL if exclusive else DEFAULT_MULTI_TEXTCAT_MODEL
        )
    if textcat_model == "spacy.TextCatCNN.v2":
        config["model"]["exclusive_classes"] = exclusive
        config["model"]["tok2vec"] = {
            "@architectures": "spacy.Tok2Vec.v2",
            "embed": {
                "@architectures": "spacy.MultiHashEmbed.v2",
                "width": 64,
                "rows": [2000, 2000, 500, 1000, 500],
                "attrs": ["NORM", "LOWER", "PREFIX", "SUFFIX", "SHAPE"],
                "include_static_vectors": False,
            },
            "encode": {
                "@architectures": "spacy.MaxoutWindowEncoder.v2",
                "width": 64,
                "window_size": 1,
                "maxout_pieces": 3,
                "depth": 2,
            },
        }
    if textcat_model == "spacy.TextCatBOW.v2":
        config["model"]["exclusive_classes"] = exclusive
        config["model"]["ngram_size"] = 1
        config["model"]["no_output_layer"] = False

    if exclusive:
        doc.cats = {"pos": 1, "neg": 0}
        textcat = nlp.add_pipe("textcat", config=config)
    else:
        doc.cats = {"pos": 1, "neg": 1}
        textcat = nlp.add_pipe("textcat_multilabel", config=config)

    # Initialize the component and recipe
    textcat.initialize(lambda: [Example(doc, doc)], nlp=nlp)
    component = get_textcat_component(nlp.pipe_names, component=None)

    # Confirm correct behavior
    assert infer_exclusive(nlp, component) == exclusive


@pytest.mark.parametrize(
    "accept_empty", [True, False], ids=["accept_empty", "deny_empty"]
)
@pytest.mark.parametrize("labels", [["pos"], ["pos", "neg"]], ids=["single", "multi"])
@pytest.mark.parametrize("exclusive", [True, False], ids=["exclusive", "not-exclusive"])
def test_validator_correct(dataset, text_stream, exclusive, labels, accept_empty):
    # First build a spaCy model, depending on it being exclusive or not
    nlp = spacy.blank("en")
    doc = nlp("This is an example")
    if exclusive:
        doc.cats = {"pos": 1, "neg": 0}
        textcat = nlp.add_pipe("textcat")
    else:
        doc.cats = {"pos": 1, "neg": 1}
        textcat = nlp.add_pipe("textcat_multilabel")

    # Initialize the component and recipe
    textcat.initialize(lambda: [Example(doc, doc)], nlp=nlp)
    components = correct(
        dataset, nlp, text_stream, label=labels, accept_empty=accept_empty
    )

    # The validator should trigger here
    if len(labels) > 1 and exclusive and (not accept_empty):
        # This should break
        with pytest.raises(AssertionError):
            components["validate_answer"]({"answer": "accept", "accept": labels})
        # This is fine
        components["validate_answer"]({"answer": "accept", "accept": [labels[0]]})
        components["validate_answer"]({"answer": "accept", "accept": [labels[1]]})
        components["validate_answer"]({"answer": "ignore", "accept": labels})
        components["validate_answer"]({"answer": "ignore", "accept": []})
        components["validate_answer"]({"answer": "reject", "accept": []})
    else:
        # In all other cases, no need to automatically validate
        assert components["validate_answer"] is None


# textcat.teach #


def test_textcat_teach_with_no_answers_vectors(dataset, nlp_md):
    """Ensure that the textcat.teach recipe provides the same answers when not updating"""
    custom_labels = ["MY_POS", "MY_NEG"]
    inputs = list(examples())
    by_id = {eg["_id"]: eg for eg in inputs}
    components = teach(dataset, nlp_md, inputs, label=custom_labels)
    stream = generator_to_stream(components["stream"])
    stream.create_queue("vincent", n_history=-1)
    assert "update" in components
    assert hasattr(components["update"], "__call__")
    for item in stream.iter_queue(lambda d: ["vincent"], "vincent"):
        eg = item.data
        orig_eg = by_id[eg["_id"]]
        score = eg["score"]
        assert score >= 0
        assert score <= 1
        assert "text" in eg
        assert eg["text"] == orig_eg["text"]
        if "answer" in orig_eg:
            assert eg["answer"] == orig_eg["answer"]


def test_textcat_teach_with_no_answers_no_vectors(dataset, nlp):
    custom_labels = ["MY_POS", "MY_NEG"]
    inputs = list(examples())
    by_id = {eg["_id"]: eg for eg in inputs}
    components = teach(dataset, nlp, inputs, label=custom_labels)
    stream = generator_to_stream(components["stream"])
    stream.create_queue("vincent", n_history=-1)
    assert "update" in components
    assert hasattr(components["update"], "__call__")
    for item in stream.iter_queue(lambda d: ["vincent"], "vincent"):
        eg = item.data
        orig_eg = by_id[eg["_id"]]
        score = eg["score"]
        assert score >= 0
        assert score <= 1
        assert "text" in eg
        assert eg["text"] == orig_eg["text"]
        if "answer" in orig_eg:
            assert eg["answer"] == orig_eg["answer"]


def test_textcat_teach_updates(dataset, nlp):
    """Ensure that the textcat.teach recipe is able to overfit through active learning in new controller setup"""
    custom_labels = ["MY_POS", "MY_NEG"]

    def yield_tasks():
        for i in range(500):
            yield {"text": f"We're relatively happy with purchase {i}."}

    components = teach(dataset, nlp, yield_tasks(), label=custom_labels)
    ctrl = Controller.from_components("ner.teach", components=components)

    batch = []
    pos_nr, neg_nr = 0, 0
    pos_score, neg_score = 0, 0
    ctrl.stream.create_queue("vincent", n_history=-1)
    queue = ctrl.stream.iter_queue(lambda d: ["vincent"], "vincent")

    for item in queue:
        eg = item.data
        # forcing this sentence to be negative
        if eg["label"] == "MY_NEG":
            eg["answer"] = "accept"
            neg_nr += 1
            neg_score += eg["score"]
        else:
            eg["answer"] = "reject"
            pos_nr += 1
            pos_score += eg["score"]
        batch.append(eg)
        if len(batch) == 16:
            if pos_nr:
                pos = pos_score / pos_nr
            else:
                pos = 0
            if neg_nr:
                neg = neg_score / neg_nr
            else:
                neg = 0

            pos_nr, neg_nr = 0, 0
            pos_score, neg_score = 0, 0
            components["update"](batch)
            batch = []

    # If this fails, we haven't learned anything...
    assert pos + neg
    if neg:
        assert neg > 0.95
    if pos:
        assert pos < 0.05


def test_textcat_with_matcher(datasets_path, nlp_fresh):
    custom_labels = ["GANGSTER"]
    inputs = list(examples())
    inputs.append({"text": "And a swindler", "_id": 4})
    pattern_path = datasets_path / "ner_patterns.txt"
    {eg["_id"]: eg for eg in inputs}
    components = teach(
        dataset, nlp_fresh, inputs, label=custom_labels, patterns=str(pattern_path)
    )
    annotated_examples = list(components["stream"])
    assert len(annotated_examples) == 5
    swindler_examples = [eg for eg in annotated_examples if eg["_id"] == 4]
    assert len(swindler_examples) == 2
    assert len(swindler_examples[0]["spans"]) == 1
    assert annotated_examples[1]["meta"].get("score") is not None
