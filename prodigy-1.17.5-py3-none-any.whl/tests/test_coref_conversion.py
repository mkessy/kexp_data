from prodigy.recipes.data_utils import _convert_coref_to_clusters

COREF_DATA = [
    {
        "text": "I saw Sam in the grocery store, she said it was warm there.",
        "relations": [
            {
                "head": 2,
                "child": 8,
                "head_span": {
                    "start": 6,
                    "end": 9,
                    "token_start": 2,
                    "token_end": 2,
                    "label": "PERSON",
                },
                "child_span": {
                    "start": 32,
                    "end": 35,
                    "token_start": 8,
                    "token_end": 8,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
            {
                "head": 6,
                "child": 13,
                "head_span": {
                    "start": 13,
                    "end": 30,
                    "token_start": 4,
                    "token_end": 6,
                    "label": "NP",
                },
                "child_span": {
                    "start": 53,
                    "end": 58,
                    "token_start": 13,
                    "token_end": 13,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
        ],
        "answer": "accept",
        "true_clusters": 2,
    },
    {
        "text": "I left my plant in a sunny window, it likes it there.",
        "relations": [
            {
                "head": 3,
                "child": 9,
                "head_span": {
                    "start": 10,
                    "end": 15,
                    "token_start": 3,
                    "token_end": 3,
                    "label": "NP",
                },
                "child_span": {
                    "start": 35,
                    "end": 37,
                    "token_start": 9,
                    "token_end": 9,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
            {
                "head": 7,
                "child": 12,
                "head_span": {
                    "start": 19,
                    "end": 33,
                    "token_start": 5,
                    "token_end": 7,
                    "label": "NP",
                },
                "child_span": {
                    "start": 47,
                    "end": 52,
                    "token_start": 12,
                    "token_end": 12,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
        ],
        "answer": "accept",
        "true_clusters": 2,
    },
    {
        "text": "The sky is blue.",
        "answer": "accept",
        "relations": [],
        "true_clusters": 0,
    },
    {
        "text": "Tom said he would come but he changed his mind.",
        "relations": [
            {
                "head": 0,
                "child": 2,
                "head_span": {
                    "start": 0,
                    "end": 3,
                    "token_start": 0,
                    "token_end": 0,
                    "label": "PERSON",
                },
                "child_span": {
                    "start": 9,
                    "end": 11,
                    "token_start": 2,
                    "token_end": 2,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
            {
                "head": 2,
                "child": 6,
                "head_span": {
                    "start": 9,
                    "end": 11,
                    "token_start": 2,
                    "token_end": 2,
                    "label": None,
                },
                "child_span": {
                    "start": 27,
                    "end": 29,
                    "token_start": 6,
                    "token_end": 6,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
            {
                "head": 6,
                "child": 8,
                "head_span": {
                    "start": 27,
                    "end": 29,
                    "token_start": 6,
                    "token_end": 6,
                    "label": None,
                },
                "child_span": {
                    "start": 38,
                    "end": 41,
                    "token_start": 8,
                    "token_end": 8,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
        ],
        "true_clusters": 1,
    },
]


def test_coref_conversion():
    for doc in COREF_DATA:
        clusters = _convert_coref_to_clusters(doc["relations"])
        assert len(clusters) == doc["true_clusters"], "Wrong cluster count"
