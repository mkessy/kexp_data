from pathlib import Path
from typing import Iterable, Optional, cast

import pytest
import spacy
from spacy.tokens import Doc
from spacy.util import registry
from thinc.api import Ops, get_current_ops
from thinc.types import Ints1d, Ragged

from prodigy.components.loaders import JSONL
from prodigy.core import Controller
from prodigy.recipes.spans import manual, validate_with_suggester
from prodigy.util import set_hashes


@pytest.fixture
def dataset():
    return "tmp-test-dataset"


@pytest.fixture
def text_stream():
    data_path = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    tasks = JSONL(data_path)
    return [set_hashes(task) for task in tasks]


@pytest.fixture
def patterns_path():
    data_path = Path(__file__).parent / "sample_datasets" / "ner_patterns.txt"
    return data_path


# spans.manual #


def test_spans_manual_blank_model(dataset, text_stream, nlp_blank):
    """Ensure that the spans.manual recipe works well with custom labels"""
    custom_labels = ["MY_LABEL", "ANOTHER_LABEL"]
    components = manual(dataset, nlp_blank, text_stream, label=custom_labels)
    ctrl = Controller.from_components("spans.manual", components)
    queue = list(ctrl.stream)
    labels = ctrl.config["labels"]
    assert labels == custom_labels
    eg = queue[0]
    assert "spans" not in eg
    ctrl.db.drop_dataset(dataset)


def test_spans_manual_pretrained_model_labels(dataset, text_stream, nlp):
    """Ensure that the spans.manual recipe works well with a pretrained model and custom labels"""
    custom_labels = ["MY_LABEL", "ANOTHER_LABEL"]
    components = manual(dataset, nlp, text_stream, label=custom_labels)
    ctrl = Controller.from_components("spans.manual", components)
    queue = list(ctrl.stream)
    labels = ctrl.config["labels"]
    assert labels == custom_labels
    eg = queue[0]
    assert "spans" not in eg
    ctrl.db.drop_dataset(dataset)


def test_spans_manual_patterns(dataset, text_stream, nlp, patterns_path):
    """Ensure that the spans.manual recipe pre-annotates entities from the provided patterns"""
    custom_labels = ["MY_LABEL", "ANOTHER_LABEL"]
    components = manual(
        dataset, nlp, text_stream, patterns=patterns_path, label=custom_labels
    )
    ctrl = Controller.from_components("spans.manual", components)
    queue = list(ctrl.stream)
    eg = queue[0]
    assert "illegally touting horses" in eg["text"]
    assert len(eg["spans"]) == 1
    assert eg["spans"][0]["text"] == "swindler"
    assert eg["spans"][0]["label"] == "GANGSTER"
    assert len(eg["tokens"]) == 79
    ctrl.db.drop_dataset(dataset)


def test_spans_manual_chars(dataset, text_stream, nlp):
    """Ensure that the spans.manual recipe's highlight_chars option works well"""
    custom_labels = ["MY_LABEL", "ANOTHER_LABEL"]
    components = manual(
        dataset, nlp, text_stream, highlight_chars=True, label=custom_labels
    )
    ctrl = Controller.from_components("spans.manual", components)
    queue = list(ctrl.stream)
    eg = queue[0]
    assert "illegally touting horses" in eg["text"]
    assert len(eg["text"].replace(" ", "")) == 327
    assert len(eg["tokens"]) == 79
    ctrl.db.drop_dataset(dataset)


# suggester validation #


@registry.misc("noun_suggester")
def build_noun_suggester():
    """This suggester suggests every token which .pos_ is a NOUN"""

    def noun_suggester(docs: Iterable[Doc], *, ops: Optional[Ops] = None) -> Ragged:
        if ops is None:
            ops = get_current_ops()

        spans = []
        lengths = []

        for doc in docs:
            cache = set()
            length = 0

            for token in doc:
                if token.pos_ == "NOUN":
                    if (token.i, token.i + 1) not in cache:
                        spans.append((token.i, token.i + 1))
                        cache.add((token.i, token.i + 1))
                        length += 1
            lengths.append(length)

        lengths_array = cast(Ints1d, ops.asarray(lengths, dtype="i"))
        if len(spans) > 0:
            output = Ragged(ops.asarray(spans, dtype="i"), lengths_array)
        else:
            output = Ragged(ops.xp.zeros((0, 0), dtype="i"), lengths_array)

        return output

    return noun_suggester


def test_suggester_validation():
    """Ensure that suggesters relying on annotations from other components work"""
    data_path = Path(__file__).parent / "sample_datasets" / "suggester_validation.jsonl"
    tasks = [task for task in JSONL(data_path)]
    validation = validate_with_suggester(
        spacy.load("en_core_web_sm"), "noun_suggester", use_annotations=True
    )

    # I love turtles!, spans = ["turtles"] | Validation should be successful
    assert validation(tasks[0]) is None

    # I love trains!, spans = ["love"] | Validation should throw an error
    with pytest.raises(ValueError):
        validation(tasks[1])
