from pathlib import Path

import pytest

from prodigy.recipes.audio import transcribe
from prodigy.util import INPUT_HASH_ATTR


@pytest.fixture
def dataset() -> str:
    return "tmp-test-dataset"


@pytest.fixture
def audio_stream_path() -> Path:
    # Credits: pauliuw (OpenGameArt): https://opengameart.org/content/the-field-of-dreams
    data_path = Path(__file__).parent / "recordings"
    return data_path


# audio.transcribe #


@pytest.mark.parametrize("text_rows", [1, 2, 4])
def test_audio_transcribe_stream_props(
    dataset: str, audio_stream_path: Path, text_rows: int
):
    """Ensure that audio.transcribe can stream examples and has the
    correct properties to display the view"""
    recipe = transcribe(dataset, audio_stream_path, text_rows=text_rows)
    eg = list(recipe["stream"])[0]  # take one example
    assert INPUT_HASH_ATTR in eg
    assert eg["field_rows"] == text_rows
    assert eg["field_label"] == "Transcript"
    assert eg["field_id"] == "transcript"
    assert eg["field_autofocus"] is True
