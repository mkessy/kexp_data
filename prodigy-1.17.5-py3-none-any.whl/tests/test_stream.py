import io
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, TypeVar, cast

import pytest
import srsly
from pydantic import BaseModel
from pytest_lazyfixture import lazy_fixture

from prodigy.components.db import Database, DatasetNotFound
from prodigy.components.source import ListSource, load_noop
from prodigy.components.stream import Stream, _get_stream_internal, get_stream
from prodigy.structured_types import (
    AudioSpansExample,
    Example,
    ImageExample,
    VideoSpansExample,
    prodigy_example_type,
)
from prodigy.types import TaskType
from prodigy.util import INPUT_HASH_ATTR, TASK_HASH_ATTR, set_hashes

from .util import FixtureRequest

_ExampleT = TypeVar("_ExampleT", TaskType, Example)


@pytest.fixture
def unst_stream(datasets_path: Path) -> Stream[Any, TaskType]:
    input_file = datasets_path / "input_2000.jsonl"
    examples = cast(List[Dict[str, Any]], list(srsly.read_jsonl(input_file)))
    examples = [set_hashes(eg) for eg in examples]
    return Stream(
        source=ListSource(examples),
        loader=load_noop,
        wrappers=[],
    )


@pytest.fixture
def st_stream(datasets_path: Path) -> Stream[Any, Example]:
    input_file = datasets_path / "input_2000_st.jsonl"
    examples = cast(List[Dict[str, Any]], list(srsly.read_jsonl(input_file)))
    st_examples = []
    for eg in examples:
        _ = eg.pop("__class__")
        st_examples.append(Example.from_dict(eg))
    return Stream(
        source=ListSource(examples),
        loader=load_noop,
        wrappers=[],
    )


@pytest.fixture(params=[lazy_fixture("unst_stream"), lazy_fixture("st_stream")])
def stream(request: FixtureRequest[Stream]) -> Stream:
    return request.param


def _test_wrapper(stream: Iterator[_ExampleT]) -> Iterator[_ExampleT]:
    for eg in stream:
        if isinstance(eg, dict):
            eg["meta"] = {"test": "test"}
        elif isinstance(eg, Example):
            eg.meta = {"test": "test"}
        yield eg


def _dummy_router(d: Any) -> List[str]:
    return ["vincent"]


def test_smoke_stream(stream: Stream):
    """This is a smoke test."""
    # Add wrapper
    stream.apply(_test_wrapper)
    # Check source size
    assert stream.source_size == 2000

    # Assume there are three people who might annotate
    names = ["vincent", "noa", "tim"]
    for name in names:
        stream.create_queue(name, n_history=0)

    def demo_router(item):
        """This router will pass examples to everyone."""
        return names

    for i in range(10):
        # When we peek an item, it is added to the buffer
        item_peek = stream.peek()
        assert item_peek is not None
        assert len(stream._buffer) == 1
        # Only one item is kept in the buffer, even if we peek again
        item_peek_again = stream.peek()
        assert item_peek is not None
        assert item_peek_again is not None
        assert item_peek.key == item_peek_again.key
        # Everyone should get the same item here.
        item_tim = stream.get_next(demo_router, "tim")
        item_vincent = stream.get_next(demo_router, "vincent")
        item_noa = stream.get_next(demo_router, "noa")
        # After which the buffer should be empty.
        assert len(stream._buffer) == 0

        # Because all the items should be the same, the keys should match
        assert item_peek.key == item_tim.key
        assert item_peek.key == item_vincent.key
        assert item_peek.key == item_noa.key

        # The position of the source should be known, it
        # starts at zero but increments on every next()
        assert stream.source_position == i + 1

        # Confirm that hashes are automatically fixed
        # this assert statement should go away for Prodigy v2.
        if isinstance(item_peek.data, dict):
            assert INPUT_HASH_ATTR in item_peek.data


def test_router_ignore_scenario(stream: Stream):
    """This is a check for the router."""
    # Assume there are three people who might annotate
    names = ["vincent", "noa", "tim"]
    for name in names:
        stream.create_queue(name, n_history=0)

    def demo_router(d):
        """This router will pass examples to everyone except `vincent`."""
        return ["noa", "tim"]

    for _ in range(10):
        # Noa should receive the same stuff here, but not Vincent
        stream.get_next(demo_router, "tim")

    assert stream._queues["vincent"].qsize() == 0
    assert stream._queues["noa"].qsize() == 10

    for _ in range(10):
        # Again, Vincent should not receive stuff here
        stream.get_next(demo_router, "noa")

    # Tim has already consumed the items Noa just saw
    # Vincent never got any items because of the router
    # Noa consumed their entire queue
    assert stream._queues["tim"].qsize() == 0
    assert stream._queues["vincent"].qsize() == 0
    assert stream._queues["noa"].qsize() == 0


def test_empty():
    """Making sure that `.is_empty` works."""
    examples = [{"text": f"example {i}"} for i in range(20)]
    s = Stream(
        source=ListSource(examples),
        loader=load_noop,
        wrappers=[],
    )
    s.create_queue("vincent", n_history=0)
    for _ in range(20):
        assert not s.is_empty
        s.get_next(lambda d: ["vincent"], "vincent")
    assert s.is_empty


@pytest.mark.parametrize("size", [5, 10, 15])
def test_history_and_copy(size: int):
    """Test to ensure history plays nice with copies."""

    # This is a function with no args/kwargs, it should work. And yet ...
    def add_key(gen):
        for item in gen:
            item["foo"] = "bar"
            yield item

    examples = [set_hashes({"text": f"example {i}"}) for i in range(20)]
    s = Stream(
        source=ListSource(examples),
        loader=load_noop,
        wrappers=[add_key],
        max_history_size=size,
    )
    # Creates a user who is getting items
    s.create_queue("vincent", n_history=10)

    def vincent_router(_: Any) -> List[str]:
        return ["vincent"]

    for _ in range(20):
        s.get_next(vincent_router, "vincent")

    # We should now have items in the history
    assert len(s._history) == size

    # When a new user is created, these history automatically
    # get these items in their queue
    s.create_queue("noa", n_history=20)
    assert s._queues["noa"].qsize() == size

    # When we create a copy of the original stream
    # we would get the same behavior with a new user
    s_copy = s.copy()
    s_copy.create_queue("tim", n_history=20)
    assert s_copy._queues["tim"].qsize() == size
    assert len(s_copy._history) == size

    # Also confirm wrappers are copied along
    for item in s_copy.iter_queue(lambda d: ["tim"], "tim"):
        assert item.data["foo"] == "bar"

    # But a restarted stream also restarts the history
    # so here a new queue would be empty
    s_copy_restart = s.copy_restarted()
    s_copy_restart.create_queue("sok", n_history=20)
    assert s_copy_restart._queues["sok"].qsize() == 0
    assert len(s_copy_restart._history) == 0

    # Also confirm wrappers are copied along
    for item in s_copy_restart.iter_queue(lambda d: ["sok"], "sok"):
        assert item.data["foo"] == "bar"


def test_raise_error_create_same_queue_twice(stream: Stream):
    """You shouldn't be able to rerun create_queue with same id."""
    stream.create_queue("vincent", n_history=0)
    with pytest.raises(RuntimeError):
        stream.create_queue("vincent", n_history=0)


class TextInput(BaseModel):
    text: str


@prodigy_example_type("tests.TextExample.v1")
class TextExample(Example):
    input_keys = ["text"]
    server_ann_keys = []
    user_ann_keys = []

    input: TextInput


@pytest.mark.parametrize("stringify", [True, False])
@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
@pytest.mark.parametrize("rehash", [True, False], ids=["rehash", "no_rehash"])
@pytest.mark.parametrize(
    "datafile",
    [
        "nyt_text_14.jsonl",
        "nyt_text_14.json",
        "nyt_text_14.txt",
        "nyt_text_14.csv",
        "nyt_text_14.parquet",
    ],
)
def test_get_stream(
    capsys,
    datasets_path: Path,
    datafile: str,
    stringify: bool,
    structured: bool,
    rehash: bool,
):
    # Read in data
    path = datasets_path / datafile
    # Path can also be passed as a string  (custom recipes)
    if stringify:
        path = str(path)

    kwargs = dict(rehash=rehash)

    try:
        if structured:
            stream = get_stream(
                path, structured=structured, structured_class=TextExample, **kwargs
            )
        else:
            stream = get_stream(path, **kwargs)
    except ImportError as e:
        # get_stream will raise an ImportError for parquet if pyarrow is not installed
        pytest.skip("Skipping test because of missing dependency: " + str(e))
    assert stream.source_position == 0

    # Creates a user who is getting items
    # When we just started loading a stream there is no position
    stream.create_queue("vincent", -1)
    for _ in range(14):
        example = stream.get_next(_dummy_router, "vincent")
        if structured:
            assert isinstance(example.data, TextExample)
            assert example.key == example.data.task_hash
            assert example.data.input.text is not None
        else:
            assert isinstance(example.data, dict)
            assert example.key == example.data[TASK_HASH_ATTR]
            assert "text" in example.data
        assert stream.source_position == example.position
    # But now the stream should be exhausted.
    with pytest.raises(StopIteration):
        example = stream.get_next(_dummy_router, "vincent")


@pytest.mark.parametrize("listify", [True, False], ids=["generator", "list"])
@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_get_stream_py_obj(datasets_path: Path, listify: bool, structured: bool):
    # Read in data
    data = srsly.read_jsonl(datasets_path / "nyt_text_14.jsonl")
    if listify:
        data = list(data)
    if structured:
        stream = get_stream(data, structured=structured, structured_class=TextExample)
    else:
        stream = get_stream(data)
    # When we just started loading a stream there is no position
    assert stream.source_position == 0
    stream.create_queue("vincent", -1)
    for _ in range(14):
        example = stream.get_next(_dummy_router, "vincent")
        if structured:
            assert isinstance(example.data, Example)
            assert example.key == example.data.task_hash
            assert example.data.input.text is not None
        else:
            assert isinstance(example.data, dict)
            assert example.key == example.data[TASK_HASH_ATTR]
            assert "text" in example.data
        assert stream.source_position == example.position
    # But now the stream should be exhausted.
    with pytest.raises(StopIteration):
        example = stream.get_next(_dummy_router, "vincent")


@pytest.mark.parametrize("folder", ["images", "recordings", "videos"])
@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_get_stream_binary(tests_path: Path, folder: str, structured: bool):
    # Each of these paths are folders with a single item
    loader_mapping = {
        "images": ("images", "image", ImageExample),
        "recordings": ("audio", "audio", AudioSpansExample),
        "videos": ("video", "video", VideoSpansExample),
    }
    # Each of these paths are folders with a single item
    input_path = tests_path / folder

    # Set up stream with single queue
    loader_id, input_key, structured_class = loader_mapping[folder]
    # Try once without loader to ensure source resolution works
    stream = get_stream(
        input_path, structured=structured, structured_class=structured_class
    )
    stream = get_stream(
        input_path,
        loader=loader_id,
        structured=structured,
        structured_class=structured_class,
    )

    stream.create_queue("vincent", -1)

    # Confirm that example exists and has expected properties
    example = stream.get_next(lambda d: ["vincent"], "vincent").data
    if isinstance(example, Example):
        example = example.to_unst()
    assert input_key in example.keys()
    assert str(input_path) in example["meta"]["path"]
    assert example["meta"]["file"]


@pytest.mark.parametrize(
    "structured_table", [True, False], ids=["st_table", "unst_table"]
)
@pytest.mark.parametrize(
    "structured_stream", [True, False], ids=["structured", "unstructured"]
)
def test_get_stream_can_load_dataset(
    database: Database,
    datasets_path: Path,
    structured_table: bool,
    structured_stream: bool,
):
    # We're loading the database fixture to ensure a clean DB before we add data
    examples = srsly.read_jsonl(datasets_path / "nyt_text_14.jsonl")
    # We have to hash, examples otherwise the `.add_examples` call won't allow it.
    examples = [{**set_hashes(cast(dict, e)), "answer": "accept"} for e in examples]

    database.add_dataset("test-stream", structured=structured_table)
    if structured_table:
        st_examples = [TextExample.from_unst_user(eg) for eg in examples]
        database.add_st_examples(st_examples, "test-stream", "test_session")
    else:
        database.add_examples(examples, ["test-stream"])

    if structured_table is False and structured_stream is True:
        with pytest.raises(SystemExit):
            stream = get_stream(
                "dataset:test-stream",
                structured=structured_stream,
                structured_class=TextExample,
            )
        return

    stream = get_stream(
        "dataset:test-stream",
        structured=structured_stream,
        structured_class=TextExample,
    )

    # From here it's just like the previous test
    assert stream.source_position == 0
    stream.create_queue("vincent", -1)
    for _ in range(14):
        example = stream.get_next(lambda d: ["vincent"], "vincent")
        if structured_stream:
            assert isinstance(example.data, TextExample)
            assert example.key == example.data.task_hash
            assert example.data.input.text is not None
        else:
            assert isinstance(example.data, dict)
            assert example.key == example.data[TASK_HASH_ATTR]
            assert "text" in example.data
        assert stream.source_position == example.position
    # But now the stream should be exhausted.
    with pytest.raises(StopIteration):
        example = stream.get_next(lambda d: ["vincent"], "vincent")


def test_get_stream_dataset_loader_regression(
    database: Database,
    datasets_path: Path,
):
    """Regression test for https://support.prodi.gy/t/prodigy-1-12-0-is-out/6655/8
    The `dataset:my_dataset` source should always take precedence over resolving
    a source based on a path.
    """
    examples = srsly.read_jsonl(datasets_path / "nyt_text_14.jsonl")
    # We have to hash, examples otherwise the `.add_examples` call won't allow it.
    examples = [{**set_hashes(cast(dict, e)), "answer": "accept"} for e in examples]

    database.add_dataset("test-stream")
    database.add_examples(examples, ["test-stream"])

    stream = get_stream("dataset:test-stream", loader="jsonl")
    assert len(list(stream)) == 14


@pytest.mark.parametrize(
    "structured", [True, False], ids=["structured", "unstructured"]
)
def test_get_stream_dataset_loader_answer_regression(
    database: Database, dataset: str, structured: bool
):
    """Regression test for https://support.prodi.gy/t/reviewing-ignored-cases/3356/9
    The `dataset:my_dataset` source works now but `dataset:my_dataset:{answer}` was not
    filtering, it was always returning all examples in the dataset
    """
    examples = [
        {
            "text": "test accept",
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
            "label": "TEST",
        },
        {
            "text": "test ignore",
            INPUT_HASH_ATTR: 2,
            TASK_HASH_ATTR: 2,
            "answer": "ignore",
            "label": "TEST",
        },
    ]
    database.add_dataset(dataset, structured=structured)

    if structured:
        examples = [
            Example.from_unst_user(
                eg, input_keys=["text"], server_ann_keys=[], user_ann_keys=["label"]
            )
            for eg in examples
        ]
        database.add_st_examples(examples, dataset, session_id="test_session")
    else:
        database.add_examples(examples, [dataset])

    stream = get_stream(f"dataset:{dataset}")
    assert stream.source_size == 2

    stream = get_stream(f"dataset:{dataset}:accept")
    assert stream.source_size == 1

    stream = get_stream(f"dataset:{dataset}:ignore")
    assert stream.source_size == 1

    stream = get_stream(f"dataset:{dataset}:reject")
    assert stream.source_size == 0

    with pytest.raises(SystemExit):
        stream = get_stream(f"dataset:{dataset}:invalid_answer")


def test_stream_set_max_history_size(stream: Stream):
    assert stream.max_history_size == -1

    stream.set_max_history_size(10)
    assert stream.max_history_size == 10

    stream.set_max_history_size(100_000)
    assert stream.max_history_size == 100_000


def test_get_stream_invalid_path(datasets_path: Path):
    valid_path = datasets_path / "nyt_text_14.jsonl"
    invalid_path = datasets_path / "nyt_text_14.jsonlmispelledextension"
    valid_nonexistent_path = datasets_path / "nonexistent.jsonl"

    stream = get_stream(valid_path)
    assert isinstance(stream, Stream)
    for path in [invalid_path, valid_nonexistent_path]:
        try:
            _get_stream_internal(path)
        except ValueError as e:
            assert str(e) == (
                f"Provided source: '{path}' was resolved as a Path but does not exist. "
                "If this is not a Path, try specifying an explicit loader. "
                "Otherwise, ensure the Path exists. "
                "If this is a dataset, remember to prefix the dataset name with `dataset:`."
            )

        with pytest.raises(SystemExit):
            get_stream(path)


def test_get_stream_invalid_loader(datasets_path: Path):
    valid_path = datasets_path / "nyt_text_14.jsonl"
    with pytest.raises(ValueError) as e:
        _get_stream_internal(valid_path, loader="invalid_loader")
        assert str(e) == "Loader: 'invalid_loader' could not be resolved."

    with pytest.raises(SystemExit):
        get_stream(valid_path, loader="invalid_loader")


def test_get_stream_invalid_api(datasets_path: Path):
    valid_path = datasets_path / "nyt_text_14.jsonl"
    try:
        _get_stream_internal(valid_path, api="invalid_api")
    except ValueError as e:
        assert str(e) == (
            "Using the 'api' loader is not supported with the new `get_stream` implementation. "
            "To use the 'api' loader you will need to use the legacy "
            "`prodigy.components.loaders.get_stream` function instead and provide the "
            "the stream as a plain python generator of task dicts. "
        )


def test_get_stream_dataset_not_found(database: Database):
    database.add_dataset("valid-dataset")
    examples = [
        {
            "text": "test accept",
            INPUT_HASH_ATTR: 1,
            TASK_HASH_ATTR: 1,
            "answer": "accept",
        },
        {
            "text": "test ignore",
            INPUT_HASH_ATTR: 2,
            TASK_HASH_ATTR: 2,
            "answer": "ignore",
        },
    ]
    database.add_examples(examples, ["valid-dataset"])
    stream = get_stream("dataset:valid-dataset")
    assert isinstance(stream, Stream)
    assert stream.source_size == 2

    with pytest.raises(DatasetNotFound):
        _get_stream_internal("dataset:non-existent-dataset")

    with pytest.raises(SystemExit):
        get_stream("dataset:non-existent-dataset")


def test_get_stream_dataset_is_path(database: Database):
    database.add_dataset("valid-dataset")
    example = {
        "text": "test",
        INPUT_HASH_ATTR: 1,
        TASK_HASH_ATTR: 1,
        "answer": "accept",
    }
    database.add_examples([example], ["valid-dataset"])
    stream = get_stream(Path("dataset:valid-dataset"))
    assert isinstance(stream, Stream)
    assert stream.source_size == 1


@pytest.mark.parametrize(
    "loader, datafile",
    [
        ("jsonl", "nyt_text_14.jsonl"),
        ("json", "nyt_text_14.json"),
        ("csv", "nyt_text_14.csv"),
        ("text", "nyt_text_14.txt"),
        (None, "nyt_text_14.txt"),
        ("nonexistent", "nyt_text_14.txt"),
    ],
    ids=["jsonl", "json", "csv", "text", "None", "nonexistent"],
)
def test_stdin_works(
    monkeypatch, loader: Optional[str], datafile: str, datasets_path: Path
):
    path = datasets_path / datafile
    going_in = Path(path).read_text()

    fake_stdin = io.BytesIO(going_in.encode("utf-8"))
    fake_stdin_wrapper = io.TextIOWrapper(fake_stdin, encoding="utf-8")
    # Pretending that this is going through stdin
    monkeypatch.setattr("sys.stdin", fake_stdin_wrapper)

    # Check the stream can read in from stdout.
    if loader is None:
        with pytest.raises(SystemExit) as e:
            stream = get_stream("-")
            assert e.match("Loader should be specified when reading from stdin")
    elif loader == "nonexistent":
        with pytest.raises(SystemExit) as e:
            stream = get_stream("-", loader=loader)
            assert e.match("Can't find 'nonexistent' in registry prodigy -> loaders.")
    else:
        stream = get_stream("-", loader=loader)
        for ex in stream:
            assert "text" in ex
