import sys
from pathlib import Path
from typing import List, cast

import pytest
import srsly

from prodigy.components.db import Database
from prodigy.components.loaders import JSONL
from prodigy.core import Controller, ControllerComponentsDict
from prodigy.recipes.generic import filter_by_patterns, mark
from prodigy.types import TaskType
from prodigy.util import set_hashes

from .util import make_tempdir


@pytest.fixture
def text_stream(datasets_path):
    data_path = datasets_path / "nyt_text.jsonl"
    tasks = JSONL(data_path)
    return [set_hashes(task) for task in tasks]


@pytest.fixture
def movies_path(datasets_path) -> Path:
    return datasets_path / "movies_sample.jsonl"


@pytest.fixture
def patterns_path(datasets_path) -> Path:
    return datasets_path / "ner_patterns.txt"


@pytest.mark.parametrize(
    "n_annots,answer,view_id", [(5, "accept", "classification"), (3, "reject", "text")]
)
def test_mark_recipe(
    database: Database,
    text_stream: List[TaskType],
    n_annots: int,
    answer: str,
    view_id: str,
    capsys,
):
    # [Vincent] The tests became flaky again. So I've put this back. If only for now.
    if sys.platform.startswith("win"):
        pytest.skip(
            "This test is very flaky on Windows in Github CI. We should investigate, but it's become very annoying to deal with."
        )
    dataset = "test_mark_recipe_dataset"
    components = cast(ControllerComponentsDict, mark(dataset, text_stream, view_id))
    components["db"] = database
    ctrl = Controller.from_components("mark", components)
    queue = ctrl.get_questions()
    answers = []
    for eg in queue[:n_annots]:
        eg["answer"] = answer
        answers.append(eg)
    ctrl.receive_answers(answers)
    ctrl.save()
    captured = capsys.readouterr()
    out = captured.out.lower()
    assert answer in out and str(n_annots) in out


def test_filter_by_patterns_base_behavior(movies_path, patterns_path, nlp_blank):
    # Temp file to check.
    with make_tempdir() as d:
        out_path = d / "tmp-filtered-out.jsonl"
        filter_by_patterns(
            source=movies_path,
            output=out_path,
            nlp=nlp_blank,
            patterns=patterns_path,
        )
        for ex in srsly.read_jsonl(out_path):
            assert "swindler" in ex["text"]


def test_filter_by_patterns_base_behavior_database(
    database, movies_path, patterns_path, nlp_blank
):
    # Name of dataset to upload to.
    dataset_name = "filtered-dataset"

    filter_by_patterns(
        source=movies_path,
        output=dataset_name,
        nlp=nlp_blank,
        patterns=patterns_path,
    )
    for ex in database.get_dataset_examples(dataset_name):
        assert "swindler" in ex["text"]
    database.drop_dataset(dataset_name)
