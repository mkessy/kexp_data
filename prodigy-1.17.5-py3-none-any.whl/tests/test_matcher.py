import warnings

import pytest
import spacy
from spacy.matcher import Matcher, PhraseMatcher

from prodigy.models.matcher import PatternMatcher, get_pattern_id, parse_patterns


@pytest.fixture
def nlp():
    return spacy.blank("en")


@pytest.fixture
def patterns():
    return [
        {"label": "FRUIT", "pattern": "apple"},
        {"label": "FRUIT", "pattern": [{"orth": "orange"}], "id": 1234},
        {"label": "VEG", "pattern": "butternut pumpkin"},
    ]


def test_init(nlp):
    PatternMatcher(nlp)


def test_split_patterns(patterns):
    token_patterns, phrase_patterns, _ = parse_patterns(patterns)
    assert len(token_patterns) == 1
    assert len(phrase_patterns) == 2
    assert token_patterns["FRUIT"][0][0] == 1234
    assert token_patterns["FRUIT"][0][1] == [{"orth": "orange"}]
    assert phrase_patterns["FRUIT"][0][1] == "apple"
    assert phrase_patterns["VEG"][0][1] == "butternut pumpkin"


def test_add_only_phrase_patterns(nlp):
    patterns = [{"label": "FRUIT", "pattern": "apple"}]
    model = PatternMatcher(nlp)
    model.add_patterns(patterns)
    assert len(model.matchers) == 1
    assert isinstance(model.matchers[0], PhraseMatcher)


def test_add_only_token_patterns(nlp):
    patterns = [{"label": "FRUIT", "pattern": [{"lemma": "apple"}]}]
    model = PatternMatcher(nlp)
    model.add_patterns(patterns)
    assert len(model.matchers) == 1
    assert isinstance(model.matchers[0], Matcher)


def test_add_both_patterns(nlp, patterns):
    model = PatternMatcher(nlp)
    model.add_patterns(patterns)
    assert len(model.matchers) == 2


def test_pattern_hashes_added(nlp, patterns):
    model = PatternMatcher(nlp)
    model.add_patterns(patterns)
    for pattern in patterns:
        pattern_id = pattern.get("id", get_pattern_id(pattern))
        assert model.correct_scores[str(pattern_id)] == model.prior_correct
        assert model.incorrect_scores[str(pattern_id)] == model.prior_incorrect


def test_pattern_hashes_update(nlp, patterns):
    pattern_ids = [p.get("id", get_pattern_id(p)) for p in patterns]
    answers = [
        {"answer": "accept", "spans": [{"pattern": pattern_ids[0]}]},
        {
            "answer": "reject",
            "spans": [{"pattern": pattern_ids[1]}, {"pattern": pattern_ids[2]}],
        },
    ]
    model = PatternMatcher(nlp)
    model.add_patterns(patterns)
    model.update(answers)
    assert model.correct_scores[str(pattern_ids[0])] == model.prior_correct + 1
    assert model.incorrect_scores[str(pattern_ids[0])] == model.prior_incorrect
    assert model.correct_scores[str(pattern_ids[1])] == model.prior_correct
    assert model.incorrect_scores[str(pattern_ids[1])] == model.prior_incorrect + 1
    assert model.correct_scores[str(pattern_ids[2])] == model.prior_correct
    assert model.incorrect_scores[str(pattern_ids[2])] == model.prior_incorrect + 1


@pytest.mark.parametrize(
    "stream,expected",
    [
        ([{"text": "apple pie"}], [(0, "apple")]),
        ([{"text": "appled"}], []),
        ([{"text": "pumpkin pie"}], []),
        ([{"text": "butternut pumpkin pie"}], [(2, "butternut pumpkin")]),
        ([{"text": "apple orange"}], [(1, "orange"), (0, "apple")]),
    ],
)
def test_match_patterns(nlp, patterns, stream, expected):
    model = PatternMatcher(nlp)
    model.add_patterns(patterns)
    matched = []
    for score, eg in model(stream):
        for span in eg["spans"]:
            matched.append((span["pattern"], span["text"]))
    expected_matches = []
    for i, match_text in expected:
        pattern = patterns[i]
        pattern_id = pattern["id"] if "id" in pattern else get_pattern_id(pattern)
        expected_matches.append((pattern_id, match_text))
    assert matched == expected_matches


def test_pattern_matcher_no_needless_w306_warning(datasets_path):
    # This test was introduced because of PS-1.
    # The file below contains the following patterns.
    # {"label": "GANGSTER", "pattern": "swindler"}
    pattern_path = datasets_path / "ner_patterns.txt"

    # https://docs.pytest.org/en/7.1.x/how-to/capture-warnings.html#additional-use-cases-of-warnings-in-tests
    # This block should confirm that no `[W036] UserWarning` from spaCy should
    # appear when we apply this pattern to a single text example.
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        matcher = PatternMatcher(spacy.blank("en")).from_disk(pattern_path)
        stream = [{"text": "you are such a swindler"}]
        next(matcher(stream))
