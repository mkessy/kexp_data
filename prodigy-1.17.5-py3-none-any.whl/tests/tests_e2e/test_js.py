import time

import pytest

from .util import prodigy_playwright


@pytest.mark.e2e
def test_js_overrides(dataset) -> None:
    overrides = {"javascript": "var dinosaurhead = 1;"}
    with prodigy_playwright(
        f"image.manual {dataset} ./tests/images --label floof,kitty",
        overrides=overrides,
    ) as (ctx, page):
        # Shame that this is needed, but it does take a bit.
        time.sleep(0.5)
        # Just checking that the variable "dinosaurhead" is indeed around.
        assert page.evaluate("dinosaurhead") == 1
