import atexit
import json
import os
import signal
import subprocess
import time
from contextlib import contextmanager
from io import BytesIO

import numpy as np
from PIL import Image, ImageColor
from playwright.sync_api import expect, sync_playwright

from prodigy.util import msg

PORT = 12345
BASE_URL = f"http://localhost:{PORT}"


@contextmanager
def prodigy_run_server(command: str, overrides={"port": PORT}):
    """
    Starts Prodigy, allow you to run playwright, turn it off after
    """
    config = json.dumps(overrides)
    cmd = f"python -m prodigy {command}"
    environment = os.environ
    environment["PRODIGY_CONFIG_OVERRIDES"] = f"{config}"
    serv_cmd = subprocess.Popen(cmd.split(), stdout=subprocess.PIPE, env=environment)

    # Make sure we shutdown properly if program exits via CTRL+C
    atexit.register(lambda: os.kill(serv_cmd.pid, signal.SIGKILL))

    # Sleep a bit, just in case.
    time.sleep(4)
    msg.info(f"running: {cmd} on pid={serv_cmd.pid}")
    yield serv_cmd.pid
    msg.info(f"shutting down {cmd}")
    os.kill(serv_cmd.pid, signal.SIGKILL)


@contextmanager
def prodigy_playwright(command: str, overrides=dict(), headless: bool = True):
    """
    Starts Prodigy, then playwright.
    """
    overrides = {"port": PORT, **overrides}
    with prodigy_run_server(command, overrides):
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=headless)
            context = browser.new_context()
            page = context.new_page()
            page.goto(BASE_URL)
            yield context, page
            context.close()
            browser.close()


def rougly_same_image(screenshot1: bytes, screenshot2: bytes):
    img1 = Image.open(BytesIO(screenshot1))
    img2 = Image.open(BytesIO(screenshot2))
    arr1 = np.array(img1)
    arr2 = np.array(img2)
    return np.isclose(arr1.mean(), arr2.mean())


def get_color_count(screenshot: bytes, color: str):
    assert color in ["yellow", "blue", "purple", "green"]
    # Color map according to the docs https://prodi.gy/docs/api-web-app#theme-color-palettes
    color_map = {
        "yellow": "#ffff00",
        "blue": "#00ffff",
        "purple": "#ff00ff",
        "green": "#00ff7f",
    }
    aim = ImageColor.getcolor(color_map[color], "RGB")
    img = Image.open(BytesIO(screenshot)).convert("RGB")
    w, h = img.size
    colors = img.getcolors(w * h)
    for count, rbg in colors:
        if rbg == aim:
            return count
    return 0


class Interactions:
    def __init__(self, page):
        self.page = page

    def hit_button(self, btn: str = "accept"):
        if btn == "accept":
            name = "accept (a)"
        if btn == "reject":
            name = "reject (x)"
        if btn == "ignore":
            name = "ignore (space)"
        if btn == "undo":
            name = "undo (backspace, del)"
        self.page.get_by_role("button", name=name).click()

    def accept(self):
        self.hit_button(btn="accept")

    def get_image_canvas(self):
        canvas = self.page.locator("canvas").nth(1)
        expect(canvas).to_be_visible(timeout=1000)
        return canvas

    def draw(
        self,
        label: str,
        shape: str = "rectangle",
        shortcut: bool = False,
        x1: int = 10,
        x2: int = 100,
        y1: int = 10,
        y2: int = 100,
    ):
        """Utility for drawing on image.manual"""
        self.select_shape(shape)
        self.select_label(label, shortcut=shortcut)

        if shape == "rectangle":
            self.get_image_canvas().hover(position={"x": x1, "y": y1})
            canvas_bb = self.get_image_canvas().bounding_box()
            self.page.mouse.down()
            self.page.mouse.move(x=canvas_bb["x"] + x2, y=canvas_bb["y"] + y2, steps=10)
            self.page.mouse.up()
        if shape == "poly":
            self.get_image_canvas().hover(position={"x": x1, "y": y1})
            canvas_bb = self.get_image_canvas().bounding_box()
            self.page.mouse.click(x=canvas_bb["x"] + x1, y=canvas_bb["y"] + y1)
            self.page.mouse.click(x=canvas_bb["x"] + x2, y=canvas_bb["y"] + y1)
            self.page.mouse.click(x=canvas_bb["x"] + x2, y=canvas_bb["y"] + y2)
            self.page.mouse.click(x=canvas_bb["x"] + x1, y=canvas_bb["y"] + y2)
            self.page.mouse.click(x=canvas_bb["x"] + x1, y=canvas_bb["y"] + y1)
        if shape == "freehand":
            self.get_image_canvas().hover(position={"x": x1, "y": y1})
            canvas_bb = self.get_image_canvas().bounding_box()
            self.page.mouse.down()
            self.page.mouse.move(x=canvas_bb["x"] + x2, y=canvas_bb["y"] + y1, steps=10)
            self.page.mouse.move(x=canvas_bb["x"] + x2, y=canvas_bb["y"] + y2, steps=10)
            self.page.mouse.move(x=canvas_bb["x"] + x1, y=canvas_bb["y"] + y2, steps=10)
            self.page.mouse.up()

    def select_label(self, label: str, shortcut: bool = False):
        if shortcut:
            number = self.page.locator(f'[data-test="{label}"] span').inner_text()
            self.page.keyboard.press(number)
        else:
            self.page.locator(f'[data-test="{label}"]').click()

    def select_shape(self, shape: str, shortcut: bool = False):
        assert shape in ["rectangle", "poly", "freehand"]
        if shortcut:
            if shape == "rectangle":
                self.page.keyboard.press("r")
            if shape == "poly":
                self.page.keyboard.press("p")
            if shape == "freehand":
                self.page.keyboard.press("f")
        else:
            if shape == "rectangle":
                self.page.get_by_role("button", name="Rect (r)").click()
            if shape == "poly":
                self.page.get_by_role("button", name="Polygon (t, p)").click()
            if shape == "freehand":
                self.page.get_by_role("button", name="Freehand (f)").click()

    def save(self):
        self.page.locator('[data-test="sidebar-button-save"]').click()
