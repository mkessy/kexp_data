import pytest

from .util import Interactions, get_color_count, prodigy_playwright, rougly_same_image


@pytest.mark.e2e
def test_image_manual_add_remove_rectangle(tmp_path, dataset) -> None:
    """For a rectangle it is easy to know where to click to remove the element"""
    with prodigy_playwright(
        f"image.manual {dataset} ./tests/images --label floof,kitty"
    ) as (ctx, page):
        # The canvas element is the thing that matters
        canvas_elem = page.locator("canvas").nth(1)

        # Remember what the image looked like before
        screenshot1 = canvas_elem.screenshot(path=tmp_path / "screen1.png")

        # Draw a square
        canvas_elem.hover(position={"x": 10, "y": 10})
        canvas_bb = canvas_elem.bounding_box()
        page.mouse.down()
        page.mouse.move(x=canvas_bb["x"] + 100, y=canvas_bb["y"] + 100, steps=4)
        page.mouse.up()

        # Remember what the canvas looks like after drawing
        screenshot2 = canvas_elem.screenshot(path=tmp_path / "screen2.png")

        # Remove the rectangle and screenshot canvas again
        canvas_elem.click(position={"x": 20, "y": 20})
        page.get_by_role("button", name="Delete (d)").click()
        screenshot3 = canvas_elem.screenshot(path=tmp_path / "screen3.png")

        # Removing the rectangle should result in the original screen
        assert rougly_same_image(screenshot1, screenshot3)
        assert not rougly_same_image(screenshot1, screenshot2)

        # Drawn rectangle is yellow, so we also have some color expectations
        c1 = get_color_count(screenshot1, color="yellow")
        c2 = get_color_count(screenshot2, color="yellow")
        c3 = get_color_count(screenshot3, color="yellow")
        assert c1 < c2
        assert c2 > c3


@pytest.mark.e2e
@pytest.mark.parametrize("shape", ["rectangle", "freehand", "poly"])
@pytest.mark.parametrize("shortcut", [True, False])
def test_can_select_labels_and_draw(shape, shortcut, dataset) -> None:
    """For all shapes we should be able to select and draw. Also checks shortcuts"""
    with prodigy_playwright(
        f"image.manual {dataset} ./tests/images --label floof,kitty"
    ) as (ctx, page):
        interactions = Interactions(page)
        canvas_elem = interactions.get_image_canvas()
        screenshot1 = canvas_elem.screenshot()
        interactions.draw(
            "kitty", shape=shape, shortcut=shortcut, x1=10, y1=10, x2=100, y2=100
        )
        screenshot2 = canvas_elem.screenshot()
        interactions.draw(
            "floof", shape=shape, shortcut=shortcut, x1=30, y1=30, x2=130, y2=130
        )
        screenshot3 = canvas_elem.screenshot()

        # Something yellow got added
        c1 = get_color_count(screenshot1, color="yellow")
        c2 = get_color_count(screenshot2, color="yellow")
        assert c1 < c2
        # Something blue got added
        c3 = get_color_count(screenshot2, color="blue")
        c4 = get_color_count(screenshot3, color="blue")
        assert c3 < c4
