import shutil
import tempfile
from contextlib import contextmanager
from pathlib import Path

import pytest
import spacy
from spacy.tokens import DocBin
from spacy.training.initialize import init_nlp
from spacy.training.loop import train as spacy_train
from spacy.util import load_config

from prodigy.components.db import Database
from prodigy.recipes.data_utils import merge_data, validate_examples
from prodigy.recipes.train import data_to_spacy, train, train_curve
from prodigy.util import MISSING_VALUE as MISSING
from prodigy.util import NER_DEFAULT_INCORRECT_KEY, SPANCAT_DEFAULT_KEY, set_hashes


@contextmanager
def make_tempdir():
    d = Path(tempfile.mkdtemp())
    yield d
    shutil.rmtree(str(d))


NER_DATA = [
    {
        "text": "I should have just gone to the wedding last year.",
        "spans": [{"start": 39, "end": 48, "label": "DATE"}],
        "answer": "accept",
    },
    {
        "text": "In Bad Muenstereifel?",
        "spans": [{"start": 3, "end": 20, "label": "GPE"}],
        "answer": "accept",
    },
    {
        "text": "Keds are alright. I think they do have the stereotype of \"early 2010s teenage girl\" (maybe just because I wore them as a teenage girl in like 2012 haha). I haven't worn Keds in a few years, but I think they're just okay. I wore mine a lot and they didn't hold up that well. And if you want or need a supportive shoe, then I'd suggest wearing an insert with Keds because there's absolutely no arch support. I'm a bigger fan of Superga now. They're similar to Keds but I think they look more modern and adult. I still wear an insert with Supergas, though.",
        "spans": [
            {
                "start": 0,
                "end": 4,
                "token_start": 0,
                "token_end": 0,
                "label": "FASHION_BRAND",
            },
        ],
        "answer": "accept",
    },
    {
        "text": "Keds are alright. I think they do have the stereotype of \"early 2010s teenage girl\" (maybe just because I wore them as a teenage girl in like 2012 haha). I haven't worn Keds in a few years, but I think they're just okay. I wore mine a lot and they didn't hold up that well. And if you want or need a supportive shoe, then I'd suggest wearing an insert with Keds because there's absolutely no arch support. I'm a bigger fan of Superga now. They're similar to Keds but I think they look more modern and adult. I still wear an insert with Supergas, though.",
        "spans": [
            {
                "start": 169,
                "end": 173,
                "token_start": 39,
                "token_end": 39,
                "label": "FASHION_BRAND",
            },
        ],
        "answer": "accept",
    },
    {
        "text": "Keds are alright. I think they do have the stereotype of \"early 2010s teenage girl\" (maybe just because I wore them as a teenage girl in like 2012 haha). I haven't worn Keds in a few years, but I think they're just okay. I wore mine a lot and they didn't hold up that well. And if you want or need a supportive shoe, then I'd suggest wearing an insert with Keds because there's absolutely no arch support. I'm a bigger fan of Superga now. They're similar to Keds but I think they look more modern and adult. I still wear an insert with Supergas, though.",
        "spans": [
            {
                "start": 357,
                "end": 361,
                "token_start": 85,
                "token_end": 85,
                "label": "FASHION_BRAND",
            },
        ],
        "answer": "accept",
    },
    {
        "text": "Keds are alright. I think they do have the stereotype of \"early 2010s teenage girl\" (maybe just because I wore them as a teenage girl in like 2012 haha). I haven't worn Keds in a few years, but I think they're just okay. I wore mine a lot and they didn't hold up that well. And if you want or need a supportive shoe, then I'd suggest wearing an insert with Keds because there's absolutely no arch support. I'm a bigger fan of Superga now. They're similar to Keds but I think they look more modern and adult. I still wear an insert with Supergas, though.",
        "spans": [
            {
                "start": 426,
                "end": 433,
                "token_start": 100,
                "token_end": 100,
                "label": "FASHION_BRAND",
            },
        ],
        "answer": "accept",
    },
    {
        "text": "Keds are alright. I think they do have the stereotype of \"early 2010s teenage girl\" (maybe just because I wore them as a teenage girl in like 2012 haha). I haven't worn Keds in a few years, but I think they're just okay. I wore mine a lot and they didn't hold up that well. And if you want or need a supportive shoe, then I'd suggest wearing an insert with Keds because there's absolutely no arch support. I'm a bigger fan of Superga now. They're similar to Keds but I think they look more modern and adult. I still wear an insert with Supergas, though.",
        "spans": [
            {
                "start": 458,
                "end": 462,
                "token_start": 107,
                "token_end": 107,
                "label": "FASHION_BRAND",
            },
        ],
        "answer": "accept",
    },
    {
        "text": "Keds are alright. I think they do have the stereotype of \"early 2010s teenage girl\" (maybe just because I wore them as a teenage girl in like 2012 haha). I haven't worn Keds in a few years, but I think they're just okay. I wore mine a lot and they didn't hold up that well. And if you want or need a supportive shoe, then I'd suggest wearing an insert with Keds because there's absolutely no arch support. I'm a bigger fan of Superga now. They're similar to Keds but I think they look more modern and adult. I still wear an insert with Supergas, though.",
        "spans": [
            {
                "start": 536,
                "end": 544,
                "token_start": 124,
                "token_end": 124,
                "label": "FASHION_BRAND",
            },
        ],
        "answer": "accept",
    },
]

SENT_DATA = [
    {
        "text": "In Bad Muenstereifel?",
        "spans": [
            {
                "start": 0,
                "end": 2,
                "text": "In",
                "token_start": 0,
                "token_end": 0,
                "label": "S",
            },
            {
                "start": 3,
                "end": 6,
                "text": "Bad",
                "token_start": 1,
                "token_end": 1,
                "label": "I",
            },
            {
                "start": 7,
                "end": 20,
                "text": "Muenstereifel",
                "token_start": 2,
                "token_end": 2,
                "label": "I",
            },
            {
                "start": 20,
                "end": 21,
                "text": "?",
                "token_start": 3,
                "token_end": 3,
                "label": "I",
            },
        ],
        "answer": "accept",
        "tokens": [
            {"text": "In", "start": 0, "end": 2, "id": 0},
            {"text": "Bad", "start": 3, "end": 6, "id": 1},
            {"text": "Muenstereifel", "start": 7, "end": 20, "id": 2},
            {"text": "?", "start": 20, "end": 21, "id": 3},
        ],
    },
    {
        "text": "Keds are alright. I think they do have the stereotype of \"early 2010s teenage girl\" (maybe just because I wore them as a teenage girl in like 2012 haha). I haven't worn Keds in a few years, but I think they're just okay. I wore mine a lot and they didn't hold up that well. And if you want or need a supportive shoe, then I'd suggest wearing an insert with Keds because there's absolutely no arch support. I'm a bigger fan of Superga now. They're similar to Keds but I think they look more modern and adult. I still wear an insert with Supergas, though.",
        "tokens": [
            {"text": "Keds", "start": 0, "end": 4, "id": 0, "ws": True},
            {"text": "are", "start": 5, "end": 8, "id": 1, "ws": True},
            {"text": "alright", "start": 9, "end": 16, "id": 2, "ws": False},
            {"text": ".", "start": 16, "end": 17, "id": 3, "ws": True},
            {"text": "I", "start": 18, "end": 19, "id": 4, "ws": True},
            {"text": "think", "start": 20, "end": 25, "id": 5, "ws": True},
            {"text": "they", "start": 26, "end": 30, "id": 6, "ws": True},
            {"text": "do", "start": 31, "end": 33, "id": 7, "ws": True},
            {"text": "have", "start": 34, "end": 38, "id": 8, "ws": True},
            {"text": "the", "start": 39, "end": 42, "id": 9, "ws": True},
            {"text": "stereotype", "start": 43, "end": 53, "id": 10, "ws": True},
            {"text": "of", "start": 54, "end": 56, "id": 11, "ws": True},
            {"text": '"', "start": 57, "end": 58, "id": 12, "ws": False},
            {"text": "early", "start": 58, "end": 63, "id": 13, "ws": True},
            {"text": "2010s", "start": 64, "end": 69, "id": 14, "ws": True},
            {"text": "teenage", "start": 70, "end": 77, "id": 15, "ws": True},
            {"text": "girl", "start": 78, "end": 82, "id": 16, "ws": False},
            {"text": '"', "start": 82, "end": 83, "id": 17, "ws": True},
            {"text": "(", "start": 84, "end": 85, "id": 18, "ws": False},
            {"text": "maybe", "start": 85, "end": 90, "id": 19, "ws": True},
            {"text": "just", "start": 91, "end": 95, "id": 20, "ws": True},
            {"text": "because", "start": 96, "end": 103, "id": 21, "ws": True},
            {"text": "I", "start": 104, "end": 105, "id": 22, "ws": True},
            {"text": "wore", "start": 106, "end": 110, "id": 23, "ws": True},
            {"text": "them", "start": 111, "end": 115, "id": 24, "ws": True},
            {"text": "as", "start": 116, "end": 118, "id": 25, "ws": True},
            {"text": "a", "start": 119, "end": 120, "id": 26, "ws": True},
            {"text": "teenage", "start": 121, "end": 128, "id": 27, "ws": True},
            {"text": "girl", "start": 129, "end": 133, "id": 28, "ws": True},
            {"text": "in", "start": 134, "end": 136, "id": 29, "ws": True},
            {"text": "like", "start": 137, "end": 141, "id": 30, "ws": True},
            {"text": "2012", "start": 142, "end": 146, "id": 31, "ws": True},
            {"text": "haha", "start": 147, "end": 151, "id": 32, "ws": False},
            {"text": ")", "start": 151, "end": 152, "id": 33, "ws": False},
            {"text": ".", "start": 152, "end": 153, "id": 34, "ws": True},
            {"text": "I", "start": 154, "end": 155, "id": 35, "ws": True},
            {"text": "have", "start": 156, "end": 160, "id": 36, "ws": False},
            {"text": "n't", "start": 160, "end": 163, "id": 37, "ws": True},
            {"text": "worn", "start": 164, "end": 168, "id": 38, "ws": True},
            {"text": "Keds", "start": 169, "end": 173, "id": 39, "ws": True},
            {"text": "in", "start": 174, "end": 176, "id": 40, "ws": True},
            {"text": "a", "start": 177, "end": 178, "id": 41, "ws": True},
            {"text": "few", "start": 179, "end": 182, "id": 42, "ws": True},
            {"text": "years", "start": 183, "end": 188, "id": 43, "ws": False},
            {"text": ",", "start": 188, "end": 189, "id": 44, "ws": True},
            {"text": "but", "start": 190, "end": 193, "id": 45, "ws": True},
            {"text": "I", "start": 194, "end": 195, "id": 46, "ws": True},
            {"text": "think", "start": 196, "end": 201, "id": 47, "ws": True},
            {"text": "they", "start": 202, "end": 206, "id": 48, "ws": False},
            {"text": "'re", "start": 206, "end": 209, "id": 49, "ws": True},
            {"text": "just", "start": 210, "end": 214, "id": 50, "ws": True},
            {"text": "okay", "start": 215, "end": 219, "id": 51, "ws": False},
            {"text": ".", "start": 219, "end": 220, "id": 52, "ws": True},
            {"text": "I", "start": 221, "end": 222, "id": 53, "ws": True},
            {"text": "wore", "start": 223, "end": 227, "id": 54, "ws": True},
            {"text": "mine", "start": 228, "end": 232, "id": 55, "ws": True},
            {"text": "a", "start": 233, "end": 234, "id": 56, "ws": True},
            {"text": "lot", "start": 235, "end": 238, "id": 57, "ws": True},
            {"text": "and", "start": 239, "end": 242, "id": 58, "ws": True},
            {"text": "they", "start": 243, "end": 247, "id": 59, "ws": True},
            {"text": "did", "start": 248, "end": 251, "id": 60, "ws": False},
            {"text": "n't", "start": 251, "end": 254, "id": 61, "ws": True},
            {"text": "hold", "start": 255, "end": 259, "id": 62, "ws": True},
            {"text": "up", "start": 260, "end": 262, "id": 63, "ws": True},
            {"text": "that", "start": 263, "end": 267, "id": 64, "ws": True},
            {"text": "well", "start": 268, "end": 272, "id": 65, "ws": False},
            {"text": ".", "start": 272, "end": 273, "id": 66, "ws": True},
            {"text": "And", "start": 274, "end": 277, "id": 67, "ws": True},
            {"text": "if", "start": 278, "end": 280, "id": 68, "ws": True},
            {"text": "you", "start": 281, "end": 284, "id": 69, "ws": True},
            {"text": "want", "start": 285, "end": 289, "id": 70, "ws": True},
            {"text": "or", "start": 290, "end": 292, "id": 71, "ws": True},
            {"text": "need", "start": 293, "end": 297, "id": 72, "ws": True},
            {"text": "a", "start": 298, "end": 299, "id": 73, "ws": True},
            {"text": "supportive", "start": 300, "end": 310, "id": 74, "ws": True},
            {"text": "shoe", "start": 311, "end": 315, "id": 75, "ws": False},
            {"text": ",", "start": 315, "end": 316, "id": 76, "ws": True},
            {"text": "then", "start": 317, "end": 321, "id": 77, "ws": True},
            {"text": "I", "start": 322, "end": 323, "id": 78, "ws": False},
            {"text": "'d", "start": 323, "end": 325, "id": 79, "ws": True},
            {"text": "suggest", "start": 326, "end": 333, "id": 80, "ws": True},
            {"text": "wearing", "start": 334, "end": 341, "id": 81, "ws": True},
            {"text": "an", "start": 342, "end": 344, "id": 82, "ws": True},
            {"text": "insert", "start": 345, "end": 351, "id": 83, "ws": True},
            {"text": "with", "start": 352, "end": 356, "id": 84, "ws": True},
            {"text": "Keds", "start": 357, "end": 361, "id": 85, "ws": True},
            {"text": "because", "start": 362, "end": 369, "id": 86, "ws": True},
            {"text": "there", "start": 370, "end": 375, "id": 87, "ws": False},
            {"text": "'s", "start": 375, "end": 377, "id": 88, "ws": True},
            {"text": "absolutely", "start": 378, "end": 388, "id": 89, "ws": True},
            {"text": "no", "start": 389, "end": 391, "id": 90, "ws": True},
            {"text": "arch", "start": 392, "end": 396, "id": 91, "ws": True},
            {"text": "support", "start": 397, "end": 404, "id": 92, "ws": False},
            {"text": ".", "start": 404, "end": 405, "id": 93, "ws": True},
            {"text": "I", "start": 406, "end": 407, "id": 94, "ws": False},
            {"text": "'m", "start": 407, "end": 409, "id": 95, "ws": True},
            {"text": "a", "start": 410, "end": 411, "id": 96, "ws": True},
            {"text": "bigger", "start": 412, "end": 418, "id": 97, "ws": True},
            {"text": "fan", "start": 419, "end": 422, "id": 98, "ws": True},
            {"text": "of", "start": 423, "end": 425, "id": 99, "ws": True},
            {"text": "Superga", "start": 426, "end": 433, "id": 100, "ws": True},
            {"text": "now", "start": 434, "end": 437, "id": 101, "ws": False},
            {"text": ".", "start": 437, "end": 438, "id": 102, "ws": True},
            {"text": "They", "start": 439, "end": 443, "id": 103, "ws": False},
            {"text": "'re", "start": 443, "end": 446, "id": 104, "ws": True},
            {"text": "similar", "start": 447, "end": 454, "id": 105, "ws": True},
            {"text": "to", "start": 455, "end": 457, "id": 106, "ws": True},
            {"text": "Keds", "start": 458, "end": 462, "id": 107, "ws": True},
            {"text": "but", "start": 463, "end": 466, "id": 108, "ws": True},
            {"text": "I", "start": 467, "end": 468, "id": 109, "ws": True},
            {"text": "think", "start": 469, "end": 474, "id": 110, "ws": True},
            {"text": "they", "start": 475, "end": 479, "id": 111, "ws": True},
            {"text": "look", "start": 480, "end": 484, "id": 112, "ws": True},
            {"text": "more", "start": 485, "end": 489, "id": 113, "ws": True},
            {"text": "modern", "start": 490, "end": 496, "id": 114, "ws": True},
            {"text": "and", "start": 497, "end": 500, "id": 115, "ws": True},
            {"text": "adult", "start": 501, "end": 506, "id": 116, "ws": False},
            {"text": ".", "start": 506, "end": 507, "id": 117, "ws": True},
            {"text": "I", "start": 508, "end": 509, "id": 118, "ws": True},
            {"text": "still", "start": 510, "end": 515, "id": 119, "ws": True},
            {"text": "wear", "start": 516, "end": 520, "id": 120, "ws": True},
            {"text": "an", "start": 521, "end": 523, "id": 121, "ws": True},
            {"text": "insert", "start": 524, "end": 530, "id": 122, "ws": True},
            {"text": "with", "start": 531, "end": 535, "id": 123, "ws": True},
            {"text": "Supergas", "start": 536, "end": 544, "id": 124, "ws": False},
            {"text": ",", "start": 544, "end": 545, "id": 125, "ws": True},
            {"text": "though", "start": 546, "end": 552, "id": 126, "ws": False},
            {"text": ".", "start": 552, "end": 553, "id": 127, "ws": False},
        ],
        "spans": [
            {
                "start": 0,
                "end": 4,
                "text": "Keds",
                "token_start": 0,
                "token_end": 0,
                "label": "S",
            },
            {
                "start": 5,
                "end": 8,
                "text": "are",
                "token_start": 1,
                "token_end": 1,
                "label": "I",
            },
            {
                "start": 9,
                "end": 16,
                "text": "alright",
                "token_start": 2,
                "token_end": 2,
                "label": "I",
            },
            {
                "start": 16,
                "end": 17,
                "text": ".",
                "token_start": 3,
                "token_end": 3,
                "label": "I",
            },
            {
                "start": 18,
                "end": 19,
                "text": "I",
                "token_start": 4,
                "token_end": 4,
                "label": "S",
            },
            {
                "start": 20,
                "end": 25,
                "text": "think",
                "token_start": 5,
                "token_end": 5,
                "label": "I",
            },
            {
                "start": 26,
                "end": 30,
                "text": "they",
                "token_start": 6,
                "token_end": 6,
                "label": "I",
            },
            {
                "start": 31,
                "end": 33,
                "text": "do",
                "token_start": 7,
                "token_end": 7,
                "label": "I",
            },
            {
                "start": 34,
                "end": 38,
                "text": "have",
                "token_start": 8,
                "token_end": 8,
                "label": "I",
            },
            {
                "start": 39,
                "end": 42,
                "text": "the",
                "token_start": 9,
                "token_end": 9,
                "label": "I",
            },
            {
                "start": 43,
                "end": 53,
                "text": "stereotype",
                "token_start": 10,
                "token_end": 10,
                "label": "I",
            },
            {
                "start": 54,
                "end": 56,
                "text": "of",
                "token_start": 11,
                "token_end": 11,
                "label": "I",
            },
            {
                "start": 57,
                "end": 58,
                "text": '"',
                "token_start": 12,
                "token_end": 12,
                "label": "I",
            },
            {
                "start": 58,
                "end": 63,
                "text": "early",
                "token_start": 13,
                "token_end": 13,
                "label": "I",
            },
            {
                "start": 64,
                "end": 69,
                "text": "2010s",
                "token_start": 14,
                "token_end": 14,
                "label": "I",
            },
            {
                "start": 70,
                "end": 77,
                "text": "teenage",
                "token_start": 15,
                "token_end": 15,
                "label": "I",
            },
            {
                "start": 78,
                "end": 82,
                "text": "girl",
                "token_start": 16,
                "token_end": 16,
                "label": "I",
            },
            {
                "start": 82,
                "end": 83,
                "text": '"',
                "token_start": 17,
                "token_end": 17,
                "label": "I",
            },
            {
                "start": 84,
                "end": 85,
                "text": "(",
                "token_start": 18,
                "token_end": 18,
                "label": "I",
            },
            {
                "start": 85,
                "end": 90,
                "text": "maybe",
                "token_start": 19,
                "token_end": 19,
                "label": "I",
            },
            {
                "start": 91,
                "end": 95,
                "text": "just",
                "token_start": 20,
                "token_end": 20,
                "label": "I",
            },
            {
                "start": 96,
                "end": 103,
                "text": "because",
                "token_start": 21,
                "token_end": 21,
                "label": "I",
            },
            {
                "start": 104,
                "end": 105,
                "text": "I",
                "token_start": 22,
                "token_end": 22,
                "label": "I",
            },
            {
                "start": 106,
                "end": 110,
                "text": "wore",
                "token_start": 23,
                "token_end": 23,
                "label": "I",
            },
            {
                "start": 111,
                "end": 115,
                "text": "them",
                "token_start": 24,
                "token_end": 24,
                "label": "I",
            },
            {
                "start": 116,
                "end": 118,
                "text": "as",
                "token_start": 25,
                "token_end": 25,
                "label": "I",
            },
            {
                "start": 119,
                "end": 120,
                "text": "a",
                "token_start": 26,
                "token_end": 26,
                "label": "I",
            },
            {
                "start": 121,
                "end": 128,
                "text": "teenage",
                "token_start": 27,
                "token_end": 27,
                "label": "I",
            },
            {
                "start": 129,
                "end": 133,
                "text": "girl",
                "token_start": 28,
                "token_end": 28,
                "label": "I",
            },
            {
                "start": 134,
                "end": 136,
                "text": "in",
                "token_start": 29,
                "token_end": 29,
                "label": "I",
            },
            {
                "start": 137,
                "end": 141,
                "text": "like",
                "token_start": 30,
                "token_end": 30,
                "label": "I",
            },
            {
                "start": 142,
                "end": 146,
                "text": "2012",
                "token_start": 31,
                "token_end": 31,
                "label": "I",
            },
            {
                "start": 147,
                "end": 151,
                "text": "haha",
                "token_start": 32,
                "token_end": 32,
                "label": "I",
            },
            {
                "start": 151,
                "end": 152,
                "text": ")",
                "token_start": 33,
                "token_end": 33,
                "label": "I",
            },
            {
                "start": 152,
                "end": 153,
                "text": ".",
                "token_start": 34,
                "token_end": 34,
                "label": "I",
            },
            {
                "start": 154,
                "end": 155,
                "text": "I",
                "token_start": 35,
                "token_end": 35,
                "label": "S",
            },
            {
                "start": 156,
                "end": 160,
                "text": "have",
                "token_start": 36,
                "token_end": 36,
                "label": "I",
            },
            {
                "start": 160,
                "end": 163,
                "text": "n't",
                "token_start": 37,
                "token_end": 37,
                "label": "I",
            },
            {
                "start": 164,
                "end": 168,
                "text": "worn",
                "token_start": 38,
                "token_end": 38,
                "label": "I",
            },
            {
                "start": 169,
                "end": 173,
                "text": "Keds",
                "token_start": 39,
                "token_end": 39,
                "label": "I",
            },
            {
                "start": 174,
                "end": 176,
                "text": "in",
                "token_start": 40,
                "token_end": 40,
                "label": "I",
            },
            {
                "start": 177,
                "end": 178,
                "text": "a",
                "token_start": 41,
                "token_end": 41,
                "label": "I",
            },
            {
                "start": 179,
                "end": 182,
                "text": "few",
                "token_start": 42,
                "token_end": 42,
                "label": "I",
            },
            {
                "start": 183,
                "end": 188,
                "text": "years",
                "token_start": 43,
                "token_end": 43,
                "label": "I",
            },
            {
                "start": 188,
                "end": 189,
                "text": ",",
                "token_start": 44,
                "token_end": 44,
                "label": "I",
            },
            {
                "start": 190,
                "end": 193,
                "text": "but",
                "token_start": 45,
                "token_end": 45,
                "label": "I",
            },
            {
                "start": 194,
                "end": 195,
                "text": "I",
                "token_start": 46,
                "token_end": 46,
                "label": "I",
            },
            {
                "start": 196,
                "end": 201,
                "text": "think",
                "token_start": 47,
                "token_end": 47,
                "label": "I",
            },
            {
                "start": 202,
                "end": 206,
                "text": "they",
                "token_start": 48,
                "token_end": 48,
                "label": "I",
            },
            {
                "start": 206,
                "end": 209,
                "text": "'re",
                "token_start": 49,
                "token_end": 49,
                "label": "I",
            },
            {
                "start": 210,
                "end": 214,
                "text": "just",
                "token_start": 50,
                "token_end": 50,
                "label": "I",
            },
            {
                "start": 215,
                "end": 219,
                "text": "okay",
                "token_start": 51,
                "token_end": 51,
                "label": "I",
            },
            {
                "start": 219,
                "end": 220,
                "text": ".",
                "token_start": 52,
                "token_end": 52,
                "label": "I",
            },
            {
                "start": 221,
                "end": 222,
                "text": "I",
                "token_start": 53,
                "token_end": 53,
                "label": "S",
            },
            {
                "start": 223,
                "end": 227,
                "text": "wore",
                "token_start": 54,
                "token_end": 54,
                "label": "I",
            },
            {
                "start": 228,
                "end": 232,
                "text": "mine",
                "token_start": 55,
                "token_end": 55,
                "label": "I",
            },
            {
                "start": 233,
                "end": 234,
                "text": "a",
                "token_start": 56,
                "token_end": 56,
                "label": "I",
            },
            {
                "start": 235,
                "end": 238,
                "text": "lot",
                "token_start": 57,
                "token_end": 57,
                "label": "I",
            },
            {
                "start": 239,
                "end": 242,
                "text": "and",
                "token_start": 58,
                "token_end": 58,
                "label": "I",
            },
            {
                "start": 243,
                "end": 247,
                "text": "they",
                "token_start": 59,
                "token_end": 59,
                "label": "I",
            },
            {
                "start": 248,
                "end": 251,
                "text": "did",
                "token_start": 60,
                "token_end": 60,
                "label": "I",
            },
            {
                "start": 251,
                "end": 254,
                "text": "n't",
                "token_start": 61,
                "token_end": 61,
                "label": "I",
            },
            {
                "start": 255,
                "end": 259,
                "text": "hold",
                "token_start": 62,
                "token_end": 62,
                "label": "I",
            },
            {
                "start": 260,
                "end": 262,
                "text": "up",
                "token_start": 63,
                "token_end": 63,
                "label": "I",
            },
            {
                "start": 263,
                "end": 267,
                "text": "that",
                "token_start": 64,
                "token_end": 64,
                "label": "I",
            },
            {
                "start": 268,
                "end": 272,
                "text": "well",
                "token_start": 65,
                "token_end": 65,
                "label": "I",
            },
            {
                "start": 272,
                "end": 273,
                "text": ".",
                "token_start": 66,
                "token_end": 66,
                "label": "I",
            },
            {
                "start": 274,
                "end": 277,
                "text": "And",
                "token_start": 67,
                "token_end": 67,
                "label": "S",
            },
            {
                "start": 278,
                "end": 280,
                "text": "if",
                "token_start": 68,
                "token_end": 68,
                "label": "I",
            },
            {
                "start": 281,
                "end": 284,
                "text": "you",
                "token_start": 69,
                "token_end": 69,
                "label": "I",
            },
            {
                "start": 285,
                "end": 289,
                "text": "want",
                "token_start": 70,
                "token_end": 70,
                "label": "I",
            },
            {
                "start": 290,
                "end": 292,
                "text": "or",
                "token_start": 71,
                "token_end": 71,
                "label": "I",
            },
            {
                "start": 293,
                "end": 297,
                "text": "need",
                "token_start": 72,
                "token_end": 72,
                "label": "I",
            },
            {
                "start": 298,
                "end": 299,
                "text": "a",
                "token_start": 73,
                "token_end": 73,
                "label": "I",
            },
            {
                "start": 300,
                "end": 310,
                "text": "supportive",
                "token_start": 74,
                "token_end": 74,
                "label": "I",
            },
            {
                "start": 311,
                "end": 315,
                "text": "shoe",
                "token_start": 75,
                "token_end": 75,
                "label": "I",
            },
            {
                "start": 315,
                "end": 316,
                "text": ",",
                "token_start": 76,
                "token_end": 76,
                "label": "I",
            },
            {
                "start": 317,
                "end": 321,
                "text": "then",
                "token_start": 77,
                "token_end": 77,
                "label": "I",
            },
            {
                "start": 322,
                "end": 323,
                "text": "I",
                "token_start": 78,
                "token_end": 78,
                "label": "I",
            },
            {
                "start": 323,
                "end": 325,
                "text": "'d",
                "token_start": 79,
                "token_end": 79,
                "label": "I",
            },
            {
                "start": 326,
                "end": 333,
                "text": "suggest",
                "token_start": 80,
                "token_end": 80,
                "label": "I",
            },
            {
                "start": 334,
                "end": 341,
                "text": "wearing",
                "token_start": 81,
                "token_end": 81,
                "label": "I",
            },
            {
                "start": 342,
                "end": 344,
                "text": "an",
                "token_start": 82,
                "token_end": 82,
                "label": "I",
            },
            {
                "start": 345,
                "end": 351,
                "text": "insert",
                "token_start": 83,
                "token_end": 83,
                "label": "I",
            },
            {
                "start": 352,
                "end": 356,
                "text": "with",
                "token_start": 84,
                "token_end": 84,
                "label": "I",
            },
            {
                "start": 357,
                "end": 361,
                "text": "Keds",
                "token_start": 85,
                "token_end": 85,
                "label": "I",
            },
            {
                "start": 362,
                "end": 369,
                "text": "because",
                "token_start": 86,
                "token_end": 86,
                "label": "I",
            },
            {
                "start": 370,
                "end": 375,
                "text": "there",
                "token_start": 87,
                "token_end": 87,
                "label": "I",
            },
            {
                "start": 375,
                "end": 377,
                "text": "'s",
                "token_start": 88,
                "token_end": 88,
                "label": "I",
            },
            {
                "start": 378,
                "end": 388,
                "text": "absolutely",
                "token_start": 89,
                "token_end": 89,
                "label": "I",
            },
            {
                "start": 389,
                "end": 391,
                "text": "no",
                "token_start": 90,
                "token_end": 90,
                "label": "I",
            },
            {
                "start": 392,
                "end": 396,
                "text": "arch",
                "token_start": 91,
                "token_end": 91,
                "label": "I",
            },
            {
                "start": 397,
                "end": 404,
                "text": "support",
                "token_start": 92,
                "token_end": 92,
                "label": "I",
            },
            {
                "start": 404,
                "end": 405,
                "text": ".",
                "token_start": 93,
                "token_end": 93,
                "label": "I",
            },
            {
                "start": 406,
                "end": 407,
                "text": "I",
                "token_start": 94,
                "token_end": 94,
                "label": "S",
            },
            {
                "start": 407,
                "end": 409,
                "text": "'m",
                "token_start": 95,
                "token_end": 95,
                "label": "I",
            },
            {
                "start": 410,
                "end": 411,
                "text": "a",
                "token_start": 96,
                "token_end": 96,
                "label": "I",
            },
            {
                "start": 412,
                "end": 418,
                "text": "bigger",
                "token_start": 97,
                "token_end": 97,
                "label": "I",
            },
            {
                "start": 419,
                "end": 422,
                "text": "fan",
                "token_start": 98,
                "token_end": 98,
                "label": "I",
            },
            {
                "start": 423,
                "end": 425,
                "text": "of",
                "token_start": 99,
                "token_end": 99,
                "label": "I",
            },
            {
                "start": 426,
                "end": 433,
                "text": "Superga",
                "token_start": 100,
                "token_end": 100,
                "label": "I",
            },
            {
                "start": 434,
                "end": 437,
                "text": "now",
                "token_start": 101,
                "token_end": 101,
                "label": "I",
            },
            {
                "start": 437,
                "end": 438,
                "text": ".",
                "token_start": 102,
                "token_end": 102,
                "label": "I",
            },
            {
                "start": 439,
                "end": 443,
                "text": "They",
                "token_start": 103,
                "token_end": 103,
                "label": "S",
            },
            {
                "start": 443,
                "end": 446,
                "text": "'re",
                "token_start": 104,
                "token_end": 104,
                "label": "I",
            },
            {
                "start": 447,
                "end": 454,
                "text": "similar",
                "token_start": 105,
                "token_end": 105,
                "label": "I",
            },
            {
                "start": 455,
                "end": 457,
                "text": "to",
                "token_start": 106,
                "token_end": 106,
                "label": "I",
            },
            {
                "start": 458,
                "end": 462,
                "text": "Keds",
                "token_start": 107,
                "token_end": 107,
                "label": "I",
            },
            {
                "start": 463,
                "end": 466,
                "text": "but",
                "token_start": 108,
                "token_end": 108,
                "label": "I",
            },
            {
                "start": 467,
                "end": 468,
                "text": "I",
                "token_start": 109,
                "token_end": 109,
                "label": "I",
            },
            {
                "start": 469,
                "end": 474,
                "text": "think",
                "token_start": 110,
                "token_end": 110,
                "label": "I",
            },
            {
                "start": 475,
                "end": 479,
                "text": "they",
                "token_start": 111,
                "token_end": 111,
                "label": "I",
            },
            {
                "start": 480,
                "end": 484,
                "text": "look",
                "token_start": 112,
                "token_end": 112,
                "label": "I",
            },
            {
                "start": 485,
                "end": 489,
                "text": "more",
                "token_start": 113,
                "token_end": 113,
                "label": "I",
            },
            {
                "start": 490,
                "end": 496,
                "text": "modern",
                "token_start": 114,
                "token_end": 114,
                "label": "I",
            },
            {
                "start": 497,
                "end": 500,
                "text": "and",
                "token_start": 115,
                "token_end": 115,
                "label": "I",
            },
            {
                "start": 501,
                "end": 506,
                "text": "adult",
                "token_start": 116,
                "token_end": 116,
                "label": "I",
            },
            {
                "start": 506,
                "end": 507,
                "text": ".",
                "token_start": 117,
                "token_end": 117,
                "label": "I",
            },
        ],
        "answer": "accept",
    },
]

POS_DATA = [
    {
        "text": "I should have just gone to the wedding last year.",
        "spans": [
            {"start": 0, "end": 1, "token_start": 0, "token_end": 0, "label": "PRP"},
            {"start": 2, "end": 8, "token_start": 1, "token_end": 1, "label": "MD"},
            {"start": 9, "end": 13, "token_start": 2, "token_end": 2, "label": "VB"},
            {"start": 31, "end": 38, "token_start": 7, "token_end": 7, "label": "NN"},
            {"start": 44, "end": 48, "token_start": 9, "token_end": 9, "label": "NN"},
        ],
        "answer": "accept",
        "tokens": [
            {"text": "I", "start": 0, "end": 1, "id": 0},
            {"text": "should", "start": 2, "end": 8, "id": 1},
            {"text": "have", "start": 9, "end": 13, "id": 2},
            {"text": "just", "start": 14, "end": 18, "id": 3},
            {"text": "gone", "start": 19, "end": 23, "id": 4},
            {"text": "to", "start": 24, "end": 26, "id": 5},
            {"text": "the", "start": 27, "end": 30, "id": 6},
            {"text": "wedding", "start": 31, "end": 38, "id": 7},
            {"text": "last", "start": 39, "end": 43, "id": 8},
            {"text": "year", "start": 44, "end": 48, "id": 9},
            {"text": ".", "start": 48, "end": 49, "id": 10},
        ],
    },
    {
        "text": "In Bad Muenstereifel?",
        "spans": [
            {"start": 3, "end": 6, "token_start": 1, "token_end": 1, "label": "NNP"},
            {"start": 7, "end": 20, "token_start": 2, "token_end": 2, "label": "NNP"},
        ],
        "answer": "accept",
        "tokens": [
            {"text": "In", "start": 0, "end": 2, "id": 0},
            {"text": "Bad", "start": 3, "end": 6, "id": 1},
            {"text": "Muenstereifel", "start": 7, "end": 20, "id": 2},
            {"text": "?", "start": 20, "end": 21, "id": 3},
        ],
    },
]

DEP_DATA = [
    {
        "text": "I should have just gone to the wedding last year.",
        "arcs": [{"head": 4, "child": 0, "label": "nsubj"}],
        "answer": "accept",
        "tokens": [
            {"text": "I", "start": 0, "end": 1, "id": 0},
            {"text": "should", "start": 2, "end": 8, "id": 1},
            {"text": "have", "start": 9, "end": 13, "id": 2},
            {"text": "just", "start": 14, "end": 18, "id": 3},
            {"text": "gone", "start": 19, "end": 23, "id": 4},
            {"text": "to", "start": 24, "end": 26, "id": 5},
            {"text": "the", "start": 27, "end": 30, "id": 6},
            {"text": "wedding", "start": 31, "end": 38, "id": 7},
            {"text": "last", "start": 39, "end": 43, "id": 8},
            {"text": "year", "start": 44, "end": 48, "id": 9},
            {"text": ".", "start": 48, "end": 49, "id": 10},
        ],
    },
    {
        "text": "I should have just gone to the wedding last year.",
        "arcs": [{"head": 5, "child": 7, "label": "dobj"}],
        "answer": "reject",
        "tokens": [
            {"text": "I", "start": 0, "end": 1, "id": 0},
            {"text": "should", "start": 2, "end": 8, "id": 1},
            {"text": "have", "start": 9, "end": 13, "id": 2},
            {"text": "just", "start": 14, "end": 18, "id": 3},
            {"text": "gone", "start": 19, "end": 23, "id": 4},
            {"text": "to", "start": 24, "end": 26, "id": 5},
            {"text": "the", "start": 27, "end": 30, "id": 6},
            {"text": "wedding", "start": 31, "end": 38, "id": 7},
            {"text": "last", "start": 39, "end": 43, "id": 8},
            {"text": "year", "start": 44, "end": 48, "id": 9},
            {"text": ".", "start": 48, "end": 49, "id": 10},
        ],
    },
    {
        "text": "I should have just gone to the wedding last year.",
        "arcs": [{"head": 5, "child": 7, "label": "pobj"}],
        "answer": "accept",
        "tokens": [
            {"text": "I", "start": 0, "end": 1, "id": 0},
            {"text": "should", "start": 2, "end": 8, "id": 1},
            {"text": "have", "start": 9, "end": 13, "id": 2},
            {"text": "just", "start": 14, "end": 18, "id": 3},
            {"text": "gone", "start": 19, "end": 23, "id": 4},
            {"text": "to", "start": 24, "end": 26, "id": 5},
            {"text": "the", "start": 27, "end": 30, "id": 6},
            {"text": "wedding", "start": 31, "end": 38, "id": 7},
            {"text": "last", "start": 39, "end": 43, "id": 8},
            {"text": "year", "start": 44, "end": 48, "id": 9},
            {"text": ".", "start": 48, "end": 49, "id": 10},
        ],
    },
    {
        "text": "In Bad Muenstereifel?",
        "arcs": [{"head": 0, "child": 0, "label": "root"}],
        "answer": "accept",
        "tokens": [
            {"text": "In", "start": 0, "end": 2, "id": 0},
            {"text": "Bad", "start": 3, "end": 6, "id": 1},
            {"text": "Muenstereifel", "start": 7, "end": 20, "id": 2},
            {"text": "?", "start": 20, "end": 21, "id": 3},
        ],
    },
]

TEXTCAT_DATA = [
    {
        "text": "Keds are alright. I think they do have the stereotype of \"early 2010s teenage girl\" (maybe just because I wore them as a teenage girl in like 2012 haha). I haven't worn Keds in a few years, but I think they're just okay. I wore mine a lot and they didn't hold up that well. And if you want or need a supportive shoe, then I'd suggest wearing an insert with Keds because there's absolutely no arch support. I'm a bigger fan of Superga now. They're similar to Keds but I think they look more modern and adult. I still wear an insert with Supergas, though.",
        "options": [
            {"id": "COSMETICS", "text": "COSMETICS"},
            {"id": "FASHION", "text": "FASHION"},
        ],
        "accept": ["FASHION"],
        "answer": "accept",
    },
    {
        "text": "Banana Republic has a lot of feminine cuts and patterns",
        "label": "FASHION",
        "answer": "accept",
    },
    {
        "text": "Trader Joe\u2019s gel moisturizer is great and lightweight and way cheaper than other brands :)",
        "options": [
            {"id": "COSMETICS", "text": "COSMETICS"},
            {"id": "FASHION", "text": "FASHION"},
        ],
        "accept": ["COSMETICS"],
        "answer": "accept",
    },
]


TEXTCAT_SINGLE_DATA = [
    {
        "text": "Keds are alright. I think they do have the stereotype of \"early 2010s teenage girl\" (maybe just because I wore them as a teenage girl in like 2012 haha). I haven't worn Keds in a few years, but I think they're just okay. I wore mine a lot and they didn't hold up that well. And if you want or need a supportive shoe, then I'd suggest wearing an insert with Keds because there's absolutely no arch support. I'm a bigger fan of Superga now. They're similar to Keds but I think they look more modern and adult. I still wear an insert with Supergas, though.",
        "label": "FASHION",
        "answer": "accept",
    },
    {
        "text": "Banana Republic has a lot of feminine cuts and patterns",
        "label": "FASHION",
        "answer": "accept",
    },
    {
        "text": "Trader Joe\u2019s gel moisturizer is great and lightweight and way cheaper than other brands :)",
        "label": "FASHION",
        "answer": "reject",
    },
]

NER_DUPLICATE_DATA = [
    {
        "text": "There's a lifetime of contemplation in the 4 Noble Truths.",
        "spans": [
            {
                "start": 45,
                "end": 50,
                "text": "Noble",
                "rank": 2,
                "label": "TRUTHS",
                "score": 0.0268965187,
                "source": "core_web_sm",
                "input_hash": -1681330188,
                "answer": "reject",
            }
        ],
        "meta": {"section": "IAmA", "score": 0.0268965187},
        "_input_hash": -1681330188,
        "_task_hash": 308411403,
        "answer": "reject",
    },
    {
        "text": "There's a lifetime of contemplation in the 4 Noble Truths.",
        "spans": [
            {
                "start": 51,
                "end": 57,
                "text": "Truths",
                "rank": 1,
                "label": "TRUTHS",
                "score": 0.2232650834,
                "source": "core_web_sm",
                "input_hash": -1681330188,
                "answer": "reject",
            }
        ],
        "meta": {"section": "IAmA", "score": 0.2232650834},
        "_input_hash": -1681330188,
        "_task_hash": 792590542,
        "answer": "reject",
    },
    {
        "text": "There's a lifetime of contemplation in the 4 Noble Truths.",
        "spans": [
            {
                "start": 45,
                "end": 57,
                "text": "Noble Truths",
                "rank": 2,
                "label": "TRUTHS",
                "score": 0.5268965187,
                "source": "core_web_sm",
                "input_hash": -1681330188,
                "answer": "accept",
            }
        ],
        "meta": {"section": "IAmA", "score": 0.5268965187},
        "_input_hash": -1681330188,
        "_task_hash": 682590403,
        "answer": "reject",
    },
]


NER_CONFLICT_DATA = [
    {
        "text": "I should have just gone to the wedding last year.",
        "spans": [{"start": 39, "end": 48, "label": "DATE"}],
        "answer": "reject",
    },
    {
        "text": "I should have just gone to the wedding last year.",
        "spans": [{"start": 39, "end": 48, "label": "DATE"}],
        "answer": "accept",
    },
]

COREF_DATA = [
    {
        "text": "I saw Sam in the grocery store, she said it was warm there.",
        "relations": [
            {
                "head": 2,
                "child": 8,
                "head_span": {
                    "start": 6,
                    "end": 9,
                    "token_start": 2,
                    "token_end": 2,
                    "label": "PERSON",
                },
                "child_span": {
                    "start": 32,
                    "end": 35,
                    "token_start": 8,
                    "token_end": 8,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
            {
                "head": 6,
                "child": 13,
                "head_span": {
                    "start": 13,
                    "end": 30,
                    "token_start": 4,
                    "token_end": 6,
                    "label": "NP",
                },
                "child_span": {
                    "start": 53,
                    "end": 58,
                    "token_start": 13,
                    "token_end": 13,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
        ],
        "answer": "accept",
        "true_clusters": 2,
        "tokens": [
            {"text": "I", "start": 0, "end": 1, "id": 0, "ws": True, "disabled": False},
            {
                "text": "saw",
                "start": 2,
                "end": 5,
                "id": 1,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "Sam",
                "start": 6,
                "end": 9,
                "id": 2,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "in",
                "start": 10,
                "end": 12,
                "id": 3,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "the",
                "start": 13,
                "end": 16,
                "id": 4,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "grocery",
                "start": 17,
                "end": 24,
                "id": 5,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "store",
                "start": 25,
                "end": 30,
                "id": 6,
                "ws": False,
                "disabled": False,
            },
            {
                "text": ",",
                "start": 30,
                "end": 31,
                "id": 7,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "she",
                "start": 32,
                "end": 35,
                "id": 8,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "said",
                "start": 36,
                "end": 40,
                "id": 9,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "it",
                "start": 41,
                "end": 43,
                "id": 10,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "was",
                "start": 44,
                "end": 47,
                "id": 11,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "warm",
                "start": 48,
                "end": 52,
                "id": 12,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "there",
                "start": 53,
                "end": 58,
                "id": 13,
                "ws": False,
                "disabled": False,
            },
            {
                "text": ".",
                "start": 58,
                "end": 59,
                "id": 14,
                "ws": False,
                "disabled": False,
            },
        ],
    },
    {
        "text": "I left my plant in a sunny window, it likes it there.",
        "relations": [
            {
                "head": 3,
                "child": 9,
                "head_span": {
                    "start": 10,
                    "end": 15,
                    "token_start": 3,
                    "token_end": 3,
                    "label": "NP",
                },
                "child_span": {
                    "start": 35,
                    "end": 37,
                    "token_start": 9,
                    "token_end": 9,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
            {
                "head": 7,
                "child": 12,
                "head_span": {
                    "start": 19,
                    "end": 33,
                    "token_start": 5,
                    "token_end": 7,
                    "label": "NP",
                },
                "child_span": {
                    "start": 47,
                    "end": 52,
                    "token_start": 12,
                    "token_end": 12,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
        ],
        "answer": "accept",
        "true_clusters": 2,
        "tokens": [
            {"text": "I", "start": 0, "end": 1, "id": 0, "ws": True, "disabled": False},
            {
                "text": "left",
                "start": 2,
                "end": 6,
                "id": 1,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "my",
                "start": 7,
                "end": 9,
                "id": 2,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "plant",
                "start": 10,
                "end": 15,
                "id": 3,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "in",
                "start": 16,
                "end": 18,
                "id": 4,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "a",
                "start": 19,
                "end": 20,
                "id": 5,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "sunny",
                "start": 21,
                "end": 26,
                "id": 6,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "window",
                "start": 27,
                "end": 33,
                "id": 7,
                "ws": False,
                "disabled": False,
            },
            {
                "text": ",",
                "start": 33,
                "end": 34,
                "id": 8,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "it",
                "start": 35,
                "end": 37,
                "id": 9,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "likes",
                "start": 38,
                "end": 43,
                "id": 10,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "it",
                "start": 44,
                "end": 46,
                "id": 11,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "there",
                "start": 47,
                "end": 52,
                "id": 12,
                "ws": False,
                "disabled": False,
            },
            {
                "text": ".",
                "start": 52,
                "end": 53,
                "id": 13,
                "ws": False,
                "disabled": False,
            },
        ],
    },
    {
        "text": "The sky is blue.",
        "answer": "accept",
        "relations": [],
        "true_clusters": 0,
        "tokens": [
            {
                "text": "The",
                "start": 0,
                "end": 3,
                "id": 0,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "sky",
                "start": 4,
                "end": 7,
                "id": 1,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "is",
                "start": 8,
                "end": 10,
                "id": 2,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "blue",
                "start": 11,
                "end": 15,
                "id": 3,
                "ws": False,
                "disabled": False,
            },
            {
                "text": ".",
                "start": 15,
                "end": 16,
                "id": 4,
                "ws": False,
                "disabled": False,
            },
        ],
    },
    {
        "text": "Tom said he would come but he changed his mind.",
        "relations": [
            {
                "head": 0,
                "child": 2,
                "head_span": {
                    "start": 0,
                    "end": 3,
                    "token_start": 0,
                    "token_end": 0,
                    "label": "PERSON",
                },
                "child_span": {
                    "start": 9,
                    "end": 11,
                    "token_start": 2,
                    "token_end": 2,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
            {
                "head": 2,
                "child": 6,
                "head_span": {
                    "start": 9,
                    "end": 11,
                    "token_start": 2,
                    "token_end": 2,
                    "label": None,
                },
                "child_span": {
                    "start": 27,
                    "end": 29,
                    "token_start": 6,
                    "token_end": 6,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
            {
                "head": 6,
                "child": 8,
                "head_span": {
                    "start": 27,
                    "end": 29,
                    "token_start": 6,
                    "token_end": 6,
                    "label": None,
                },
                "child_span": {
                    "start": 38,
                    "end": 41,
                    "token_start": 8,
                    "token_end": 8,
                    "label": None,
                },
                "color": "#c5bdf4",
                "label": "COREF",
            },
        ],
        "answer": "accept",
        "true_clusters": 1,
        "tokens": [
            {
                "text": "Tom",
                "start": 0,
                "end": 3,
                "id": 0,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "said",
                "start": 4,
                "end": 8,
                "id": 1,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "he",
                "start": 9,
                "end": 11,
                "id": 2,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "would",
                "start": 12,
                "end": 17,
                "id": 3,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "come",
                "start": 18,
                "end": 22,
                "id": 4,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "but",
                "start": 23,
                "end": 26,
                "id": 5,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "he",
                "start": 27,
                "end": 29,
                "id": 6,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "changed",
                "start": 30,
                "end": 37,
                "id": 7,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "his",
                "start": 38,
                "end": 41,
                "id": 8,
                "ws": True,
                "disabled": False,
            },
            {
                "text": "mind",
                "start": 42,
                "end": 46,
                "id": 9,
                "ws": False,
                "disabled": False,
            },
            {
                "text": ".",
                "start": 46,
                "end": 47,
                "id": 10,
                "ws": False,
                "disabled": False,
            },
        ],
    },
]


@pytest.fixture(autouse=True, scope="function")
def database_setup(database: Database):
    # This runs before each test
    data = {
        "ner_db": NER_DATA,
        "ner_dup_db": NER_DUPLICATE_DATA,
        "ner_conflict_db": NER_CONFLICT_DATA,
        "textcat_db": TEXTCAT_DATA,
        "textcat_single_db": TEXTCAT_SINGLE_DATA,
        "tagger_db": POS_DATA,
        "parser_db": DEP_DATA,
        "senter_db": SENT_DATA,
        "coref_db": COREF_DATA,
    }
    for name, examples in data.items():
        examples = [set_hashes(eg) for eg in examples]
        database.add_dataset(name)
        database.add_examples(examples, datasets=[name])
    yield


@pytest.fixture
def nlp():
    _nlp = spacy.blank("en")
    return _nlp


@pytest.fixture
def has_experimental_coref(nlp):
    try:
        pass

        nlp.add_pipe("experimental_coref")
    except (ModuleNotFoundError, ValueError):
        pytest.skip("needs Experimental coref & PyTorch")


def test_merge_data(nlp):
    docs, dev_docs, pipes = merge_data(
        nlp,
        ner_datasets=["ner_db"],
        spancat_datasets=["ner_db"],
        textcat_datasets=["textcat_db"],
        textcat_multilabel_datasets=["textcat_db"],
        tagger_datasets=["tagger_db"],
        senter_datasets=["senter_db"],
        parser_datasets=["parser_db"],
        coref_datasets=["coref_db"],
    )
    assert len(dev_docs) == 0
    assert len(docs) == 9
    assert len(pipes.keys()) == 8
    assert pipes["ner"] == (["ner_db"], [])
    assert pipes["spancat"] == (["ner_db"], [])
    assert pipes["textcat"] == (["textcat_db"], [])
    assert pipes["textcat_multilabel"] == (["textcat_db"], [])
    assert pipes["tagger"] == (["tagger_db"], [])
    assert pipes["senter"] == (["senter_db"], [])
    assert pipes["parser"] == (["parser_db"], [])
    assert pipes["experimental_coref"] == (["coref_db"], [])

    # fmt: off
    # I should have just gone to the wedding last year.
    doc0 = docs[0]
    assert len(doc0.ents) == 1
    assert len(doc0.spans[SPANCAT_DEFAULT_KEY]) == 1
    assert doc0.ents[0].text == "last year"
    assert [t.ent_iob_ for t in doc0] == ["O", "O", "O", "O", "O", "O", "O", "O", "B", "I", "O"]
    assert [t.ent_type_ for t in doc0] == [MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, "DATE", "DATE", MISSING]
    assert [t.tag_ for t in doc0] == ["PRP", "MD", "VB", MISSING, MISSING, MISSING, MISSING, "NN", MISSING, "NN", MISSING]
    # note: partial parse tree leads to invalid sentence boundaries
    assert [t.is_sent_start for t in doc0] == [False] * len(doc0)
    assert [t.dep_ for t in doc0] == ["nsubj", MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, "pobj", MISSING, MISSING, MISSING]
    assert [t.has_head() for t in doc0] == [True, False, False, False, False, False, False, True, False, False, False]
    assert doc0[0].head.i == 4
    assert doc0[7].head.i == 5
    assert doc0.cats == {}

    # In Bad Muenstereifel?
    doc1 = docs[1]
    assert len(doc1.ents) == 1
    assert len(doc1.spans[SPANCAT_DEFAULT_KEY]) == 1
    assert doc1.ents[0].text == "Bad Muenstereifel"
    assert [t.ent_iob_ for t in doc1] == ["O", "B", "I", "O"]
    assert [t.ent_type_ for t in doc1] == [MISSING, "GPE", "GPE", MISSING]
    assert [t.tag_ for t in doc1] == [MISSING, "NNP", "NNP", MISSING]
    # note: partial parse tree leads to invalid sentence boundaries
    assert [t.is_sent_start for t in doc1] == [False] * len(doc1)
    assert [t.dep_ for t in doc1] == ["root", MISSING, MISSING, MISSING]
    assert [t.has_head() for t in doc1] == [True, False, False, False]
    assert doc1[0].head.i == 0
    assert doc1.cats == {}

    # Keds are alright [...]
    doc2 = docs[2]
    assert len(doc2.ents) == 6
    assert len(doc2.spans[SPANCAT_DEFAULT_KEY]) == 6
    # fmt: off
    assert [t.ent_iob_ for t in doc2] == [
        "B", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O",
        "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O",
        "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O",
        "B", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O",
        "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O",
        "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O",
        "O", "O", "O", "O", "O", "O", "O", "B", "O", "O", "O",
        "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "B",
        "O", "O", "O", "O", "O", "O", "B", "O", "O", "O", "O",
        "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O", "O",
        "B", "O", "O", "O"
    ]
    assert [t.ent_type_ for t in doc2] == [
        "FASHION_BRAND", MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING,
        MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING,
        MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING,
        "FASHION_BRAND", MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING,
        MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING,
        MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING,
        MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, "FASHION_BRAND", MISSING, MISSING, MISSING,
        MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, "FASHION_BRAND",
        MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, "FASHION_BRAND", MISSING, MISSING, MISSING, MISSING,
        MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING, MISSING,
        "FASHION_BRAND", MISSING, MISSING, MISSING
    ]
    # fmt: on
    assert [t.tag_ for t in doc2] == [MISSING] * len(doc2)
    sent_starts = [0, 4, 35, 53, 67, 94, 103]
    for token in doc2:
        if token.i < 118:
            if token.i in sent_starts:
                assert token.is_sent_start is True
            else:
                assert token.is_sent_start is False
        # remaining values are False because it's not from binary annotations
        else:
            assert token.is_sent_start is False
    assert [t.dep_ for t in doc2] == [MISSING] * len(doc2)
    assert [t.head.i for t in doc2] == list(range(len(doc2)))
    assert len(doc2.cats) == 2
    assert doc2.cats["FASHION"] == 1.0
    assert doc2.cats["COSMETICS"] == 0.0

    # Banana Republic has a lot of feminine cuts and patterns
    doc3 = docs[3]
    assert len(doc3.ents) == 0
    assert len(doc3.spans.get(SPANCAT_DEFAULT_KEY, [])) == 0
    assert [t.tag_ for t in doc3] == [MISSING] * len(doc3)
    assert [t.is_sent_start for t in doc3] == [True] + [None] * (len(doc3) - 1)
    assert [t.dep_ for t in doc3] == [MISSING] * len(doc3)
    assert [t.head.i for t in doc3] == list(range(len(doc3)))
    assert len(doc3.cats) == 2
    assert doc3.cats["FASHION"] == 1.0
    assert doc3.cats["COSMETICS"] == 0.0

    # Trader Joe\u2019s gel moisturizer is great [...]
    doc4 = docs[4]
    assert len(doc4.ents) == 0
    assert len(doc4.spans.get(SPANCAT_DEFAULT_KEY, [])) == 0
    assert [t.tag_ for t in doc4] == [MISSING] * len(doc4)
    assert [t.is_sent_start for t in doc4] == [True] + [None] * (len(doc4) - 1)
    assert [t.dep_ for t in doc4] == [MISSING] * len(doc4)
    assert [t.head.i for t in doc4] == list(range(len(doc4)))
    assert len(doc4.cats) == 2
    assert doc4.cats["FASHION"] == 0.0
    assert doc4.cats["COSMETICS"] == 1.0
    # fmt: on


def test_merge_data_no_dup_within_dataset(nlp):
    """Ensure that train/dev don't have overlapping sentences
    when one dataset is used"""
    train_docs, dev_docs, pipes = merge_data(
        nlp,
        ner_datasets=["ner_db"],
        eval_split=0.5,
    )

    train_texts = {doc.text for doc in train_docs}
    dev_texts = {doc.text for doc in dev_docs}
    assert len(train_texts) > 0
    assert len(dev_texts) > 0
    assert len(train_texts.intersection(dev_texts)) == 0


def test_merge_data_no_dup_across_datasets(nlp):
    train_docs, dev_docs, pipes = merge_data(
        nlp,
        ner_datasets=["ner_db"],
        spancat_datasets=["ner_db"],
        textcat_datasets=["textcat_db"],
        textcat_multilabel_datasets=["textcat_db"],
        tagger_datasets=["tagger_db"],
        senter_datasets=["senter_db"],
        parser_datasets=["parser_db"],
        eval_split=0.5,
    )
    train_texts = {doc.text for doc in train_docs}
    dev_texts = {doc.text for doc in dev_docs}
    assert len(train_texts) > 0
    assert len(dev_texts) > 0
    assert len(train_texts.intersection(dev_texts)) == 0


def test_data_to_spacy():
    cfg = {
        "ner": ["ner_db"],
        "spancat": ["ner_db"],
        "textcat": ["textcat_db"],
        "tagger": ["tagger_db"],
        "parser": ["parser_db"],
        "eval_split": 0.0,
        "verbose": True,
    }
    nlp = spacy.blank("en")
    with make_tempdir() as output_dir:
        data_to_spacy(output_dir, **cfg)
        doc_bin = DocBin().from_disk(output_dir / "train.spacy")
        docs = list(doc_bin.get_docs(nlp.vocab))
    assert len(docs) == 5

    # fmt: off
    # I should have just gone to the wedding last year.
    doc0 = docs[0]
    assert doc0.text == NER_DATA[0]["text"]
    assert len(list(doc0.sents)) == 1
    assert len(doc0) == 11
    assert doc0[0].head.i == 4
    assert doc0[7].head.i == 5
    assert [t.dep_ for t in doc0] == ["nsubj", "", "", "", "", "", "", "pobj", "", "", ""]
    assert [t.tag_ for t in doc0] == ["PRP", "MD", "VB", "", "", "", "", "NN", "", "NN", ""]
    assert [t.ent_iob_ for t in doc0] == ["O", "O", "O", "O", "O", "O", "O", "O", "B", "I", "O"]
    assert [t.ent_type_ for t in doc0] == ["", "", "", "", "", "", "", "", "DATE", "DATE", ""]
    assert doc0.cats == {}

    # In Bad Muenstereifel?
    doc1 = docs[1]
    assert doc1.text == NER_DATA[1]["text"]
    assert len(list(doc1.sents)) == 1
    assert len(doc1) == 4
    assert doc1[0].head.i == 0
    assert [t.dep_ for t in doc1] == ["root", "", "", ""]
    assert [t.tag_ for t in doc1] == ["", "NNP", "NNP", ""]
    assert [t.ent_iob_ for t in doc1] == ["O", "B", "I", "O"]
    assert [t.ent_type_ for t in doc1] == ["", "GPE", "GPE", ""]
    assert doc1.cats == {}

    # Keds are alright [...]
    doc2 = docs[2]
    assert doc2.text == NER_DATA[2]["text"]
    sentences = list(doc2.sents)
    assert len(sentences) == 8
    sent3 = sentences[7]
    assert len(sent3) == 10
    assert [t.tag_ for t in sent3] == [""] * len(sent3)
    assert [t.dep_ for t in sent3] == [""] * len(sent3)
    assert [t.head.i for t in sent3] == [t.i for t in sent3]
    assert len(doc2.cats) == 2
    assert doc2.cats["FASHION"] == 1.0
    assert doc2.cats["COSMETICS"] == 0.0

    # Banana Republic has a lot of feminine cuts and patterns
    doc3 = docs[3]
    assert doc3.text == TEXTCAT_DATA[1]["text"]
    assert len(list(doc3.sents)) == 1
    assert len(doc3) == 10
    assert [t.tag_ for t in doc3] == [""] * len(doc3)
    assert [t.dep_ for t in doc3] == [""] * len(doc3)
    assert [t.head.i for t in doc3] == [t.i for t in doc3]
    assert len(doc3.cats) == 2
    assert doc3.cats["FASHION"] == 1.0
    assert doc3.cats["COSMETICS"] == 0.0

    # Trader Joe\u2019s gel moisturizer is great [...]
    doc4 = docs[4]
    assert doc4.text == TEXTCAT_DATA[2]["text"]
    assert len(list(doc4.sents)) == 1
    assert len(doc4) == 16
    assert [t.tag_ for t in doc4] == [""] * len(doc4)
    assert [t.dep_ for t in doc4] == [""] * len(doc4)
    assert [t.head.i for t in doc4] == [t.i for t in doc4]
    assert len(doc4.cats) == 2
    assert doc4.cats["FASHION"] == 0.0
    assert doc4.cats["COSMETICS"] == 1.0
    # fmt: on


def test_data_to_spacy_train():
    """Check that 'spacy train' works for the generated data"""
    cfg = {
        "ner": ["ner_db"],
        "spancat": ["ner_db"],
        "textcat": ["textcat_db"],
        "tagger": ["tagger_db"],
        # "parser": ["parser_db"],
        "eval_split": 0.0,
        "verbose": True,
    }
    with make_tempdir() as output_dir:
        data_to_spacy(output_dir, **cfg)
        config = load_config(output_dir / "config.cfg")
        config["paths"]["train"] = str(output_dir / "train.spacy")
        config["paths"]["dev"] = str(output_dir / "train.spacy")
        config["training"]["max_epochs"] = 2
        assert set(config["components"]) == {
            "ner",
            "spancat",
            "textcat",
            "tagger",
            # "parser",
            "tok2vec",
        }
        nlp = init_nlp(config)
        spacy_train(nlp, output_path=None)


def test_data_to_spacy_textcat_single_invalid():
    """Single-label textcat datasets can not be processed with the 'textcat' component"""
    cfg = {
        "textcat": ["textcat_single_db"],
        "eval_split": 0.0,
    }
    with make_tempdir() as output_dir:
        with pytest.raises(ValueError):
            data_to_spacy(output_dir, **cfg)


def test_data_to_spacy_textcat_single():
    cfg = {
        "textcat_multilabel": ["textcat_single_db"],
        "eval_split": 0.0,
    }
    nlp = spacy.blank("en")
    with make_tempdir() as output_dir:
        data_to_spacy(output_dir, **cfg)
        doc_bin = DocBin().from_disk(output_dir / "train.spacy")
        docs = list(doc_bin.get_docs(nlp.vocab))
    assert len(docs) == 3

    # fmt: off
    # Keds are alright [...]
    doc0 = docs[0]
    assert doc0.text == TEXTCAT_SINGLE_DATA[0]["text"]
    assert len(doc0.cats) == 1
    assert doc0.cats["FASHION"] == 1.0

    # Banana Republic [...]
    doc1 = docs[1]
    assert doc1.text == TEXTCAT_SINGLE_DATA[1]["text"]
    assert len(doc1.cats) == 1
    assert doc1.cats["FASHION"] == 1.0

    # Trader Joe [...]
    doc2 = docs[2]
    assert doc2.text == TEXTCAT_SINGLE_DATA[2]["text"]
    assert len(doc2.cats) == 1
    assert doc2.cats["FASHION"] == 0.0
    # fmt: on


def test_data_to_spacy_senter():
    cfg = {
        "senter": ["senter_db"],
        "eval_split": 0.0,
        "verbose": True,
    }
    nlp = spacy.blank("en")
    with make_tempdir() as output_dir:
        data_to_spacy(output_dir, **cfg)
        doc_bin = DocBin().from_disk(output_dir / "train.spacy")
        docs = list(doc_bin.get_docs(nlp.vocab))
    assert len(docs) == 2

    # fmt: off
    # In Bad Muenstereifel?
    doc0 = docs[0]
    assert doc0.text == SENT_DATA[0]["text"]
    assert len(list(doc0.sents)) == 1

    # Keds are alright [...]
    doc1 = docs[1]
    assert doc1.text == SENT_DATA[1]["text"]
    sentences = list(doc1.sents)
    assert len(sentences) == 7
    # fmt: on


@pytest.mark.parametrize(
    "component,examples",
    [
        ("ner", NER_DATA),
        ("textcat", TEXTCAT_DATA),
        ("tagger", POS_DATA),
        ("senter", SENT_DATA),
        ("parser", DEP_DATA),
    ],
)
def test_validate_examples_valid(component, examples):
    examples = (set_hashes(eg) for eg in examples)
    assert list(validate_examples(examples, component))


INVALID_NER = [
    {
        "text": "I should have just gone to the wedding last year.",
        "spans": [{"start": 39, "end": 48}],
        "answer": "accept",
    },
    {
        "text": "I should have just gone to the wedding last year.",
        "spans": [{"start": 39, "end": 48, "label": "DATE"}],
    },
    {"text": "In Bad Muenstereifel?"},
]

INVALID_TEXTCAT = [
    {"text": "In Bad Muenstereifel?"},
    {"text": "In Bad Muenstereifel?", "accept": ["QUESTION"]},
]

INVALID_DEP = [
    {"text": "In Bad Muenstereifel?"},
    {
        "text": "In Bad Muenstereifel?",
        "arcs": [{"head": 0, "child": 0, "label": "root"}],
        "answer": "accept",
    },
]


@pytest.mark.parametrize(
    "component,eg",
    [
        *[("ner", eg) for eg in INVALID_NER],
        *[("textcat", eg) for eg in INVALID_TEXTCAT],
        *[("tagger", eg) for eg in INVALID_DEP],
    ],
)
def test_validate_examples_invalid(component, eg):
    eg = set_hashes(eg)
    with pytest.raises(SystemExit):
        list(validate_examples([eg], component))


@pytest.mark.usefixtures("has_experimental_coref")
# TODO remove slow marker once we move ro radicli and it's possible to override the default config settings
# so that max_epochs can be set to 1 or 2 ('--training.max_epochs=1',), right now plac parses it wrong
@pytest.mark.slow()
def test_train_coref():
    """A smoke test for the train command with experimental-coref."""
    # this test is skipped if spacy-experimental or torch are not installed
    _, scores = train(None, ner=["ner_db"], textcat=["textcat_db"], coref=["coref_db"])
    assert scores is not None
    other_scores = scores.get("other_scores")
    losses = scores.get("losses")
    assert other_scores is not None
    assert losses is not None
    assert set(["token_acc", "coref_f", "cats_score"]).issubset(
        set(other_scores.keys())
    )
    assert set(["ner", "experimental_coref", "textcat", "tok2vec"]).issubset(
        set(losses.keys())
    )


# TODO remove slow marker once we move ro radicli and it's possible to override the default config settings
# so that max_epochs can be set to 1 or 2 ('--training.max_epochs=1',), right now plac parses it wrong
@pytest.mark.slow()
def test_train():
    """A smoke test for the train command."""
    # TODO: add parser component when it's possible to override the default config settings
    # by passing overrides to spaCy config e.g. ('--components.parser.min_action_freq=1',)
    # right now plac parses it wrong
    _, scores = train(
        None, ner=["ner_db"], textcat=["textcat_db"], tagger=["tagger_db"]
    )
    assert scores is not None
    other_scores = scores.get("other_scores")
    losses = scores.get("losses")
    assert other_scores is not None
    assert losses is not None
    assert set(["token_acc", "cats_score"]).issubset(set(other_scores.keys()))
    assert set(["ner", "textcat", "tok2vec", "tagger"]).issubset(set(losses.keys()))


@pytest.mark.usefixtures("has_experimental_coref")
# TODO remove slow marker once we move ro radicli and it's possible to override the default config settings
# so that max_epochs can be set to 1 or 2 ('--training.max_epochs=1',), right now plac parses it wrong
@pytest.mark.slow()
def test_train_curve_coref(capsys):
    """A smoke test for the train_curve command with spacy-experimental."""
    # this test is skipped if spacy-experimental or torch are not installed
    train_curve(
        ner=["ner_db"],
        coref=["coref_db"],
        n_samples=2,
        eval_split=0.5,
    )
    out, _ = capsys.readouterr()
    assert "⚠ Accuracy stayed the same in the last sample" in out


# TODO remove slow marker once we move ro radicli and it's possible to override the default config settings
# so that max_epochs can be set to 1 or 2 ('--training.max_epochs=1',), right now plac parses it wrong
@pytest.mark.slow()
def test_train_curve(capsys):
    """A smoke test for the train_curve command."""
    train_curve(
        ner=["ner_db"],
        eval_split=0.5,
        n_samples=2,
    )
    out, _ = capsys.readouterr()
    assert "⚠ Accuracy stayed the same in the last sample" in out


def test_data_to_spacy_merging():
    cfg = {
        "ner": ["ner_dup_db"],
        "eval_split": 0.0,
    }
    nlp = spacy.blank("en")
    with make_tempdir() as output_dir:
        data_to_spacy(output_dir, **cfg)
        doc_bin = DocBin().from_disk(output_dir / "train.spacy")
        docs = list(doc_bin.get_docs(nlp.vocab))
        assert len(docs) == 1
        doc = docs[0]
        assert len(doc.spans[NER_DEFAULT_INCORRECT_KEY]) == 2
        assert "Truths" in [ent.text for ent in doc.spans[NER_DEFAULT_INCORRECT_KEY]]
        assert "Noble" in [ent.text for ent in doc.spans[NER_DEFAULT_INCORRECT_KEY]]
        assert {"TRUTHS"} == {
            ent.label_ for ent in doc.spans[NER_DEFAULT_INCORRECT_KEY]
        }
        assert len(doc.ents) == 1
        assert "Noble Truths" in [ent.text for ent in doc.ents]
        assert {"TRUTHS"} == {ent.label_ for ent in doc.ents}


def test_data_to_spacy_merging_conflict():
    """Test that in an accept/reject conflict, the negative span is not retained"""
    cfg = {
        "ner": ["ner_conflict_db"],
        "eval_split": 0.0,
    }
    nlp = spacy.blank("en")
    with make_tempdir() as output_dir:
        data_to_spacy(output_dir, **cfg)
        doc_bin = DocBin().from_disk(output_dir / "train.spacy")
        docs = list(doc_bin.get_docs(nlp.vocab))
        assert len(docs) == 1
        assert len(docs[0].ents) == 1
        assert len(docs[0].spans[NER_DEFAULT_INCORRECT_KEY]) == 0
