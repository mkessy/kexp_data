import contextlib
import os
import shutil
import tempfile
from pathlib import Path
from typing import List

import pytest
import srsly
from peewee import SqliteDatabase

from prodigy.components.db import (
    Database,
    Example,
    get_exports_path,
    get_prodigy_path,
    get_trash_path,
)
from prodigy.types import TaskType
from prodigy.util import ENV_VARS, INPUT_HASH_ATTR, TASK_HASH_ATTR

HASH_ONE = 13
HASH_TWO = 67


@contextlib.contextmanager
def make_tempdir():
    d = Path(tempfile.mkdtemp())
    yield d
    shutil.rmtree(str(d))


@pytest.fixture
def session_id():
    return "1337"


@pytest.fixture
def session_examples():
    return [
        {INPUT_HASH_ATTR: HASH_ONE, TASK_HASH_ATTR: 37, "content": {"first": True}},
        {INPUT_HASH_ATTR: HASH_TWO, TASK_HASH_ATTR: 34, "content": {"second": False}},
    ]


examples = [
    {
        "id": 11,
        INPUT_HASH_ATTR: 67,
        TASK_HASH_ATTR: 34,
        "content": {
            "text": "Hello",
            "entities": [{"start": 0, "end": 6, "label": "UH", "answer": "ignore"}],
        },
    }
]


datasets = [
    {"desc": "Session 1", "id": 232},
    {"desc": "Train example model", "id": 3457},
    {"desc": "Test example model", "id": 6991},
]

session = "test"

membership = [{"example": 11, "dataset": 232}, {"example": 11, "dataset": 3457}]


@pytest.fixture
def many_examples():
    examples = []
    for i in range(999):
        examples.append(
            {INPUT_HASH_ATTR: i, TASK_HASH_ATTR: -i, "content": {str(i): True}}
        )
    return examples


def test_orm_delete_many_examples_no_batching(
    database, many_examples, session_id="cool-session"
):
    database.add_examples(many_examples, (session_id,))
    database.drop_dataset(session_id)


def test_orm_delete_many_examples_batched(
    database, many_examples, session_id="batched-drop"
):
    database.add_examples(many_examples, (session_id,))
    database.drop_dataset(session_id, 100)


def test_orm_drop_examples_foreignkey_constraints(database, many_examples):
    """Verify that delete_examples does not trigger foreign key constraint errors"""
    database.add_examples(many_examples, ("session_1", "session_2"))
    many_ids = [e[TASK_HASH_ATTR] for e in many_examples]
    database.drop_examples(many_ids)


def test_custom_connect():
    sqlite_db = SqliteDatabase(":memory:")
    db = Database(sqlite_db)
    assert db.db_id == "custom"


def test_add_examples(database: Database):
    database.add_dataset("train")
    database.add_examples(examples, ["train"])


def test_drop_dataset(database: Database):
    database.add_dataset("train")
    database.add_examples(examples, ["train"])
    database.drop_dataset("train")


def test_add_dataset(database: Database):
    database.add_dataset("train")


def test_get_dataset_names(database: Database):
    database.add_dataset("train")
    names = database.datasets
    assert "train" in names


def test_get_dataset(database: Database):
    database.add_examples(examples, datasets=["dev"])
    dev = database.get_dataset_examples("dev")
    dev_deprecated = database.get_dataset("dev")
    assert len(dev) == len(examples)
    assert len(dev) == len(dev_deprecated)
    assert database.count_dataset("dev") == len(dev)


def test_get_dataset_examples(database: Database):
    database.add_examples(examples, datasets=["dev"])
    dev = database.get_dataset_examples("dev")
    assert len(dev) == len(examples)
    assert database.count_dataset("dev") == len(dev)


def test_get_hashes(database: Database):
    n_hashes = 100
    dataset_id = "hash_dev"
    hash_examples = [
        {TASK_HASH_ATTR: i * 10, INPUT_HASH_ATTR: i * 10} for i in range(n_hashes)
    ]
    database.add_examples(examples, datasets=["dev"])
    database.add_examples(hash_examples, datasets=[dataset_id])
    dataset = database.get_dataset_examples(dataset_id)
    task_hashes = database.get_task_hashes(dataset_id)
    input_hashes = database.get_input_hashes(dataset_id)
    assert len(dataset) == n_hashes
    assert len(task_hashes) == n_hashes
    assert len(input_hashes) == n_hashes


def test_orm_get_sessions_examples(
    database: Database, session_examples: List[TaskType], session_id: str
):
    with pytest.raises(ValueError):
        database.get_sessions_examples(None)
    with pytest.raises(ValueError):
        database.get_sessions_examples([])

    other_session = "session_id_2"
    session_ids = [session_id, other_session]
    database.add_dataset(session_id, session=True)
    database.add_dataset(other_session, session=True)
    database.add_examples(session_examples, session_ids)
    found = database.get_sessions_examples(session_ids)
    # should find (sessions * examples) results
    assert len(found) == len(session_examples) * len(session_ids)

    # verify session_id is added to the examples
    for example in found:
        assert example["session_id"] in session_ids


def test_orm_export_session(
    database: Database, session_examples: List[TaskType], session_id: str
):
    with pytest.raises(ValueError):
        database.export_session(None)
    with pytest.raises(ValueError):
        database.export_session("invalid-dataset-name")

    # Submit examples for the current session (state value in controller)
    database.add_dataset(session_id, session=True)
    database.add_examples(session_examples, (session_id,))

    data = database.export_session(session_id)
    # Find expected exported examples
    assert data["total"] == len(session_examples)

    # Verify the file exists on disk
    export_file = Path(data["file"])
    assert export_file.is_file() is True

    # Read the file in and verify it contains the two original inputs
    stream = srsly.read_jsonl(export_file)
    for json_line in stream:
        assert (
            json_line[INPUT_HASH_ATTR] == HASH_ONE
            or json_line[INPUT_HASH_ATTR] == HASH_TWO
        )


def test_orm_export_sessions(
    database: Database, session_examples: List[TaskType], session_id: str
):
    with pytest.raises(ValueError):
        database.export_sessions(None, None)
    with pytest.raises(ValueError):
        database.export_sessions([], None)

    other_session = "session_id_2"
    out_name = "task-examples"
    session_ids = [session_id, other_session]
    database.add_dataset(session_id, session=True)
    database.add_dataset(other_session, session=True)
    database.add_examples(session_examples, session_ids)

    # Export should yield (examples * sessions) results
    data = database.export_sessions(session_ids, out_name)
    assert data["total"] == len(session_examples) * len(session_ids)

    # Verify the file exists on disk
    export_file = Path(data["file"])
    assert export_file.is_file() is True

    # Read the file in and verify its contents
    stream = srsly.read_jsonl(export_file)
    for json_line in stream:
        # Input hash comes from one of the two input questions
        assert (
            json_line[INPUT_HASH_ATTR] == HASH_ONE
            or json_line[INPUT_HASH_ATTR] == HASH_TWO
        )
        # session_id links back to one of the session ids
        assert json_line["session_id"] in session_ids


def test_orm_export_collection(
    database: Database, session_examples: List[TaskType], session_id: str
):
    other_session = "other-guid"
    group_one = "group_one"
    group_two = "group_two"
    session_ids = [session_id, other_session]
    database.add_dataset(session_id, session=True)
    database.add_dataset(other_session, session=True)
    database.add_examples(session_examples, session_ids)

    one_sessions = [session_id]
    two_sessions = [session_id, other_session]
    shape = {"group_one": [session_id], "group_two": [session_id, other_session]}
    data = database.export_collection(shape, "my_collection")

    # number of examples times number of sessions in all groups
    assert data["total"] == len(session_examples) * (
        len(one_sessions) + len(two_sessions)
    )

    # Verify the index file exists on disk
    export_file = Path(data["file"])
    assert export_file.is_file() is True

    # Read the file in and verify its contents
    index = srsly.read_json(export_file)

    # Verify export of group "one"
    one = index[group_one]
    assert len(one["sessions"]) == 1
    assert Path(one["file"]).is_file()

    # Verify export of group "two"
    two = index[group_two]
    assert len(two["sessions"]) == 2
    assert Path(two["file"]).is_file()


def test_orm_trash_session(
    database: Database, session_examples: List[TaskType], session_id: str
):
    # There are no examples in the session dataset to remove
    data = database.trash_session(session_id)
    assert data["total"] == 0

    # Insert examples
    database.add_examples(session_examples, (session_id,))

    # Remove the session examples
    data = database.trash_session(session_id)
    assert data["total"] == len(session_examples)

    # The examples in the 'train' dataset will be gone because the session that
    # added them was the only reference and it went away.
    assert database.get_dataset_examples("train", None) is None


def test_orm_trash_sessions(
    database: Database, session_examples: List[TaskType], session_id: str
):
    other_session = "session_id_2"
    out_name = "task-examples"
    session_ids = [session_id, other_session]

    # There are no examples in the session dataset to remove
    data = database.trash_sessions([session_id], out_name)
    assert data["total"] == 0

    database.add_dataset(session_id, session=True)
    database.add_dataset(other_session, session=True)
    database.add_examples(session_examples, session_ids)

    # Remove the session examples
    data = database.trash_sessions(session_ids, out_name)
    assert data["total"] == len(session_examples) * len(session_ids)

    # The examples in the 'train' dataset will be gone because the session that
    # added them was the only reference and it went away.
    assert database.get_dataset_examples("train", None) is None

    # Verify the backup exists on disk
    export_file = Path(data["file"])
    assert export_file.is_file() is True

    # Read the file in and verify its contents
    stream = srsly.read_jsonl(export_file)
    for json_line in stream:
        # Input hash comes from one of the two input questions
        assert (
            json_line[INPUT_HASH_ATTR] == HASH_ONE
            or json_line[INPUT_HASH_ATTR] == HASH_TWO
        )
        # session_id links back to one of the session ids
        assert json_line["session_id"] in session_ids


def test_orm_trash_session_strong_ref_preserve(
    database: Database, session_examples: List[TaskType], session_id: str
):
    # Insert examples from two sessions
    database.add_examples(session_examples, (session_id,))
    database.add_examples(session_examples, ("{}2".format(session_id),))
    example_input_hashes = [HASH_ONE, HASH_TWO]

    # Trash the session
    data = database.trash_session(session_id)
    assert data["total"] == len(session_examples)

    # The examples with the input_hash will still exist because they're referenced by
    # the controller dataset as well as the session.
    examples = Example.select().where(Example.input_hash << example_input_hashes)
    assert len(examples) == len(session_examples)


def test_orm_trash_session_strong_ref_delete(
    database: Database, session_examples: List[TaskType], session_id: str
):
    # Insert examples
    database.add_examples(session_examples, (session_id,))
    example_input_hashes = [HASH_ONE, HASH_TWO]

    # Verify the examples query yields two results
    examples = Example.select().where(Example.input_hash << example_input_hashes)
    assert len(examples) == len(session_examples)

    # Trash the session
    data = database.trash_session(session_id)
    assert data["total"] == len(session_examples)

    # The examples will be removed because they're no longer referenced
    examples = Example.select().where(Example.input_hash << example_input_hashes)
    assert len(examples) == 0


def test_orm_trash_session_file_backup(
    database: Database, session_examples: List[TaskType], session_id: str
):
    # Insert examples
    database.add_examples(session_examples, (session_id,))

    # Trash the session
    data = database.trash_session(session_id)

    # Verify the backup file exists on disk
    trash_file = Path(data["file"])
    assert trash_file.is_file() is True

    # Read the backup file in and verify it contains the two original inputs
    stream = srsly.read_jsonl(trash_file)
    for json_line in stream:
        assert (
            json_line[INPUT_HASH_ATTR] == HASH_ONE
            or json_line[INPUT_HASH_ATTR] == HASH_TWO
        )


def test_orm_trash_session_file_backup_conflicts(
    database: Database, session_examples: List[TaskType], session_id: str
):
    # Insert examples, trash the session to get a backup file
    database.add_examples(session_examples, (session_id,))
    data = database.trash_session(session_id)
    trash_file_one = Path(data["file"])
    assert trash_file_one.is_file() is True

    # Insert the same examples again and repeat to get another backup
    database.add_examples(session_examples, (session_id,))
    data = database.trash_session(session_id)
    trash_file_two = Path(data["file"])
    assert trash_file_two.is_file() is True

    # verify the two backups are different files.
    assert trash_file_one != trash_file_two


def test_orm_trash_collection(
    database: Database, session_examples: List[TaskType], session_id: str
):
    other_session = "other-guid"
    out_name = "collection_id"
    group_one = "deadbeef"
    group_two = "badf00d"
    session_ids = [session_id, other_session]
    database.add_dataset(session_id, session=True)
    database.add_dataset(other_session, session=True)
    database.add_examples(session_examples, session_ids)

    one_sessions = [session_id]
    two_sessions = [session_id, other_session]
    shape = {group_one: one_sessions, group_two: two_sessions}
    data = database.trash_collection(shape, out_name)

    # number of examples times number of sessions in all groups
    assert data["total"] == len(session_examples) * (
        len(one_sessions) + len(two_sessions)
    )

    # Verify the index file exists on disk
    trash_file = Path(data["file"])
    assert trash_file.is_file() is True

    # Read the file in and verify its contents
    index = srsly.read_json(trash_file)

    # Verify backup of group one
    one = index[group_one]
    assert len(one["sessions"]) == 1
    assert Path(one["file"]).is_file()

    # Verify backup of group two
    two = index[group_two]
    assert len(two["sessions"]) == 2
    assert Path(two["file"]).is_file()


def test_util_get_trash_path_defaults():
    # By default trash path is read from an env var
    with make_tempdir() as temp_dir:
        os.environ[ENV_VARS.TRASH] = str(temp_dir)
        assert get_trash_path() == str(temp_dir)
    del os.environ[ENV_VARS.TRASH]
    # If not specified in the env, trash goes in the prodigy path
    assert get_prodigy_path() in get_trash_path()


def test_util_get_exports_path_defaults():
    # By default trash path is read from an env var
    with make_tempdir() as temp_dir:
        os.environ[ENV_VARS.EXPORTS] = str(temp_dir)
        assert get_exports_path() == str(temp_dir)
    del os.environ[ENV_VARS.EXPORTS]
    # If not specified in the env, trash goes in the prodigy path
    assert get_prodigy_path() in get_exports_path()
