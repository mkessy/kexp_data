import functools
from collections import Counter
from pathlib import Path
from typing import List, cast

import pytest
import srsly

from prodigy.components.db import Database
from prodigy.components.routers import full_overlap, no_overlap, route_average_per_task
from prodigy.components.source import ListSource, load_noop
from prodigy.components.stream import Stream
from prodigy.core import Controller
from prodigy.types import TaskType
from prodigy.util import ENV_VARS, set_hashes

from .util import env_var_override


@pytest.fixture
def stream(datasets_path: Path) -> Stream[TaskType, TaskType]:
    input_file = datasets_path / "input_130.jsonl"
    stream_examples = list(srsly.read_jsonl(input_file))
    stream_examples = cast(List[TaskType], stream_examples)
    s = Stream[TaskType, TaskType](
        source=ListSource(stream_examples),
        loader=load_noop,
        wrappers=[],
    )
    s.apply(lambda data: map(set_hashes, data))
    return s


@pytest.fixture
def recipe_config(
    database: Database,
    stream: Stream[TaskType, TaskType],
):
    database.add_dataset("xxx")
    return {
        "dataset": "xxx",
        "view_id": "classification",
        "stream": stream,
        "update": None,
        "db": database,
        "progress": None,
        "on_load": None,
        "on_exit": None,
        "before_db": None,
        "validate_answer": None,
        "get_session_id": None,
        "exclude": None,
        "config": {"max_sessions": 100},
        "metrics": None,
        "task_router": None,
    }


def stream_list(stream_examples: List[TaskType]):
    return Stream(
        source=ListSource(stream_examples),
        loader=load_noop,
        wrappers=[],
    )


@pytest.mark.parametrize("average", [1, 2, 3])
@pytest.mark.parametrize("n_users", [1, 2, 3, 5])
def test_annotations_per_task_integer(average, n_users, recipe_config):
    users = [f"u{i}" for i in range(n_users)]
    recipe_config["config"] = {
        **recipe_config["config"],
        "annotations_per_task": average,
    }
    with env_var_override(ENV_VARS.ALLOWED_SESSIONS, ",".join(users)):
        ctrl = Controller(**recipe_config)

    assert len(ctrl.session_ids) == n_users

    # Now lets get questions for them
    for user in users:
        session_id = ctrl.get_session_name(user)
        tasks = ctrl.get_questions(session_id=session_id)
        while len(tasks):
            ctrl.receive_answers(tasks, session_id=session_id)
            tasks = ctrl.get_questions(session_id=session_id)

    examples = ctrl.db.get_dataset_examples(ctrl.dataset)

    # We're using the input 130 dataset here, hence this expectation.
    expected_factor = min(average, n_users)
    assert len(examples) == expected_factor * 130

    # Each example should be annotated exactly `average` times.
    per_hash = Counter(ex["_task_hash"] for ex in examples).values()
    assert all([c == expected_factor for c in per_hash])

    # Check that the distribution is somewhat the same
    per_hash = Counter(ex["_annotator_id"] for ex in examples).values()
    if n_users == average:
        assert all(count == 130 for count in per_hash)


@pytest.mark.parametrize("average", [1.0, 2.5, 1.5])
@pytest.mark.parametrize("n_users", [1, 3, 5])
def test_annotations_per_task_float(average, n_users, recipe_config):
    users = [f"u{i}" for i in range(n_users)]
    recipe_config["config"] = {
        **recipe_config["config"],
        "annotations_per_task": average,
    }
    with env_var_override(ENV_VARS.ALLOWED_SESSIONS, ",".join(users)):
        ctrl = Controller(**recipe_config)

    # Now lets get questions for them
    for user in users:
        session_id = ctrl.get_session_name(user)
        tasks = ctrl.get_questions(session_id=session_id)
        while len(tasks):
            ctrl.receive_answers(tasks, session_id=session_id)
            tasks = ctrl.get_questions(session_id=session_id)

    examples = ctrl.db.get_dataset_examples(ctrl.dataset)

    # We're using the input 130 dataset here, hence this expectation.
    expected_factor = min(average, n_users)
    assert len(examples) == pytest.approx(expected_factor * 130, abs=10)

    # Each example should be annotated approx `average` times.
    # It might deviate a little bit, but never more than 1
    per_hash = Counter(ex["_task_hash"] for ex in examples).values()
    assert all([c == pytest.approx(expected_factor, abs=1) for c in per_hash])


@pytest.mark.parametrize("annotations_per_task", [1, 2])
def test_router_does_not_exceed_overlap(recipe_config, annotations_per_task):
    ctrl_params = {
        **recipe_config,
        "stream": stream_list([set_hashes({"text": f"{i}"}) for i in range(50)]),
        "config": {
            "annotations_per_task": annotations_per_task,
        },
    }
    ctrl = Controller(**ctrl_params)

    # Let's ensure that some users exist.
    for name in "a,b,c".split(","):
        ctrl.confirm_session(name)
        # There are zero annotations, users are just added
        assert len(ctrl._sessions[name]._answered_task_hashes) == 0

    # Let's suppose some annotations suddenly exist in the database. Magically.
    for name in "x,y".split(","):
        sess_id = ctrl.get_session_name(name)
        some_tasks = [
            set_hashes({"text": f"{i}", "_session_id": sess_id}) for i in range(10)
        ]
        ctrl.db.add_examples(some_tasks, datasets=[ctrl.dataset])

    # Then the routers should recognize that these tasks are meant to be skipped
    excluded_hashes = [_["_task_hash"] for _ in some_tasks]
    for name in "a,b,c".split(","):
        current_hashes = [_["_task_hash"] for _ in ctrl.get_questions(name)]
        assert all([h not in excluded_hashes for h in current_hashes])

    # So _even if_ somebody goes a db-in while folks are annotating, we should prevent duplicates!


def test_custom_task_router(dataset, recipe_config):
    def router(ctrl: Controller, session_id, item):
        annot = []
        if int(item["text"]) % 2:
            annot.append("user1")
        else:
            annot.append("user2")
        annot = [ctrl.get_session_name(n) for n in annot]
        for sess_id in annot:
            ctrl.confirm_session(sess_id)
        return annot

    ctrl_params = {
        **recipe_config,
        "task_router": router,
        "config": {"feed_overlap": False},
    }
    ctrl = Controller(**ctrl_params)

    tasks1 = ctrl.get_questions(session_id=ctrl.get_session_name("user1"))
    tasks2 = ctrl.get_questions(session_id=ctrl.get_session_name("user2"))
    assert all([int(t["text"]) % 2 == 1 for t in tasks1])
    assert all([int(t["text"]) % 2 == 0 for t in tasks2])


@pytest.mark.parametrize("should_steal_tasks", [True, False])
def test_work_stealing_config(should_steal_tasks, recipe_config, caplog, dataset):
    """In general you want to be careful with work stealing when the annotations_per_task
    settings is small because you might end up with a single user doing all
    the annotations and preventing other annotations from doing work. There is
    a parameter called `allow_work_stealing` config to allow work stealing
    again for this use-case though."""

    with env_var_override(ENV_VARS.LOGGING, "basic"):
        with env_var_override(ENV_VARS.ALLOWED_SESSIONS, "u1,u2,u3"):
            ctrl_params = {
                **recipe_config,
                "config": {
                    "annotations_per_task": 2,
                    "allow_work_stealing": should_steal_tasks,
                },
            }
            ctrl = Controller(**ctrl_params)

            # First user annotates everythings they see
            tasks = ctrl.get_questions(session_id=ctrl.get_session_name("u1"))
            while len(tasks):
                ctrl.receive_answers(tasks, session_id=ctrl.get_session_name("u1"))
                tasks = ctrl.get_questions(session_id=ctrl.get_session_name("u1"))

            # Now we see user number two annotate something.
            tasks = ctrl.get_questions(session_id=ctrl.get_session_name("u2"))

            # Does the first user see new tasks now? If so that's work-stealing and
            # in this special case the `allow_work_stealing` config determines what needs
            # to happen.
            can_steal_tasks = (
                len(ctrl.get_questions(session_id=ctrl.get_session_name("u1"))) > 0
            )
            assert should_steal_tasks == can_steal_tasks
    # Also check if it appears in the logs
    assert ("stolen" in caplog.text) == should_steal_tasks


@pytest.mark.parametrize("annotations_per_task", [2, 3])
def test_annotations_per_task_answered_task_hashes(recipe_config, annotations_per_task):
    """Ensure that the session factory is able to populate the _answered_task_hashes
    when annotations_per_task is set."""
    ctrl_params = {
        **recipe_config,
        "stream": stream_list([set_hashes({"text": f"{i}"}) for i in range(50)]),
        "config": {
            "annotations_per_task": annotations_per_task,
        },
    }

    ctrl = Controller(**ctrl_params)

    # Let's assume some annotations already exist in the database.
    some_tasks = [set_hashes({"text": f"{i}"}) for i in range(10)]
    for name in "a,b".split(","):
        sess_id = ctrl.get_session_name(name)
        ctrl.receive_answers(some_tasks, session_id=sess_id)
        assert len(ctrl._sessions[sess_id]._answered_task_hashes) == 10

    # Add session c, does it have answered task hashes?
    sess_id = ctrl.get_session_name("c")
    ctrl.confirm_session(sess_id)
    if annotations_per_task == 2:
        assert len(ctrl._sessions[sess_id]._answered_task_hashes) == 10
    else:
        # Because annotations_per_task is 3, session c will not have any excluded
        # task hashes and will be the 3rd session to get these hashes
        assert len(ctrl._sessions[sess_id]._answered_task_hashes) == 0


def flatten(d):
    return functools.reduce(lambda a, b: a + b, list(d))


# fmt: off
combinations = [
    ("a,b,c", 1, 0),    # single user should see task, no issues
    ("a,b,c,d", 1, 0),  # single user should see task, no issues
    ("a,b,c", 2, 10),   # first a blocks 10 from b and c, then good
    ("a,b,c,d", 2, 10), # first a blocks 10 from b/c/d, then good
    ("a,b,c", 3, 30),   # first a blocks 10 from b/c, costs 20 because annotations_per_task=3, then b blocks 10 from c, costs 10
    ("a,b,c,d", 3, 30), # first a blocks 10 from b/c/d, costs 20 because annotations_per_task=3, then b blocks 10 from c/d, costs 10
]
# fmt: on


@pytest.mark.parametrize("users, annotations, expected_delta", combinations)
def test_integer_round_robin_sessions_not_known_upfront(
    recipe_config, users, annotations, expected_delta
):
    # When using task routing, we want to make sure that users don't see
    # the same examples in their first batch. Even when we don't know the
    # sessions upfront. This test makes sure that this is the case.
    ctrl_params = {
        **recipe_config,
        "config": {
            "annotations_per_task": annotations,
            "allow_work_stealing": False,
        },
    }
    ctrl = Controller(**ctrl_params)

    tasks = {}
    for user in users.split(","):
        session_id = ctrl.get_session_name(user)
        tasks[session_id] = ctrl.get_questions(session_id=session_id)

    # Keep doing round robin until tasks are empty.
    while len(flatten(tasks.values())) > 0:
        for sess_id, annot_tasks in tasks.items():
            ctrl.receive_answers(annot_tasks, session_id=sess_id)
            tasks[sess_id] = ctrl.get_questions(session_id=sess_id)

    examples = ctrl.db.get_dataset_examples(ctrl.dataset)

    # We're using the input 130 dataset here, and there is work not
    # being allocated correctly in the beginning because users are not
    # known upfront. Tasks can only be routed to 1 user in the begining,
    # when the 2nd user joins it can be routed to at most 2, etc.
    assert len(examples) == annotations * 130 - expected_delta


@pytest.mark.parametrize("annotations_per_task", [2, 5])
@pytest.mark.parametrize("batch_size", [2, 5])
@pytest.mark.parametrize("n_users", [5, 10])
def test_integer_round_robin_many_users_known_upfront_with_restart(
    datasets_path, recipe_config, annotations_per_task, batch_size, n_users
):
    # This test was added as a response to this issue:
    # https://support.prodi.gy/t/task-routings-problem-i-want-to-get-5-annotations-per-task-but-it-doesnt-work/6754/6
    # There was an edge case that involved server restarts
    users = ",".join([f"user{i}" for i in range(n_users)])

    # First, define a function that allows us to restart the stream
    def restart_server(users: str) -> Stream[TaskType, TaskType]:
        # Start a new stream from disk
        input_file = datasets_path / "input_130.jsonl"
        stream_examples = list(srsly.read_jsonl(input_file))
        stream_examples = cast(List[TaskType], stream_examples)
        s = Stream[TaskType, TaskType](
            source=ListSource(stream_examples),
            loader=load_noop,
            wrappers=[],
        )
        s.apply(lambda data: map(set_hashes, data))
        recipe_config["stream"] = s

        # Add it to the controller params
        ctrl_params = {
            **recipe_config,
            "config": {
                "annotations_per_task": annotations_per_task,
                "allow_work_stealing": False,
                "batch_size": batch_size,
                "exclude_by": "input",
            },
        }

        # Users should be known upfront
        with env_var_override("PRODIGY_ALLOWED_SESSIONS", users):
            ctrl = Controller(**ctrl_params)

        # Assign users tasks
        tasks = {}
        for user in users.split(","):
            session_id = ctrl.get_session_name(user)
            tasks[session_id] = ctrl.get_questions(session_id=session_id)
        return ctrl, tasks

    ctrl, tasks = restart_server(users)
    while len(flatten(tasks.values())) > 0:
        # All users start to do some annotation
        for user in users.split(","):
            session_id = ctrl.get_session_name(user)
            ctrl.receive_answers(tasks[session_id], session_id=session_id)
            tasks[session_id] = ctrl.get_questions(session_id=session_id)
        # But then the server restarts
        ctrl, tasks = restart_server(users)
        examples = ctrl.db.get_dataset_examples(ctrl.dataset)

    examples = ctrl.db.get_dataset_examples(ctrl.dataset)
    assert len(examples) == 130 * annotations_per_task
    for count in Counter([ex["_input_hash"] for ex in examples]).values():
        assert count == annotations_per_task


@pytest.mark.parametrize("annotations_per_task", [4, 5])
@pytest.mark.parametrize("n_users", [8, 10])
@pytest.mark.parametrize("n_annot_before", [1, 2])
def test_route_with_annots_already_there(
    recipe_config, annotations_per_task, n_users, n_annot_before
):
    # This test was added to make sure that the router doesn't use a global
    # https://github.com/explosion/prodigy/pull/1010#discussion_r1312878479

    ctrl_params = {
        **recipe_config,
        "config": {
            "annotations_per_task": annotations_per_task,
            "allow_work_stealing": False,
        },
    }

    users = ",".join([f"user{i}" for i in range(n_users)])
    with env_var_override("PRODIGY_ALLOWED_SESSIONS", users):
        ctrl = Controller(**ctrl_params)
    sessions = [ctrl.get_session_name(u) for u in users.split(",")]

    # Some annotated examples, some of which have been annotated before
    # so they appear in the database before routing starts
    annot_sess = sessions[:n_annot_before]
    annot_examples = [
        {"text": "1", "_task_hash": 1, "_input_hash": 1, "_session_id": u}
        for u in annot_sess
    ]

    # Now the examples are added
    ctrl.db.add_examples(examples=annot_examples, datasets=[ctrl.dataset])

    # The first time around, the task router returns something
    routed_users1 = ctrl.task_router(ctrl, "doesnt matter here", annot_examples[0])

    # And, while we never run the task router twice in practice,
    # it should return the same thing the second time around
    routed_users2 = ctrl.task_router(ctrl, "doesnt matter here", annot_examples[0])
    assert routed_users1 == routed_users2


@pytest.mark.parametrize("users, annotations, expected_delta", combinations)
def test_integer_round_robin_no_sessions_known_upfront_custom_router(
    recipe_config, users, annotations, expected_delta
):
    # Any custom router should also function without having to worry about users
    # seeing the same examples in their first batch.
    ctrl_params = {
        **recipe_config,
        "task_router": route_average_per_task(annotations),
        "config": {"allow_work_stealing": False},
    }
    ctrl = Controller(**ctrl_params)

    tasks = {}
    for user in users.split(","):
        session_id = ctrl.get_session_name(user)
        tasks[session_id] = ctrl.get_questions(session_id=session_id)

    # Keep doing round robin until tasks are empty.
    while len(flatten(tasks.values())) > 0:
        for sess_id, annot_tasks in tasks.items():
            ctrl.receive_answers(annot_tasks, session_id=sess_id)
            tasks[sess_id] = ctrl.get_questions(session_id=sess_id)

    examples = ctrl.db.get_dataset_examples(ctrl.dataset)

    # We're using the input 130 dataset here, and there is work not
    # being allocated correctly in the beginning because users are not
    # known upfront. Tasks can only be routed to 1 user in the begining,
    # when the 2nd user joins it can be routed to at most 2, etc.
    assert len(examples) == annotations * 130 - expected_delta


@pytest.mark.parametrize("feed_overlap", [True, False])
@pytest.mark.parametrize("annotations_per_task", [True, False])
@pytest.mark.parametrize("custom_router", [True, False])
def test_exit_when_bad_combination_of_config_params(
    recipe_config, feed_overlap, annotations_per_task, custom_router
):
    # Make sure that we properly exit when some combinations of settings
    # are given. We want to make sure that it's clear that certaint parameters
    # carry different semantics with them.
    config = {"feed_overlap": feed_overlap}
    if annotations_per_task:
        config["annotations_per_task"] = 2
    if custom_router:
        recipe_config = {**recipe_config, "task_router": route_average_per_task(2)}

    ctrl_params = {**recipe_config, "config": config}

    raise_err = False
    if custom_router and (feed_overlap or annotations_per_task):
        raise_err = True
    if feed_overlap and annotations_per_task:
        raise_err = True

    if raise_err:
        with pytest.raises(SystemExit):
            Controller(**ctrl_params)
    else:
        Controller(**ctrl_params)


@pytest.mark.parametrize("logging_level", ["basic", "verbose"])
@pytest.mark.parametrize(
    "router", [route_average_per_task(3), no_overlap, full_overlap]
)
def test_task_router_logging(recipe_config, logging_level, router, caplog):
    """Routers should only log when at verbose level"""
    with env_var_override(ENV_VARS.LOGGING, logging_level):
        ctrl_params = {**recipe_config, "task_router": router}
        ctrl = Controller(**ctrl_params)
        session_id = ctrl.get_session_name("a")
        _ = ctrl.get_questions(session_id=session_id)

    # We expect one log line from the router for each of the 10 items in the batch
    router_lines = [line for line in caplog.text.split("\n") if "ROUTER" in line]
    router_logged = len(router_lines) == 10
    assert router_logged == (logging_level == "verbose")


def test_task_router_list_error(recipe_config):
    """Routers should return a list and we should err if this does not happen."""

    def bad_router(ctrl, session_id, item):
        # Am only returning a single string
        return session_id

    ctrl_params = {**recipe_config, "task_router": bad_router}
    ctrl = Controller(**ctrl_params)
    with pytest.raises(SystemExit) as e:
        session_id = ctrl.get_session_name("a")
        _ = ctrl.get_questions(session_id=session_id)
        assert "The task router is not returning a list of sessions" in e
