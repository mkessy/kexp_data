from typing import Any, Dict, List

import pytest

from prodigy.core import Controller
from prodigy.errors import RecipeError
from prodigy.recipes.review import (
    filter_accept_single_stream,
    filter_auto_accept_stream,
)
from prodigy.recipes.review import get_review_stream as get_stream
from prodigy.util import SESSION_ID_ATTR as S_ID
from prodigy.util import VIEW_ID_ATTR


def test_review_binary_textcat():
    base_eg = {VIEW_ID_ATTR: "classification"}
    examples = [
        {**base_eg, "text": "a", "label": "A", S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "a", "label": "A", S_ID: "2", "answer": "accept"},
        {**base_eg, "text": "a", "label": "A", S_ID: "3", "answer": "reject"},
        {**base_eg, "text": "a", "label": "B", S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "a", "label": "B", S_ID: "2", "answer": "reject"},
        {**base_eg, "text": "b", "label": "A", S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "b", "label": "A", S_ID: "4", "answer": "ignore"},
    ]
    stream = list(get_stream({"test": examples}))
    assert len(stream) == 3
    assert stream[0]["view_id"] == "classification"
    assert stream[0]["label"] == "A"
    assert len(stream[0]["versions"]) == 2
    assert stream[0]["versions"][0]["answer"] == "accept"
    assert stream[0]["versions"][0]["sessions"] == ["1", "2"]
    assert stream[0]["versions"][0]["default"] is True
    assert stream[0]["versions"][1]["answer"] == "reject"
    assert stream[0]["versions"][1]["sessions"] == ["3"]
    assert stream[0]["versions"][1]["default"] is False
    assert stream[1]["label"] == "B"
    assert len(stream[1]["versions"]) == 2
    assert stream[1]["versions"][0]["answer"] == "accept"
    assert stream[1]["versions"][0]["sessions"] == ["1"]
    assert stream[1]["versions"][0]["default"] is True
    assert stream[1]["versions"][1]["answer"] == "reject"
    assert stream[1]["versions"][1]["sessions"] == ["2"]
    assert stream[1]["versions"][1]["default"] is False
    assert stream[2]["label"] == "A"
    assert len(stream[2]["versions"]) == 1
    assert stream[2]["versions"][0]["answer"] == "accept"
    assert stream[2]["versions"][0]["sessions"] == ["1"]
    assert stream[2]["versions"][0]["default"] is True


def test_review_manual_ner():
    view_id = "ner_manual"
    base_eg = {VIEW_ID_ATTR: view_id}
    eg1 = {
        "text": "Hello world",
        "tokens": [
            {"text": "Hello", "start": 0, "end": 5, "id": 0},
            {"text": "world", "start": 6, "end": 11, "id": 1},
        ],
    }
    sp1 = [{"start": 0, "end": 5, "label": "TEST", "token_start": 0, "token_end": 0}]
    eg2 = {
        "text": "Yo!",
        "tokens": [
            {"text": "Yo", "start": 0, "end": 2, "id": 0},
            {"text": "!", "start": 2, "end": 3, "id": 1},
        ],
    }
    sp2_1 = [{"start": 2, "end": 3, "label": "TEST", "token_start": 1, "token_end": 1}]
    sp2_2 = [{"start": 0, "end": 2, "label": "TEST", "token_start": 0, "token_end": 0}]
    examples = [
        {**base_eg, **eg1, "spans": [], S_ID: "1", "answer": "accept"},
        {**base_eg, **eg1, "spans": [], S_ID: "2", "answer": "reject"},
        {**base_eg, **eg1, "spans": sp1, S_ID: "3", "answer": "accept"},
        {**base_eg, **eg1, "spans": sp1, S_ID: "4", "answer": "ignore"},
        {**base_eg, **eg1, "spans": sp1, S_ID: "5", "answer": "accept"},
        {**base_eg, **eg2, "spans": sp2_1, S_ID: "1", "answer": "accept"},
        {**base_eg, **eg2, "spans": [], S_ID: "2", "answer": "accept"},
        {**base_eg, **eg2, "spans": [], S_ID: "3", "answer": "accept"},
        {**base_eg, **eg2, "spans": sp2_1, S_ID: "4", "answer": "accept"},
        {**base_eg, **eg2, "spans": sp2_2, S_ID: "5", "answer": "accept"},
    ]
    stream = list(get_stream({"test": examples}))
    assert len(stream) == 2
    assert stream[0]["view_id"] == view_id
    assert len(stream[0]["versions"]) == 2
    assert stream[0]["versions"][0]["answer"] == "accept"
    assert stream[0]["versions"][0]["spans"] == []
    assert stream[0]["versions"][0]["sessions"] == ["1"]
    assert stream[0]["versions"][0]["default"] is False
    assert stream[0]["versions"][1]["answer"] == "accept"
    assert stream[0]["versions"][1]["spans"] == sp1
    assert stream[0]["versions"][1]["sessions"] == ["3", "5"]
    assert stream[0]["versions"][1]["default"] is True
    assert stream[1]["view_id"] == view_id
    assert len(stream[1]["versions"]) == 3
    assert stream[1]["versions"][0]["answer"] == "accept"
    assert stream[1]["versions"][0]["spans"] == sp2_1
    assert stream[1]["versions"][0]["sessions"] == ["1", "4"]
    assert stream[1]["versions"][0]["default"] is True
    assert stream[1]["versions"][1]["answer"] == "accept"
    assert stream[1]["versions"][1]["spans"] == []
    assert stream[1]["versions"][1]["sessions"] == ["2", "3"]
    assert stream[1]["versions"][1]["default"] is False
    assert stream[1]["versions"][2]["answer"] == "accept"
    assert stream[1]["versions"][2]["spans"] == sp2_2
    assert stream[1]["versions"][2]["sessions"] == ["5"]
    assert stream[1]["versions"][2]["default"] is False


def test_review_choice():
    view_id = "choice"
    options = [{"id": i, "text": "{}".format(i)} for i in [1, 2, 3, 4]]
    base_eg = {VIEW_ID_ATTR: view_id, "options": options}
    examples = [
        {**base_eg, "text": "a", "accept": [], S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "a", "accept": [], S_ID: "2", "answer": "reject"},
        {**base_eg, "text": "a", "accept": [2, 3], S_ID: "5", "answer": "accept"},
        {**base_eg, "text": "a", "accept": [2, 3], S_ID: "3", "answer": "accept"},
        {**base_eg, "text": "a", "accept": [2], S_ID: "4", "answer": "accept"},
        {**base_eg, "text": "b", "accept": [], S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "b", "accept": [], S_ID: "2", "answer": "accept"},
    ]
    stream = list(get_stream({"test": examples}))
    assert len(stream) == 2
    assert stream[0]["view_id"] == view_id
    assert len(stream[0]["versions"]) == 3
    assert stream[0]["versions"][0]["answer"] == "accept"
    assert stream[0]["versions"][0]["accept"] == []
    assert stream[0]["versions"][0]["sessions"] == ["1"]
    assert stream[0]["versions"][1]["answer"] == "accept"
    assert stream[0]["versions"][1]["accept"] == [2, 3]
    assert stream[0]["versions"][1]["sessions"] == ["3", "5"]
    assert stream[0]["versions"][1]["default"] is True
    assert stream[0]["versions"][2]["answer"] == "accept"
    assert stream[0]["versions"][2]["accept"] == [2]
    assert stream[0]["versions"][2]["sessions"] == ["4"]
    assert stream[0]["versions"][2]["default"] is False
    assert len(stream[1]["versions"]) == 1
    assert stream[1]["versions"][0]["answer"] == "accept"
    assert stream[1]["versions"][0]["accept"] == []
    assert stream[1]["versions"][0]["sessions"] == ["1", "2"]
    assert stream[1]["versions"][0]["default"] is True


@pytest.mark.parametrize(
    "relations1,relations2,versions,sessions,default",
    [
        # (1,4)(5,4) and (1,4)(5,4) - should show no diff
        (
            [
                {
                    "head": 1,
                    "child": 4,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "buy",
                },
                {
                    "head": 5,
                    "child": 4,
                    "head_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "sell",
                },
            ],
            [
                {
                    "head": 1,
                    "child": 4,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "buy",
                },
                {
                    "head": 5,
                    "child": 4,
                    "head_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "sell",
                },
            ],
            1,
            [["1", "2"]],
            [True],
        ),
        (  # (1,4)(5,4) and (5,4)(1,4) - should show no diff
            [
                {
                    "head": 1,
                    "child": 4,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "buy",
                },
                {
                    "head": 5,
                    "child": 4,
                    "head_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "sell",
                },
            ],
            [
                {
                    "head": 5,
                    "child": 4,
                    "head_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "sell",
                },
                {
                    "head": 1,
                    "child": 4,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "buy",
                },
            ],
            1,
            [["1", "2"]],
            [True],
        ),
        (  # (1,4)(1,5) and (1,5)(1,4) - should show no diff
            [
                {
                    "head": 1,
                    "child": 4,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "buy",
                },
                {
                    "head": 1,
                    "child": 5,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "label": "sell",
                },
            ],
            [
                {
                    "head": 1,
                    "child": 5,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "label": "sell",
                },
                {
                    "head": 1,
                    "child": 4,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "label": "buy",
                },
            ],
            1,
            [["1", "2"]],
            [True],
        ),
        (  # (1,3)(4,5) and (4,5)(1,3) - should show no diff
            [
                {
                    "head": 1,
                    "child": 3,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 12,
                        "end": 14,
                        "token_start": 3,
                        "token_end": 3,
                        "label": None,
                    },
                    "label": "buy",
                },
                {
                    "head": 4,
                    "child": 5,
                    "head_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "child_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "label": "sell",
                },
            ],
            [
                {
                    "head": 4,
                    "child": 5,
                    "head_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "child_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "label": "sell",
                },
                {
                    "head": 1,
                    "child": 3,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 12,
                        "end": 14,
                        "token_start": 3,
                        "token_end": 3,
                        "label": None,
                    },
                    "label": "buy",
                },
            ],
            1,
            [["1", "2"]],
            [True],
        ),
        (  # (1,3)(4,5) and (1,3)(2,5) - should show diff
            [
                {
                    "head": 1,
                    "child": 3,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 12,
                        "end": 14,
                        "token_start": 3,
                        "token_end": 3,
                        "label": None,
                    },
                    "label": "buy",
                },
                {
                    "head": 4,
                    "child": 5,
                    "head_span": {
                        "start": 15,
                        "end": 18,
                        "token_start": 4,
                        "token_end": 4,
                        "label": None,
                    },
                    "child_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "label": "sell",
                },
            ],
            [
                {
                    "head": 1,
                    "child": 3,
                    "head_span": {
                        "start": 4,
                        "end": 7,
                        "token_start": 1,
                        "token_end": 1,
                        "label": None,
                    },
                    "child_span": {
                        "start": 12,
                        "end": 14,
                        "token_start": 3,
                        "token_end": 3,
                        "label": None,
                    },
                    "label": "buy",
                },
                {
                    "head": 2,
                    "child": 5,
                    "head_span": {
                        "start": 8,
                        "end": 11,
                        "token_start": 2,
                        "token_end": 2,
                        "label": None,
                    },
                    "child_span": {
                        "start": 19,
                        "end": 22,
                        "token_start": 5,
                        "token_end": 5,
                        "label": None,
                    },
                    "label": "buy",
                },
            ],
            2,
            [["1"], ["2"]],
            [True, False],
        ),
    ],
)
def test_review_rel(
    relations1: List[Dict[str, Any]],
    relations2: List[Dict[str, Any]],
    versions: int,
    sessions: list,
    default: list,
):
    base_eg = {VIEW_ID_ATTR: "relations"}
    eg = {
        "text": "The cat sat on the mat.",
        "tokens": [
            {"text": "The", "start": 0, "end": 3, "id": 0},
            {"text": "cat", "start": 4, "end": 7, "id": 1},
            {"text": "sat", "start": 8, "end": 11, "id": 2},
            {"text": "on", "start": 12, "end": 14, "id": 3},
            {"text": "the", "start": 15, "end": 18, "id": 4},
            {"text": "mat", "start": 19, "end": 22, "id": 5},
        ],
    }
    examples = [
        {**base_eg, **eg, S_ID: "1", "answer": "accept", "relations": relations1},
        {**base_eg, **eg, S_ID: "2", "answer": "accept", "relations": relations2},
    ]
    stream = list(get_stream({"test": examples}))
    assert len(stream) == 1
    assert stream[0]["view_id"] == "relations"
    assert len(stream[0]["versions"]) == versions

    assert stream[0]["versions"][0]["answer"] == "accept"
    assert stream[0]["versions"][0]["sessions"] == sessions[0]
    assert stream[0]["versions"][0]["default"] is default[0]
    if len(stream[0]["versions"]) == 2:
        assert stream[0]["versions"][1]["sessions"] == sessions[1]
        assert stream[0]["versions"][1]["default"] is default[1]


def test_review_view_id_mismatch():
    examples = [
        {VIEW_ID_ATTR: "ner", "text": "a", "spans": [], "answer": "accept"},
        {VIEW_ID_ATTR: "ner_manual", "text": "b", "spans": [], "answer": "accept"},
    ]
    with pytest.raises(RecipeError):
        list(get_stream({"test": examples}))


def test_review_not_implemented():
    examples = [{VIEW_ID_ATTR: "image_manual", "image": "test.jpg", "answer": "accept"}]
    with pytest.raises(RecipeError):
        list(get_stream({"test": examples}))


def test_filter_auto_accept_stream(database):
    """`filter_auto_accept_stream` should remove examples without conflicts"""
    base_eg = {VIEW_ID_ATTR: "classification"}
    examples = [
        {**base_eg, "text": "a", "label": "A", S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "a", "label": "A", S_ID: "2", "answer": "accept"},
        {**base_eg, "text": "a", "label": "A", S_ID: "3", "answer": "accept"},
        {**base_eg, "text": "b", "label": "B", S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "b", "label": "B", S_ID: "2", "answer": "accept"},
        {**base_eg, "text": "c", "label": "C", S_ID: "2", "answer": "accept"},
    ]
    stream = get_stream({"test": examples})
    # Run through stream
    stream = filter_auto_accept_stream(stream, database, "xxx")
    # Only one example should be shown in the UI, the one with a single person's annotation.
    stream_lst = list(stream)
    assert len(stream_lst) == 1
    assert stream_lst[0]["label"] == "C"
    # Should result in three automatically saved examples: 2 w/o conflict and 1 annotated by a single person.
    assert len(database.get_dataset_examples("xxx")) == 2


def test_filter_accept_single_stream(database):
    """`filter_accept_single_stream` should remove examples annotated by a single annotator"""
    base_eg = {VIEW_ID_ATTR: "classification"}
    examples = [
        {**base_eg, "text": "a", "label": "A", S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "a", "label": "A", S_ID: "2", "answer": "accept"},
        {**base_eg, "text": "a", "label": "A", S_ID: "3", "answer": "accept"},
        {**base_eg, "text": "b", "label": "B", S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "c", "label": "C", S_ID: "1", "answer": "accept"},
    ]
    stream = get_stream({"test": examples})
    # Run through stream
    stream = filter_accept_single_stream(stream, database, "xxx")
    # Only one example should be shown in the UI, the one annotated by multiple annotators
    stream_lst = list(stream)
    assert len(stream_lst) == 1
    assert stream_lst[0]["label"] == "A"
    # Should result in one automatically saved example
    assert len(database.get_dataset_examples("xxx")) == 2


def test_both_filter_flags(database):
    """Both `auto_accept` and `accept_single` should result in stream showing examples with conflicts only"""
    base_eg = {VIEW_ID_ATTR: "classification"}
    examples = [
        {**base_eg, "text": "a", "label": "A", S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "a", "label": "A", S_ID: "2", "answer": "reject"},
        {**base_eg, "text": "b", "label": "B", S_ID: "1", "answer": "accept"},
        {**base_eg, "text": "b", "label": "B", S_ID: "2", "answer": "accept"},
        {**base_eg, "text": "c", "label": "C", S_ID: "2", "answer": "accept"},
    ]
    stream = get_stream({"test": examples})
    # Run through stream
    stream = filter_auto_accept_stream(stream, database, "xxx")
    stream = filter_accept_single_stream(stream, database, "xxx")
    # Only one example should be shown in the UI, the one with a conflict.
    stream_lst = list(stream)
    assert len(stream_lst) == 1
    assert stream_lst[0]["label"] == "A"
    # Should result in one automatically saved 2 examples: 1 w/o conflict and 1 annotated by a single person.
    assert len(database.get_dataset_examples("xxx")) == 2


def test_review_stream_in_new_controller(dataset):
    base_eg = {VIEW_ID_ATTR: "classification"}
    examples = {
        "database_name": [
            {**base_eg, "text": "a", "label": "A", S_ID: "1", "answer": "accept"},
            {**base_eg, "text": "a", "label": "A", S_ID: "2", "answer": "accept"},
            {**base_eg, "text": "a", "label": "A", S_ID: "3", "answer": "reject"},
            {**base_eg, "text": "a", "label": "B", S_ID: "1", "answer": "accept"},
            {**base_eg, "text": "a", "label": "B", S_ID: "2", "answer": "reject"},
            {**base_eg, "text": "b", "label": "A", S_ID: "1", "answer": "accept"},
            {**base_eg, "text": "b", "label": "A", S_ID: "4", "answer": "ignore"},
        ]
    }

    ctrl = Controller.from_components(
        "review",
        {"stream": get_stream(examples), "view_id": "review", "dataset": dataset},
    )

    assert ctrl.get_questions("vincent")
