from pathlib import Path

import pytest
import srsly

from prodigy.errors import RecipeError
from prodigy.recipes.commands import db_in, db_out, drop, stats
from prodigy.util import TASK_HASH_ATTR, set_hashes

from .util import make_tempdir


@pytest.fixture
def movies_path(datasets_path) -> Path:
    return datasets_path / "movies_sample.jsonl"


@pytest.fixture(params=["random-dataset-name", "another-dataset-name"])
def dataset_name(request):
    return request.param


def test_some_basic_interactions(database, movies_path, dataset_name):
    """Smoke test for some of the common commands."""
    with make_tempdir() as tempdir:
        # Put a file in
        db_in(dataset_name, movies_path)
        # Stats should confirm file is now in the database
        stats_out = stats(dataset_name, silent=True)["dataset_stats"]
        assert stats_out["dataset"] == dataset_name
        # Get the same file out, confirm contents are same
        db_out(dataset_name, out_dir=tempdir)
        g_orig = list(set_hashes(ex) for ex in srsly.read_jsonl(movies_path))
        g_written = list(srsly.read_jsonl(tempdir / f"{dataset_name}.jsonl"))
        assert len(g_orig) == len(g_written)
        for o, w in zip(g_orig, g_written):
            assert o[TASK_HASH_ATTR] == w[TASK_HASH_ATTR]
        # The first time when we drop, no sys-exit should appear
        drop(dataset_name)
        # But now the file doesn't exist, so sys-exit!
        with pytest.raises(RecipeError):
            drop(dataset_name)


def test_db_out_print(database, movies_path, capsys, dataset_name):
    """Ensure that db-out does the printing appropriately because front-end tests depend on it."""
    # Put a file in
    db_in(dataset_name, movies_path)
    # Ignore stdout so far.
    _ = capsys.readouterr()
    # Get the same text contents printed out
    db_out(dataset_name)
    # Capture relevant output here
    captured = capsys.readouterr()
    # Three examples go in, so three examples should get printed
    # Plus one extra line because print always adds a `\n`
    assert len(captured.out.split("\n")) == (3 + 1)
    # Check for properties
    for item in srsly.read_jsonl(movies_path):
        item = set_hashes(item)
        assert str(item[TASK_HASH_ATTR]) in captured.out


@pytest.mark.parametrize("answer", ["accept", "reject", "ignore"])
def test_accept_value(database, movies_path, answer, capsys, dataset_name):
    """We can give different answers and this is reflected in stats."""
    # Put a file in with answer
    db_in(dataset_name, movies_path, answer=answer)
    # Confirm the stats on this answer
    stats_out = stats(dataset_name, silent=True)["dataset_stats"]
    assert stats_out["annotations"] == 3
    assert stats_out[answer] == 3
    # Ignore stdout so far.
    _ = capsys.readouterr()
    # This should print zero items, so no stdout
    db_out(dataset_name, answer=answer)
    captured = capsys.readouterr()
    # Three examples go in, so three examples should get printed
    # Plus one extra line because print always adds a `\n`
    assert len(captured.out.split("\n")) == (3 + 1)
    # Check stats for other answers
    for other_value in ["accept", "reject", "ignore"]:
        if other_value != answer:
            # Confirm zero value
            assert stats_out[other_value] == 0
            # Ignore stdout so far.
            _ = capsys.readouterr()
            # This should print zero items, so no stdout
            db_out(dataset_name, answer=other_value)
            captured = capsys.readouterr()
            assert captured.out == ""
