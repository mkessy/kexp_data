import copy
import random
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, cast

import pytest
import srsly

from prodigy.components.db import Database
from prodigy.components.progress import (
    SourceProgressEstimator,
    TargetTotalProgressEstimator,
)
from prodigy.components.session import Session
from prodigy.components.source import GeneratorSource, ListSource, load_noop
from prodigy.components.stream import QueueItem, Stream, get_stream
from prodigy.core import (
    Controller,
)
from prodigy.errors import NoSessionFeedOverlapError
from prodigy.protocols import ControllerComponentsDict
from prodigy.structured_types import TextcatExample, ensure_structured_stream
from prodigy.types import RecipeComponents, TaskType
from prodigy.util import (
    ANNOTATOR_ID_ATTR,
    ENV_VARS,
    INPUT_HASH_ATTR,
    SESSION_ID_ATTR,
    TASK_HASH_ATTR,
    set_hashes,
)

from .util import env_var_override


def _get_hashes(tasks, by: str = TASK_HASH_ATTR):
    return [eg[by] for eg in tasks]


@pytest.fixture
def dataset():
    return "xxx"


@pytest.fixture
def max_sessions():
    return 100


@pytest.fixture
def view_id():
    return "classification"


@pytest.fixture
def stream(datasets_path: Path) -> Stream[TaskType, TaskType]:
    input_file = datasets_path / "input_130.jsonl"
    stream_examples = list(srsly.read_jsonl(input_file))
    stream_examples = cast(List[TaskType], stream_examples)
    s = Stream[TaskType, TaskType](
        source=ListSource(stream_examples),
        loader=load_noop,
        wrappers=[],
    )
    s.apply(lambda data: map(set_hashes, data))
    return s


@pytest.fixture
def recipe_config(
    database: Database,
    dataset: str,
    view_id: str,
    stream: Stream[TaskType, TaskType],
    max_sessions: int,
):
    database.add_dataset(dataset)
    return {
        "dataset": dataset,
        "view_id": view_id,
        "stream": stream,
        "update": None,
        "db": database,
        "progress": None,
        "on_load": None,
        "on_exit": None,
        "before_db": None,
        "validate_answer": None,
        "get_session_id": None,
        "exclude": None,
        "config": {"max_sessions": max_sessions},
        "metrics": None,
        "task_router": None,
    }


def stream_list(stream_examples: List[TaskType]):
    return Stream(
        source=ListSource(stream_examples),
        loader=load_noop,
        wrappers=[],
    )


def test_controller_init(recipe_config: Dict[str, Any], dataset: str, view_id: str):
    controller = Controller(**recipe_config)
    assert controller.dataset == dataset
    assert controller.view_id == view_id
    assert controller.session_id is not None


def test_controller_gives_examples(recipe_config: Dict[str, Any]):
    stream_examples = [{"text": "valid text", "_task_hash": 12, "_input_hash": 12}]
    recipe_config["stream"] = stream_list(stream_examples)
    ctrl = Controller(**recipe_config)
    assert ctrl.session_id
    assert ctrl.get_questions(ctrl.session_id)


def test_controller_validate_is_true(recipe_config: Dict[str, Any]):
    stream_examples = [{"the-text": "is-missing", "_task_hash": 12, "_input_hash": 12}]
    recipe_config["stream"] = stream_list(stream_examples)
    recipe_config["view_id"] = "text"
    recipe_config["config"]["validate"] = True
    ctrl = Controller(**recipe_config)
    with pytest.raises(SystemExit):
        ctrl.get_questions(ctrl.session_id)


def test_controller_validate_is_false(recipe_config: Dict[str, Any]):
    stream_examples = [{"the-text": "is-missing", "_task_hash": 12, "_input_hash": 12}]
    recipe_config["stream"] = stream_list(stream_examples)
    recipe_config["view_id"] = "text"
    recipe_config["config"]["validate"] = False
    ctrl = Controller(**recipe_config)
    assert ctrl.get_questions(ctrl.session_id)


def test_default_session_created_only_on_question_ask(recipe_config: Dict[str, Any]):
    stream_examples = [{"text": "is-fine", "_task_hash": 12, "_input_hash": 12}]
    recipe_config["stream"] = stream_list(stream_examples)
    ctrl = Controller(**recipe_config)
    # When controller is created, default session is not populated
    assert ctrl._default_session is None
    # When a named session is created, default session is still not populated
    ctrl.get_questions("named-session")
    assert ctrl._default_session is None
    # When questions are asked without session, default sessions is populated
    assert ctrl.get_questions(None)
    assert ctrl._default_session


@pytest.mark.parametrize("callback", [True, False])
def test_validation_callback(recipe_config: Dict[str, Any], callback):
    def validate_answer(eg):
        assert len(eg.get("spans", [])) > 0

    stream_examples = [{"text": "is-fine", "_task_hash": 12, "_input_hash": 12}]
    recipe_config["stream"] = stream_list(stream_examples)

    if callback:
        recipe_config["validate_answer"] = validate_answer

    ctrl = Controller(**recipe_config)

    if callback:
        with pytest.raises(AssertionError):
            ctrl.validate_answer(
                {"text": "no spans", TASK_HASH_ATTR: 1, INPUT_HASH_ATTR: 2, "spans": []}
            )

    # Ensure that the config for `validate_answer` is True and available when callback is in place,
    # this way the front-end is able to alert the user if the callback errors.
    assert ctrl.config.get("validate_answer", False) == callback


def test_controller_misc(
    database: Database, datasets_path: Path, stream: Stream[TaskType, TaskType]
):
    input_file = datasets_path / "input_2000.jsonl"
    stream_examples = list(srsly.read_jsonl(input_file))
    eg = stream_examples[0]
    assert isinstance(eg, dict)
    example_text = eg["text"]
    dataset = "xxx"
    progress = 25
    loaded = False
    exited = False
    called_before_db = False

    def on_load(ctrl):
        nonlocal loaded
        loaded = True

    def on_exit(ctrl):
        nonlocal exited
        exited = True

    def before_db(examples):
        nonlocal called_before_db
        called_before_db = True
        return examples

    def validate_answer(eg):
        assert len(eg.get("spans", [])) > 0

    config = {
        "dataset": dataset,
        "stream": stream,
        "update": lambda x: progress,
        "view_id": "text",
        "db": database,
        "progress": lambda *x, **y: progress,
        "on_load": on_load,
        "on_exit": on_exit,
        "before_db": before_db,
        "validate_answer": validate_answer,
        "get_session_id": None,
        "exclude": ["xxx"],
        "config": {},
        "metrics": None,
        "task_router": None,
    }

    controller = Controller(**config)
    assert controller.db is not False
    assert len(controller.db.datasets) == 1
    assert len(controller.db.sessions) == 1

    questions = list(controller.get_questions())
    controller.receive_answers(questions)
    controller.save()
    assert controller.dataset == dataset
    assert controller.progress == progress
    assert controller.db is not False
    assert len(controller.db.datasets) == 1
    assert len(controller.db.sessions) == 1
    assert questions[0]["text"] == example_text
    assert loaded
    assert exited
    assert called_before_db


def test_controller_custom_session_id(recipe_config: Dict[str, Any]):
    config = {**recipe_config, "get_session_id": lambda: "RANDOMNAME"}
    controller = Controller(**config)
    controller.get_questions(None)
    assert "RANDOMNAME" in controller.all_session_ids


examples = [
    {INPUT_HASH_ATTR: 0, TASK_HASH_ATTR: 1, "text": "Test 1", "label": "TEST"},
    {INPUT_HASH_ATTR: 2, TASK_HASH_ATTR: 3, "text": "Test 2", "label": "TEST"},
    {INPUT_HASH_ATTR: 4, TASK_HASH_ATTR: 5, "text": "Test 3", "label": "TEST"},
    {INPUT_HASH_ATTR: 6, TASK_HASH_ATTR: 7, "text": "Test 4", "label": "TEST"},
    {INPUT_HASH_ATTR: 8, TASK_HASH_ATTR: 9, "text": "Test 5", "label": "TEST"},
    {INPUT_HASH_ATTR: 10, TASK_HASH_ATTR: 11, "text": "Test 6", "label": "TEST"},
]


def test_controller_receive_answers_stores_annotator_id_with_eg(
    recipe_config: Dict[str, Any]
):
    controller = Controller(**recipe_config)
    answers = [
        {
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
            "text": "Test 1",
            "label": "TEST",
            "answer": "accept",
        }
    ]
    controller.receive_answers(answers, annotator_id="test")
    examples = controller.db.get_dataset_examples(recipe_config["dataset"])
    assert examples is not None and len(examples) == 1
    assert examples[0][ANNOTATOR_ID_ATTR] == "test"


@pytest.mark.parametrize("exclude_by", ["task", "input"])
def test_controller_feed_overlap_disabled_shares_questions(
    recipe_config: Dict[str, Any], exclude_by: str
):
    recipe_config["config"]["feed_overlap"] = False
    recipe_config["config"]["exclude_by"] = exclude_by
    recipe_config["config"]["batch_size"] = 3
    recipe_config["stream"] = stream_list(examples)
    controller = Controller(**recipe_config)
    # Session 1 gets all the questions in the first batch
    session_one = "cat"
    questions_one = list(controller.get_questions(session_one))
    assert len(questions_one) == len(examples) / 2
    # Session 2 can't get the same questions as Session 1
    session_two = "dog"
    questions_two = list(controller.get_questions(session_two))
    assert len(questions_two) == len(examples) / 2
    assert not _tasks_equal(questions_one, questions_two)


@pytest.mark.parametrize("exclude_by", ["task", "input"])
def test_controller_feed_overlap_enabled_repeats_questions(
    recipe_config: Dict[str, Any], exclude_by: str
):
    ctrl_params = {
        **recipe_config,
        "config": {
            "feed_overlap": True,
            "exclude_by": exclude_by,
        },
    }
    controller = Controller(**ctrl_params)
    session_one = "cat"
    questions_one = list(controller.get_questions(session_one))
    assert len(questions_one) == controller.batch_size
    session_two = "dog"
    questions_two = list(controller.get_questions(session_two))
    assert len(questions_two) == len(questions_one)
    assert _tasks_equal(questions_one, questions_two)


def test_controller_feed_overlap_raises_exception_when_using_default_session(
    recipe_config: Dict[str, Any],
):
    """When using feed_overlap=True it can produce bad behavior if
    you use the default session. Because it changes every time the
    server restarts, you will always begin annotation from the beginning.

    We produce a warning in this case.
    """
    recipe_config["config"]["feed_overlap"] = True
    recipe_config["stream"] = stream_list(examples)
    controller = Controller(**recipe_config)
    # Does not warn when overlapping and given a session_id
    controller.get_questions("session1")
    # Does warn when overlapping but not using named sessions
    with pytest.raises(NoSessionFeedOverlapError):
        controller.get_questions()


def test_controller_feed_returns_correct_session_name(recipe_config: Dict[str, Any]):
    controller = Controller(
        **{
            **recipe_config,  # type: ignore
            "stream": stream_list(examples),
        }
    )
    session_names = ["session_a", "session_b", "session_c"]
    for sess in session_names:
        controller.get_questions(sess)
    for sess in session_names:
        assert sess in controller._sessions.keys()


@pytest.mark.parametrize("exclude_by", ["task", "input"])
def test_controller_feed_returns_open_questions_with_overlap(
    recipe_config: Dict[str, Any], dataset: str, exclude_by: str
):
    controller = Controller(
        **{
            **recipe_config,
            "config": {
                "exclude_by": exclude_by,
                "feed_overlap": True,
            },
            "stream": stream_list(examples),
        }
    )
    answers = [
        {
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
            "text": "Test 1",
            "label": "TEST",
            "answer": "accept",
        }
    ]
    sess_one = "session_1"
    sess_two = "session_2"
    # Returns the same questions until answered
    for _ in range(3):
        assert len(controller.get_questions(sess_one)) == len(examples)
        assert len(controller.get_questions(sess_two)) == len(examples)
    # Answer question 1 from multiple sessions
    controller.receive_answers(answers, sess_one)
    controller.receive_answers(answers, sess_two)
    # Now it returns questions - 1
    for _ in range(3):
        assert len(controller.get_questions(sess_one)) == len(examples) - 1
        assert len(controller.get_questions(sess_two)) == len(examples) - 1
    assert isinstance(controller.db, Database)
    assert controller.db.count_dataset(dataset) == 2


@pytest.mark.parametrize("exclude_by", ["task", "input"])
def test_controller_feed_returns_open_questions_no_overlap(
    recipe_config: Dict[str, Any], database: Database, dataset: str, exclude_by: str
):
    controller = Controller(
        **{
            **recipe_config,
            "config": {
                "batch_size": 2,
                "feed_overlap": False,
                "exclude_by": exclude_by,
            },
            "stream": stream_list(examples),
        }
    )
    # Repeats questions until answered
    questions = controller.get_questions()
    assert len(questions) == 2
    for _ in range(3):
        # The same session requests so return the same tasks since they haven't been annotated yet
        assert questions == controller.get_questions()

    questions_a = list(controller.get_questions(session_id="session_a"))
    assert len(questions_a) == 2
    questions_b = list(controller.get_questions(session_id="session_b"))
    assert len(questions_b) == 2

    # Work stealing kicks in since the 6 available examples have been distributed
    # Only 1 example is stolen at a time
    questions_c = list(controller.get_questions(session_id="session_c"))
    assert len(questions_c) == 1

    answers = [
        {
            INPUT_HASH_ATTR: 0,
            TASK_HASH_ATTR: 1,
            "text": "Test 1",
            "label": "TEST",
            "answer": "accept",
        }
    ]
    controller.receive_answers(answers)

    # After anwswering one of the open questions for the default session,
    # the next request only returns the other open task. No tasks are stolen
    # from other sessions until all open tasks are answered.
    default_questions = controller.get_questions()
    assert len(default_questions) == 1
    # Receiving answers from the default session doesn't affect other sessions
    questions = controller.get_questions(session_id="session_a")
    assert len(questions) == 2
    questions = controller.get_questions(session_id="session_b")
    assert len(questions) == 2
    questions = controller.get_questions(session_id="session_c")
    assert len(questions) == 1

    # And stores only the first item (ignoring duplicates)
    assert isinstance(controller.db, Database)
    assert controller.db.count_dataset(dataset) == 1


@pytest.mark.parametrize("feed_overlap", [True, False])
def test_controller_session_counts(
    recipe_config: Dict[str, Any], database: Database, feed_overlap: bool
):
    def create_controller(dataset):
        examples = [set_hashes({"text": f"{i}"}) for i in range(100)]
        stream = Stream(source=ListSource(examples), loader=load_noop, wrappers=[])
        cfg = {
            **recipe_config["config"],
            "batch_size": 10,
            "feed_overlap": feed_overlap,
            "auto_exclude_current": False,
            "total_examples_target": 100,
        }
        ctrl_params = {
            **recipe_config,
            "progress": TargetTotalProgressEstimator(),
            "dataset": dataset,
            "stream": stream,
            "config": cfg,
        }
        ctrl = Controller(**ctrl_params)
        return ctrl

    dataset = "_session_counts"
    sessions = [f"{dataset}-{session}" for session in ("one", "two", "three")]

    # First annotation run
    ctrl = create_controller(dataset=dataset)
    assert not ctrl.get_progress()
    q1 = ctrl.get_questions(sessions[0])
    q2 = ctrl.get_questions(sessions[1])
    q3 = ctrl.get_questions(sessions[2])
    ctrl.receive_answers([q for q in q1], sessions[0])
    ctrl.receive_answers([q for q in q2][:2], sessions[1])
    assert ctrl.session_annotated_by_session[sessions[0]] == 10
    assert ctrl.get_total_by_session(sessions[0]) == 10
    assert ctrl.session_annotated_by_session[sessions[1]] == 2
    assert ctrl.get_total_by_session(sessions[1]) == 2
    assert ctrl.session_annotated_by_session[sessions[2]] == 0
    assert ctrl.get_total_by_session(sessions[2]) == 0
    assert ctrl.total_annotated == 12
    assert ctrl.session_annotated == 12
    if feed_overlap:
        assert ctrl.get_progress() is None
        assert ctrl.get_progress(sessions[0]) == 0.1
        assert ctrl.get_progress(sessions[1]) == 0.02
        assert ctrl.get_progress(sessions[2]) == 0.0
    else:
        assert ctrl.get_progress() == 0.12
        assert ctrl.get_progress(sessions[0]) == 0.12
        assert ctrl.get_progress(sessions[1]) == 0.12
        assert ctrl.get_progress(sessions[2]) == 0.12

    # This controller is gone. Mimic a restart of Prodigy
    del ctrl

    # Second annotation run
    ctrl2 = create_controller(dataset=dataset)
    assert ctrl2.get_total_by_session(sessions[0]) == 10
    assert ctrl2.get_total_by_session(sessions[1]) == 2
    assert ctrl2.get_total_by_session(sessions[2]) == 0
    assert ctrl2.session_annotated_by_session == {}
    q1 = ctrl2.get_questions(sessions[0])
    ctrl2.receive_answers([q for q in q1][:5], sessions[0])
    q3 = ctrl2.get_questions(sessions[2])
    ctrl2.receive_answers([q for q in q3], sessions[2])
    assert ctrl2.session_annotated_by_session[sessions[0]] == 5
    assert ctrl2.get_total_by_session(sessions[0]) == 15
    assert ctrl2.session_annotated_by_session[sessions[1]] == 0
    assert ctrl2.get_total_by_session(sessions[1]) == 2
    assert ctrl2.session_annotated_by_session[sessions[2]] == 10
    assert ctrl2.get_total_by_session(sessions[2]) == 10
    assert ctrl2.total_annotated == 27
    assert ctrl2.session_annotated == 15
    if feed_overlap:
        assert ctrl2.get_progress() is None
        assert ctrl2.get_progress(sessions[0]) == 0.15
        assert ctrl2.get_progress(sessions[1]) == 0.02
        assert ctrl2.get_progress(sessions[2]) == 0.1
    else:
        assert ctrl2.get_progress() == 0.27


def test_controller_progress_and_update(recipe_config: Dict[str, Any]):
    count = 0
    stream = stream_list([set_hashes({"text": f"{i}"}) for i in range(100)])

    def get_progress(ctrl, update_return_value=None):
        nonlocal count
        assert isinstance(ctrl, Controller)
        count += 2
        if update_return_value:
            return update_return_value
        return count

    def update(answers):
        return 0.123

    config = {
        **recipe_config,
        "progress": get_progress,
        "update": update,
        "stream": stream,
    }
    controller = Controller(**config)
    qs = controller.get_questions()
    controller.receive_answers([qs[0]])
    assert controller.progress == 0.123
    controller.receive_answers([qs[1]])
    assert controller.progress == 0.123


@pytest.mark.skip(
    "Vincent -> calling progress twice should increase the progress? This seems to test the implementation rather than the behavior."
)
def test_controller_progress_original(recipe_config: Dict[str, Any]):
    """Test that the new progress function (v1.10) is called correctly."""
    count = 0

    def get_progress(ctrl, update_return_value=None):
        nonlocal count
        assert isinstance(ctrl, Controller)
        count += 1
        if update_return_value:
            return update_return_value
        return count

    def update(answers):
        return 123

    config = {**recipe_config, "update": update, "progress": get_progress}
    controller = Controller(**config)
    assert controller.progress == 1
    assert controller.progress == 2
    controller.receive_answers([])
    assert controller.progress == 123
    assert controller.progress == 123
    assert count > 1


def test_controller_no_dataset(
    stream: Stream[TaskType, TaskType], recipe_config: Dict[str, Any]
):
    updated = False

    def update(answers):
        nonlocal updated
        updated = True

    sessions = [f"{dataset}-{session}" for session in ("one", "two")]
    config = {**recipe_config, "stream": stream, "dataset": False, "update": update}
    ctrl = Controller(**config)
    assert ctrl.total_annotated == 0
    assert ctrl.session_annotated == 0
    assert ctrl.progress is None
    q1 = ctrl.get_questions(sessions[0])
    q2 = ctrl.get_questions(sessions[1])
    ctrl.receive_answers([q for q in q1], sessions[0])
    ctrl.receive_answers([q for q in q2[:2]], sessions[1])
    assert ctrl.total_annotated == 12
    assert ctrl.session_annotated == 12
    assert ctrl.progress is None
    assert updated


def test_correct_session_id_set(
    stream: Stream[TaskType, TaskType], recipe_config: Dict[str, Any]
):
    recipe_config["config"]["feed_overlap"] = True
    recipe_config["config"]["batch_size"] = 1
    ctrl = Controller(**{**recipe_config, "stream": stream})
    assert isinstance(ctrl.dataset, str)
    assert isinstance(ctrl.db, Database)
    sessions = [f"{ctrl.dataset}-{session}" for session in ("one", "two")]
    assert ctrl.total_annotated == 0
    assert ctrl.session_annotated == 0
    q1 = ctrl.get_questions(sessions[0])
    q2 = ctrl.get_questions(sessions[1])
    assert len(q1) == len(q2) == 1
    ctrl.receive_answers([q for q in q1], sessions[0], f"{sessions[0]}-annotator")
    ctrl.receive_answers([q for q in q2], sessions[1], f"{sessions[1]}-annotator")
    saved_answers = ctrl.db.get_dataset_examples(ctrl.dataset)
    assert len(saved_answers) == 2
    a1, a2 = saved_answers
    assert a1["_session_id"] == sessions[0]
    assert a2["_session_id"] == sessions[1]
    assert a1["_annotator_id"] == f"{sessions[0]}-annotator"
    assert a2["_annotator_id"] == f"{sessions[1]}-annotator"


# TODO Vincent -> check with Matt if this is really the behavior we want
@pytest.mark.skip("Vincent -> Need to check with Matt if we want to support this.")
def test_default_session_answers_feed_questions(
    stream: Stream[TaskType, TaskType], recipe_config: Dict[str, Any]
):
    ctrl_params = {
        **recipe_config,
        "stream": stream,
        "config": {
            "feed_overlap": False,
            "batch_size": 1,
        },
    }
    ctrl = Controller(**ctrl_params)
    assert ctrl.session_id is not None
    questions = ctrl.get_questions()
    ctrl.receive_answers([q for q in questions])
    # This confirms the test wants to have a session around
    assert len(ctrl.session_annotated_by_session) == 1
    # But ... somehow we don't want the session to appear?
    assert ctrl.session_id not in ctrl.session_annotated_by_session
    # Looking at `feed.py` it seems the original behavior is to
    # allow for a `None`-session to be tracked by the counters
    # in `receive_answers`. That feels a bit inconsistent with
    # how we try to fill in a default
    assert ctrl.session_annotated == 1


@pytest.mark.parametrize("progress", [None, False, 0])
@pytest.mark.skip("Vincent -> Need to check with Matt if we want to support this.")
def test_progress_false_or_none(
    stream: Stream[TaskType, TaskType], recipe_config: Dict[str, Any], progress: Any
):
    recipe_config["config"]["feed_overlap"] = False
    recipe_config["config"]["batch_size"] = 1
    recipe_config["progress"] = lambda *args, **kwargs: progress
    ctrl = Controller(**{**recipe_config, "stream": stream})
    assert ctrl.session_id is not None
    questions = ctrl.get_questions()
    ctrl.receive_answers([q for q in questions])

    # Why would None/False cause the progress to be 1?
    # The signature is pretty clear that this should always be a float
    if progress is None or progress is False:
        assert ctrl.progress == 1
    elif progress == 0:
        assert ctrl.progress == 0


def test_stream_history_size_updated_on_overlap(
    recipe_config: Dict[str, Any], datasets_path: Path
):
    # Stream size is set to -1 by default
    stream = recipe_config["stream"]
    assert stream.max_history_size == -1

    # If feed_overlap is True, stream size is set to source size
    ctrl_params = {
        **recipe_config,
        "config": {"feed_overlap": True},
    }
    ctrl = Controller(**ctrl_params)
    assert ctrl.stream.max_history_size == stream.source_size

    # If stream has a source without a len (e.g. GeneratorSource)
    # use the `history_size` Config
    data = srsly.read_jsonl(datasets_path / "input_2000.jsonl")
    gen_stream = get_stream(data, rehash=True)
    assert gen_stream.max_history_size == -1
    assert gen_stream.source_size is None

    new_ctrl_params = {
        **ctrl_params,
        "stream": gen_stream,
        "config": {"feed_overlap": True, "history_size": 10},
    }
    ctrl = Controller(**new_ctrl_params)
    assert ctrl.stream.max_history_size == 10

    # Now that the max_history_size is overriden, overlap requests work up to
    # the max history size
    q1 = ctrl.get_questions("s1")
    q2 = ctrl.get_questions("s2")
    assert q1 == q2


#################################################################################
# NOTE: The following tests should fail for the new Controller.
# They aim to test the old Controller/Feed behavior
# and show any other obvious errors


# KNOWN ISSUES

# [x] 1. `get_stream` returns a `Stream` object with no history by default.
# [x] 2. Controller can't configure history size right now
# 1 and 2 means overlap doesn't work with unless `Stream` object is constructured manually with history
# NOTE: 1 and 2 solved by adding `history_size` to Controller config and set_max_history_size to Stream
#
# 3. Controller by default doesn't exclude previously saved examples in its dataset
# 4. Controller can't just exclude its dataset, needs to exclude by session for overlap
# 5. No default progress implementation
#
#################################################################################


## PROGRESS TESTS


def test_default_progress_sized_source(recipe_config: Dict[str, Any]):
    """
    With a source that has some len (e.g. ListSource, DatasetSource, etc)
    progress should have a default implementation that is simply
    (how many examples are saved in the dataset?) / (how many examples in stream?)

    For other sources where we have an estimate instead of an exact position this number
    will be an estimate but should be something along the lines of

    ctrl.stream.source_position / ctrl.stream.source_size.
    """
    stream: Stream[TaskType, TaskType] = recipe_config["stream"]
    dataset: str = recipe_config["dataset"]

    assert stream.source_size is not None
    assert stream.source_size == len(stream._source)

    # initial progress should be 0, not None since we know what the
    # source size is and that we haven't done any annotating yet
    ctrl_params = {
        **recipe_config,
        "progress": SourceProgressEstimator(),
    }
    ctrl = Controller(**ctrl_params)
    assert ctrl.get_progress() == 0.008

    questions = ctrl.get_questions("s1")
    assert len(questions) == ctrl.batch_size
    assert ctrl.get_progress() == 0.077

    ctrl.receive_answers(questions)
    assert ctrl.db.count_dataset(dataset) == ctrl.batch_size
    assert ctrl.get_progress() == round(ctrl.batch_size / stream.source_size, 3)


def test_default_progress_jsonl_file_source(
    recipe_config: Dict[str, Any], datasets_path: Path
):
    """For other sources without an exact size (i.e. a FileSource)
    we have an estimate instead of an exact position of where we are in the file.

    e.g. approximately
    ctrl.stream.source_position / ctrl.stream.source_size.
    """
    stream = get_stream(datasets_path / "input_2000.jsonl", rehash=True)
    ctrl_params = {
        **recipe_config,
        "progress": SourceProgressEstimator(),
        "stream": stream,
    }
    ctrl = Controller(**ctrl_params)
    assert ctrl.get_progress() == 0.001

    questions = ctrl.get_questions("s1")
    assert len(questions) == ctrl.batch_size
    assert ctrl.get_progress() == 0.005

    ctrl.receive_answers(questions, "s1")
    assert ctrl.get_progress() == 0.005

    for _ in range(100):
        questions = ctrl.get_questions("s1")
        ctrl.receive_answers(questions, "s1")

    progress = ctrl.get_progress()
    assert progress is not None
    assert progress > 0.005


##


@pytest.mark.parametrize("batch_size", [1, 2, 5, 10])
def test_remember_and_skip_prev_annotations(
    datasets_path: Path, recipe_config: Dict[str, Any], batch_size: int
):
    def create_controller():
        stream = get_stream(datasets_path / "input_2000.jsonl", rehash=True)
        config = {
            **recipe_config,
            "stream": stream,
            "config": {"batch_size": batch_size},
        }
        ctrl = Controller(**config)
        return ctrl

    # Start normally
    ctrl = create_controller()
    assert ctrl.dataset is not False
    assert ctrl.dataset is not None

    # Get and answer a batch of questions
    q1 = ctrl.get_questions("vincent")
    ctrl.receive_answers([q for q in q1], "vincent", "vincent")

    saved_answers = ctrl.db.get_dataset_examples(ctrl.dataset)
    assert len(saved_answers) == len(q1)
    assert ctrl._sessions["vincent"].total_annotated == batch_size
    assert ctrl.get_total_by_session("vincent") == batch_size
    assert ctrl.get_total_by_session("kevin") == 0
    assert ctrl.session_annotated_by_session["vincent"] == batch_size

    # Prodigy will now shut down
    del ctrl

    # Start again, maybe the next day?
    ctrl = create_controller()
    q2 = ctrl.get_questions("vincent")

    # Vincent should not see the same questions
    q1_keys = _get_hashes(q1)
    q2_keys = _get_hashes(q2)
    assert q1_keys != q2_keys
    assert ctrl.dataset is not False
    assert ctrl.dataset is not None

    # Data needs to be stored in database
    ctrl.receive_answers([q for q in q2], "vincent", "vincent")
    saved_answers = ctrl.db.get_dataset_examples(ctrl.dataset)

    # Check session stats
    assert len(saved_answers) == len(q1) + len(q2)
    assert ctrl._sessions["vincent"].total_annotated == batch_size * 2
    assert ctrl.get_total_by_session("vincent") == batch_size * 2
    assert ctrl.get_total_by_session("kevin") == 0
    assert ctrl.session_annotated_by_session["vincent"] == batch_size

    # Prodigy will shut down again
    del ctrl

    # Start again, maybe the next day?
    ctrl = create_controller()
    assert ctrl.dataset is not False
    assert ctrl.dataset is not None

    # A newly created session should not see the same questions
    # as the annotators from yesterday, this should fast-forward the stream
    q3 = ctrl.get_questions("some-new-annotator")
    q3_keys = _get_hashes(q3)
    # If we didn't fast forward the stream for this new annotator
    # they would get the first batch of questions again. Assert this
    # does not happen
    assert q1_keys != q3_keys

    q4 = ctrl.get_questions("vincent")
    q4_keys = _get_hashes(q4)

    # Vincent should also not see the same questions
    # as yesterday or as any of the other sessions
    assert q4_keys != q1_keys
    assert q4_keys != q2_keys
    assert q4_keys != q3_keys

    # Data needs to be stored in database
    ctrl.receive_answers([q for q in q3], "vincent", "vincent")
    saved_answers = ctrl.db.get_dataset_examples(ctrl.dataset)

    # Check session stats
    assert len(saved_answers) == len(q1) + len(q2) + len(q3)
    assert ctrl._sessions["vincent"].total_annotated == batch_size * 3
    assert ctrl.get_total_by_session("vincent") == batch_size * 3
    assert ctrl.get_total_by_session("kevin") == 0
    assert ctrl.session_annotated_by_session["vincent"] == batch_size


@pytest.mark.parametrize("batch_size", [1, 2, 5, 10])
def test_remember_and_skip_prev_annotations_overlap(
    datasets_path: Path, recipe_config: Dict[str, Any], batch_size: int
):
    def create_controller():
        stream = get_stream(datasets_path / "input_2000.jsonl", rehash=True)
        config = {
            **recipe_config,
            "stream": stream,
            "config": {"feed_overlap": True, "batch_size": batch_size},
        }
        ctrl = Controller(**config)
        return ctrl

    # Start normally
    ctrl = create_controller()
    assert ctrl.dataset is not False
    assert ctrl.dataset is not None
    q1 = ctrl.get_questions("vincent")
    q2 = ctrl.get_questions("kabir")

    q1_keys = _get_hashes(q1)
    q2_keys = _get_hashes(q2)
    assert q1_keys == q2_keys
    ctrl.receive_answers([q for q in q1], "vincent", "vincent")

    del ctrl

    # Start again, maybe the next day?
    ctrl = create_controller()
    q1_new = ctrl.get_questions("vincent")
    q2_new = ctrl.get_questions("kabir")

    q1_new_keys = _get_hashes(q1_new)
    q2_new_keys = _get_hashes(q2_new)
    assert q1_new_keys != q1_keys
    assert q2_new_keys == q2_keys


## Extended annotation flow tests ##
# The following tests aim to simluate the Prodigy front end behavior
# including single and multi-annotator workflows, overlap and non overlap.
# Based on old Feed tests


@pytest.mark.parametrize("exclude_by", ["task", "input"])
@pytest.mark.parametrize("batch_size", [2, 5, 10])
def test_extended_annotation_flow_single_annotator(
    recipe_config: Dict[str, Any],
    exclude_by: str,
    batch_size: int,
):
    """Simulate a single annotator annotating a full source continuously.
    Tests that the annotator receives each example exactly once."""
    ctrl_params = {
        **recipe_config,
        "config": {
            "batch_size": batch_size,
            "feed_overlap": False,
            "exclude_by": exclude_by,
        },
    }
    ctrl = Controller(**ctrl_params)

    queue = []
    answers = []
    outbox = []

    queue += ctrl.get_questions()

    i = 0
    while len(queue) > 0:
        q = queue.pop(0)
        i += 1
        answer = {**q, "answer": "accept", "label": "TEST_LABEL"}
        outbox.append(answer)
        if len(outbox) >= ctrl.batch_size:
            answers += outbox
            outbox = []
            ctrl.receive_answers(answers)
            answers = []
        if len(queue) < 2 or len(queue) < (ctrl.batch_size / 2):
            excludes = _get_hashes(queue) + _get_hashes(outbox)
            if q:
                excludes.append(q[TASK_HASH_ATTR])
            queue += ctrl.get_questions(excludes=excludes)

    assert i == ctrl.stream.source_size


def _refresh(
    ctrl: Controller,
    session_id: Optional[str] = None,
    excludes: Optional[List[int]] = None,
):
    """Simulate a browser refresh by closing the session before getting another batch"""
    return ctrl.get_questions(session_id, excludes)


def _tasks_equal(
    tasks1: List[TaskType],
    tasks2: List[TaskType],
    exclude_props: List[str] = [SESSION_ID_ATTR],
) -> bool:
    def delete_prop(tasks: List[TaskType]):
        tasks = copy.deepcopy(tasks)
        for t in tasks:
            for prop in exclude_props:
                if prop in t:
                    del t[prop]
        return tasks

    return delete_prop(tasks1) == delete_prop(tasks2)


@pytest.mark.parametrize("exclude_by", ["task", "input"])
@pytest.mark.parametrize("session_ids_k", [7, 15])
def test_extended_annotation_flow_multiple_annotators_no_overlap(
    recipe_config: Dict[str, Any],
    exclude_by: str,
    session_ids_k: int,
):
    """Simulate a multiple annotator, non-overlapping workflow,
    annotating a full source continuously.
    Tests that each example is seen at least once. Some examples
    will be annotated more than once
    session_ids_k (int): We have 4 session_ids that can be chosen, this
        param creates a random oversampling of these 4 session ids to simulate
        some annotators doing more work than others
    """
    random.seed(0)

    ctrl_params = {
        **recipe_config,
        "config": {
            "feed_overlap": False,
            "exclude_by": exclude_by,
        },
    }
    ctrl = Controller(**ctrl_params)

    queues = defaultdict(list)
    outboxes = defaultdict(list)
    answers = []
    allowed_session_ids = [None, "one", "two", "three"]
    session_ids = random.choices(allowed_session_ids, k=session_ids_k)
    for session_id in allowed_session_ids:
        if session_id not in session_ids:
            session_ids.append(session_id)

    history = []
    history_map = {}
    for session_id in allowed_session_ids:
        queues[session_id] += ctrl.get_questions(session_id)

    # Ensure the first batches are all different for each session
    assert (
        len(queues[None])
        == len(queues["one"])
        == len(queues["two"])
        == len(queues["three"])
        == ctrl.batch_size
    )
    assert (
        _get_hashes(queues[None], INPUT_HASH_ATTR)
        != _get_hashes(queues["one"], INPUT_HASH_ATTR)
        != _get_hashes(queues["two"], INPUT_HASH_ATTR)
        != _get_hashes(queues["three"], INPUT_HASH_ATTR)
    )

    i = 0
    while not ctrl.stream.is_empty:
        i += 1
        session_id = random.choice(session_ids)
        if i > 50 and i % 3 == 0:
            # Tests periodic browser refresh after we have some
            # saved examples
            answers = outboxes[session_id]
            outboxes[session_id] = []
            ctrl.receive_answers(answers, session_id)
            queues[session_id] = _refresh(ctrl, session_id)
        if len(queues[session_id]) > 0:
            q = queues[session_id].pop(0)
            history.append(q)
            history_map[q[INPUT_HASH_ATTR]] = q
            answer = {**q, "answer": "accept", "label": "TEST_LABEL"}
            outboxes[session_id].append(answer)
            if len(outboxes[session_id]) >= ctrl.batch_size:
                answers = outboxes[session_id]
                outboxes[session_id] = []
                ctrl.receive_answers(answers, session_id)
            if len(queues[session_id]) < 2 or len(queues[session_id]) < (
                ctrl.batch_size / 2
            ):
                excludes = _get_hashes(outboxes[session_id]) + _get_hashes(
                    queues[session_id]
                )
                if q:
                    excludes.append(q[TASK_HASH_ATTR])
                batch = ctrl.get_questions(session_id, excludes=excludes)
                queues[session_id] += batch

    # Assert there are no duplicates in the
    # questions that have been seen so far
    assert len(history) == len(_get_hashes(history))

    # There are still tasks pending in the queues after the feed is empty.
    # Make sure these are answered.
    for session_id, queue in queues.items():
        for task in queue:
            history.append(task)
            outboxes[session_id].append(task)
            if len(outboxes[session_id]) >= ctrl.batch_size:
                answers = outboxes[session_id]
                outboxes[session_id] = []
                ctrl.receive_answers(answers, session_id)

    for session_id, outbox in outboxes.items():
        answers = [{**q, "answer": "accept", "label": "TEST_LABEL"} for q in outbox]
        ctrl.receive_answers(answers, session_id)

    # Get any final examples left in the Feed table that were cancelled.
    final_session_id = random.choice(session_ids)
    queue = ctrl.get_questions(final_session_id)
    while len(queue) > 0:
        history += queue
        answers = [{**q, "answer": "accept", "label": "TEST_LABEL"} for q in queue]
        ctrl.receive_answers(answers, final_session_id)
        queue = ctrl.get_questions(final_session_id)

    assert len(history) == pytest.approx(ctrl.stream.source_size, abs=10)


@pytest.mark.parametrize("exclude_by", ["task", "input"])
@pytest.mark.parametrize("session_ids_k", [7, 15])
def test_extended_annotation_flow_multiple_annotators_overlap(
    recipe_config: Dict[str, Any],
    exclude_by: str,
    session_ids_k: int,
):
    """Simulate a multiple annotator, non-overlapping workflow,
    annotating a full source continuously.
    Tests that each example is seen at least once. Some examples
    will be annotated more than once"""

    ctrl_params = {
        **recipe_config,
        "config": {
            "feed_overlap": True,
            "exclude_by": exclude_by,
        },
    }
    ctrl = Controller(**ctrl_params)

    queues = defaultdict(list)
    outboxes = defaultdict(list)
    answers = []
    history = defaultdict(list)
    session_ids = ["one", "two", "three"]
    for session_id in session_ids:
        if session_id not in queues:
            queues[session_id] += ctrl.get_questions(session_id)

    assert _tasks_equal(queues["one"], queues["two"])
    assert _tasks_equal(queues["two"], queues["three"])
    sessions = ctrl.get_sessions()
    session_ids_sample = random.choices(session_ids, k=session_ids_k)
    for session_id in session_ids:
        if session_id not in session_ids_sample:
            session_ids_sample.append(session_id)

    while not any([session.stream.is_empty for session in sessions]):
        session_id = random.choice(session_ids_sample)
        if len(queues[session_id]) > 0:
            q = queues[session_id].pop(0)
            history[session_id].append(q)
            answer = {**q, "answer": "accept", "label": "TEST_LABEL"}
            outboxes[session_id].append(answer)
            if len(outboxes[session_id]) >= ctrl.batch_size:
                answers += outboxes[session_id]
                outboxes[session_id] = []
                ctrl.receive_answers(answers, session_id)
                answers = []
            if len(queues[session_id]) < 2 or len(queues[session_id]) < (
                ctrl.batch_size / 2
            ):
                excludes = _get_hashes(outboxes[session_id]) + _get_hashes(
                    queues[session_id]
                )
                if q:
                    excludes.append(q[TASK_HASH_ATTR])
                queues[session_id] += ctrl.get_questions(session_id, excludes=excludes)

    assert all(
        [session.session_annotated != ctrl.stream.source_size for session in sessions]
    )
    slowest_n = min([len(session_history) for _, session_history in history.items()])
    assert _tasks_equal(history["one"][:slowest_n], history["two"][:slowest_n])
    assert _tasks_equal(history["one"][:slowest_n], history["three"][:slowest_n])


def test_custom_task_router(dataset, recipe_config):
    def router(ctrl: Controller, session_id, item):
        annot = []
        if int(item["text"]) % 2:
            annot.append("user1")
        else:
            annot.append("user2")
        annot = [ctrl.get_session_name(n) for n in annot]
        for sess_id in annot:
            ctrl.confirm_session(sess_id)
        return annot

    ctrl_params = {
        **recipe_config,
        "task_router": router,
        "config": {"feed_overlap": False},
    }
    ctrl = Controller(**ctrl_params)

    tasks1 = ctrl.get_questions(session_id=ctrl.get_session_name("user1"))
    tasks2 = ctrl.get_questions(session_id=ctrl.get_session_name("user2"))
    assert all([int(t["text"]) % 2 == 1 for t in tasks1])
    assert all([int(t["text"]) % 2 == 0 for t in tasks2])


def test_router_error_msg_unensured_session(recipe_config):
    def router(ctrl: Controller, session_id, item):
        annot = []
        if int(item["text"]) % 2:
            annot.append("user1")
        else:
            annot.append("user2")
        annot = [ctrl.get_session_name(n) for n in annot]
        # This is similar to the previous test, but we're no longer
        # ensuring the session!
        # for sess_id in annot:
        #     ctrl.confirm_session(sess_id)
        return annot

    ctrl_params = {
        **recipe_config,
        "task_router": router,
        "config": {"feed_overlap": False},
    }
    ctrl = Controller(**ctrl_params)

    with pytest.raises(SystemExit):
        ctrl.get_questions(session_id=ctrl.get_session_name("user1"))


@pytest.mark.parametrize("users", ["a,b,c", "a,b,c,d"])
def test_allowed_sessions_set(recipe_config, users):
    with env_var_override(ENV_VARS.ALLOWED_SESSIONS, users):
        ctrl = Controller(**recipe_config)
        assert len(ctrl.session_ids) == len(users.split(","))


@pytest.mark.parametrize("history_size", [2, 5, 9])
def test_session_length_may_differ_from_global_setting(
    datasets_path, recipe_config, history_size
):
    # Create custom stream with specific history
    input_file = datasets_path / "input_130.jsonl"
    stream_examples = list(srsly.read_jsonl(input_file))
    stream_examples = cast(List[TaskType], stream_examples)
    s = Stream[TaskType, TaskType](
        source=ListSource(stream_examples),
        loader=load_noop,
        wrappers=[],
        history=[QueueItem(i, i, set_hashes({"text": f"1000{i}"})) for i in range(10)],
    )
    s.apply(lambda data: map(set_hashes, data))
    recipe_config["stream"] = s

    # Init controller with said stream, create sessions.
    ctrl = Controller(**recipe_config)
    ctrl.confirm_session("user_a")
    sess = Session("user_b", stream=ctrl.stream, batch_size=10)
    ctrl.add_session(session=sess, n_history=history_size)

    assert ctrl.stream._queues["user_a"].qsize() == 10
    assert ctrl.stream._queues["user_b"].qsize() == history_size


def test_controller_components_dict_recipe_components_in_sync():
    """The RecipeComponents Pydantic model is used to actually validate components
    returned by recipes and passed to `Controller.from_components`.
    ControllerCompomentsDict is used for static type checking in the Controller class.
    """
    controller_component_keys = ControllerComponentsDict.__required_keys__.union(
        ControllerComponentsDict.__optional_keys__
    )
    assert sorted(controller_component_keys) == sorted(RecipeComponents.__fields__)


def test_controller_from_components_custom_routing(recipe_config: Dict[str, Any]):
    def custom_router(ctrl: Controller, session_id: str, item: Dict):
        annot = []
        if int(item["text"]) % 2:
            annot.append("user1")
        else:
            annot.append("user2")
        annot = [ctrl.get_session_name(n) for n in annot]
        for sess_id in annot:
            ctrl.confirm_session(sess_id)
        return annot

    def custom_session_factory(ctrl: Controller, session_id: str):
        return Session("user1", stream=ctrl.stream, batch_size=10)

    components = {
        **recipe_config,
        "task_router": custom_router,
        "session_factory": custom_session_factory,
    }

    controller1 = Controller.from_components("test", components)
    controller2 = Controller(**components)
    assert controller1.task_router == controller2.task_router
    assert controller1.session_factory == controller2.session_factory


def test_controller_can_handle_structured_stream_e2e(recipe_config):
    # Create custom stream with specific history
    stream = (set_hashes({"text": f"text {i}"}) for i in range(100))
    structured_stream = ensure_structured_stream(stream, parse_as=TextcatExample)

    s = Stream(
        source=GeneratorSource(structured_stream),
        loader=load_noop,
        wrappers=[],
    )
    recipe_config["stream"] = s

    # Init controller with said stream, create sessions.
    ctrl = Controller(**recipe_config)
    sess = Session("user_a", stream=ctrl.stream, batch_size=10)
    ctrl.add_session(session=sess, n_history=10)

    # Confirm that `ensure_structured_stream` gives back examples
    assert len(ctrl.get_questions("user_a")) == 10


@pytest.mark.parametrize("feed_overlap", [True, False], ids=["overlap", "no_overlap"])
def test_session_factory_history_hashes(
    recipe_config: Dict[str, Any], database: Database, dataset: str, feed_overlap: bool
):
    ctrl_params = {
        **recipe_config,
        "db": database,
        "dataset": dataset,
        "config": {"feed_overlap": feed_overlap},
    }
    ctrl = Controller(**ctrl_params)
    sid1 = ctrl.get_session_name("user1")
    sid2 = ctrl.get_session_name("user2")
    sid3 = ctrl.get_session_name("user3")
    answers = [set_hashes({**eg, "answer": "accept"}) for eg in examples]
    answer_hashes = {eg[TASK_HASH_ATTR] for eg in answers}

    # Simulate previously added answers for a single session
    ctrl._db_add_examples(answers, session_id=sid1)

    # Refresh controller to load answers
    ctrl = Controller(**ctrl_params)

    s1 = ctrl.confirm_session(sid1)
    s2 = ctrl.confirm_session(sid2)
    s3 = ctrl.confirm_session(sid3)

    # The first session has excluded hashes
    assert s1._answered_task_hashes == answer_hashes
    if feed_overlap is True:
        # If feed_overlap is True, the other sessions should not exclude
        # the hashes from the first session
        assert s2._answered_task_hashes == set()
        assert s3._answered_task_hashes == set()
    else:
        # If feed_overlap is False, each task should only be answered once
        # and the other sessions should also exclude the hashes answered by
        # the first session
        assert s2._answered_task_hashes == answer_hashes
        assert s3._answered_task_hashes == answer_hashes

    # Only the first session should have the total_annotated of len(answers)
    assert s1.total_annotated == len(answers)
    assert s2.total_annotated == 0
    assert s3.total_annotated == 0

    # Controller total_annotated_by_session should mirror session totals
    assert ctrl.total_annotated_by_session[s1.id] == len(answers)
    assert ctrl.total_annotated_by_session[s2.id] == 0
    assert ctrl.total_annotated_by_session[s3.id] == 0

    # Total annotated for the controller is total
    # of all sessions in this no overlap case
    assert ctrl.total_annotated == len(answers)


@pytest.mark.parametrize("prepend_old_wrappers", [True, False])
def test_reset_stream(
    recipe_config: Dict[str, Any],
    database: Database,
    dataset: str,
    prepend_old_wrappers: bool,
):
    ctrl_params = {
        **recipe_config,
        "db": database,
        "dataset": dataset,
        "config": {"feed_overlap": True},
    }
    ctrl = Controller(**ctrl_params)

    # This represents the wrapper that we may want to keep
    def add_key(examples, key):
        for ex in examples:
            ex[key] = True
            yield ex

    ctrl.stream.apply(add_key, key="key_on_old_stream")

    sid1 = ctrl.get_session_name("user1")
    sid2 = ctrl.get_session_name("user2")
    sid3 = ctrl.get_session_name("user3")
    s1 = ctrl.confirm_session(sid1)
    s2 = ctrl.confirm_session(sid2)
    s3 = ctrl.confirm_session(sid3)

    new_examples = [{"text": f"this is example {i}"} for i in range(20)]
    new_stream = Stream.from_iterable(new_examples)

    def add_hashes(stream):
        for ex in stream:
            yield set_hashes(ex)

    # We want to confirm that these keys _never_ get lost.
    new_stream.apply(add_hashes)
    new_stream.apply(add_key, key="key_on_new_stream")
    ctrl.reset_stream(new_stream, prepend_old_wrappers=prepend_old_wrappers)

    for sess in [s1, s2, s3]:
        questions = ctrl.get_questions(sess.id)
        for question_ex, orig_ex in zip(questions, new_examples):
            # The fact that these keys are around prooves that wrappers are applied properly.
            assert ("key_on_old_stream" in question_ex) == prepend_old_wrappers
            assert "key_on_new_stream" in question_ex
            assert orig_ex["text"] == question_ex["text"]
            assert "_input_hash" in question_ex
            assert "_task_hash" in question_ex


def test_session_factory_history_hashes_anns_per_task(
    recipe_config: Dict[str, Any], database: Database, dataset: str
):
    ctrl_params = {
        **recipe_config,
        "db": database,
        "dataset": dataset,
        "config": {"annotations_per_task": 3},
    }
    ctrl = Controller(**ctrl_params)
    sid1 = ctrl.get_session_name("user1")
    sid2 = ctrl.get_session_name("user2")
    sid3 = ctrl.get_session_name("user3")
    sid4 = ctrl.get_session_name("user4")
    answers = [set_hashes({**eg, "answer": "accept"}) for eg in examples]
    answer_hashes = {eg[TASK_HASH_ATTR] for eg in answers}

    # Simulate previously added answers for a single session
    ctrl._db_add_examples(answers, session_id=sid1)

    # Refresh controller to load answers
    ctrl = Controller(**ctrl_params)

    s1 = ctrl.confirm_session(sid1)
    s2 = ctrl.confirm_session(sid2)
    s3 = ctrl.confirm_session(sid3)
    s4 = ctrl.confirm_session(sid4)

    # Adding answers for 1 session doesn't exclude them from any other sessions
    # since these examples have not been annotated 3 times yet
    assert s1._answered_task_hashes == answer_hashes
    assert s2._answered_task_hashes == set()
    assert s3._answered_task_hashes == set()
    assert s4._answered_task_hashes == set()

    # Only the first session should have the total_annotated of len(answers)
    assert s1.total_annotated == len(answers)
    assert s2.total_annotated == 0
    assert s3.total_annotated == 0
    assert s4.total_annotated == 0

    ctrl._db_add_examples(answers, session_id=sid2)
    ctrl._db_add_examples(answers, session_id=sid3)

    # Refresh Controller so sessions can be recreated via session_factory
    ctrl2 = Controller(**ctrl_params)
    s1 = ctrl2.confirm_session(sid1)
    s2 = ctrl2.confirm_session(sid2)
    s3 = ctrl2.confirm_session(sid3)
    s4 = ctrl2.confirm_session(sid4)

    # Adding answers for 2 other sessions means we have our target
    # number of annotations per task. So now these get excluded from
    # sessions 1-3 since those are the sessions that actually annotated these
    # answers.
    assert s1._answered_task_hashes == answer_hashes
    assert s2._answered_task_hashes == answer_hashes
    assert s3._answered_task_hashes == answer_hashes

    # Session 4 also has these tasks excluded though since we've met the
    # target of 3 annotations per task.
    assert s4._answered_task_hashes == answer_hashes

    # Controller total_annotated_by_session should mirror session totals
    assert ctrl2.total_annotated_by_session[s1.id] == len(answers)
    assert ctrl2.total_annotated_by_session[s2.id] == len(answers)
    assert ctrl2.total_annotated_by_session[s3.id] == len(answers)
    assert ctrl2.total_annotated_by_session[s4.id] == 0


def test_session_factory_history_hashes_anns_per_task_pct(
    recipe_config: Dict[str, Any], database: Database, dataset: str
):
    ctrl_params = {
        **recipe_config,
        "db": database,
        "dataset": dataset,
        "config": {"annotations_per_task": 2.5},
    }
    ctrl = Controller(**ctrl_params)
    sid1 = ctrl.get_session_name("user1")
    sid2 = ctrl.get_session_name("user2")
    sid3 = ctrl.get_session_name("user3")
    sid4 = ctrl.get_session_name("user4")
    answers = [set_hashes({**eg, "answer": "accept"}) for eg in examples]
    answer_hashes = {eg[TASK_HASH_ATTR] for eg in answers}

    # Simulate previously added answers for a single session
    ctrl._db_add_examples(answers, session_id=sid1)

    # Refresh controller to load answers
    ctrl = Controller(**ctrl_params)

    s1 = ctrl.confirm_session(sid1)
    s2 = ctrl.confirm_session(sid2)
    s3 = ctrl.confirm_session(sid3)
    s4 = ctrl.confirm_session(sid4)

    # Adding answers for 1 session doesn't exclude them from any other sessions
    # since these examples have not been annotated the configured 1.5 times yet
    assert s1._answered_task_hashes == answer_hashes
    assert s2._answered_task_hashes == set()
    assert s3._answered_task_hashes == set()
    assert s4._answered_task_hashes == set()

    # Only the first session should have the total_annotated of len(answers)
    assert s1.total_annotated == len(answers)
    assert s2.total_annotated == 0
    assert s3.total_annotated == 0
    assert s4.total_annotated == 0

    ctrl._db_add_examples(answers, session_id=sid2)

    # Refresh Controller so sessions can be recreated via session_factory
    ctrl2 = Controller(**ctrl_params)
    s1 = ctrl2.confirm_session(sid1)
    s2 = ctrl2.confirm_session(sid2)
    s3 = ctrl2.confirm_session(sid3)
    s4 = ctrl2.confirm_session(sid4)

    # Adding answers for session number 2 means that we DONT have our target
    # number of annotations per task yet. While these do get excluded from
    # sessions 1-2 they won't be excluded from 3-4.
    assert s1._answered_task_hashes == answer_hashes
    assert s2._answered_task_hashes == answer_hashes
    assert s3._answered_task_hashes == set()
    assert s4._answered_task_hashes == set()

    # Controller total_annotated_by_session should mirror session totals
    assert ctrl2.total_annotated_by_session[s1.id] == len(answers)
    assert ctrl2.total_annotated_by_session[s2.id] == len(answers)
    assert ctrl2.total_annotated_by_session[s3.id] == 0
    assert ctrl2.total_annotated_by_session[s4.id] == 0

    # Add examples one more time. For session 3.
    ctrl._db_add_examples(answers, session_id=sid3)

    # Refresh Controller so sessions can be recreated via session_factory
    ctrl3 = Controller(**ctrl_params)
    s1 = ctrl3.confirm_session(sid1)
    s2 = ctrl3.confirm_session(sid2)
    s3 = ctrl3.confirm_session(sid3)
    s4 = ctrl3.confirm_session(sid4)

    # We now have 3 sessions per item, which exceeds the 2.5 average.
    # So now all of these hashes should be excluded.
    assert s1._answered_task_hashes == answer_hashes
    assert s2._answered_task_hashes == answer_hashes
    assert s3._answered_task_hashes == answer_hashes
    assert s4._answered_task_hashes == answer_hashes

    # Controller total_annotated_by_session should mirror session totals
    assert ctrl3.total_annotated_by_session[s1.id] == len(answers)
    assert ctrl3.total_annotated_by_session[s2.id] == len(answers)
    assert ctrl3.total_annotated_by_session[s3.id] == len(answers)
    assert ctrl3.total_annotated_by_session[s4.id] == 0

    # We can also add new sessions, which should also see the same behavior
    for user_num in [5, 6, 7, 8, 9]:
        sess_name = ctrl.get_session_name(f"user{user_num}")
        sess_obj = ctrl3.confirm_session(sess_name)
        assert sess_obj._answered_task_hashes == answer_hashes
        assert ctrl3.total_annotated_by_session[sess_obj.id] == 0


def test_controller_missing_event_hooks(recipe_config: Dict[str, Any]):
    controller = Controller(**recipe_config)
    assert controller.recipe_event_hooks == {}
    with pytest.raises(KeyError):
        controller.call_event("hello", {})


def test_controller_event_hook(recipe_config: Dict[str, Any]):
    def hook1(ctrl, arg1: str) -> Tuple[str, str]:
        return ("called hook1", arg1)

    def hook2(ctrl, arg1: str) -> Tuple[str, str]:
        return ("called hook2", arg1)

    recipe_config["recipe_event_hooks"] = {"h1": hook1, "h2": hook2}
    controller = Controller(**recipe_config)
    assert controller.recipe_event_hooks == {"h1": hook1, "h2": hook2}
    assert controller.call_event("h1", {"arg1": "hi"}) == ("called hook1", "hi")
    assert controller.call_event("h1", {"arg1": "bye"}) == ("called hook1", "bye")
    assert controller.call_event("h2", {"arg1": "yo"}) == ("called hook2", "yo")
