from pathlib import Path
from typing import Callable, List

import numpy as np
import pytest
import spacy
import srsly
from spacy.lang.en import English
from spacy.language import Language

from prodigy import ControllerComponentsDict
from prodigy.components.routers import full_overlap
from prodigy.components.source import GeneratorSource, Source
from prodigy.components.stream import get_stream
from prodigy.core import Controller, _session_factory
from prodigy.recipes.audio import manual as audio_manual
from prodigy.recipes.audio import transcribe as audio_transcribe
from prodigy.recipes.compare import compare
from prodigy.recipes.coref import manual as coref_manual
from prodigy.recipes.dep import correct as dep_correct
from prodigy.recipes.dep import teach as dep_teach
from prodigy.recipes.generic import mark, match
from prodigy.recipes.image import image_manual
from prodigy.recipes.llm import (
    llm_correct_ner,
    llm_correct_spans,
    llm_correct_textcat,
)
from prodigy.recipes.ner import ab_evaluate as ner_ab
from prodigy.recipes.ner import correct as ner_correct
from prodigy.recipes.ner import manual as ner_manual
from prodigy.recipes.ner import teach as ner_teach
from prodigy.recipes.pos import correct as pos_correct
from prodigy.recipes.pos import teach as pos_teach
from prodigy.recipes.rel import manual as rel_manual
from prodigy.recipes.sent import correct as sent_correct
from prodigy.recipes.sent import teach as sent_teach
from prodigy.recipes.spans import correct as spans_correct
from prodigy.recipes.spans import manual as spans_manual
from prodigy.recipes.terms import teach as terms_teach
from prodigy.recipes.textcat import correct as textcat_correct
from prodigy.recipes.textcat import manual as textcat_manual
from prodigy.recipes.textcat import teach as textcat_teach
from prodigy.structured_types import TextcatExample
from prodigy.util import set_hashes

from .util import make_tempdir

# Some of these tests require a trained model that's not provided by
# a pretrained spaCy model. The `scripts/train-models-for-testing.sh`
# file will take care of training those.
movie_data_path = str(Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl")
image_data_path = str(Path(__file__).parent / "sample_datasets" / "tumblr_images.jsonl")
audio_data_path = str(Path(__file__).parent / "recordings")
patterns_path = str(Path(__file__).parent / "sample_datasets" / "ner_patterns.txt")
tmp_dataset_name = "tmp-dataset-test"


spacy_llm_ner_cfg_path = str(
    Path(__file__).parent / "config-files" / "spacy-llm" / "spacy-llm-ner.cfg"
)
spacy_llm_textcat_cfg_path = str(
    Path(__file__).parent / "config-files" / "spacy-llm" / "spacy-llm-textcat.cfg"
)
spacy_llm_spancat_cfg_path = str(
    Path(__file__).parent / "config-files" / "spacy-llm" / "spacy-llm-spancat.cfg"
)


@Language.component("textcat_mocker")
def mocker(doc):
    # This component mocks spancat
    doc.cats = {"foo": 0.9}
    return doc


# Construct an `nlp` pipeline with a mocked textcat and spancat in there.
nlp = spacy.load("en_core_web_md")
ruler = nlp.add_pipe("span_ruler")
patterns = [{"label": "GANGSTER", "pattern": "swindler"}]
ruler.add_patterns(patterns)
nlp.add_pipe("textcat_mocker")

# Also create a small one, needed for `ner.ab-eval` recipe
nlp_sm = spacy.load("en_core_web_sm")

# Create senter pipeline from blank model
nlp_senter = spacy.blank("en")
nlp_senter.add_pipe("senter")
nlp_senter.initialize()


def image_manual_base_settings():
    components = image_manual(
        tmp_dataset_name, image_data_path, label=["cat"], loader="jsonl"
    )
    return Controller.from_components("image.manual", components)


def audio_manual_base_settings():
    components = audio_manual(tmp_dataset_name, audio_data_path, label=["cat"])
    return Controller.from_components("audio.manual", components)


def audio_transcribe_base_settings():
    components = audio_transcribe(tmp_dataset_name, audio_data_path)
    return Controller.from_components("audio.transcribe", components)


def terms_teach_base_settings():
    # The terms recipe is very slow because it needs to shuffle through the
    # entire vocab, which is extremely time consuming. We also don't really
    # need it for these tests, so we build a custom `nlp` object with a very
    # small vocab with some random vectors instead. Shaves off about 20s of
    # test time this way.
    nlp = English()
    np.random.get_state(42)
    for string in "abcdefhijklmnopqrstuvwxyz":
        nlp.vocab.set_vector(string, np.random.random(300))
    components = terms_teach(tmp_dataset_name, nlp=nlp, seeds="cat")
    return Controller.from_components("terms.teach", components)


def textcat_manual_base_settings():
    components = textcat_manual(tmp_dataset_name, movie_data_path, label=["pos", "neg"])
    return Controller.from_components("textcat.manual", components)


def textcat_teach_base_settings():
    components = textcat_teach(
        tmp_dataset_name, nlp, movie_data_path, label=["pos", "neg"]
    )
    return Controller.from_components("textcat.teach", components)


def textcat_correct_base_settings():
    components = textcat_correct(
        tmp_dataset_name,
        nlp,
        movie_data_path,
        label=["pos", "neg"],
        component="textcat_mocker",
    )
    return Controller.from_components("textcat.correct", components)


def ner_manual_base_settings():
    components = ner_manual(
        tmp_dataset_name, spacy.blank("en"), movie_data_path, label=["movie-title"]
    )
    return Controller.from_components("ner.manual", components)


def ner_correct_base_settings():
    components = ner_correct(tmp_dataset_name, nlp, movie_data_path)
    return Controller.from_components("ner.correct", components)


def ner_teach_base_settings():
    components = ner_teach(tmp_dataset_name, nlp, movie_data_path)
    return Controller.from_components("ner.teach", components)


def ner_ab_base_settings():
    components = ner_ab(tmp_dataset_name, nlp, nlp_sm, movie_data_path)
    return Controller.from_components("ner.eval-ab", components)


def pos_correct_base_settings():
    components = pos_correct(tmp_dataset_name, nlp, movie_data_path)
    return Controller.from_components("pos.correct", components)


def pos_teach_base_settings():
    components = pos_teach(tmp_dataset_name, nlp, movie_data_path)
    return Controller.from_components("pos.teach", components)


def sent_correct_base_settings():
    components = sent_correct(tmp_dataset_name, nlp, movie_data_path)
    return Controller.from_components("sent.correct", components)


def sent_teach_base_settings():
    components = sent_teach(tmp_dataset_name, nlp_senter, movie_data_path)
    return Controller.from_components("sent.teach", components)


def dep_correct_base_settings():
    components = dep_correct(tmp_dataset_name, nlp, movie_data_path)
    return Controller.from_components("dep.correct", components)


def dep_teach_base_settings():
    components = dep_teach(tmp_dataset_name, nlp, movie_data_path)
    return Controller.from_components("dep.teach", components)


def spans_manual_base_settings():
    components = spans_manual(
        tmp_dataset_name, spacy.blank("en"), movie_data_path, label=["GANGSTER"]
    )
    return Controller.from_components("spans.manual", components)


def spans_correct_base_settings():
    components = spans_correct(
        tmp_dataset_name,
        nlp,
        movie_data_path,
        label=["GANGSTER"],
        component="span_ruler",
    )
    return Controller.from_components("spans.correct", components)


def coref_manual_base_settings():
    components = coref_manual(tmp_dataset_name, nlp, movie_data_path)
    return Controller.from_components("coref.manual", components)


def rel_manual_base_settings():
    components = rel_manual(
        tmp_dataset_name,
        spacy.blank("en"),
        movie_data_path,
        label=["COREF", "OBJECT"],
        span_label=["PERSON"],
    )
    return Controller.from_components("rel.manual", components)


def mark_base_settings():
    components = mark(
        tmp_dataset_name,
        movie_data_path,
        label=["pos", "neg"],
        view_id="classification",
    )
    return Controller.from_components("mark", components)


def match_base_settings():
    components = match(
        tmp_dataset_name,
        nlp,
        movie_data_path,
        patterns=patterns_path,
        label=["GANGSTER"],
    )
    return Controller.from_components("match", components)


def compare_base_settings():
    path_a = str(Path(__file__).parent / "sample_datasets" / "compare_dataset_a.jsonl")
    path_b = str(Path(__file__).parent / "sample_datasets" / "compare_dataset_b.jsonl")
    components = compare(
        tmp_dataset_name,
        path_a,
        path_b,
    )
    return Controller.from_components("compare", components)


def custom_recipe():
    components = {
        "dataset": tmp_dataset_name,
        "view_id": "classification",
        "stream": get_stream(movie_data_path, rehash=True),
        "task_router": full_overlap,
        "session_factory": _session_factory,
    }
    return Controller.from_components("custom-recipe", components)


def llm_ner_recipe():
    components = llm_correct_ner(
        tmp_dataset_name,
        spacy_llm_ner_cfg_path,
        source=movie_data_path,
    )
    return Controller.from_components("ner.llm.correct", components)


def llm_textcat_recipe():
    components = llm_correct_textcat(
        tmp_dataset_name,
        spacy_llm_textcat_cfg_path,
        source=movie_data_path,
    )
    return Controller.from_components("textcat.llm.correct", components)


def llm_spans_recipe():
    components = llm_correct_spans(
        tmp_dataset_name,
        spacy_llm_spancat_cfg_path,
        source=movie_data_path,
    )
    return Controller.from_components("spans.llm.correct", components)


def custom_structured_recipe():
    data = [set_hashes(eg) for eg in srsly.read_jsonl(movie_data_path)]
    with make_tempdir() as tmpdir:
        srsly.write_jsonl(tmpdir / "movie_data.jsonl", data)
    stream = get_stream(
        data, rehash=True, structured=True, structured_class=TextcatExample
    )
    components = {
        "dataset": tmp_dataset_name,
        "view_id": "classification",
        "stream": stream,
        "task_router": full_overlap,
        "session_factory": _session_factory,
    }
    return Controller.from_components("custom-recipe", components)


# A few recipes aren't tested here because they don't provide an
# annotation interface or they depend on state in the database. These include:
# review, train, train-curve, data-to-spacy, terms.to-patterns,  print-stream, print-dataset,
# db-out, db-merge, db-in, drop, stats, progress
all_controllers = {
    "ner.llm.correct": llm_ner_recipe,
    "textcat.llm.correct": llm_textcat_recipe,
    "spans.llm.correct": llm_spans_recipe,
    "terms.teach": terms_teach_base_settings,
    "ner.manual": ner_manual_base_settings,
    "ner.correct": ner_correct_base_settings,
    "ner.teach": ner_teach_base_settings,
    "ner.ab-eval": ner_ab_base_settings,
    "spans.manual": spans_manual_base_settings,
    "spans.correct": spans_correct_base_settings,
    "textcat.manual": textcat_manual_base_settings,
    "textcat.teach": textcat_teach_base_settings,
    "textcat.correct": textcat_correct_base_settings,
    "pos.correct": pos_correct_base_settings,
    "pos.teach": pos_teach_base_settings,
    "sent.correct": sent_correct_base_settings,
    "sent.teach": sent_teach_base_settings,
    "dep.correct": dep_correct_base_settings,
    "dep.teach": dep_teach_base_settings,
    "coref.manual": coref_manual_base_settings,
    "rel.manual": rel_manual_base_settings,
    "image.manual": image_manual_base_settings,
    "audio.manual": audio_manual_base_settings,
    "audio.transcribe": audio_transcribe_base_settings,
    "mark": mark_base_settings,
    "match": match_base_settings,
    "compare": compare_base_settings,
    "custom_recipe": custom_recipe,
    "custom_structured_recipe": custom_structured_recipe,
}


@pytest.mark.parametrize(
    "controller", all_controllers.values(), ids=all_controllers.keys()
)
def test_base_settings_no_warning_on_batch(controller, capsys):
    ctrl: Controller = controller()
    # Make sure we can grab examples
    assert ctrl.get_questions(session_id="a")

    # Test that the hashing error message does not appear
    out, err = capsys.readouterr()
    assert "⚠" not in out

    # Confirm that we're dealing with a new Source
    assert isinstance(controller().stream._source, Source)

    # Make sure that the stream isn't the GeneratorSource, because
    # that way we'd not have any of the benefits that we'd like.
    # Some recipes are ignored here.
    # - ner.ab-eval combines two streams internally via a generator
    # - compare combines two files interally via `srsly.load_jsonl`, feels like an old recipe
    if ctrl.config["recipe_name"] not in ["ner.eval-ab", "compare"]:
        assert not isinstance(controller().stream._source, GeneratorSource)

    # Cleanup
    ctrl.db.drop_dataset(tmp_dataset_name)


@pytest.mark.parametrize(
    "recipe, valid_config_path, invalid_config_paths",
    [
        (
            llm_correct_ner,
            spacy_llm_ner_cfg_path,
            [spacy_llm_spancat_cfg_path, spacy_llm_textcat_cfg_path],
        ),
        (
            llm_correct_spans,
            spacy_llm_spancat_cfg_path,
            [spacy_llm_ner_cfg_path, spacy_llm_textcat_cfg_path],
        ),
        (
            llm_correct_textcat,
            spacy_llm_textcat_cfg_path,
            [spacy_llm_ner_cfg_path, spacy_llm_spancat_cfg_path],
        ),
    ],
    ids=["ner.llm.correct", "spans.llm.correct", "textcat.llm.correct"],
)
def test_llm_recipes_invalid_tasks(
    recipe: Callable[..., ControllerComponentsDict],
    valid_config_path: Path,
    invalid_config_paths: List[Path],
):
    components = recipe(
        tmp_dataset_name,
        valid_config_path,
        source=movie_data_path,
    )

    valid_ctrl = Controller.from_components("ner.llm.correct", components)
    assert isinstance(valid_ctrl, Controller)

    for invalid_path in invalid_config_paths:
        with pytest.raises(SystemExit):
            recipe(
                tmp_dataset_name,
                invalid_path,
                source=movie_data_path,
            )
