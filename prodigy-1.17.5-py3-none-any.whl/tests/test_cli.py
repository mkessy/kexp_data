import json
import sys
import unittest.mock
from typing import List

import pytest
import srsly
import uvicorn

import prodigy.recipes  # noqa: F401
from prodigy.__main__ import FILE, main
from prodigy.cli import generate_cli_components, get_cli, run_recipe
from prodigy.core import Controller
from prodigy.util import registry

from .util import make_tempdir

SERVER_START_TEXT = "Starting the web server"
ALL_RECIPES = registry.recipes.get_all()


def run(args: List[str]) -> None:
    # We use sys.argv and the main function here to really simulate the prodigy
    # command being called internally (which constructs the command and starts
    # the server if needed – it doesn't just run cli.run)
    sys.argv = ["prodigy", *args]
    main()


@pytest.fixture(scope="function")
def server():
    # Mock the server so we can assert whether it's called
    patcher = unittest.mock.patch("uvicorn.run")
    patcher.start()
    return uvicorn.run


@pytest.mark.parametrize("command", list(ALL_RECIPES.values()))
def test_cli_annotations(command):
    """Test that all commands provide docstrings and argument help texts."""
    assert command.description, f"no docstring for {command.display_name}"
    for arg in command.args:
        if arg.id == "_extra":
            continue
        assert arg.arg.help, f"no help text for {command.display_name} -> {arg.id}"


def test_cli_no_server(capsys, server):
    """Tests that commands that don't start the server work."""
    run(["stats"])
    captured = capsys.readouterr()
    assert "Stats" in captured.out
    server.assert_not_called()


def test_cli_help_text(capsys, server):
    with pytest.raises(SystemExit):
        run(["--help"])
    captured = capsys.readouterr()
    assert "Available commands" in captured.out
    server.assert_not_called()


def test_cli_server_ner_manual(capsys, server):
    dataset = "test_cli_server_ner_manual"
    stream = [{"text": "hello"}, {"text": "world"}]
    with make_tempdir() as d:
        source = d / "source.jsonl"
        srsly.write_jsonl(source, stream)
        args = ["ner.manual", dataset, "blank:en", str(source), "--label", "A,B"]
        run(args)
    captured = capsys.readouterr()
    assert "Using 2 label(s): A, B" in captured.out
    assert SERVER_START_TEXT in captured.out
    server.assert_called_once()


def test_cli_server_ner_manual_bad(capsys, server):
    dataset = "test_cli_server_ner_manual"
    stream = [{"text": "hello"}, {"text": "world"}]
    with make_tempdir() as d:
        source = d / "source.jsonl"
        srsly.write_jsonl(source, stream)
        args = ["ner.manual", dataset, "blank:en", str(source)]
        with pytest.raises(SystemExit):
            run(args)
    captured = capsys.readouterr()
    assert "No --label argument" in captured.out
    assert SERVER_START_TEXT not in captured.out
    server.assert_not_called()


@pytest.mark.parametrize("recipe", list(ALL_RECIPES.keys()))
def test_cli_server_ner_manual_help_text(recipe, capsys, server):
    with pytest.raises(SystemExit):
        run([recipe, "--help"])
    captured = capsys.readouterr()
    assert f"usage: prodigy {recipe}" in captured.out
    server.assert_not_called()


@pytest.mark.skip(reason="Not using static CLI at the moment, see __main__.py")
def test_cli_static_up_to_date():
    """Test that the static JSON matches the current live CLI."""
    cli = get_cli()
    err = "static CLI doesn't match live CLI, re-run generate_static_cli.py"
    with FILE.open("r", encoding="utf8") as f:
        existing = f.read()
    current = json.dumps(cli.to_static_json())
    assert existing == current, err


def test_run_recipe(dataset, datasets_path):
    path = str(datasets_path / "nyt_text.jsonl")
    # Bit of a smoke test, but this should just be able to return a controller
    run_recipe(
        [
            "prodigy",
            "textcat.manual",
            dataset,
            path,
            "--label",
            "foo",
        ]
    )


class MockContextManager:
    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


def test_run_recipe_with_controller(monkeypatch):

    mock_get_recipe = unittest.mock.Mock()
    mock_controller = unittest.mock.Mock(spec=Controller)
    mock_recipe_func = unittest.mock.Mock(return_value=mock_controller)
    mock_get_recipe.return_value.func = mock_recipe_func

    mock_cli = unittest.mock.MagicMock()
    mock_cli.handle_errors.return_value = MockContextManager()

    monkeypatch.setattr("prodigy.core.get_recipe", mock_get_recipe)
    monkeypatch.setattr("prodigy.cli.get_cli", mock_cli)
    monkeypatch.setattr("prodigy.core.is_server_recipe", lambda x: True)

    result = run_recipe(["prodigy", "some_recipe", "arg1", "arg2"])

    assert isinstance(result, Controller)
    assert result == mock_controller


@pytest.mark.thisone
def test_command_to_controller(dataset, datasets_path):
    # Mainly testing to confirm there are no issues when using `serve` in v1.14
    source_path = str(datasets_path / "nyt_text.jsonl")
    cmd = f"textcat.manual {dataset} {source_path} --label foo"
    ctrl, args = generate_cli_components(cmd)
    assert ctrl.dataset == dataset
