from pathlib import Path

import pytest

from prodigy.components.loaders import JSONL
from prodigy.components.preprocess import add_tokens
from prodigy.core import Controller
from prodigy.recipes.rel import NP_LABEL, manual
from prodigy.util import set_hashes


@pytest.fixture
def dataset():
    return "tmp-test-dataset"


@pytest.fixture
def text_stream():
    data_path = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    tasks = JSONL(data_path)
    return [set_hashes(task) for task in tasks]


@pytest.fixture
def annotated_text_stream(nlp):
    data_path = Path(__file__).parent / "sample_datasets" / "movies_sample.jsonl"
    tasks = JSONL(data_path)
    tasks = list(add_tokens(nlp, tasks))
    tasks[0]["spans"] = [
        {
            "text": "swindler",
            "start": 36,
            "token_start": 9,
            "token_end": 9,
            "end": 44,
            "label": "GANGSTER",
        }
    ]
    return [set_hashes(task) for task in tasks]


@pytest.fixture
def patterns_path():
    data_path = Path(__file__).parent / "sample_datasets" / "ner_patterns.txt"
    return data_path


# rel.manual #


def test_rel_manual_exits_with_missing_label(dataset, text_stream, nlp, nlp_blank):
    """Ensure that the rel.manual recipe exits without labels"""
    with pytest.raises(SystemExit):
        components = manual(dataset, nlp_blank, text_stream)
        Controller.from_components("rel.manual", components)

    with pytest.raises(SystemExit):
        components = manual(dataset, nlp, text_stream)
        Controller.from_components("rel.manual", components)


def test_rel_manual_custom_labels(dataset, text_stream, nlp_blank):
    """Ensure that the rel.manual recipe works with a blank model and custom labels"""
    LABEL = "MY_REL"
    components = manual(dataset, nlp_blank, text_stream, label=[LABEL])
    ctrl = Controller.from_components("rel.manual", components)
    assert ctrl.config["labels"] == [LABEL]
    queue = list(ctrl.stream)
    for eg in queue:
        assert "spans" in eg
        for span in eg["spans"]:
            assert span["label"] == NP_LABEL


def test_rel_manual_no_ents(dataset, text_stream, nlp):
    """Ensure that the rel.manual recipe works well"""
    LABEL = "MY_REL"
    components = manual(dataset, nlp, text_stream, label=[LABEL])
    ctrl = Controller.from_components("rel.manual", components)
    queue = list(ctrl.stream)
    for eg in queue:
        assert eg["spans"] == []


def test_rel_manual_with_np(dataset, text_stream, nlp):
    """Ensure that the rel.manual recipe can pre-annotate noun phrases"""
    LABEL = "MY_REL"
    components = manual(dataset, nlp, text_stream, label=[LABEL], add_nps=True)
    ctrl = Controller.from_components("rel.manual", components)
    queue = list(ctrl.stream)
    found = 0
    for eg in queue:
        for span in eg["spans"]:
            assert span["label"] == NP_LABEL
            found += 1
    assert found > 0


def test_rel_manual_with_ents(dataset, text_stream, nlp):
    """Ensure that the rel.manual recipe can pre-annotate named entities"""
    LABEL = "MY_REL"
    components = manual(dataset, nlp, text_stream, label=[LABEL], add_ents=True)
    ctrl = Controller.from_components("rel.manual", components)
    queue = list(ctrl.stream)
    found = 0
    for eg in queue:
        for span in eg["spans"]:
            assert span["label"] != NP_LABEL
            found += 1
    assert found > 0


def test_rel_manual_patterns(dataset, text_stream, nlp, patterns_path):
    """Ensure that the rel.manual recipe pre-annotates entities from the provided patterns"""
    LABEL = "MY_REL"
    components = manual(
        dataset, nlp, text_stream, patterns_path=patterns_path, label=[LABEL]
    )
    ctrl = Controller.from_components("rel.manual", components)
    queue = list(ctrl.stream)
    eg = queue[0]
    assert "illegally touting horses" in eg["text"]
    assert len(eg["spans"]) == 1
    assert eg["spans"][0]["text"] == "swindler"
    assert eg["spans"][0]["label"] == "GANGSTER"
    assert len(eg["tokens"]) == 79
    ctrl.db.drop_dataset(dataset)


def test_rel_manual_disable_patterns(
    dataset, annotated_text_stream, nlp, patterns_path
):
    """Ensure that the rel.manual recipe disables tokens from the provided patterns"""
    LABEL = "MY_REL"
    components = manual(
        dataset,
        nlp,
        annotated_text_stream,
        disable_patterns_path=patterns_path,
        label=[LABEL],
    )
    ctrl = Controller.from_components("rel.manual", components)
    queue = list(ctrl.stream)
    eg = queue[0]
    assert "illegally touting horses" in eg["text"]
    assert len(eg["spans"]) == 1
    assert eg["tokens"][9]["disabled"] is True
    ctrl.db.drop_dataset(dataset)
